## GCP setup
* [Dev environment topic](https://console.cloud.google.com/cloudpubsub/topic/detail/es_i9_portal_events_handler_dev?project=ews-es-i9-npe-00c4)
* [Dev environment subscription](https://console.cloud.google.com/cloudpubsub/subscription/detail/es_i9_portal_events_handler_dev?project=ews-es-i9-npe-00c4&pli=1)


## Running locally
Local tests can either use [pub-sub emulator](https://cloud.google.com/pubsub/docs/emulator) (part of Google cloud SDK) or Dev environment pub-sub (default for all profiles).
By default, no pub-sub is used and instead message is mocked. It is recommended to always run locally test with real pub-sub or at least pub-sub emulator.   
### Pub sub emulator
In order to install pub-sub emulator locally, follow [instructions here](https://cloud.google.com/pubsub/docs/emulator#installing_the_emulator). To facilitate running of pub-sub emulator locally compliant with test configuration, you can use _startPubsubEmulator.bat_
In order to send test messages to pub-sub emulator _emulator_ profile needs to be used as additional profile, e.g. by adding following VM option that activates _emulator_ in addition to _local_:
```
-Dspring.profiles.active=local,emulator
```
### Running with GCP pub-sub
Start with additional profile _realEnv_: 
```
-Dspring.profiles.active=local,realEnv
```

### Testing guidelines
1. To provide fine code coverage, end-to-end tests were added. Typical e2e test is 
    * annotated with ```@SpringBootTest``` 
    * involves usage ```MessagePublish``` for publishing a message (which triggers execution)
    * uses ```ServiceCalls``` for stubbing responses from other (REST) services and assertions on requests sent out by i9-portal-events-handler
1. Whenever making a change to a functionality please maintain end-to-end tests  
1. Prefer end-to-end tests over unit test
1. Running and debugging i9-portal-events-handler locally connects to dev services by default and consumes dev subscriptions potentially breaking tests. 
Use option of running POH locally sparingly.
1. To make sure POH instance run locally receives message produced by API and the message is not consumed by dev's POH instance, 
one can create a private, test subscription that will get a copy of the message. Do delete test subscription.

### Logging guidelines
1. log all calls to APIs and execution path branching (if-logic) with details determining message information: document id or packet id, message id, flow (e.g. tasks, billing, pdf generation etc.)
If information identifying record being processed (documentid, packet id, etc.) is available in reactive context, putting that information in message is not needed, 
in such case ```MdcReactorLogger``` should be used to wrap log calls and copy context data to logger e.g.:
    * informative log: ```.doOnEach(MdcReactorLogger.logOnNext(ignore -> log.info("Fetched section 2 for task")));```
    * error log: ```.doOnEach(MdcReactorLogger.logOnError(t -> log.error("Error while...")))```
1. If context includes efx-session-id, efx-transaction-id, documentId etc. avoid logs not wrapped with ```MdcReactorLogger``` e.g. 
    * ```.doOnSuccess(ignore -> log.info("Successfully billed for document {}.", i9Id)) // avoid if context is set with data``` this will NOT output context information if present
    * ``` log.info("the message") // avoid if context is set with data ``` this will NOT output context information either 
1. for relevant log information use levels: **info, warn** or **error**; anything below info is for development purposes only and shall not be regarded as information visible in test and production environments

