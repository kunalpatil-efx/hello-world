package com.efx.ews.es.i9datasourcing.fieldconverter;

import static java.util.Arrays.asList;
import static org.assertj.core.api.Assertions.assertThat;

import java.util.Map;
import org.apache.groovy.util.Maps;
import org.junit.jupiter.api.Test;

class MergingPreparerConverterTest {

    private static final String KEY_1 = "sectionOne.employeeInfo.firstName";
    private static final String KEY_2 = "sectionOne.employeeInfo.middleInitial";
    private final MergingPreparerConverter converter = new MergingPreparerConverter(asList(KEY_1, KEY_2), 0);

    @Test
    void shouldConvertWithoutAddingAdditionalSpace() {
        //GIVEN
        final var name = "Pedro";
        Map<String, String> mockedFlattenedI9Form = Maps.of(
            KEY_1, name,
            KEY_2, null);

        //EXECUTE
        var result = converter.convert(mockedFlattenedI9Form);

        //ASSERT
        assertThat(result).isEqualTo(name);
    }

    @Test
    void shouldConvertWithoutAddingAdditionalSpaceAtTheBeginning() {
        //GIVEN
        final var name = "Pedro";
        Map<String, String> mockedFlattenedI9Form = Maps.of(
            KEY_2, null,
            KEY_1, name);

        //EXECUTE
        var mergingPreparerConverter = new MergingPreparerConverter(asList(KEY_2, KEY_1), 0);
        var result = mergingPreparerConverter.convert(mockedFlattenedI9Form);

        //ASSERT
        assertThat(result).isEqualTo(name);
    }

    @Test
    void shouldConvertHappyPath() {
        //GIVEN
        Map<String, String> mockedFlattenedI9Form = Maps.of(
            KEY_1, "Pedro",
            KEY_2, "Bb");

        //EXECUTE
        var result = converter.convert(mockedFlattenedI9Form);

        //ASSERT
        assertThat(result).isEqualTo("Pedro Bb");
    }

    @Test
    void convertShouldReturnNullWhenAllInputIsNull() {
        //GIVEN
        Map<String, String> mockedFlattenedI9Form = Maps.of(
            KEY_1, null,
            KEY_2, null);

        //EXECUTE
        var result = converter.convert(mockedFlattenedI9Form);

        //ASSERT
        assertThat(result).isEmpty();
    }
}