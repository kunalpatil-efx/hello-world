package com.efx.ews.es.everifydatasourcing.fieldconverter;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.only;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.verify;

import com.efx.ews.es.everifydatasourcing.mock.MockData;
import com.efx.ews.es.everifydatasourcing.model.TestCase;
import com.efx.ews.es.i9datasourcing.flattener.I9FormHistoryFlattener;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class EVerifyConverterImplTest {

    private static final String TEST_NAME = "test-01";
    private EVerifyConverterImpl eVerifyConverter;

    private Map<String, String> flattenedEVerify;
    private TestCase testCase;
    private EVerifyFieldConverterConfigProviderImpl eVerifyFieldConverterConfigProviderImpl;

    @BeforeEach
    void setUp() {
        eVerifyFieldConverterConfigProviderImpl = spy(new EVerifyFieldConverterConfigProviderImpl());
        eVerifyConverter = new EVerifyConverterImpl(eVerifyFieldConverterConfigProviderImpl);

        testCase = TestCase.create(TEST_NAME);
        var flattener = new I9FormHistoryFlattener();
        flattenedEVerify = flattener.process(testCase.getEverifyCase());
    }

    @Test
    void itShouldConvertEVerifyForm() {
        //EXECUTE
        var changeContext = testCase.getChangeContext();
        var result = eVerifyConverter.convertForm(flattenedEVerify, changeContext);
        var expected = MockData.readExpectedConvertedEVerifyForm();

        //ASSERT
        assertThat(result).isEqualTo(expected);
        verify(eVerifyFieldConverterConfigProviderImpl, only()).provideConfig(changeContext);
    }
}