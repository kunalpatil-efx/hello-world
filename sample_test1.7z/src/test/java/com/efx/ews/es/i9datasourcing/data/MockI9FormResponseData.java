package com.efx.ews.es.i9datasourcing.data;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.*;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class MockI9FormResponseData {
    private final static byte[] imageBytes = UUID.randomUUID().toString().getBytes();

    public static I9FormResponse createFormData(Long recordVersion) {
        I9FormResponse i9Form = new I9FormResponse();
        i9Form.setEmployeeId("dd7d260c-4498-4f71-a430-4d7aea04cf4c");
        i9Form.setEmployeeFactId("5678");
        i9Form.setEmployerId("27733c9f-a64a-417e-9c47-659d16a4bf8a");
        i9Form.setEmployerLocationId("099");
        i9Form.setFormRevDate("0876");
        i9Form.setEverifyVersion("v30");
        i9Form.setSourceRefId("09-99-1994");
        i9Form.setSourceId("AQWSDERF1234");
        i9Form.setRecordVersion(recordVersion);
        i9Form.setStatus("new");
        i9Form.setProjectedStartDate("09-11-2019");
        i9Form.setDocumentApiDocumentId("584275475842");
        i9Form.setDocumentApiAuditId("137591039522");
        i9Form.setDocumentApiRevisionIds(new ArrayList<>(Collections.singleton("456741099215")));
        Task task = new Task();
        task.setTaskId(UUID.randomUUID().toString());
        return i9Form;
    }

    public static I9FormResponse createFormWithoutSections(Long recordVersion) {
        return createFormData(recordVersion);
    }

    public static I9FormResponse createFormWithAllSections(Long recordVersion) {
        I9FormResponse form = createFormData(recordVersion);
        SectionOne sectionOne = setSectionOneData();
        FormData formData = new FormData();
        formData.setSectionOne(sectionOne);
        formData.setSectionTwo(createSectionTwo());
        formData.setSectionThreeList(new ArrayList<>());
        formData.getSectionThreeList().add(getSectionThreeData());
        form.setFormData(formData);

        return form;
    }

    public static List<I9FormResponse> createFormList() {
        return new ArrayList<>(Arrays.asList(
                MockI9FormResponseData.createFormWithoutSections(0L),
                MockI9FormResponseData.createFormWithAllSections(1L),
                MockI9FormResponseData.createFormWithAllSections(2L),
                MockI9FormResponseData.createFormWithAllSections(3L)
        ));
    }

    public static SectionThree getSectionThreeData() {
        SectionThree sectionThree = new SectionThree();
        sectionThree.setFormRevDate(LocalDate.now().format(DateTimeFormatter.ISO_DATE));
        sectionThree.setIsNameChange(false);
        sectionThree.setIsRehire(false);
        sectionThree.setEmployerSignature(getSignature());
        sectionThree.setTimestamp(Long.valueOf(System.currentTimeMillis() / 1000).intValue());
        return sectionThree;
    }

    private static SectionOne setSectionOneData() {
        SectionOne sectionOne = new SectionOne();
        sectionOne.setEmployeeInfo(setEmployeeInfoData());
        sectionOne.setAttestation(setAttestationData());
        sectionOne.setSignature(getSignature());
        sectionOne.setDate("2019-11-21T11:24:55.000Z");
        return sectionOne;
    }

    private static EmployeeInfo setEmployeeInfoData() {
        EmployeeInfo employeeInfo = new EmployeeInfo();
        employeeInfo.setFirstName("Jack");
        employeeInfo.setLastName("Test");
        employeeInfo.setMiddleInitial("E");
        employeeInfo.setSocialSecurityNumber("888888888");
        employeeInfo.setZipCode("12345");
        employeeInfo.setCity("Krakow");
        employeeInfo.setAddress("Opolska 110");
        employeeInfo.setState("MO");
        employeeInfo.setDateOfBirth("1924-02-12");
        return employeeInfo;
    }

    private static Attestation setAttestationData() {
        Attestation attestation = new Attestation();
        LawfulPermanentResidentInfo lawfulPermanentResident = new LawfulPermanentResidentInfo();
        attestation.setIsAlienAuthorizedToWork(false);
        attestation.setIsLawfulPermanentResident(true);
        attestation.setIsNonCitizenNational(false);
        attestation.setIsUnitedStatesCitizen(false);
        lawfulPermanentResident.setAlienRegistrationNumber("1234567");
        attestation.setLawfulPermanentResidentInfo(lawfulPermanentResident);
        return attestation;
    }

    public static SectionTwo createSectionTwo() {
        SectionTwo sectionTwoOnly = new SectionTwo();
        return sectionTwoOnly;
    }

    static SignatureData getSignature() {
        SignatureData signature = new SignatureData();
        signature.setMethod(SignatureData.Method.IMAGE);
        signature.setDate("2020-04-06T08:37:31.861809");
        signature.setName("Jack Johnson");
        signature.setImageType(String.class.getName());
        signature.setImageData(imageBytes);
        return signature;
    }
}
