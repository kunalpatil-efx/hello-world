package com.efx.ews.es.i9datasourcing.fieldconverter;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;

import java.util.Map;
import org.apache.groovy.util.Maps;
import org.junit.jupiter.api.Test;

class MergingConverterTest {

    @Test
    void shouldConvertFieldsWithMergingConverter() {
        final String key1 = "sectionOne.employeeInfo.firstName";
        final String key2 = "sectionOne.employeeInfo.middleInitial";

        { // constructor parameters validation test
            assertThatExceptionOfType(IllegalArgumentException.class).isThrownBy(
                MergingConverter::new
            );

            assertThatExceptionOfType(IllegalArgumentException.class).isThrownBy(
                () -> new MergingConverter(key1)
            );

            assertThatCode(() -> new MergingConverter(key1, key2)).doesNotThrowAnyException();
        }

        { // only 1st of the keys is present
            final MergingConverter converter = new MergingConverter(key1, key2);
            Map<String, String> mockedFlattenedI9Form = Map.of(
                "sectionOne.employeeInfo.firstName", "Aaa",
                "irrelevant.key", "Bbb");

            String convertedValue = converter.convert(mockedFlattenedI9Form);

            assertThat(convertedValue).isEqualTo("Aaa");
        }
        { // only 2nd of the keys is present
            final MergingConverter converter = new MergingConverter(key1, key2);
            Map<String, String> mockedFlattenedI9Form = Map.of(
                "irrelevant.key", "Aaa",
                "sectionOne.employeeInfo.middleInitial", "Bbb");

            String convertedValue = converter.convert(mockedFlattenedI9Form);

            assertThat(convertedValue).isEqualTo("Bbb");
        }

        { // Happy Path - both keys are present
            final MergingConverter converter = new MergingConverter(key1, key2);
            Map<String, String> mockedFlattenedI9Form = Map.of(
                "sectionOne.employeeInfo.firstName", "Aaa",
                "sectionOne.employeeInfo.middleInitial", "Bbb");

            String convertedValue = converter.convert(mockedFlattenedI9Form);

            assertThat(convertedValue).isEqualTo("Aaa Bbb");
        }

        { // It returns null when every field is null
            final MergingConverter converter = new MergingConverter(key1, key2);
            Map<String, String> mockedFlattenedI9Form =
                Maps.of(
                    key1, null,
                    key2, null);

            var convertedValue = converter.convert(mockedFlattenedI9Form);

            assertThat(convertedValue).isEmpty();
        }

        { // It doesn't add additional blank space
            final MergingConverter converter = new MergingConverter(key1, key2);
            var firstName = "someName";
            Map<String, String> mockedFlattenedI9Form =
                Maps.of(
                    key1, firstName,
                    key2, null);

            var convertedValue = converter.convert(mockedFlattenedI9Form);

            assertThat(convertedValue).isEqualTo(firstName);
        }
    }
}