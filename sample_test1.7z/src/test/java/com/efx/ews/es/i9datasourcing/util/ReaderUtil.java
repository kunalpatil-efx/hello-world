package com.efx.ews.es.i9datasourcing.util;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Objects;
import java.util.stream.Stream;
import lombok.SneakyThrows;
import org.apache.commons.io.FilenameUtils;
import org.springframework.util.ResourceUtils;

public class ReaderUtil {

    private static final ObjectMapper MAPPER = new ObjectMapper()
        .registerModule(new JavaTimeModule())
        .disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
    public static final String I9_FORMS_PATH = "classpath:i9-integration-test/";
    public static final String E_VERIFY_FORMS_PATH = "classpath:everify-integration-test/";

    @SneakyThrows
    public static <T> T readFromFile(String testName, String filename, Class<T> clazz, String rootFolder) {
        return MAPPER.readValue(readStringFromFile(testName, filename, rootFolder), clazz);
    }

    @SneakyThrows
    public static <T> T readFromFile(String path, String fileName, Class<T> clazz) {
        var resourceLocation = FilenameUtils.concat(path, fileName);
        var file = ResourceUtils.getFile(resourceLocation);
        return MAPPER.readValue(file, clazz);
    }

    @SneakyThrows
    public static String readStringFromFile(String testName, String filename, String rootFolder) {
        var resourceLocation = FilenameUtils.concat(rootFolder + testName, filename);
        return new String(
            Files.readAllBytes(Path.of(ResourceUtils.getURL(resourceLocation).toURI())));
    }

    @SneakyThrows
    private static Stream<String> listCases(final String rootFolder) {
        File file = ResourceUtils.getFile(rootFolder);
        return Stream.of(Objects.requireNonNull(file.listFiles()))
            .map(File::getName);
    }

    public static Stream<String> listI9TestCases() {
        return listCases(I9_FORMS_PATH);
    }

    public static Stream<String> listEVerifyTestCases() {
        return listCases(E_VERIFY_FORMS_PATH);
    }
}