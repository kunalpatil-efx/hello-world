package com.efx.ews.es.i9integration.i9portaleventshandler;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.employer.person.EmployeeForFactId;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.Audit;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.I9Form;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.I9FormResponse;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.Task;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.UpdateMetadataRequest;
import com.efx.ews.es.i9integration.i9portaleventshandler.pubsub.ReactiveSubscriber;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.EmployerPersonCall;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.I9ApiCall;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.PacketPubSubPublisherService;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.TaskApiRemoteCallService;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.TaskApiProperties;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.TaskApiProperties.TaskType;
import com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageConfirmation;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.cloud.gcp.pubsub.support.AcknowledgeablePubsubMessage;
import reactor.core.publisher.Mono;

public class TaskSubscriberConfigTest {

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    private I9ApiCall i9ApiCall;
    private TaskApiRemoteCallService taskApiRemoteCallService;
    private PacketPubSubPublisherService publisherService;
    private ObjectProvider<MessageConfirmation> objectProvider;
    private TaskApiProperties taskApiProperties;
    private EmployerPersonCall employerPersonCall;
    private ReactiveSubscriber reactiveSubscriber;


    @BeforeEach
    public void setup() {
        i9ApiCall = mock(I9ApiCall.class);
        taskApiRemoteCallService = mock(TaskApiRemoteCallService.class);
        publisherService = mock(PacketPubSubPublisherService.class);
        objectProvider = mock(ObjectProvider.class);
        taskApiProperties = mock(TaskApiProperties.class);
        employerPersonCall = mock(EmployerPersonCall.class);
        reactiveSubscriber = mock(ReactiveSubscriber.class);
        OBJECT_MAPPER.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    @Test
    public void testReceiptUpdate_CloseTask() throws IOException {
        String docid = "0fL2CZBpDKxjwvxA2aue";
        when(objectProvider.getObject(any())).thenReturn(new MessageConfirmation());
        TasksSubscriberConfig tc = new TasksSubscriberConfig(i9ApiCall, taskApiRemoteCallService,publisherService,
            objectProvider,taskApiProperties,employerPersonCall,reactiveSubscriber);
        List<Task> tasks = new ArrayList<>();
        Task t1 = new Task();
        t1.setTaskId("1");
        t1.setTaskType("I9:ReceiptUpdate");
        t1.setTaskStatus("NEW");

        Task t2 = new Task();
        t2.setTaskId("2");
        t2.setTaskType("I9:Section2");
        t2.setTaskStatus("COMPLETED");
        tasks.add(t1); tasks.add(t2);
        when(i9ApiCall.getTasks(docid)).thenReturn(Mono.just(tasks));
        I9Form i9Form = OBJECT_MAPPER.readValue(
            IOUtils.toString(this.getClass().getResourceAsStream(
                "/i9-integration-test/receipt_update/0fL2CZBpDKxjwvxA2aue_version9.json"), Charset.defaultCharset()),
            new TypeReference<I9Form>() {
            });
        when(i9ApiCall.getFormByRevision(docid, "9")).thenReturn(Mono.just(i9Form));
        when(taskApiRemoteCallService.createReceiptUpdateTask(anyString(), any(I9Form.class))).thenReturn(Mono.just(t1));
        TaskType taskType = new TaskType(); taskType.setCode("I9:ReceiptUpdate");
        when(taskApiProperties.getReceiptUpdateSectionTwo()).thenReturn(taskType);
        Audit audit = new Audit();
        audit.setRecordRevision(9L); audit.setEventKey("Section2_Amended");
        when(i9ApiCall.getAudit(docid, 9L)).thenReturn(Mono.just(audit));

        EmployeeForFactId employeeFactId = new EmployeeForFactId();
        employeeFactId.setEmployeeId("6362064d-5549-45a3-8841-d584266d11fb");
        when(employerPersonCall.getEmployeeByFactId(anyString())).thenReturn(Mono.just(employeeFactId));

        I9FormResponse i9FormResponse = new I9FormResponse();
        when(i9ApiCall.patchMetadata(anyString(), any(UpdateMetadataRequest.class))).thenReturn(Mono.just(i9FormResponse));

        Task taskClosed = new Task();
        taskClosed.setTaskId("4");
        taskClosed.setTaskType("I9:ReceiptUpdate");
        taskClosed.setTaskStatus("COMPLETED");
        when(taskApiRemoteCallService.completeTask(docid, t1, null)).thenReturn(Mono.just(taskClosed));

        Map<String, String> attrs = Map.of("efx-session-id", "59cb1b39-a439-4ea9-86f0-830bd78f5b7f",
            "recordVersion", "9",
            "sourceRefId", "e6e58751-19a8-485e-9a64-055afde187f2",
            "employeeFactId", "456",
            "sourceId", "packet-ui",
            "documentId", docid,
            "status", "Section2_Amended",
            "efx-transaction-id", "fffe9efc-c395-4251-9b7e-f65d015830f5",
            "employeeId", "6362064d-5549-45a3-8841-d584266d11fb");
        String data = "{\"document\":{\"employerId\":\"a1020597-e66c-479b-aac4-c00e26fa9282\",\"recordVersion\":9,\"employerLocationId\":\"dc032101-bbb5-4e0a-aae8-3344589d096e\",\"sourceRefId\":\"e6e58751-19a8-485e-9a64-055afde187f2\",\"sourceId\":\"packet-ui\",\"formRevDate\":\"i9v102119\",\"employeeId\":\"6362064d-5549-45a3-8841-d584266d11fb\",\"employeeFactId\":\"c0230bc7-f6e7-4ed1-b38a-0c0ca932f7ee\",\"status\":\"Section2_Complete\",\"projectedStartDate\":\"2021-02-27\"},\"form\":{\"specialPlacement\":false,\"ssnApplied\":false,\"ssnRefused\":false,\"isMinor\":false},\"audit\":{\"date\":\"2021-02-15T18:27:26.625Z\",\"sourceKey\":\"aef4196a-a2d0-4958-adef-ad3e35ef7448\",\"source\":{\"encryptedData\":\"9jVC79p+VXNq+g9Z84J991qRMyGYH8BoJw7xm7Cru0NAthF7++I=\",\"keyStoreId\":\"E5uThQWPaanI8vHExNTN\",\"hmacValue\":\"tkKXLoByWnQ0KZkisVIKdWELUaWl9OMADWxe/mVvrCiS8LeEl3qi/v2Ah+JSGdaTJjCZqPX81yOlcQHtbz4Q+Q==\"},\"sourceIp\":{\"encryptedData\":\"MWpWg46Joeij6tZsml53qZtvUvUGlIcJxfv8bDDaHUfwusCS+6XQx2Tr+w==\",\"keyStoreId\":\"E5uThQWPaanI8vHExNTN\",\"hmacValue\":\"MUCkcn/qPcLPEeoKmFqrzlMgb9L1iEIM8azesdVQrru3OrE4gxCANRzyBTN4T1eRQgJ3vkR8ilWiAszibqeNnQ==\"},\"eventKey\":\"Section2_Amended\",\"eventDescription\":\"Section 2 Amended\",\"dataUpdate\":true,\"dataRevision\":9}}";
        AcknowledgeablePubsubMessage message = new MockAcknowledgeablePubsubMessage("123", attrs, data);
        tc.withTaskCreatedMessage(message).block();
        verify(i9ApiCall, times(1)).getTasks(docid);
        verify(i9ApiCall, times(1)).getFormByRevision(docid, "9");
        verify(taskApiRemoteCallService, times(1)).completeTask(docid, t1, null);
    }
}
