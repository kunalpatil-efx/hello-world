package com.efx.ews.es.i9integration.i9portaleventshandler;

import com.efx.ews.es.eev.barricade.common.model.BarricadeKeyStore;
import com.efx.ews.es.eev.barricade.common.service.CryptographyService;
import com.efx.ews.es.eev.barricade.common.service.PubSubEncryptionService;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.event.I9EventPayload;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.AuditDataFeed;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.DataBaseAuditDataFeedTest;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.TaskApiRemoteCallServiceImpl;
import com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageConfirmation;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.matching.RequestPatternBuilder;
import com.github.tomakehurst.wiremock.matching.StringValuePattern;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.messaging.Message;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import static com.efx.ews.es.i9integration.i9portaleventshandler.utils.WireMockTestFile.testFileContent;
import static com.github.tomakehurst.wiremock.client.WireMock.aMultipart;
import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.anyUrl;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.equalToJson;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.matching;
import static com.github.tomakehurst.wiremock.client.WireMock.ok;
import static com.github.tomakehurst.wiremock.client.WireMock.patch;
import static com.github.tomakehurst.wiremock.client.WireMock.patchRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.postRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathMatching;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.after;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@SpringBootTest
@Slf4j
class PdfGenerationTest {
    @Autowired
    private MessagePublish messagePublish;

    @Autowired
    private ServiceCalls serviceCalls;

    @MockBean
    @Qualifier("messageConfirmation")
    private MessageConfirmation messageConfirmation;
    @MockBean
    @Qualifier("messageConfirmationForFlow")
    private MessageConfirmation messageConfirmationForFlow;

    @MockBean
    private TaskApiRemoteCallServiceImpl taskApiRemoteCallService;

    @MockBean
    List<BarricadeKeyStore> barricadeKeyStores;
    @MockBean
    CryptographyService cryptographyService;
    @MockBean
    private PubSubEncryptionService pubSubEncryptionService;
    @MockBean
    private AuditDataFeed auditFeed;

    private final String documentId = LocalDateTime.now().format(DateTimeFormatter.ISO_DATE_TIME);
    private final String sourceRefId = UUID.randomUUID().toString();
    private final Long recordVersion = 5L;

    @BeforeEach
    public void setup() throws Exception {
        // here be proper url
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/forms/" + documentId + "/history")
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("getHistory.json")));
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/audits/" + documentId + "/ice")
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("i9IceResponse.json")));

        serviceCalls.documentApi.stubFor(
                get("/internal/eev/documents/v1/document/afa913ad-34d83696-sectionOne1SignatureRef/object")
                        .willReturn(aResponse().withBody(Base64.getDecoder().decode("EncodedSignature")))
        );
        serviceCalls.documentApi.stubFor(
                get("/internal/eev/documents/v1/document/afa913ad-c494d28f-preparer1SignatureRef/object")
                        .willReturn(aResponse().withBody(Base64.getDecoder().decode("EncodedSignature")))
        );
        serviceCalls.documentApi.stubFor(
                get("/internal/eev/documents/v1/document/afa913ad-26a5e947-preparer2SignatureRef/object")
                        .willReturn(aResponse().withBody(Base64.getDecoder().decode("EncodedSignature")))
        );
        serviceCalls.documentApi.stubFor(
                get("/internal/eev/documents/v1/document/afa913ad-e07e07f1-sectionTwoSignatureRef/object")
                        .willReturn(aResponse().withBody(Base64.getDecoder().decode("EncodedSignature")))
        );
        serviceCalls.documentApi.stubFor(
                get("/internal/eev/documents/v1/document/afa913ad-e07e07f1-sectionThree1SignatureRef/object")
                        .willReturn(aResponse().withBody(Base64.getDecoder().decode("EncodedSignature")))
        );
        serviceCalls.documentApi.stubFor(
                get("/internal/eev/documents/v1/document/afa913ad-e07e07f1-sectionThree2SignatureRef/object")
                        .willReturn(aResponse().withBody(Base64.getDecoder().decode("EncodedSignature")))
        );
        serviceCalls.documentApi.stubFor(
                get("/internal/eev/documents/v1/document/afa913ad-e07e07f1-sectionThree3SignatureRef/object")
                        .willReturn(aResponse().withBody(Base64.getDecoder().decode("EncodedSignature")))
        );
        final Map<String, StringValuePattern> documentUploadQueryParameters = Map.of(
            "documentType", equalTo("application/pdf"),
            "securityModel", equalTo("basic"),
            "retentionPolicy", equalTo("90"),
            "dataClassification", equalTo("3"),
            "ownerId", equalTo("I9-form-owner"),
            "ownerReferenceId", matching("([a-z0-9-T:.]){20,27}"),
            "ownerReferenceVersion", equalTo("v1"),
            "documentName", equalTo("I9Report.pdf")
        );
        serviceCalls.documentApi.stubFor(
            post(urlPathMatching("/internal/eev/documents/v1/document"))
                .willReturn(aResponse().withStatus(201).withHeader("Content-Type", "application/json")
                    .withBodyFile("documentApiUploadResponse.json")));

        serviceCalls.i9api.stubFor(
            patch(WireMock.urlEqualTo("/internal/eev/form-i9/v1/forms/" + documentId + "/metadata"))
                .willReturn(aResponse().withStatus(200)));

        serviceCalls.referenceApi.stubFor(
            get(WireMock.urlPathMatching("/internal/eev/reference-data/v1/countries"))
            .willReturn(ok().withHeader("Content-Type", "application/json").withBodyFile("countriesResponse.json"))
        );
        serviceCalls.referenceApi.stubFor(
            get(WireMock.urlPathMatching("/internal/eev/reference-data/v1/states"))
                .willReturn(ok().withHeader("Content-Type", "application/json").withBodyFile("statesResponse.json"))
        );
        serviceCalls.referenceApi.stubFor(
            get(WireMock.urlPathMatching("/internal/eev/reference-data/v1/provinces"))
                .willReturn(ok().withHeader("Content-Type", "application/json").withBodyFile("provincesResponse.json"))
        );
        serviceCalls.referenceApi.stubFor(
            get(WireMock.urlPathMatching("/internal/eev/reference-data/v1/documents/all-documents"))
                .willReturn(ok().withHeader("Content-Type", "application/json").withBodyFile("documentDefsResponse.json"))
        );
        when(auditFeed.fetchAuditData(sourceRefId))
                .thenReturn(Mono.just(List.of(DataBaseAuditDataFeedTest.createAuditMessage())));
    }

    private void generatesPdfOnStatus(String status) throws Exception {
        // given
        serviceCalls.pdfGenerator
                .stubFor(
                        // here be proper url
                        post(anyUrl())
                                .withRequestBody(equalToJson(testFileContent("pdfRequest.json"),
                                        true,
                                        true))
                                .willReturn(aResponse()
                                        .withHeader("Content-Type", "application/pdf")
                                        .withBodyFile("I9Report.pdf")));
        // when
        messagePublish.publishMessage(Map.of(
                "status", status,
                "recordVersion", recordVersion.toString(),
                "documentId", documentId,
                "sourceRefId", sourceRefId),
                new I9EventPayload());
        //expected
        final RequestPatternBuilder pdfGeneratorRequest =
                postRequestedFor(anyUrl())
                        .withRequestBody(
                                equalToJson(
                                        testFileContent("pdfRequest.json"),
                                        true,
                                        true));
        serviceCalls.pdfGenerator.assertCall(pdfGeneratorRequest);
        final RequestPatternBuilder documentApiRequest =
                postRequestedFor(anyUrl())
                        .withQueryParam("documentType", equalTo("application/pdf"))
                        .withRequestBodyPart(
                                aMultipart().withBody(equalTo(testFileContent("I9Report.pdf"))).build());

        serviceCalls.documentApi.assertCall(documentApiRequest);

        final RequestPatternBuilder patchRequest =
                patchRequestedFor(urlEqualTo("/internal/eev/form-i9/v1/forms/" + documentId + "/metadata"))
                        .withRequestBody(equalToJson(testFileContent("patchMetadataRequest.json")));

        serviceCalls.i9api.assertCall(patchRequest);

        verify(messageConfirmation, atLeast(1)).acknowledge(any(Message.class));
    }

    @SneakyThrows
    @ParameterizedTest
    @ValueSource(strings = {
        "Section2_Complete",
        "Section2_Amended",
        "Section1_Amended",
        "Section3_Complete"
    })
    void generatePDFOnEachSection(String section){
        generatesPdfOnStatus(section);
    }

    @Test
    void nacknowledgesOnServerError() throws Exception {
        // given
        serviceCalls.pdfGenerator
                .stubFor(
                        // here be proper url
                        post(anyUrl())
                                .withRequestBody(equalToJson(testFileContent("pdfRequest.json"),
                                        true,
                                        true))
                                .willReturn(
                                        aResponse()
                                                .withStatus(500)
                                                .withStatusMessage("Something went terribly wrong on the server")));
        // when
        messagePublish.publishMessage(Map.of(
                "status", "Section2_Complete",
                "documentId", documentId,
                "recordVersion", recordVersion.toString(),
                "sourceRefId", sourceRefId), new I9EventPayload());
        //expected
        final RequestPatternBuilder pdfGeneratorRequest = postRequestedFor(anyUrl());
        serviceCalls.pdfGenerator.assertCall(pdfGeneratorRequest);
        verify(messageConfirmation, after(500).atLeast(1)).nAcknowledge(any(Message.class));
    }

    @Test
    void acknowledgesOnClientsError() throws Exception {
        //given
        serviceCalls.pdfGenerator
                .stubFor(
                        // here be proper url
                        post(anyUrl())
                                .withRequestBody(equalToJson(testFileContent("pdfRequest.json"),
                                        true,
                                        true))
                                .willReturn(
                                        aResponse()
                                                .withStatus(400)
                                                .withStatusMessage("Bad request")));
        // when
        messagePublish.publishMessage(Map.of(
                "status", "Section2_Complete",
                "documentId", documentId,
                "recordVersion", recordVersion.toString(),
                "sourceRefId", sourceRefId), new I9EventPayload());
        //expected
        final RequestPatternBuilder pdfGeneratorRequest = postRequestedFor(anyUrl());
        serviceCalls.pdfGenerator.assertCall(pdfGeneratorRequest);
        verify(messageConfirmation, after(500).atLeast(1)).acknowledge(any(Message.class));
    }

    @Test
    void amendmentsChanged() throws InterruptedException, ExecutionException, TimeoutException, JsonProcessingException {
        // given
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/forms/" + documentId + "/history")
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("getHistoryAmendmentChanged.json")));
        serviceCalls.pdfGenerator
                .stubFor(
                        // here be proper url
                        post(anyUrl())
                                .withRequestBody(equalToJson(testFileContent("pdfRequestAmendment.json"),
                                        true,
                                        true))
                                .willReturn(aResponse()
                                        .withHeader("Content-Type", "application/pdf")
                                        .withBodyFile("I9Report.pdf")));
        // when
        messagePublish.publishMessage(Map.of(
                "status", "Section1_Amended",
                "recordVersion", recordVersion.toString(),
                "documentId", documentId,
                "sourceRefId", sourceRefId),
                new I9EventPayload());
        //expected
        final RequestPatternBuilder pdfGeneratorRequest =
                postRequestedFor(anyUrl())
                        .withRequestBody(
                                equalToJson(
                                        testFileContent("pdfRequestAmendment.json"),
                                        true,
                                        true));
        serviceCalls.pdfGenerator.assertCall(pdfGeneratorRequest);
    }
}
