package com.efx.ews.es.i9integration.i9portaleventshandler.model;

import static org.junit.jupiter.api.Assertions.*;

import com.efx.ews.es.eev.barricade.common.model.BarricadeEncryptedData;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.event.I9EventAuditData;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.event.I9EventPayload;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import org.junit.jupiter.api.Test;

class PacketMailSentEventTest {

    @Test
    public void mapToPayloadTest() {
        // given
        PacketMailSentEvent packetMailSentEvent = new PacketMailSentEvent();
        String date = ZonedDateTime // without such complication, there is problem with milliseconds ending with '0'
            .parse(ZonedDateTime.now(ZoneId.of("Z")).toString(), DateTimeFormatter.ISO_OFFSET_DATE_TIME)
            .truncatedTo(ChronoUnit.MILLIS).toString();
        packetMailSentEvent.setDate(date);
        packetMailSentEvent.setPacketId("packetId-1");
        packetMailSentEvent.setReceiverId("receiverId-1");
        packetMailSentEvent.setSenderId("senderId-1");
        packetMailSentEvent.setMailType("welcome");

        BarricadeEncryptedData encryptedData = new BarricadeEncryptedData("e1", "e2", "e3");

        // when
        I9EventPayload i9EventPayload = packetMailSentEvent.mapToPayload(encryptedData);

        // then
        I9EventAuditData audit = i9EventPayload.getAudit();
        assertEquals(date, audit.getDate());
        assertEquals("senderId-1", audit.getSourceKey());
        assertEquals(encryptedData, audit.getSource());
        assertNull(audit.getSourceIp());
        assertEquals("welcome_email", audit.getEventKey());
        assertEquals("'Welcome' email sent", audit.getEventDescription());
        assertEquals(false, audit.getDataUpdate());
        assertNull(audit.getDataRevision());
    }
}