package com.efx.ews.es.i9integration.i9portaleventshandler;

import com.efx.ews.es.common.user.UserSdk;
import com.efx.ews.es.eev.barricade.common.model.BarricadeKeyStore;
import com.efx.ews.es.eev.barricade.common.service.CryptographyService;
import com.efx.ews.es.eev.barricade.common.service.PubSubEncryptionService;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.PacketMailSentEvent;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.event.I9EventPayload;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.AuditPubSubPublisherService;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.ReferenceApiService;
import com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageConfirmation;
import com.fasterxml.jackson.core.JsonProcessingException;
import java.util.TreeMap;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.messaging.Message;
import reactor.core.publisher.Mono;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyMap;
import static org.mockito.Mockito.after;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@SpringBootTest
@Slf4j
public class EmailSubscriberConfigTest {
    @Autowired
    private EmailPacketPubSub messagePublish;

    @Autowired
    private ServiceCalls serviceCalls;

    @MockBean
    @Qualifier("messageConfirmation")
    private MessageConfirmation messageConfirmation;
    @MockBean
    @Qualifier("messageConfirmationForFlow")
    private MessageConfirmation messageConfirmationForFlow;
    @MockBean
    private PubSubEncryptionService pubSubEncryptionService;
    @MockBean
    List<BarricadeKeyStore> barricadeKeyStores;
    @MockBean
    CryptographyService cryptographyService;
    @MockBean
    private ReferenceApiService referenceApiService;
    @MockBean
    private AuditPubSubPublisherService publisherService;
    @MockBean
    private UserSdk userSdk;

    private String uuid = "3da9a4db-73bd-41ff-984c-115a894e0d61";

    @Test
    public void testPublishEmailEvent() throws InterruptedException, ExecutionException, TimeoutException, JsonProcessingException {
        when(publisherService.sendAuditMessage(anyMap(), any(I9EventPayload.class))).thenReturn(Mono.just("test"));
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/forms/query?sourceRefId="+uuid)
                        .willReturn(aResponse().withStatus(HttpStatus.OK.value())
                                .withHeader("Content-Type", "application/json")
                                .withBodyFile("singleI9id.json")));

        // when
        messagePublish.publishMessage(Map.of(), payload());
        //expected
        @SuppressWarnings("unchecked")
        ArgumentCaptor<Map<String,String>> actualHeaders = ArgumentCaptor.forClass(Map.class);
        Mockito.verify(publisherService, times(1)).sendAuditMessage(actualHeaders.capture(), any(I9EventPayload.class));
        Map<String, String> expectedHeaders = Map.of(
            "documentId", "uAcCCIg8S4jbQh6OzA4y",
            "sourceId", "packet_ui",
            "sourceRefId", uuid,
            "status", "Email_Sent",
            "system", "ESP");
        assertEquals(new TreeMap<>(expectedHeaders), new TreeMap<>(actualHeaders.getValue()));
    }

    private PacketMailSentEvent payload() {
        PacketMailSentEvent event = new PacketMailSentEvent();
        event.setDate(ZonedDateTime.now().format(DateTimeFormatter.ISO_OFFSET_DATE_TIME));
        event.setMailType("WelComeEmail");
        event.setPacketId(uuid);
        event.setReceiverId(uuid);
        event.setSenderId(uuid);
        return event;
    }

    @Test
    public void nacknowledgesOnServerError() throws Exception {
        // given
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/forms/query?sourceRefId="+uuid)
                        .willReturn(aResponse().withStatus(HttpStatus.INTERNAL_SERVER_ERROR.value())
                                .withHeader("Content-Type", "application/json")
                                .withBodyFile("singleI9id.json")));
        // when
        messagePublish.publishMessage(Map.of(), payload());
        //expected
        verify(messageConfirmation, after(500).atLeast(1)).nAcknowledge(any(Message.class));
    }

    @Test
    public void acknowledgesOnClientsError() throws Exception {
        // given
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/forms/query?sourceRefId="+uuid)
                        .willReturn(aResponse().withStatus(HttpStatus.BAD_REQUEST.value())
                                .withHeader("Content-Type", "application/json")
                                .withBodyFile("singleI9id.json")));
        // when
        messagePublish.publishMessage(Map.of(), payload());
        //expected
        verify(messageConfirmation, after(500).atLeast(1)).acknowledge(any(Message.class));
    }
}
