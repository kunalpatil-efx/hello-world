package com.efx.ews.es.i9integration.i9portaleventshandler;

import static com.efx.ews.es.i9integration.i9portaleventshandler.utils.WireMockTestFile.testFileContent;
import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.anyUrl;
import static com.github.tomakehurst.wiremock.client.WireMock.equalToJson;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.postRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathMatching;

import com.efx.ews.es.eev.barricade.common.model.BarricadeKeyStore;
import com.efx.ews.es.eev.barricade.common.service.CryptographyService;
import com.efx.ews.es.eev.barricade.common.service.PubSubEncryptionService;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.I9EventStatus;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.event.I9EventPayload;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.AuditDataFeed;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.DataBaseAuditDataFeedTest;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.I9FormDao;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.PacketPubSubPublisherService;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.ReferenceApiService;
import com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageConfirmation;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.matching.RequestPatternBuilder;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.messaging.MessageHeaders;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.messaging.Message;
import reactor.core.publisher.Mono;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@SpringBootTest
@ExtendWith(SpringExtension.class)
@Slf4j
public class IngestEmployeeSubscriberConfigTest {
    @Autowired
    private MessagePublish messagePublish;
    @Autowired
    private ServiceCalls serviceCalls;

    @MockBean
    @Qualifier("messageConfirmation")
    private MessageConfirmation messageConfirmation;
    @MockBean
    @Qualifier("messageConfirmationForFlow")
    private MessageConfirmation messageConfirmationForFlow;
    @MockBean
    private PubSubEncryptionService pubSubEncryptionService;
    @MockBean
    List<BarricadeKeyStore> barricadeKeyStores;
    @MockBean
    CryptographyService cryptographyService;
    @MockBean
    private I9FormDao i9FormDao;
    @MockBean
    private PacketPubSubPublisherService publisherService;
    @MockBean
    private ReferenceApiService referenceApiService;
    @MockBean
    private AuditDataFeed auditFeed;

    private Map<String, String> attributes;
    private String documentId;
    private MessageHeaders headers = mock(MessageHeaders.class);

    @BeforeEach
    public void setup() throws Exception {
        documentId = LocalDateTime.now().format(DateTimeFormatter.ISO_DATE_TIME);
        attributes = Map.of("status", I9EventStatus.SECTION3_COMPLETE.toString(),
                            "documentId", documentId,
                            "recordVersion","1");
        serviceCalls.i9api
            .stubFor(get("/internal/eev/form-i9/v1/forms/"+documentId+"/history/1")
                .willReturn(aResponse().withHeader("Content-Type", "application/json")
                    .withBodyFile("historyResponse.json")));
        when(auditFeed.fetchAuditData(null))
                .thenReturn(Mono.just(List.of(DataBaseAuditDataFeedTest.createAuditMessage())));
    }

    @Test
    public void testPushSectionThreeData()
        throws InterruptedException, ExecutionException, TimeoutException, JsonProcessingException {
        // given
        serviceCalls.employerPersonApi.stubFor(
            post(urlPathMatching("/internal/es-platform/employer-person/v1/facts"))
                .willReturn(aResponse().withStatus(201).withHeader("Content-Type", "application/json"))
        );
        // when
        messagePublish.publishMessage(attributes, new I9EventPayload());
        //expected
        final RequestPatternBuilder pushSectionThreeRequest =
            postRequestedFor(WireMock.urlEqualTo("/internal/es-platform/employer-person/v1/facts"));
        serviceCalls.employerPersonApi.assertCall(pushSectionThreeRequest);
    }

    @Test
    public void testS1Amendment()
            throws InterruptedException, ExecutionException, TimeoutException, JsonProcessingException {
        // given
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/forms/"+documentId+"/history/2")
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("I9curr.json")));
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/forms/"+documentId+"/history/1")
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("I9Prev.json")));
        serviceCalls.employerPersonApi.stubFor(
                post(urlPathMatching("/internal/es-platform/employer-person/v1/facts"))
                        .willReturn(aResponse().withStatus(201).withHeader("Content-Type", "application/json"))
        );
        // when
        attributes = Map.of("status", I9EventStatus.SECTION1_AMENDED.toString(),
                "documentId", documentId,
                "recordVersion","2");
        messagePublish.publishMessage(attributes, new I9EventPayload());
        //expected
        final RequestPatternBuilder pushSectionThreeRequest =
                postRequestedFor(WireMock.urlEqualTo("/internal/es-platform/employer-person/v1/facts"))
                        .withRequestBody(
                                equalToJson(
                                        testFileContent("s1IngestRequest.json"),
                                        true,
                                        true));
        serviceCalls.employerPersonApi.assertCall(pushSectionThreeRequest);
    }

    @Test
    public void nacknowledgesOnServerError() throws Exception {
        // given
        serviceCalls.employerPersonApi.stubFor(
            post(urlPathMatching("/internal/es-platform/employer-person/v1/facts"))
                .willReturn(
                    aResponse()
                        .withStatus(500)
                        .withStatusMessage("Something went terribly wrong on the server")));
        // when
        messagePublish.publishMessage(attributes, new I9EventPayload());
        //expected
        final RequestPatternBuilder pushSectionThreeRequest = postRequestedFor(anyUrl());
        serviceCalls.employerPersonApi.assertCall(pushSectionThreeRequest);
        verify(messageConfirmation, after(500).atLeast(1)).nAcknowledge(any(Message.class));
    }

    @Test
    public void acknowledgesOnClientsError() throws Exception {
        // given
        serviceCalls.employerPersonApi.stubFor(
            post(urlPathMatching("/internal/es-platform/employer-person/v1/facts"))
                .willReturn(
                    aResponse()
                        .withStatus(400)
                        .withStatusMessage("Bad request")));
        // when
        messagePublish.publishMessage(attributes, new I9EventPayload());
        //expected
        final RequestPatternBuilder pushSectionThreeRequest = postRequestedFor(anyUrl());
        serviceCalls.employerPersonApi.assertCall(pushSectionThreeRequest);
        verify(messageConfirmation, after(500).atLeast(1)).acknowledge(any(Message.class));
    }
}
