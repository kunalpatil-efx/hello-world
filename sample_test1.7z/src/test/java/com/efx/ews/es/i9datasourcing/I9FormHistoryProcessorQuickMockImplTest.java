package com.efx.ews.es.i9datasourcing;

import static org.junit.Assert.assertNotNull;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.I9Form;
import lombok.SneakyThrows;
import org.junit.jupiter.api.Test;

public class I9FormHistoryProcessorQuickMockImplTest {

    private final I9FormHistoryProcessorQuickMock processorQuickMock = new I9FormHistoryProcessorQuickMockImpl();

    @SneakyThrows
    @Test
    public void shouldReturnI9FormWithSectionOne() {
        I9Form i9Form = processorQuickMock.simulateReceivedSection1Creation();
        assertNotNull(i9Form);
        assertNotNull(i9Form.getFormData().getSectionOne());
        assertNotNull(i9Form.getFormData().getSectionOne().getEmployeeInfo());
    }

    @SneakyThrows
    @Test
    public void shouldReturnI9FormWithSectionOneAndSectionTwo() {
        I9Form i9Form = processorQuickMock.simulateReceivedSection2Creation();
        assertNotNull(i9Form);
        assertNotNull(i9Form.getFormData().getSectionOne());
        assertNotNull(i9Form.getFormData().getSectionTwo());
        assertNotNull(i9Form.getFormData().getSectionTwo().getListA());
    }
}
