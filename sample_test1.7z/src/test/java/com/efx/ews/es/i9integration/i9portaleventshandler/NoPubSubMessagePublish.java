package com.efx.ews.es.i9integration.i9portaleventshandler;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.pubsub.v1.PubsubMessage;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cloud.gcp.pubsub.support.AcknowledgeablePubsubMessage;
import org.springframework.context.annotation.Profile;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.GenericMessage;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;

import java.util.Map;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@Component
@Profile({"!emulator & !realEnv"})
public class NoPubSubMessagePublish implements MessagePublish {
    private IntegrationFlow pdfSubscriptionFlow;
    private IntegrationFlow sectionThreeSubscriptionFlow;
    private IntegrationFlow dataEventsFlow;
    private IntegrationFlow i9AnywhereTasksSubscriptionFlow;
    private ObjectMapper objectMapper = new ObjectMapper();

    public NoPubSubMessagePublish(@Qualifier("PdfGenerationSubscriber") IntegrationFlow pdfSubscriptionFlow,
                                  @Qualifier("SectionThreeSubscriberConfig") IntegrationFlow sectionThreeSubscriptionFlow,
                                  @Qualifier("DataEventSubscriberConfig") IntegrationFlow dataEventsFlow,
                                  @Qualifier("I9AnywhereTasksSubscriberConfig") IntegrationFlow i9AnywhereTasksSubscriptionFlow) {
        this.pdfSubscriptionFlow = pdfSubscriptionFlow;
        this.sectionThreeSubscriptionFlow = sectionThreeSubscriptionFlow;
        this.dataEventsFlow = dataEventsFlow;
        this.i9AnywhereTasksSubscriptionFlow = i9AnywhereTasksSubscriptionFlow;
        objectMapper = new ObjectMapper();
    }

    @Override
    public void publishMessage(Map<String, String> attributes, Object payload) throws JsonProcessingException {
        publishMessageToFlow(attributes, payload, pdfSubscriptionFlow);
        publishMessageToFlow(attributes, payload, sectionThreeSubscriptionFlow);
        publishMessageToFlow(attributes, payload, dataEventsFlow);
    }

    @Override
    public void publishMessageToI9AnywhereTaskFlow(Map<String, String> attributes) throws JsonProcessingException {
        publishMessageToFlow(attributes, "", i9AnywhereTasksSubscriptionFlow);
    }

    private void publishMessageToFlow(Map<String, String> attributes, Object payload, IntegrationFlow integrationFlow) throws JsonProcessingException {
        //noinspection unchecked,rawtypes
        Message<?> message = new GenericMessage<Object>(objectMapper.writeValueAsBytes(payload), (Map) attributes);
        integrationFlow.getInputChannel().send(message);
    }
}
