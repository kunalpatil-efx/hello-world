package com.efx.ews.es.i9datasourcing.util;

public class TestConstants {

    public static final String INTEGRATION_TEST = "IntegrationTest";
}
