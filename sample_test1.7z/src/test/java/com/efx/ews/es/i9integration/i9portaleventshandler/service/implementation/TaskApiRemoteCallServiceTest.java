package com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.I9Form;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.I9FormResponse;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.Task;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.task.TaskCreateRequest;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.I9ApiCall;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.TaskApiProperties;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.TaskApiProperties.TaskType;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.nio.charset.Charset;
import java.util.List;
import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.ResponseEntity;
import reactor.core.publisher.Mono;


public class TaskApiRemoteCallServiceTest {

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    private TaskApiConnector taskApiConnector;
    private I9ApiCall i9ApiCall;
    private TaskApiProperties taskApiProperties;
    private TaskApiRemoteCallService service;

    @BeforeEach
    private void setup() {
        OBJECT_MAPPER.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        i9ApiCall = mock(I9ApiCall.class);
        taskApiConnector = mock(TaskApiConnector.class);
        taskApiProperties = mock(TaskApiProperties.class);
        service = new TaskApiRemoteCallServiceImpl(taskApiConnector, i9ApiCall, taskApiProperties);
    }

    @Test
    public void testCreateReceiptUpdateTask() throws IOException {
        I9Form i9Form =OBJECT_MAPPER.readValue(
            IOUtils.toString(this.getClass().getResourceAsStream(
                "/i9-integration-test/receipt_update/i9form.json"), Charset.defaultCharset()),
            new TypeReference<I9Form>() {
            });
        Task task = new Task();
        task.setTaskId("1"); task.setTaskStatus("NEW"); task.setTaskType("I9:ReceiptUpdate");
        when(taskApiConnector.createReceiptUpdateTask(any(TaskCreateRequest.class))).thenReturn(Mono.just(task));
        when(i9ApiCall.createTaskAssociation(anyString(), any(Task.class))).thenReturn(Mono.just(task));
        Task ret = service.createReceiptUpdateTask("0fL2CZBpDKxjwvxA2aue", i9Form).block();
        assertNotNull(ret);
        verify(taskApiConnector, times(1)).createReceiptUpdateTask(any(TaskCreateRequest.class));
        verify(i9ApiCall, times(1)).createTaskAssociation(anyString(), any(Task.class));
    }

    @Test
    public void testCreateReceiptUpdateTask_ListBC() throws IOException {
        I9Form i9Form =OBJECT_MAPPER.readValue(
            IOUtils.toString(this.getClass().getResourceAsStream(
                "/i9-integration-test/receipt_update/i9form_listbc.json"), Charset.defaultCharset()),
            new TypeReference<I9Form>() {
            });
        Task task = new Task();
        task.setTaskId("1"); task.setTaskStatus("NEW"); task.setTaskType("I9:ReceiptUpdate");
        when(taskApiConnector.createReceiptUpdateTask(any(TaskCreateRequest.class))).thenReturn(Mono.just(task));
        when(i9ApiCall.createTaskAssociation(anyString(), any(Task.class))).thenReturn(Mono.just(task));
        Task ret = service.createReceiptUpdateTask("0fL2CZBpDKxjwvxA2aue", i9Form).block();
        assertNotNull(ret);
        verify(taskApiConnector, times(1)).createReceiptUpdateTask(any(TaskCreateRequest.class));
        verify(i9ApiCall, times(1)).createTaskAssociation(anyString(), any(Task.class));
    }

    @Test
    public void testCompleteTask_Section2() throws IOException {
        String docid = "0fL2CZBpDKxjwvxA2aue";
        Task task = new Task();
        task.setTaskId("1"); task.setTaskStatus("NEW"); task.setTaskType("I9:Section2");
        TaskType taskType = new TaskType(); taskType.setCode("I9:ReceiptUpdate");
        when(taskApiProperties.getReceiptUpdateSectionTwo()).thenReturn(taskType);
        when(taskApiConnector.completeTask(task, "user123")).thenReturn(Mono.just(task));
        when(i9ApiCall.markTaskAsCompleted(docid, "1")).thenReturn(Mono.just(ResponseEntity.ok().build()));
        Task ret = service.completeTask(docid, task, "user123").block();
        assertNotNull(ret);
        verify(taskApiProperties, times(1)).getReceiptUpdateSectionTwo();
        verify(taskApiConnector, times(1)).completeTask(task, "user123");
        verify(i9ApiCall, times(1)).markTaskAsCompleted(docid, "1");
    }

    @Test
    public void testCompleteTask_ReceiptUpdate() throws IOException {
        String docid = "0fL2CZBpDKxjwvxA2aue";
        List<I9FormResponse> formhistory = OBJECT_MAPPER.readValue(
            IOUtils.toString(this.getClass().getResourceAsStream(
                "/i9-integration-test/receipt_update/0fL2CZBpDKxjwvxA2aue_history.json"), Charset.defaultCharset()),
            new TypeReference<List<I9FormResponse>>() {
            });
        assertNotNull(formhistory);
        Task task = new Task();
        task.setTaskId("1"); task.setTaskStatus("NEW"); task.setTaskType("I9:ReceiptUpdate");
        TaskType taskType = new TaskType(); taskType.setCode("I9:ReceiptUpdate");
        when(taskApiProperties.getReceiptUpdateSectionTwo()).thenReturn(taskType);
        when(i9ApiCall.getHistory(docid)).thenReturn(Mono.just(formhistory));
        when(taskApiConnector.completeTask(task, "user123")).thenReturn(Mono.just(task));
        when(i9ApiCall.markTaskAsCompleted(docid, "1")).thenReturn(Mono.just(ResponseEntity.ok().build()));
        Task ret = service.completeTask(docid, task, "user123").block();
        assertNotNull(ret);
        verify(taskApiProperties, times(1)).getReceiptUpdateSectionTwo();
        verify(i9ApiCall, times(1)).getHistory(docid);
        verify(taskApiConnector, times(1)).completeTask(task, "user123");
        verify(i9ApiCall, times(1)).markTaskAsCompleted(docid, "1");
    }

    @Test
    public void testSkip_ReceiptTaskUpdate() throws IOException {
        String docid = "0fL2CZBpDKxjwvxA2aue";
        List<I9FormResponse> formhistory = OBJECT_MAPPER.readValue(
            IOUtils.toString(this.getClass().getResourceAsStream(
                "/i9-integration-test/receipt_update/0fL2CZBpDKxjwvxA2aue_history.json"), Charset.defaultCharset()),
            new TypeReference<List<I9FormResponse>>() {
            });
        assertNotNull(formhistory);

        //set the receipt flag to true to skip complete task
        I9FormResponse form = formhistory.stream().filter(i9 -> i9.getRecordVersion() == 9L).findFirst().get();
        form.getFormData().getSectionTwo().getListA().getDocumentOne().setIsReceipt(true);

        Task task = new Task();
        task.setTaskId("1"); task.setTaskStatus("NEW"); task.setTaskType("I9:ReceiptUpdate");
        TaskType taskType = new TaskType(); taskType.setCode("I9:ReceiptUpdate");
        when(taskApiProperties.getReceiptUpdateSectionTwo()).thenReturn(taskType);
        when(i9ApiCall.getHistory(docid)).thenReturn(Mono.just(formhistory));
        when(taskApiConnector.completeTask(task, "user123")).thenReturn(Mono.just(task));
        when(i9ApiCall.markTaskAsCompleted(docid, "1")).thenReturn(Mono.just(ResponseEntity.ok().build()));
        Task ret = service.completeTask(docid, task, "user123").block();
        assertNotNull(ret);
        verify(taskApiProperties, times(1)).getReceiptUpdateSectionTwo();
        verify(i9ApiCall, times(1)).getHistory(docid);
        verify(taskApiConnector, times(0)).completeTask(task, "user123");
        verify(i9ApiCall, times(0)).markTaskAsCompleted(docid, "1");
    }


}
