package com.efx.ews.es.i9integration.i9portaleventshandler;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.stereotype.Component;

@Component
public class EVerifyPubSub extends SinglePubSubMessagePublish {

    public EVerifyPubSub(@Qualifier("EVerifyEventsSubscriber") IntegrationFlow flow) {
        super(flow);
    }
}
