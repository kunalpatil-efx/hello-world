package com.efx.ews.es.i9integration.i9portaleventshandler;

import com.efx.ews.es.i9datasourcing.data.MockI9FormResponseData;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.BytesToDocumentUpload;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.I9CompletionStatus;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.I9FormResponse;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.UpdateMetadataRequest;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.pdfGenerator.I9FormResponseToPdfGenerate;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.pdfGenerator.I9History;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.ICEAuditProvider;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.DocumentApiCall;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.I9ApiCall;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.PdfGeneratorCall;
import com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageConfirmation;
import org.apache.commons.lang.NullArgumentException;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;

import java.util.UUID;

import static org.mockito.MockitoAnnotations.initMocks;

public class PdfGenerationSubscriberTest {

    private PdfGenerationSubscriber pdfGenerationSubscriber;

    @Mock
    private I9ApiCall i9ApiCall;

    @Mock
    private I9FormResponseToPdfGenerate i9FormResponseToPdfGenerate;

    @Mock
    private PdfGeneratorCall pdfGeneratorCall;

    @Mock
    private DocumentApiCall documentApiCall;

    @Mock
    private BytesToDocumentUpload bytesToDocumentUpload;

    @Mock
    private SubscriberErrorHandling errorHandling;

    @Mock
    private MessageConfirmation messageConfirmation;

    @Mock
    private ICEAuditProvider auditProvider;

    String documentId;
    I9FormResponse form;
    PdfGenerationSubscriber.FormFixStatus formFixStatus;
    UpdateMetadataRequest metadataRequest;
    I9History history;

    @Before
    public void setUp() {
        initMocks(this);
        pdfGenerationSubscriber = new PdfGenerationSubscriber(
                messageConfirmation, i9ApiCall,
                i9FormResponseToPdfGenerate, pdfGeneratorCall,
                documentApiCall, bytesToDocumentUpload,
                true, auditProvider
        );
        documentId = UUID.randomUUID().toString();
        history = new I9History(MockI9FormResponseData.createFormList(), null);
    }

    @Test(expected = NullArgumentException.class)
    public void verifyI9HistoryValidForMessage_section1Missing() {
        Long recordVersion = 0L;
        I9CompletionStatus status = I9CompletionStatus.SECTION1_AMENDED;
        pdfGenerationSubscriber.verifyI9HistoryValidForMessage(history, recordVersion, status);
    }

    @Test(expected = NullArgumentException.class)
    public void verifyI9HistoryValidForMessage_section2Missing() {
        Long recordVersion = 0L;
        I9CompletionStatus status = I9CompletionStatus.SECTION2_AMENDED;
        pdfGenerationSubscriber.verifyI9HistoryValidForMessage(history, recordVersion, status);
    }

    @Test(expected = NullArgumentException.class)
    public void verifyI9HistoryValidForMessage_section3Missing() {
        Long recordVersion = 0L;
        I9CompletionStatus status = I9CompletionStatus.SECTION3_AMENDED;
        pdfGenerationSubscriber.verifyI9HistoryValidForMessage(history, recordVersion, status);
    }
}