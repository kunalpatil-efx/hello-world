package com.efx.ews.es.i9datasourcing.fieldconverter;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;

import com.efx.ews.es.i9datasourcing.fieldconverter.Utils.Constants;
import com.efx.ews.es.i9datasourcing.formatter.Formatters;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Map;
import org.junit.jupiter.api.Test;

class TemporalConverterTest {

    private TemporalConverter temporalConverter;

    private static final String EXPECTED_DATE = "2020-10-30";
    private static final Map<String, String> flattenedI9form = Map.of(
        "date-field", "2020-10-30",
        "datetime-field", "2020-10-30T15:30:17",
        "datetime-field-offset", "2020-10-30T15:11:11.559+00:00",
        "incorrect-date-field", "30/10/2020",
        "date-field-us-standard", "10/30/2020",
        "empty-field", "",
        "blank-field", " ");

    @Test
    void shouldConvertUsingPrimaryFormatterOnly() {
        // given
        temporalConverter = new TemporalConverter(
            "date-field",
            DateTimeFormatter.ISO_DATE,
            DateTimeFormatter.ISO_DATE);

        // when
        String convertedValue = temporalConverter.convert(flattenedI9form);

        // then
        assertThat(convertedValue).isEqualTo(EXPECTED_DATE);
    }

    @Test
    void shouldConvertUsingPrimaryFormatter() {
        // given
        temporalConverter = new TemporalConverter(
            "date-field",
            DateTimeFormatter.ISO_DATE,
            DateTimeFormatter.ISO_DATE_TIME,
            DateTimeFormatter.ISO_DATE);

        // when
        String convertedValue = temporalConverter.convert(flattenedI9form);

        // then
        assertThat(convertedValue).isEqualTo(EXPECTED_DATE);
    }

    @Test
    void shouldConvertDateTimeUsingAlternativeFormatter() {
        // given
        temporalConverter = new TemporalConverter(
            "datetime-field",
            DateTimeFormatter.ISO_DATE,
            DateTimeFormatter.ISO_DATE_TIME,
            DateTimeFormatter.ISO_DATE);

        // when
        String convertedValue = temporalConverter.convert(flattenedI9form);

        // then
        assertThat(convertedValue).isEqualTo(EXPECTED_DATE);
    }

    @Test
    void shouldConvertDateTimeUsingAlternativeFormatterOffSet() {
        // given
        temporalConverter = new TemporalConverter(
            "datetime-field-offset",
            Formatters.DATE_TIME_FORMATTER_WITH_ZONE,
            Formatters.DATE_FORMATTER,
            Formatters.DATE_FORMATTER);

        // when
        String convertedValue = temporalConverter.convert(flattenedI9form);

        // then
        assertThat(convertedValue).isEqualTo(EXPECTED_DATE);
    }

    @Test
    void shouldConvertUSDateUsingAlternativeFormatter() {
        // given
        temporalConverter = new TemporalConverter(
            "date-field-us-standard",
            DateTimeFormatter.ISO_DATE,
            Formatters.DATE_FORMATTER_US,
            Formatters.DATE_FORMATTER);

        // when
        String convertedValue = temporalConverter.convert(flattenedI9form);

        // then
        assertThat(convertedValue).isEqualTo(EXPECTED_DATE);
    }

    @Test
    void shouldNotConvertEmptyField() {
        // given
        temporalConverter = new TemporalConverter(
            "empty-field",
            DateTimeFormatter.ISO_DATE,
            DateTimeFormatter.ISO_DATE_TIME,
            Formatters.DATE_TIME_FORMATTER);

        // when
        String convertedValue = temporalConverter.convert(flattenedI9form);

        // then
        assertThat(convertedValue).isEqualTo(Constants.DEFAULT_EMPTY_VALUE);
    }

    @Test
    void shouldNotConvertBlankField() {
        // given
        temporalConverter = new TemporalConverter(
            "blank-field",
            DateTimeFormatter.ISO_DATE,
            DateTimeFormatter.ISO_DATE_TIME,
            Formatters.DATE_TIME_FORMATTER);

        // when
        String convertedValue = temporalConverter.convert(flattenedI9form);

        // then
        assertThat(convertedValue).isEqualTo(Constants.DEFAULT_EMPTY_VALUE);
    }

    @Test
    void shouldThrowExceptionOnIncorrectFormat() {
        // given
        temporalConverter = new TemporalConverter(
            "incorrect-date-field",
            DateTimeFormatter.ISO_DATE,
            DateTimeFormatter.ISO_DATE_TIME,
            Formatters.DATE_TIME_FORMATTER);

        // when-then
        assertThatExceptionOfType(DateTimeParseException.class).isThrownBy(
            () -> temporalConverter.convert(flattenedI9form)
        );
    }
}