package com.efx.ews.es.i9integration.i9portaleventshandler;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.google.api.core.ApiFuture;
import com.google.api.core.ApiFutureCallback;
import com.google.api.core.ApiFutures;
import com.google.cloud.pubsub.v1.Publisher;
import com.google.common.util.concurrent.MoreExecutors;
import com.google.protobuf.ByteString;
import com.google.pubsub.v1.PubsubMessage;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

@Slf4j
@Component
@Profile({"emulator", "realEnv"})
public class PubSubMessagePublish implements MessagePublish, AutoCloseable {
    private final Publisher publisher;

    public PubSubMessagePublish(Publisher publisher) {
        this.publisher = publisher;
    }

    @Override
    public void publishMessage(Map<String, String> attributes, Object payload) throws InterruptedException, ExecutionException, TimeoutException, JsonProcessingException {
        PubsubMessage pubsubMessage =
                PubsubMessage.newBuilder()
                        .putAllAttributes(attributes)
                        .setData(ByteString.copyFrom(new ObjectMapper().disable(SerializationFeature.FAIL_ON_EMPTY_BEANS).writeValueAsBytes(payload)))
                        .build();
        ApiFuture<String> publishFuture = publisher.publish(pubsubMessage);
        ApiFutures.addCallback(publishFuture,
                new ApiFutureCallback<>() {
                    @Override
                    public void onFailure(Throwable throwable) {
                        log.error("message publishing failed", throwable);
                    }

                    @Override
                    public void onSuccess(String id) {
                        log.info("published message with id {}", id);
                    }
                },
                MoreExecutors.directExecutor());
        publishFuture.get(30, TimeUnit.SECONDS);
    }

    @Override
    public void publishMessageToI9AnywhereTaskFlow(Map<String, String> attributes)
        throws InterruptedException, ExecutionException, TimeoutException, JsonProcessingException {
        log.info("publishing message to I9Anywhere task flow");
        publishMessage(attributes, new Object());
    }

    @Override
    public void close() throws Exception {
        if (publisher != null) {
            publisher.shutdown();
            publisher.awaitTermination(30, TimeUnit.SECONDS);
        }
    }
}