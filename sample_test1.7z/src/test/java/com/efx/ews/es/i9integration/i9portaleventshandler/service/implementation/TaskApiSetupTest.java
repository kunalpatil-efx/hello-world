package com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation;

import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.IOException;

@SpringBootTest
@ExtendWith(SpringExtension.class)
@Slf4j
public class TaskApiSetupTest extends TaskApiUnitTest {

    @Test
    public void checkAndRegisterTaskType_whenTaskDefinitionsDoNotExist_thenCreateNewTaskDefinitions() throws Exception {
        setupWireMock();
        setupNonExistingTaskDefinitions();
        try {
            taskApiProperties.getSection2Anywhere().setEnabled(Boolean.TRUE);
            taskApiProperties.getSection2CovidFollowUp().setEnabled(Boolean.TRUE);
            taskApiProperties.getSection2CovidDocumentInspection().setEnabled(Boolean.TRUE);
            new TaskApiConnector(taskApiProperties).checkAndRegisterTaskType();

            serviceCalls.taskApi.assertCall(checkTaskFamilyExistence);
            serviceCalls.taskApi.assertCall(checkTaskGroupExistence);
            serviceCalls.taskApi.assertCall(checkSection2TaskTypeExistence);
            serviceCalls.taskApi.assertCall(checkSSNAppliedTaskTypeExistence);
            serviceCalls.taskApi.assertCall(checkSection2UploadLaterTaskTypeExistence);
            serviceCalls.taskApi.assertCall(checkReceiptUpdateSectionTwoTaskTypeExistence);
            serviceCalls.taskApi.assertCall(checkSection2AnywhereTaskTypeExistence);
            serviceCalls.taskApi.assertCall(checkSection2CovidFollowUpTaskTypeExistence);

            serviceCalls.taskApi.assertCall(createSection2TaskType);
            serviceCalls.taskApi.assertCall(createSSNAppliedTaskType);
            serviceCalls.taskApi.assertCall(createSection2UploadLaterTaskType);
            serviceCalls.taskApi.assertCall(createReceiptUpdateSectionTwoTaskType);
            serviceCalls.taskApi.assertCall(createSection2AnywhereTaskType);
            serviceCalls.taskApi.assertCall(schedulerDateUpdatedTaskType);
            serviceCalls.taskApi.assertCall(createSection2CovidFollowUpTaskType);
            serviceCalls.taskApi.assertCall(createCovidDocumentInspectionTaskType);
        } catch (IOException e) {
            Assert.fail(e.getMessage());
        }
    }
}
