package com.efx.ews.es.i9integration.i9portaleventshandler.utils;

import com.github.jknack.handlebars.internal.Files;
import com.github.tomakehurst.wiremock.core.WireMockApp;
import org.springframework.util.ResourceUtils;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Paths;

public class WireMockTestFile {
    public static String testFileContent(String jsonFile) {
        final String jsonResourceFile = Paths.get(WireMockApp.FILES_ROOT, jsonFile).toUri().toString();
        final InputStream resourceAsStream = WireMockTestFile.class.getResourceAsStream(jsonResourceFile);
        try {
            final File file = ResourceUtils.getFile("classpath:" + WireMockApp.FILES_ROOT + "/" + jsonFile);
            return Files.read(file, StandardCharsets.UTF_8);
        } catch (IOException exception) {
            throw new RuntimeException(exception);
        }
    }
}
