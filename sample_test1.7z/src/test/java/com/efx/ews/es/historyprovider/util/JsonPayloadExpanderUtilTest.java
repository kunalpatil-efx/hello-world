package com.efx.ews.es.historyprovider.util;

import static org.assertj.core.api.Assertions.assertThat;

import com.efx.ews.es.i9datasourcing.dep.model.DepEventPayload;
import com.efx.ews.es.i9datasourcing.dep.model.DepEventPayloadField;
import java.util.Arrays;
import org.junit.jupiter.api.Test;

class JsonPayloadExpanderUtilTest {

    @Test
    void itShouldExpandSimpleMap() {
        DepEventPayload depEventPayload = createDepEventPayload(
            new DepEventPayloadField("1", "2"));
        assertThat(JsonPayloadExpanderUtil.expand(depEventPayload)).isEqualTo("{\"1\":\"2\"}");
    }

    @Test
    void itShouldExpandComplexMap() {
        DepEventPayload depEventPayload = createDepEventPayload(
            new DepEventPayloadField("1.2", "3"));
        assertThat(JsonPayloadExpanderUtil.expand(depEventPayload)).isEqualTo("{\"1\":{\"2\":\"3\"}}");
    }

    @Test
    void itShouldExpandSimpleMultiMap() {
        DepEventPayload depEventPayload = createDepEventPayload(
            new DepEventPayloadField("1", "2"),
            new DepEventPayloadField("3", "4"));
        assertThat(JsonPayloadExpanderUtil.expand(depEventPayload)).isEqualTo("{\"1\":\"2\",\"3\":\"4\"}");
    }

    @Test
    void itShouldExpandComplexMultiMap() {
        DepEventPayload depEventPayload = createDepEventPayload(
            new DepEventPayloadField("1", "2"),
            new DepEventPayloadField("2.3", "4"),
            new DepEventPayloadField("3.4.5", "6"),
            new DepEventPayloadField("3.4.6", "6"),
            new DepEventPayloadField("3.3.5", "6"));

        assertThat(JsonPayloadExpanderUtil.expand(depEventPayload))
            .isEqualTo("{\"1\":\"2\",\"2\":{\"3\":\"4\"},\"3\":{\"3\":{\"5\":\"6\"},\"4\":{\"5\":\"6\",\"6\":\"6\"}}}");
    }

    @Test
    void shouldExpandEmptyStringsAsNullValues() {
        DepEventPayload depEventPayload = createDepEventPayload(
            new DepEventPayloadField("1", ""),
            new DepEventPayloadField("2", " "),
            new DepEventPayloadField("3", null),
            new DepEventPayloadField("4.1", ""),
            new DepEventPayloadField("4.2", "v-4.2"),
            new DepEventPayloadField("4.3", null),
            new DepEventPayloadField("4.4", "\t"));
        assertThat(JsonPayloadExpanderUtil.expand(depEventPayload)).isEqualTo(
            "{\"1\":null,\"2\":\" \",\"3\":null,\"4\":{\"1\":null,\"2\":\"v-4.2\",\"3\":null,\"4\":\"\\t\"}}");
    }

    @Test
    void shouldExpandBooleanValues() {
        DepEventPayload depEventPayload = createDepEventPayload(
            new DepEventPayloadField("1", true),
            new DepEventPayloadField("2", false),
            new DepEventPayloadField("3", null));
        assertThat(JsonPayloadExpanderUtil.expand(depEventPayload))
            .isEqualTo("{\"1\":true,\"2\":false,\"3\":null}");
    }

    private DepEventPayload createDepEventPayload(DepEventPayloadField... content) {
        return new DepEventPayload(Arrays.asList(content));
    }
}