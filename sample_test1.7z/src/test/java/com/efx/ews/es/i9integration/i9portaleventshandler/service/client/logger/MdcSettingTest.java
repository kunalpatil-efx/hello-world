package com.efx.ews.es.i9integration.i9portaleventshandler.service.client.logger;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.MDC;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.support.GenericMessage;

import java.util.Map;

import static com.efx.ews.es.common.filter.CorrelationFilter.SESSION_ID_HEADER_NAME;
import static com.efx.ews.es.common.filter.CorrelationFilter.TRANSACTION_ID_HEADER_NAME;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;

@Slf4j
class MdcSettingTest {
    private Message<?> message;

    @BeforeEach
    void setUp() {
        Map<String, Object> headers = Map.of(TRANSACTION_ID_HEADER_NAME, "id01", SESSION_ID_HEADER_NAME, "id02");
        MessageHeaders messageHeaders = new MessageHeaders(headers);
        message = new GenericMessage(mock(Object.class), messageHeaders);
    }

    @Test
    void wrapWithHeaders_With_Runnable() {
        MdcSetting.wrapWithHeaders(message, () -> {
            log.info("Logging something");
            assertMdcValues();
        });
    }

    @Test
    void WrapWithHeaders_With_Function() {
        MdcSetting.wrapWithHeaders(message, msg -> {
            log.info("Logging something");
            assertMdcValues();
        });
    }

    private void assertMdcValues() {
        assertThat(MDC.get(TRANSACTION_ID_HEADER_NAME)).isEqualTo("id01");
        assertThat(MDC.get(SESSION_ID_HEADER_NAME)).isEqualTo("id02");
    }
}