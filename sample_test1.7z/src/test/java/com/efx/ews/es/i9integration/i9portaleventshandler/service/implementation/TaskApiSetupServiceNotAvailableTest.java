package com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation;

import static org.junit.jupiter.api.Assertions.assertThrows;

import java.io.IOException;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@SpringBootTest
@ExtendWith(SpringExtension.class)
@Slf4j
public class TaskApiSetupServiceNotAvailableTest extends TaskApiUnitTest {

    @Test
    public void checkAndRegisterTaskType_whenServiceIsUnavailable_thenCreateNewTaskDefinitions() throws Exception {
        setupWireMock();
        setupServiceUnavailableTaskApiResponse();
        taskApiProperties.getSection2Anywhere().setEnabled(Boolean.TRUE);
        taskApiProperties.getSection2CovidFollowUp().setEnabled(Boolean.TRUE);
        taskApiProperties.getSection2CovidDocumentInspection().setEnabled(Boolean.TRUE);

        Exception exception = assertThrows(IOException.class,
            () -> new TaskApiConnector(taskApiProperties).checkAndRegisterTaskType());

        serviceCalls.taskApi.assertCall(checkTaskFamilyExistence);

        serviceCalls.taskApi.assertNotCalled(checkSection2TaskTypeExistence);
        serviceCalls.taskApi.assertNotCalled(checkSSNAppliedTaskTypeExistence);
        serviceCalls.taskApi.assertNotCalled(checkSection2UploadLaterTaskTypeExistence);
        serviceCalls.taskApi.assertNotCalled(checkReceiptUpdateSectionTwoTaskTypeExistence);
        serviceCalls.taskApi.assertNotCalled(checkSection2AnywhereTaskTypeExistence);

        serviceCalls.taskApi.assertNotCalled(createSection2TaskType);
        serviceCalls.taskApi.assertNotCalled(createSSNAppliedTaskType);
        serviceCalls.taskApi.assertNotCalled(createSection2UploadLaterTaskType);
        serviceCalls.taskApi.assertNotCalled(createReceiptUpdateSectionTwoTaskType);
        serviceCalls.taskApi.assertNotCalled(createSection2AnywhereTaskType);
    }
}
