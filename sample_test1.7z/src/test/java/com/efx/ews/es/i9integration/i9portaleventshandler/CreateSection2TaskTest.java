package com.efx.ews.es.i9integration.i9portaleventshandler;

import com.efx.ews.es.eev.barricade.common.model.BarricadeKeyStore;
import com.efx.ews.es.eev.barricade.common.service.CryptographyService;
import com.efx.ews.es.eev.barricade.common.service.PubSubEncryptionService;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.event.I9EventDocumentData;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.event.I9EventFormData;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.event.I9EventPayload;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.AuditDataFeed;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.DataBaseAuditDataFeedTest;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.ReferenceApiService;
import com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageConfirmation;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.matching.RequestPatternBuilder;
import com.github.tomakehurst.wiremock.matching.UrlPattern;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.gcp.pubsub.support.AcknowledgeablePubsubMessage;
import org.springframework.http.HttpStatus;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@SpringBootTest
@Slf4j
public class CreateSection2TaskTest {
    @Autowired
    private ServiceCalls serviceCalls;
    @Autowired
    private TestableSubscriber testableSubscriber;

    @MockBean
    @Qualifier("messageConfirmation")
    private MessageConfirmation messageConfirmation;
    @MockBean
    @Qualifier("messageConfirmationForFlow")
    private MessageConfirmation messageConfirmationForFlow;
    @MockBean
    private PubSubEncryptionService pubSubEncryptionService;

    @MockBean
    List<BarricadeKeyStore> barricadeKeyStores;
    @MockBean
    CryptographyService cryptographyService;
    @MockBean
    private ReferenceApiService referenceApiService;

    private Map<String, String> attributes;
    private String documentId;
    @MockBean
    private AuditDataFeed auditFeed;

    @BeforeEach
    public void setup() throws Exception {
        documentId = UUID.randomUUID().toString();
        attributes = Map.of(
                "status", "Section1_Complete",
                "documentId", documentId,
                "sourceId", "packet-ui");
        when(auditFeed.fetchAuditData(null))
                .thenReturn(Mono.just(List.of(DataBaseAuditDataFeedTest.createAuditMessage())));
    }

    @AfterEach
    public void teardown() {
        serviceCalls.close();
    }

    @Test
    public void testCreatingSection2Task() throws Exception {
        // given
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/tasks/"+documentId)
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("tasksFromI9-NoTasks.json")));
        serviceCalls.taskApi
                .stubFor(post("/internal/es-platform/task-management/v1/tasks")
                        .willReturn(aResponse().withStatus(HttpStatus.CREATED.value())
                                .withHeader("Content-Type", "application/json")
                                .withBodyFile("taskApiResponse.json")));
        serviceCalls.i9api
                .stubFor(post(WireMock.urlEqualTo("/internal/eev/form-i9/v1/tasks/" + documentId))
                        .willReturn(aResponse().withStatus(201)));
        // when
        testableSubscriber.publishMessage(attributes, getMessagePayload());
        //expected
        final RequestPatternBuilder markCreatedRequest =
                postRequestedFor(WireMock.urlEqualTo("/internal/eev/form-i9/v1/tasks/" + documentId));
        serviceCalls.i9api.assertCall(markCreatedRequest);
        verify(messageConfirmationForFlow, after(2000).atLeast(1)).acknowledge(any(AcknowledgeablePubsubMessage.class));
    }

    @Test
    public void testCreatingSection2Task_404() throws Exception {
        // given
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/tasks/"+documentId)
                        .willReturn(aResponse().withStatus(404)));
        serviceCalls.taskApi
                .stubFor(post("/internal/es-platform/task-management/v1/tasks")
                        .willReturn(aResponse().withStatus(HttpStatus.CREATED.value())
                                .withHeader("Content-Type", "application/json")
                                .withBodyFile("taskApiResponse.json")));
        serviceCalls.i9api
                .stubFor(post("/internal/eev/form-i9/v1/tasks/" + documentId)
                        .willReturn(aResponse().withStatus(201)));
        // when
        testableSubscriber.publishMessage(attributes, getMessagePayload());
        //expected
        final RequestPatternBuilder markCreatedRequest =
                postRequestedFor(WireMock.urlEqualTo("/internal/eev/form-i9/v1/tasks/" + documentId));
        serviceCalls.i9api.assertCall(markCreatedRequest);
        verify(messageConfirmationForFlow, after(2000).atLeast(1)).acknowledge(any(AcknowledgeablePubsubMessage.class));
    }

    @Test
    public void testCreatingSection2Task_503fromTaskAPI() throws Exception {
        // given
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/tasks/"+documentId)
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("tasksFromI9-NoTasks.json")));
        serviceCalls.taskApi
                .stubFor(post("/internal/es-platform/task-management/v1/tasks")
                        .willReturn(aResponse().withStatus(503)));
        // when
        testableSubscriber.publishMessage(attributes, getMessagePayload());
        //expected
        log.info("testCreatingSection2Task_503fromTaskAPI documentId {} verifying nAcknowledge", documentId);
        verify(messageConfirmationForFlow, after(3000).atLeast(1)).nAcknowledge(any(AcknowledgeablePubsubMessage.class));
    }

    @Test
    public void testOutOfScope() throws Exception {
        //given
        serviceCalls.taskApi.stubFor(WireMock.any(UrlPattern.ANY).willReturn(aResponse().withStatus(500)));
        serviceCalls.i9api.stubFor(WireMock.any(UrlPattern.ANY).willReturn(aResponse().withStatus(500)));
        //when
        testableSubscriber.publishMessage(Map.of(
                "status", "Section1_Complete",
                "documentId", documentId,
                "sourceId", UUID.randomUUID().toString()), getMessagePayload());
        //expected
        verify(messageConfirmationForFlow, after(3000).atLeast(1)).acknowledge(any(AcknowledgeablePubsubMessage.class));
    }

    static I9EventPayload getMessagePayload() {
        I9EventPayload payload = new I9EventPayload();
        I9EventDocumentData documentData = new I9EventDocumentData();
        documentData.setEmployeeFactId("27733c9f-a64a-417e-9c47-659d16a4bf8a");
        documentData.setEmployerId("27733c9f-a64a-417e-9c47-659d16a4bf8a");
        documentData.setEmployerLocationId("27733c9f-a64a-417e-9c47-659d16a4bf8a");
        documentData.setSourceRefId("27733c9f-a64a-417e-9c47-659d16a4bf8a");
        documentData.setSourceId("packet-ui");
        documentData.setStatus("section1_complete");
        documentData.setProjectedStartDate("2020-02-01");
        payload.setDocument(documentData);
        I9EventFormData formData = new I9EventFormData();
        formData.setIsMinor(Boolean.FALSE);
        formData.setSpecialPlacement(Boolean.FALSE);
        formData.setValidListBDocs(Boolean.TRUE);
        formData.setSsnApplied(Boolean.FALSE);
        formData.setSsnRefused(Boolean.FALSE);
        payload.setForm(formData);
        return payload;
    }
}
