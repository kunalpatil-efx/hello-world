package com.efx.ews.es.i9integration.i9portaleventshandler.service.client;

import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.logger.MdcReactorLogger;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.slf4j.MDC;
import reactor.core.publisher.Mono;
import reactor.core.publisher.Signal;
import reactor.test.StepVerifier;
import reactor.util.context.Context;

import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;

import static com.efx.ews.es.common.filter.CorrelationFilter.SESSION_ID_HEADER_NAME;
import static com.efx.ews.es.common.filter.CorrelationFilter.TRANSACTION_ID_HEADER_NAME;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.only;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@Slf4j
class MdcReactorLoggerTest {

    @Test
    void itShouldCallLogOnNext_SUCCESS() {
        //given
        Signal<Object> mockedSignal = mock(Signal.class);
        Context context = mock(Context.class);

        when(mockedSignal.isOnNext()).thenReturn(true);
        when(mockedSignal.getContext()).thenReturn(context);
        String uuid = UUID.randomUUID().toString();
        when(context.getOrEmpty(anyString())).thenReturn(Optional.of(uuid));

        //execute
        MdcReactorLogger.logOnNext(s -> log.info("Some log"))
            .accept(mockedSignal);

        //verify
        verify(mockedSignal).getContext();
        verify(mockedSignal).isOnNext();
    }

    @Test
    void itShouldCallLogOnNext_And_Return_With_No_Processing() {
        //given
        Signal<Object> mockedSignal = mock(Signal.class);
        Context context = mock(Context.class);

        when(mockedSignal.isOnNext()).thenReturn(false);

        //execute
        MdcReactorLogger.logOnNext(s -> log.info("Some log"))
            .accept(mockedSignal);

        //verify
        verify(mockedSignal, never()).getContext();
        verify(mockedSignal, only()).isOnNext();
    }

    @Test
    void itShouldCallLogOnError_SUCCESS() {
        //given
        Signal<Throwable> throwableSignal = mock(Signal.class);
        Context context = mock(Context.class);

        when(throwableSignal.isOnError()).thenReturn(true);
        when(throwableSignal.getContext()).thenReturn(context);
        when(throwableSignal.getThrowable()).thenReturn(mock(Throwable.class));
        String uuid = UUID.randomUUID().toString();
        when(context.getOrEmpty(anyString())).thenReturn(Optional.of(uuid));

        //execute
        MdcReactorLogger.logOnError(throwable -> log.info("Some Consumer"))
            .accept(throwableSignal);

        //verify
        verify(throwableSignal).getContext();
        verify(throwableSignal).isOnError();
    }

    @Test
    void itShouldCallLogOnError_And_Return_With_No_Processing() {
        //given
        Signal<Throwable> stringSignal = mock(Signal.class);
        Context context = mock(Context.class);

        when(stringSignal.isOnError()).thenReturn(false);

        //execute
        MdcReactorLogger.logOnError(throwable -> log.info("Some Consumer"))
            .accept(stringSignal);

        //verify
        verify(stringSignal, never()).getContext();
        verify(stringSignal, only()).isOnError();
    }

    @Test
    void iShouldCallLog_SUCCESS() {
        AtomicBoolean isExecuted = new AtomicBoolean(false);

        assertThatCode(() ->
            Mono.just("SomeData")
                .flatMap(t -> MdcReactorLogger.logInFlatMap(() -> {
                    log.info("Test Inside Flat Map");
                    isExecuted.set(true);
                }))
                .subscriberContext(Context.of(Map.of(TRANSACTION_ID_HEADER_NAME, "id", SESSION_ID_HEADER_NAME, "id02")))
                .block()).doesNotThrowAnyException();

        assertThat(isExecuted.get()).isTrue();
    }

    @Test
    void executeTest() {
        // given
        MDC.remove(TRANSACTION_ID_HEADER_NAME);
        MDC.remove(SESSION_ID_HEADER_NAME);

        Mono<String> map = Mono.just(133)
            .flatMap(v -> MdcReactorLogger.execute(() -> v
                + "." + MDC.get(TRANSACTION_ID_HEADER_NAME)
                + "." + MDC.get(SESSION_ID_HEADER_NAME))
                .subscriberContext(Context.of(
                    TRANSACTION_ID_HEADER_NAME, "transactionId-1",
                    SESSION_ID_HEADER_NAME, "sessionId-1")));

        // then
        StepVerifier
            .create(map)
            .expectNext("133.transactionId-1.sessionId-1")
            .expectComplete()
            .verify();

        assertNull(MDC.get(TRANSACTION_ID_HEADER_NAME));
        assertNull(MDC.get(SESSION_ID_HEADER_NAME));
    }
}