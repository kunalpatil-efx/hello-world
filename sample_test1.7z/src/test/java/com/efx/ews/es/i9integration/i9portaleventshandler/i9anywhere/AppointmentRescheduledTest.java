package com.efx.ews.es.i9integration.i9portaleventshandler.i9anywhere;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.verify;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.I9AnywhereEventType;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.messaging.Message;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@SpringBootTest
@ExtendWith(SpringExtension.class)
public class AppointmentRescheduledTest extends I9AnywhereUnitTest {

    @BeforeEach
    public void setup() {
        appointmentId = UUID.randomUUID().toString();
        documentId = UUID.randomUUID().toString();
        attributes = Map.of(
            "appointmentId", appointmentId,
            "i9Id", documentId,
            "event", I9AnywhereEventType.RESCHEDULED.toString());
        setupWireMock();
        setupTaskManagement();
    }

    private void setupTaskManagement() {
        serviceCalls.taskApi
            .stubFor(post("/internal/es-platform/task-management/v1/tasks")
                .willReturn(aResponse().withStatus(HttpStatus.CREATED.value())
                    .withHeader("Content-Type", "application/json")
                    .withBodyFile("taskApiResponse.json")));
        serviceCalls.i9api
            .stubFor(get("/internal/eev/form-i9/v1/forms/" + documentId)
                .willReturn(aResponse().withHeader("Content-Type", "application/json")
                    .withBodyFile("getForm.json")));
        serviceCalls.i9api
            .stubFor(get("/internal/eev/form-i9/v1/tasks/" + documentId)
                .willReturn(aResponse().withHeader("Content-Type", "application/json")
                    .withBodyFile("tasksFromI9-NoTasks.json")));
        serviceCalls.i9api
            .stubFor(post("/internal/eev/form-i9/v1/tasks/" + documentId)
                .willReturn(aResponse().withStatus(201)));
        serviceCalls.partnerApi
            .stubFor(get("/internal/eev/partner-scheduling/partner/v1/appointments/" + appointmentId + "/status")
                .willReturn(aResponse().withHeader("Content-Type", "application/json")
                    .withBodyFile("partnerAppointmentStatus-Rescheduled.json")));
    }

    @Test
    public void appointmentRescheduled_acknowledgeMessage() throws Exception {
        // when
        messagePublish.publishMessageToI9AnywhereTaskFlow(attributes);

        // expected
        verify(messageConfirmation, atLeast(1)).acknowledge(any(Message.class));

        serviceCalls.taskApi.assertCall(createTaskRequest);
        serviceCalls.i9api.assertCall(linkTaskRequest);

        serviceCalls.taskApi.assertNotCalled(deleteI9AnywhereTaskRequest);
        serviceCalls.taskApi.assertNotCalled(completeI9AnywhereTaskRequest);
        serviceCalls.i9api.assertNotCalled(unlinkI9AnywhereTaskRequest);
        serviceCalls.i9api.assertNotCalled(markAsCompleteI9AnywhereTaskRequest);

        serviceCalls.taskApi.assertNotCalled(deleteI9PendingTaskRequest);
        serviceCalls.taskApi.assertNotCalled(completeI9PendingTaskRequest);
        serviceCalls.i9api.assertNotCalled(unlinkI9PendingTaskRequest);
        serviceCalls.i9api.assertNotCalled(markAsCompleteI9PendingTaskRequest);
    }

    @Test
    public void appointmentRescheduled_404fromFormAPI_acknowledgeMessage() throws Exception {
        // given
        serviceCalls.i9api
            .stubFor(get("/internal/eev/form-i9/v1/tasks/" + documentId)
                .willReturn(aResponse().withStatus(404)));

        // when
        messagePublish.publishMessageToI9AnywhereTaskFlow(attributes);

        //expected
        verify(messageConfirmation, atLeast(1)).acknowledge(any(Message.class));
        serviceCalls.taskApi.assertCall(createTaskRequest);
        serviceCalls.i9api.assertCall(linkTaskRequest);

        serviceCalls.taskApi.assertNotCalled(deleteI9AnywhereTaskRequest);
        serviceCalls.taskApi.assertNotCalled(completeI9AnywhereTaskRequest);
        serviceCalls.i9api.assertNotCalled(unlinkI9AnywhereTaskRequest);
        serviceCalls.i9api.assertNotCalled(markAsCompleteI9AnywhereTaskRequest);

        serviceCalls.taskApi.assertNotCalled(deleteI9PendingTaskRequest);
        serviceCalls.taskApi.assertNotCalled(completeI9PendingTaskRequest);
        serviceCalls.i9api.assertNotCalled(unlinkI9PendingTaskRequest);
        serviceCalls.i9api.assertNotCalled(markAsCompleteI9PendingTaskRequest);
    }

    @Test
    public void appointmentRescheduled_503fromFormAPI_nAcknowledgeMessage() throws Exception {
        // given
        serviceCalls.i9api
            .stubFor(get("/internal/eev/form-i9/v1/tasks/" + documentId)
                .willReturn(aResponse().withStatus(503)));

        // when
        messagePublish.publishMessageToI9AnywhereTaskFlow(attributes);

        //expected
        verify(messageConfirmation, atLeast(1)).nAcknowledge(any(Message.class));
        serviceCalls.taskApi.assertNotCalled(createTaskRequest);
        serviceCalls.i9api.assertNotCalled(linkTaskRequest);

        serviceCalls.taskApi.assertNotCalled(deleteI9AnywhereTaskRequest);
        serviceCalls.taskApi.assertNotCalled(completeI9AnywhereTaskRequest);
        serviceCalls.i9api.assertNotCalled(unlinkI9AnywhereTaskRequest);
        serviceCalls.i9api.assertNotCalled(markAsCompleteI9AnywhereTaskRequest);

        serviceCalls.taskApi.assertNotCalled(deleteI9PendingTaskRequest);
        serviceCalls.taskApi.assertNotCalled(completeI9PendingTaskRequest);
        serviceCalls.i9api.assertNotCalled(unlinkI9PendingTaskRequest);
        serviceCalls.i9api.assertNotCalled(markAsCompleteI9PendingTaskRequest);
    }

    @Test
    public void appointmentRescheduled_503fromTaskAPI_acknowledgeMessage() throws Exception {
        // given
        serviceCalls.taskApi
            .stubFor(post("/task-management/core/api/internal/v1/tasks")
                .willReturn(aResponse().withStatus(503)));

        // when
        messagePublish.publishMessageToI9AnywhereTaskFlow(attributes);

        // expected
        verify(messageConfirmation, atLeast(1)).acknowledge(any(Message.class));
    }

    @Test
    public void appointmentRescheduled_503fromPartnerAPI_nAcknowledgeMessage() throws Exception {
        // given
        serviceCalls.partnerApi
            .stubFor(get("/internal/eev/partner-scheduling/partner/v1/appointments/" + appointmentId + "/status")
                .willReturn(aResponse().withStatus(503)));

        // when
        messagePublish.publishMessageToI9AnywhereTaskFlow(attributes);

        //expected
        verify(messageConfirmation, atLeast(1)).nAcknowledge(any(Message.class));
        serviceCalls.taskApi.assertNotCalled(createTaskRequest);
        serviceCalls.i9api.assertNotCalled(linkTaskRequest);

        serviceCalls.taskApi.assertNotCalled(deleteI9AnywhereTaskRequest);
        serviceCalls.taskApi.assertNotCalled(completeI9AnywhereTaskRequest);
        serviceCalls.i9api.assertNotCalled(unlinkI9AnywhereTaskRequest);
        serviceCalls.i9api.assertNotCalled(markAsCompleteI9AnywhereTaskRequest);

        serviceCalls.taskApi.assertNotCalled(deleteI9PendingTaskRequest);
        serviceCalls.taskApi.assertNotCalled(completeI9PendingTaskRequest);
        serviceCalls.i9api.assertNotCalled(unlinkI9PendingTaskRequest);
        serviceCalls.i9api.assertNotCalled(markAsCompleteI9PendingTaskRequest);
    }

    @Test
    public void appointmentRescheduled_statusFromPartnerAPINotCancelled_nAcknowledgeMessage() throws Exception {
        // given
        serviceCalls.partnerApi
            .stubFor(get("/internal/eev/partner-scheduling/partner/v1/appointments/" + appointmentId + "/status")
                .willReturn(aResponse().withHeader("Content-Type", "application/json")
                    .withBodyFile("partnerAppointmentStatus-Cancelled.json")));

        // when
        messagePublish.publishMessageToI9AnywhereTaskFlow(attributes);

        //expected
        verify(messageConfirmation, atLeast(1)).acknowledge(any(Message.class));
        serviceCalls.taskApi.assertNotCalled(createTaskRequest);
        serviceCalls.i9api.assertNotCalled(linkTaskRequest);

        serviceCalls.taskApi.assertNotCalled(deleteI9AnywhereTaskRequest);
        serviceCalls.taskApi.assertNotCalled(completeI9AnywhereTaskRequest);
        serviceCalls.i9api.assertNotCalled(unlinkI9AnywhereTaskRequest);
        serviceCalls.i9api.assertNotCalled(markAsCompleteI9AnywhereTaskRequest);

        serviceCalls.taskApi.assertNotCalled(deleteI9PendingTaskRequest);
        serviceCalls.taskApi.assertNotCalled(completeI9PendingTaskRequest);
        serviceCalls.i9api.assertNotCalled(unlinkI9PendingTaskRequest);
        serviceCalls.i9api.assertNotCalled(markAsCompleteI9PendingTaskRequest);
    }
}
