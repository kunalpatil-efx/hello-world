package com.efx.ews.es.i9datasourcing.provider;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

class CountryCodeProviderMockTest {

    @Test
    public void providerShouldReturnExpectedValue() {
        //Given
        String countryName = "Poland";
        String countryCode = "POL";
        CountryCodeProvider countryCodeProvider = new CountryCodeProviderMock();

        //When
        String actualCountryCode = countryCodeProvider.getCountryCode(countryName);

        //Then
        assertThat(actualCountryCode).isEqualTo(countryCode);
    }
}