package com.efx.ews.es.i9datasourcing.processor;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.groups.Tuple.tuple;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.efx.ews.es.i9datasourcing.constant.DepEventName;
import com.efx.ews.es.i9datasourcing.dep.api.DepEventPayloadSender;
import com.efx.ews.es.i9datasourcing.dep.model.DepEventPayload;
import com.efx.ews.es.i9datasourcing.dep.model.DepEventPayloadField;
import com.efx.ews.es.i9datasourcing.formatter.TemporalFormatter;
import com.efx.ews.es.i9datasourcing.model.ChangeContext;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
class AuditSummarySingleI9FormHistoryProcessorTest {

    @Mock
    private DepEventPayloadSender depPubSubSender;
    @Mock
    private TemporalFormatter temporalFormatter;
    @InjectMocks
    AuditSummarySingleI9FormHistoryProcessor instance;

    @Captor
    ArgumentCaptor<DepEventPayload> payloadCaptor;

    @Test
    void process() {
        //Given
        String formatDateTime = "2020-10-10T16:57:57.817Z";
        String i9FormId = "jdB2h8oFnaDh892sa47";

        ChangeContext changeContext = new ChangeContext();
        changeContext.setI9FormId(i9FormId);
        changeContext.setSourceEventDateTime(Instant.parse(formatDateTime).atZone(ZoneOffset.UTC));

        Map<String, String> flattenedI9formAfter = Map.of(
            "key1", "value1",
            "key2", "value2",
            "key3", "true",
            "SECTION_ONE.EMPLOYEE_INFO.SSN_APPLIED_FOR", "true",
            "SECTION_ONE.EMPLOYEE_INFO.SSN_NOT_SUPPLIED", "false",
            "FICA_EXEMPT", "not-a-boolean-value"
        );

        when(temporalFormatter.formatDateTime(changeContext.getSourceEventDateTime())).thenReturn(formatDateTime);

        instance.process(null, flattenedI9formAfter, changeContext);

        verify(depPubSubSender).publish(payloadCaptor.capture(), eq(changeContext), eq(DepEventName.AUDIT_SUMMARY_I9));

        DepEventPayload publishedPayload = payloadCaptor.getValue();

        assertThat(publishedPayload).isNotNull();
        assertThat(publishedPayload.getFields())
            .extracting(DepEventPayloadField::getName, DepEventPayloadField::getValue)
            .containsExactlyInAnyOrder(
                tuple("I9_ID", i9FormId),
                tuple("MODIFICATION_TS", formatDateTime),
                tuple("key1", "value1"),
                tuple("key2", "value2"),
                tuple("key3", "true"),
                tuple("SECTION_ONE.EMPLOYEE_INFO.SSN_APPLIED_FOR", Boolean.TRUE),
                tuple("SECTION_ONE.EMPLOYEE_INFO.SSN_NOT_SUPPLIED", Boolean.FALSE),
                tuple("FICA_EXEMPT", null)
            );
    }
}