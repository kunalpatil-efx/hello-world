package com.efx.ews.es.i9datasourcing.dep.infrastructure;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

import com.efx.ews.es.eev.barricade.common.model.PubSubEncryptedData;
import com.efx.ews.es.i9datasourcing.constant.DepEventName;
import com.efx.ews.es.i9datasourcing.dep.model.DepEventDataHolder;
import com.efx.ews.es.i9datasourcing.dep.model.DepEventPayload;
import com.efx.ews.es.i9datasourcing.dep.util.PubSubEventBuilder;
import com.efx.ews.es.i9datasourcing.model.ChangeContext;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.pubsub.PubSubEvent;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.DataEngineeringTopicService;
import java.util.function.BiFunction;
import lombok.SneakyThrows;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;

class DepEventPayloadSenderAdapterTest {

    private DepEventPayloadSenderAdapter instance;

    @Mock
    private DataEngineeringTopicService dataEngineeringTopicService;

    @Mock
    private PubSubEventBuilder pubSubEventBuilder;

    @BeforeEach
    void init() {
        initMocks(this);
        instance = new DepEventPayloadSenderAdapter(dataEngineeringTopicService, pubSubEventBuilder);
    }

    @SneakyThrows
    @Test
    void publish() {

        //Given
        String jsonPayload = "Test-jsonPayload";
        DepEventPayload mockPayload = mock(DepEventPayload.class);
        ChangeContext changeContext = mock(ChangeContext.class);
        PubSubEvent pubSubEvent = mock(PubSubEvent.class);
        PubSubEncryptedData pubSubEncryptedData = mock(PubSubEncryptedData.class);

        DepEventDataHolder dataHolder = DepEventDataHolder.builder()
            .payloadJson(jsonPayload)
            .changeContext(changeContext)
            .eventName(DepEventName.I9_AUDIT_DETAIL.name())
            .build();

        //When
        when(pubSubEventBuilder.buildAuditEvent(dataHolder, pubSubEncryptedData)).thenReturn(pubSubEvent);

        //Execute
        instance.publish(mockPayload, changeContext, DepEventName.I9_AUDIT_DETAIL);

        //Verify
        verify(dataEngineeringTopicService).sendEvent(any(DepEventDataHolder.class), any(BiFunction.class));
    }
}
