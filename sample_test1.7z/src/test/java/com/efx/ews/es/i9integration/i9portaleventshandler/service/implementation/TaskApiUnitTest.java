package com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.equalToJson;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.getRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.postRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlMatching;

import com.efx.ews.es.eev.barricade.common.model.BarricadeKeyStore;
import com.efx.ews.es.eev.barricade.common.service.CryptographyService;
import com.efx.ews.es.eev.barricade.common.service.PubSubEncryptionService;
import com.efx.ews.es.i9integration.i9portaleventshandler.ServiceCalls;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.TaskApiProperties;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.matching.RequestPatternBuilder;
import com.github.tomakehurst.wiremock.matching.StringValuePattern;
import com.github.tomakehurst.wiremock.matching.UrlPattern;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@SpringBootTest
@ExtendWith(SpringExtension.class)
@Slf4j
public class TaskApiUnitTest {

    @Autowired protected ServiceCalls serviceCalls;
    @Autowired protected TaskApiProperties taskApiProperties;

    @MockBean List<BarricadeKeyStore> barricadeKeyStores;
    @MockBean CryptographyService cryptographyService;
    @MockBean protected PubSubEncryptionService pubSubEncryptionService;
    @MockBean protected ReferenceApiService referenceApiService;

    protected RequestPatternBuilder checkTaskFamilyExistence;
    protected RequestPatternBuilder checkTaskGroupExistence;
    protected RequestPatternBuilder checkSection2TaskTypeExistence;
    protected RequestPatternBuilder checkSSNAppliedTaskTypeExistence;
    protected RequestPatternBuilder checkSection2UploadLaterTaskTypeExistence;
    protected RequestPatternBuilder checkReceiptUpdateSectionTwoTaskTypeExistence;
    protected RequestPatternBuilder checkSection2AnywhereTaskTypeExistence;
    protected RequestPatternBuilder checkSection2CovidFollowUpTaskTypeExistence;

    protected RequestPatternBuilder createSection2TaskType;
    protected RequestPatternBuilder createSSNAppliedTaskType;
    protected RequestPatternBuilder createSection2UploadLaterTaskType;
    protected RequestPatternBuilder createReceiptUpdateSectionTwoTaskType;
    protected RequestPatternBuilder createSection2AnywhereTaskType;
    protected RequestPatternBuilder schedulerDateUpdatedTaskType;
    protected RequestPatternBuilder createSection2CovidFollowUpTaskType;
    protected RequestPatternBuilder createCovidDocumentInspectionTaskType;

    protected void setupWireMock() {

        checkTaskFamilyExistence = getRequestedFor(WireMock.urlEqualTo("/internal/es-platform/task-management/v1/task-families/I9%20Form"));
        checkTaskGroupExistence = getRequestedFor(WireMock.urlEqualTo("/internal/es-platform/task-management/v1/task-groups/es-portal"));
        checkSection2TaskTypeExistence = getRequestedFor(WireMock.urlEqualTo("/internal/es-platform/task-management/v1/task-types/I9:Section2"));
        checkSSNAppliedTaskTypeExistence = getRequestedFor(WireMock.urlEqualTo("/internal/es-platform/task-management/v1/task-types/I9:SSNApplied"));
        checkSection2UploadLaterTaskTypeExistence = getRequestedFor(WireMock.urlEqualTo("/internal/es-platform/task-management/v1/task-types/I9:Section2UploadLater"));
        checkReceiptUpdateSectionTwoTaskTypeExistence = getRequestedFor(WireMock.urlEqualTo("/internal/es-platform/task-management/v1/task-types/I9:ReceiptUpdate"));
        checkSection2AnywhereTaskTypeExistence = getRequestedFor(WireMock.urlEqualTo("/internal/es-platform/task-management/v1/task-types/I9:Section2Anywhere"));
        checkSection2CovidFollowUpTaskTypeExistence = getRequestedFor(WireMock.urlEqualTo("/internal/es-platform/task-management/v1/task-types/I9:CovidFollowUp"));

        UrlPattern postTaskType = WireMock.urlEqualTo("/internal/es-platform/task-management/v1/task-types");

        StringValuePattern section2TaskTypeRequest = equalToJson("{"
            + "\"code\": \"I9:Section2\","
            + "\"name\": \"Pending I9\","
            + "\"taskGroupId\": \"f046c85a-c206-4845-b67b-7dce695169cd\","
            + "\"taskProcessorUrlTemplate\": \"i9/section2/document-selection/[id]\","
            + "\"workerSecurityFunction\": \"EEV.I9_SECTION_2_EDIT\""
            + "}");

        StringValuePattern ssnAppliedTaskTypeRequest = equalToJson("{"
            + "\"code\": \"I9:SSNApplied\","
            + "\"name\": \"Pending SSN\","
            + "\"taskGroupId\": \"f046c85a-c206-4845-b67b-7dce695169cd\","
            + "\"taskProcessorUrlTemplate\": \"\","
            + "\"workerSecurityFunction\": \"EEV.I9_READ\""
            + "}");

        StringValuePattern section2UploadLaterTaskTypeRequest = equalToJson("{"
            + "\"code\": \"I9:ReceiptUpdate\","
            + "\"name\": \"Receipt update\","
            + "\"taskGroupId\": \"f046c85a-c206-4845-b67b-7dce695169cd\","
            + "\"taskProcessorUrlTemplate\": \"apps/portal/i9/section2/receipt-update/task/[id]\","
            + "\"workerSecurityFunction\": \"EEV.I9_SECTION_2_EDIT\""
            + "}");

        StringValuePattern receiptUpdateSectionTwoTaskTypeRequest = equalToJson("{"
            + "\"code\": \"I9:Section2Anywhere\","
            + "\"name\": \"I-9 Anywhere\","
            + "\"taskGroupId\": \"f046c85a-c206-4845-b67b-7dce695169cd\","
            + "\"taskProcessorUrlTemplate\": \"\","
            + "\"workerSecurityFunction\": \"EMPLOYER_PERSON.I9_INFORMATION_TAB\""
            + "}");

        StringValuePattern section2AnywhereTaskTypeRequest = equalToJson("{"
            + "\"code\": \"I9:Section2Anywhere\","
            + "\"name\": \"I-9 Anywhere\","
            + "\"taskGroupId\": \"f046c85a-c206-4845-b67b-7dce695169cd\","
            + "\"taskProcessorUrlTemplate\": \"\","
            + "\"workerSecurityFunction\": \"EMPLOYER_PERSON.I9_INFORMATION_TAB\""
            + "}");

        StringValuePattern schedulerDateUpdatedTypeRequest = equalToJson("{"
            + "\"code\": \"I9:Section3\","
            + "\"name\": \"I-9 Reverification\","
            + "\"taskGroupId\": \"f046c85a-c206-4845-b67b-7dce695169cd\","
            + "\"taskProcessorUrlTemplate\": \"apps/portal/i9/section3/task/[id]\","
            + "\"workerSecurityFunction\": \"EEV.I9_READ\""
            + "}");

        StringValuePattern section2CovidFollowUpRequest = equalToJson("{"
            + "\"code\": \"I9:CovidFollowUp\","
            + "\"name\": \"Covid-19 Follow-up\","
            + "\"taskGroupId\": \"f046c85a-c206-4845-b67b-7dce695169cd\","
            + "\"taskProcessorUrlTemplate\": \"i9/section2/covid-document-update/task/[id]\","
            + "\"workerSecurityFunction\": \"TASK.I9_SECTION_2\""
            + "}");

        StringValuePattern section2CovidDocumentInspectionTaskTypeRequest = equalToJson("{"
            + "\"code\": \"I9:CovidDocumentInspection\","
            + "\"name\": \"Covid-19 Document Inspection\","
            + "\"taskGroupId\": \"f046c85a-c206-4845-b67b-7dce695169cd\","
            + "\"taskProcessorUrlTemplate\": \"i9/section2/covid-document-inspection/task/[id]\","
            + "\"workerSecurityFunction\": \"TASK.I9_SECTION_2\""
            + "}");

        createSection2TaskType = postRequestedFor(postTaskType).withRequestBody(section2TaskTypeRequest);
        createSSNAppliedTaskType = postRequestedFor(postTaskType).withRequestBody(ssnAppliedTaskTypeRequest);
        createSection2UploadLaterTaskType = postRequestedFor(postTaskType).withRequestBody(section2UploadLaterTaskTypeRequest);
        createReceiptUpdateSectionTwoTaskType = postRequestedFor(postTaskType).withRequestBody(receiptUpdateSectionTwoTaskTypeRequest);
        createSection2AnywhereTaskType = postRequestedFor(postTaskType).withRequestBody(section2AnywhereTaskTypeRequest);
        schedulerDateUpdatedTaskType = postRequestedFor(postTaskType).withRequestBody(schedulerDateUpdatedTypeRequest);
        createSection2CovidFollowUpTaskType = postRequestedFor(postTaskType).withRequestBody(section2CovidFollowUpRequest);
        createCovidDocumentInspectionTaskType = postRequestedFor(postTaskType).withRequestBody(section2CovidDocumentInspectionTaskTypeRequest);

        serviceCalls.taskApi
            .stubFor(post("/internal/es-platform/task-management/v1/task-families")
                .willReturn(aResponse().withStatus(HttpStatus.CREATED.value())
                    .withHeader("Content-Type", "application/json")
                    .withBodyFile("taskFamilyResponse.json")));

        serviceCalls.taskApi
            .stubFor(post("/internal/es-platform/task-management/v1/task-groups")
                .willReturn(aResponse().withStatus(HttpStatus.CREATED.value())
                    .withHeader("Content-Type", "application/json")
                    .withBodyFile("taskGroupResponse.json")));

        serviceCalls.taskApi
            .stubFor(post("/internal/es-platform/task-management/v1/task-types")
                .willReturn(aResponse().withStatus(HttpStatus.CREATED.value())
                    .withHeader("Content-Type", "application/json")
                    .withBodyFile("taskTypeResponse.json")));
    }

    protected void setupExistingTaskDefinitions() {
        serviceCalls.taskApi
            .stubFor(get(urlMatching("/internal/es-platform/task-management/v1/task-families/[A-Za-z0-9%-]+"))
                .willReturn(aResponse().withStatus(HttpStatus.OK.value())
                    .withHeader("Content-Type", "application/json")
                    .withBodyFile("taskFamilyResponse.json")));

        serviceCalls.taskApi
            .stubFor(get(urlMatching("/internal/es-platform/task-management/v1/task-groups/[A-Za-z0-9%-]+"))
                .willReturn(aResponse().withStatus(HttpStatus.OK.value())
                    .withHeader("Content-Type", "application/json")
                    .withBodyFile("taskGroupResponse.json")));

        serviceCalls.taskApi
            .stubFor(get(urlMatching("/internal/es-platform/task-management/v1/task-types/[A-Za-z0-9%-:]+"))
                .willReturn(aResponse().withStatus(HttpStatus.OK.value())
                    .withHeader("Content-Type", "application/json")
                    .withBodyFile("taskTypeResponse.json")));
    }

    protected void setupNonExistingTaskDefinitions() {
        serviceCalls.taskApi
            .stubFor(get(urlMatching("/internal/es-platform/task-management/v1/task-families/[A-Za-z0-9%-]+"))
                .willReturn(aResponse().withStatus(HttpStatus.NOT_FOUND.value())
                    .withHeader("Content-Type", "application/json")
                    .withBodyFile("taskInvalidCode.json")));

        serviceCalls.taskApi
            .stubFor(get(urlMatching("/internal/es-platform/task-management/v1/task-groups/[A-Za-z0-9%-]+"))
                .willReturn(aResponse().withStatus(HttpStatus.NOT_FOUND.value())
                    .withHeader("Content-Type", "application/json")
                    .withBodyFile("taskInvalidCode.json")));

        serviceCalls.taskApi
            .stubFor(get(urlMatching("/internal/es-platform/task-management/v1/task-types/[A-Za-z0-9%-:]+"))
                .willReturn(aResponse().withStatus(HttpStatus.NOT_FOUND.value())
                    .withHeader("Content-Type", "application/json")
                    .withBodyFile("taskInvalidCode.json")));
    }

    protected void setupServiceUnavailableTaskApiResponse() {
        serviceCalls.taskApi
            .stubFor(get(urlMatching("/internal/es-platform/task-management/v1/task-families/[A-Za-z0-9%-]+"))
                .willReturn(aResponse().withStatus(HttpStatus.SERVICE_UNAVAILABLE.value())
                    .withHeader("Content-Type", "application/json")
                    .withBodyFile("taskInvalidCode.json")));

        serviceCalls.taskApi
            .stubFor(get(urlMatching("/internal/es-platform/task-management/v1/task-groups/[A-Za-z0-9%-]+"))
                .willReturn(aResponse().withStatus(HttpStatus.SERVICE_UNAVAILABLE.value())
                    .withHeader("Content-Type", "application/json")
                    .withBodyFile("taskInvalidCode.json")));

        serviceCalls.taskApi
            .stubFor(get(urlMatching("/internal/es-platform/task-management/v1/task-types/[A-Za-z0-9%-:]+"))
                .willReturn(aResponse().withStatus(HttpStatus.SERVICE_UNAVAILABLE.value())
                    .withHeader("Content-Type", "application/json")
                    .withBodyFile("taskInvalidCode.json")));
    }
}
