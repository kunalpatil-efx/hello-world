package com.efx.ews.es.i9datasourcing.fieldconverter;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Map;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.Test;

class ESignatureConverterTest {

    @Test
    public void shouldConvertFieldsWithESignatureConverter() {

        final ESignatureConverter converter = new ESignatureConverter("sectionOne.employeeInfo.socialSecurityNumber");

        { // the given key is not present

            Map<String, String> mockedFlattenedI9Form = Map.of(
                "irrelevant.key", "Bbb");

            String convertedValue = converter.convert(mockedFlattenedI9Form);

            assertThat(convertedValue).isEqualTo(StringUtils.EMPTY);
        }
        { // the given key is present, but is empty string

            Map<String, String> mockedFlattenedI9Form = Map.of(
                "sectionOne.employeeInfo.socialSecurityNumber", "");

            String convertedValue = converter.convert(mockedFlattenedI9Form);

            assertThat(convertedValue).isEqualTo(StringUtils.EMPTY);
        }
        { // the given key is present, but is blank

            Map<String, String> mockedFlattenedI9Form = Map.of(
                "sectionOne.employeeInfo.socialSecurityNumber", " ");

            String convertedValue = converter.convert(mockedFlattenedI9Form);

            assertThat(convertedValue).isEqualTo(StringUtils.EMPTY);
        }
        { // Happy Path: the given key is in the map, so return E-signature

            Map<String, String> mockedFlattenedI9Form = Map.of(
                "sectionOne.employeeInfo.socialSecurityNumber", "98765432");

            String convertedValue = converter.convert(mockedFlattenedI9Form);

            assertThat(convertedValue).isEqualTo("E-signature");
        }
    }
}