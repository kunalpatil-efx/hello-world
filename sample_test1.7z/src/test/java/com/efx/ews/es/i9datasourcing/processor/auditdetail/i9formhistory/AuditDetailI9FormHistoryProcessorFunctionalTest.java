package com.efx.ews.es.i9datasourcing.processor.auditdetail.i9formhistory;

import static org.assertj.core.api.Assertions.assertThat;

import com.efx.ews.es.historyprovider.util.JsonPayloadExpanderUtil;
import com.efx.ews.es.i9datasourcing.constant.DepEventName;
import com.efx.ews.es.i9datasourcing.constant.I9Event;
import com.efx.ews.es.i9datasourcing.data.MockI9FormData;
import com.efx.ews.es.i9datasourcing.dep.api.DepEventPayloadSender;
import com.efx.ews.es.i9datasourcing.dep.model.DepEventPayload;
import com.efx.ews.es.i9datasourcing.formatter.DefaultTemporalFormatter;
import com.efx.ews.es.i9datasourcing.model.ChangeContext;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

@Slf4j
class AuditDetailI9FormHistoryProcessorFunctionalTest {

    private CollectingDepEventPayloadSender collectingDepPubSubSender;
    private AuditDetailI9FormHistoryProcessor auditDetailProcessor;

    @BeforeEach
    public void setUp() {
        collectingDepPubSubSender = new CollectingDepEventPayloadSender();
        var sectionDescriptionProvider = new SectionDescriptionProvider();
        var signatureMethodProvider = new SignatureMethodProvider();
        var temporalFormatter = new DefaultTemporalFormatter();
        var i9FormSingleChangeProcessorBuilder = new I9FormSingleChangeProcessorBuilder(
            collectingDepPubSubSender,
            sectionDescriptionProvider, signatureMethodProvider, temporalFormatter);
        var convertedI9FormDiffProcessor = new ConvertedI9FormDiffProcessor();
        auditDetailProcessor = new AuditDetailI9FormHistoryProcessor(convertedI9FormDiffProcessor,
            i9FormSingleChangeProcessorBuilder);
    }

    @Test
    void i9FormChangePubSubPayloadsGenerationTest() {
        // given
        Map<String, String> convertedI9FormBefore = Map.of(
            ReportField.SSN.sourceLabel, "v1",
            ReportField.LAST_NAME.sourceLabel, "v2",
            ReportField.FIRST_NAME.sourceLabel, "v3",
            ReportField.MIDDLE_INITIAL.sourceLabel, "v4",
            ReportField.DATE_OF_BIRTH.sourceLabel, "v5",
            "SIGNATURE_METHOD", "v6",
            ReportField.LOCATION_CODE.sourceLabel, "v7",
            "FIELD_1", "v8",
            "SECTION_ONE.EMPLOYEE_INFO.SIGNATURE.SIGNATURE_DATE", "v9",
            "FIELD_3", "v10");

        Map<String, String> convertedI9FormAfter = Map.of(
            ReportField.SSN.sourceLabel, "v1",
            ReportField.LAST_NAME.sourceLabel, "v2-changed",
            ReportField.FIRST_NAME.sourceLabel, "v3",
            ReportField.MIDDLE_INITIAL.sourceLabel, "v4",
            ReportField.DATE_OF_BIRTH.sourceLabel, "v5",
            "SIGNATURE_METHOD", "v6",
            ReportField.LOCATION_CODE.sourceLabel, "v7",
            "FIELD_1", "v8-changed",
            "SECTION_ONE.EMPLOYEE_INFO.SIGNATURE.SIGNATURE_DATE", "v9",
            "FIELD_4", "v11");

        ChangeContext changeContext = new ChangeContext(
            "c1",
            "c2",
            I9Event.SECTION_1_COMPLETE,
            "c3",
            "",
            "",
            ZonedDateTime.now(ZoneOffset.UTC),
            "c4",
            "messageId-1");

        // when
        auditDetailProcessor.process(convertedI9FormBefore, convertedI9FormAfter, changeContext);

        // then
        var expectedResult = MockI9FormData.buildExpectedResultI9FormChange();

        assertThat(collectingDepPubSubSender.getDepEventExpandedPayloads())
            .containsExactlyInAnyOrderElementsOf(expectedResult);
    }

    @Test
    void i9FormCreatedPubSubPayloadsGenerationTest() {
        // given
        Map<String, String> convertedI9FormAfter = Map.of(
            ReportField.SSN.sourceLabel, "v1",
            ReportField.LAST_NAME.sourceLabel, "v2",
            ReportField.FIRST_NAME.sourceLabel, "v3",
            ReportField.MIDDLE_INITIAL.sourceLabel, "v4",
            ReportField.DATE_OF_BIRTH.sourceLabel, "v5",
            "SIGNATURE_METHOD", "v6",
            ReportField.LOCATION_CODE.sourceLabel, "v7",
            "SECTION_ONE.EMPLOYEE_INFO.SIGNATURE.SIGNATURE_DATE", "v8");

        ChangeContext changeContext = new ChangeContext(
            "c1",
            "c2",
            I9Event.SECTION_1_COMPLETE,
            "c3",
            "",
            "",
            ZonedDateTime.now(ZoneOffset.UTC),
            "c4",
            "messageId-1");

        // when
        auditDetailProcessor.process(null, convertedI9FormAfter, changeContext);

        // then
        var expectedResult = MockI9FormData.buildI9FormCreatedPubSubPayloads();

        assertThat(collectingDepPubSubSender.getDepEventExpandedPayloads())
            .containsExactlyInAnyOrderElementsOf(expectedResult);
    }

    static class CollectingDepEventPayloadSender implements DepEventPayloadSender {

        @Getter
        private final List<String> depEventExpandedPayloads = new ArrayList<>();

        @Override
        public void publish(DepEventPayload eventPayload, ChangeContext changeContext, DepEventName eventName) {
            eventPayload.getFields().stream()
                .filter(item -> item.getName().equals(ReportField.EVENT_CREATE_TS.targetLabel)
                    || item.getName().equals(ReportField.CREATE_TS.targetLabel))
                .forEach(item -> item.setValue("*"));
            var payload = JsonPayloadExpanderUtil.expand(eventPayload);
            log.info("Publishing event {}", eventPayload);
            depEventExpandedPayloads.add(payload);
        }
    }
}
