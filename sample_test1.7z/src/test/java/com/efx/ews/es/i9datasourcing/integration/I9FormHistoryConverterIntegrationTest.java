package com.efx.ews.es.i9datasourcing.integration;

import static com.efx.ews.es.i9datasourcing.util.ReaderUtil.I9_FORMS_PATH;
import static com.efx.ews.es.i9datasourcing.util.TestConstants.INTEGRATION_TEST;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.clearInvocations;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.skyscreamer.jsonassert.JSONAssert.assertEquals;

import com.efx.ews.es.dto.LocationDto;
import com.efx.ews.es.eev.barricade.common.model.BarricadeKeyStore;
import com.efx.ews.es.eev.barricade.common.model.PubSubEncryptedData;
import com.efx.ews.es.eev.barricade.common.service.CryptographyService;
import com.efx.ews.es.eev.barricade.common.service.PubSubEncryptionService;
import com.efx.ews.es.i9datasourcing.I9FormHistoryConverter;
import com.efx.ews.es.i9datasourcing.config.TestConfig;
import com.efx.ews.es.i9datasourcing.dep.api.DepEventPayloadSender;
import com.efx.ews.es.i9datasourcing.model.ChangeContext;
import com.efx.ews.es.i9datasourcing.provider.LocationDataProvider;
import com.efx.ews.es.i9datasourcing.util.JsonReaderUtil;
import com.efx.ews.es.i9datasourcing.util.ReaderUtil;
import com.efx.ews.es.i9datasourcing.util.WriterUtil;
import com.efx.ews.es.i9integration.i9portaleventshandler.I9PortalEventsHandlerApplication;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.I9Form;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.pubsub.PubSubEvent;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.GooglePublisherService;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.ReferenceApiService;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.ArgumentCaptor;
import org.mockito.ArgumentMatchers;
import org.mockito.Captor;
import org.skyscreamer.jsonassert.JSONCompareMode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.SpyBean;
import reactor.core.publisher.Mono;

@SpringBootTest(classes = {I9PortalEventsHandlerApplication.class, TestConfig.class})
@Slf4j
@Tag(INTEGRATION_TEST)
class I9FormHistoryConverterIntegrationTest {

    private static final int JSON_INDENT_SPACES = 2;

    @Autowired
    private I9FormHistoryConverter instance;

    @SpyBean
    private DepEventPayloadSender depEventPayloadSender;

    @SpyBean
    private GooglePublisherService googlePublisherService;

    @MockBean
    private LocationDataProvider locationDataProvider;

    @MockBean
    private PubSubEncryptionService encryptionService;

    @MockBean
    private List<BarricadeKeyStore> barricadeKeyStores;

    @MockBean
    private CryptographyService cryptographyService;

    @Captor
    private ArgumentCaptor<PubSubEvent> eventCaptor;
    @MockBean
    private ReferenceApiService referenceApiService;

    @BeforeEach
    public void setUp() {
        when(locationDataProvider.getLocation(ArgumentMatchers.any(UUID.class), ArgumentMatchers.any(UUID.class)))
            .thenReturn(Mono.just(new LocationDto().setLocationName("Manteo Office")));
        when(encryptionService.encrypt(any())).thenAnswer(invocation -> {
            byte[] payload = invocation.getArgument(0);
            return new PubSubEncryptedData(new String(payload), "encryptionMetadata", "gcsBucketPath");
        });
    }

    @ParameterizedTest
    @MethodSource("testCases")
    void shouldProcessHistoryConverter(TestCase testCase) throws Exception {
        // call test method
        instance.convert(testCase.i9before, testCase.i9after, testCase.changeContext);
        // read actual events
        verify(googlePublisherService, atLeastOnce()).sendEvent(eventCaptor.capture());
        List<JSONObject> depEventPayloads = eventCaptor.getAllValues().stream()
            .map(PubSubEvent::getEventPayload)
            .map(JsonReaderUtil::parseJSONObject)
            .collect(Collectors.toList());
        clearInvocations(googlePublisherService);
        // gather actual events
        JSONObject actualSummaryEvent = depEventPayloads.get(0);
        var actualDetailEvents = sortByFieldName(depEventPayloads.subList(1, depEventPayloads.size()));
        // write actual events to file
        WriterUtil.writeActualI9SummaryEvent(testCase.name, actualSummaryEvent.toString(JSON_INDENT_SPACES));
        WriterUtil.writeActualI9AuditDetailEvents(testCase.name, new JSONArray(actualDetailEvents).toString(2));
        // assert events
        assertEquals(testCase.expectedResult.summaryEvent, actualSummaryEvent, JSONCompareMode.NON_EXTENSIBLE);
        var expectedDetailEvents = sortByFieldName(testCase.expectedResult.detailEvents);
        for (int i = 0; i < expectedDetailEvents.size(); i++) {
            assertEquals(expectedDetailEvents.get(i), actualDetailEvents.get(i), JSONCompareMode.NON_EXTENSIBLE);
        }
    }

    public List<JSONObject> sortByFieldName(List<JSONObject> jsonObjects) {
        return jsonObjects.stream()
            .sorted(Comparator.comparing(this::getFieldName))
            .collect(Collectors.toList());
    }

    private String getFieldName(JSONObject jsonObject) {
        try {
            return jsonObject.getJSONObject("UPDATE_DTLS").getString("FIELD_NAME");
        } catch (JSONException e) {
            throw new IllegalArgumentException("Not found UPDATE_DTLS.FIELD_NAME key");
        }
    }

    private static Stream<TestCase> testCases() {
        return ReaderUtil.listI9TestCases().map(TestCase::create);
    }

    static class TestCase {

        private static final String I9_BEFORE_FILENAME = "i9-before.json";
        private static final String I9_AFTER_FILENAME = "i9-after.json";
        private static final String SUMMARY_FILENAME = "expected/summary_event.json";
        private static final String AUDIT_DETAIL_EVENTS_FILENAME = "expected/audit_detail_events.json";
        private static final String CHANGE_CTX_FILENAME = "change-context.json";

        private String name;
        private I9Form i9after;
        private I9Form i9before;
        private ChangeContext changeContext;
        private ExpectedResult expectedResult;

        public static TestCase create(String testName) {
            TestCase testCase = new TestCase();
            testCase.name = testName;
            testCase.i9after = ReaderUtil.readFromFile(testName, I9_AFTER_FILENAME, I9Form.class, I9_FORMS_PATH);
            testCase.i9before = ReaderUtil.readFromFile(testName, I9_BEFORE_FILENAME, I9Form.class, I9_FORMS_PATH);
            testCase.changeContext = ReaderUtil
                .readFromFile(testName, CHANGE_CTX_FILENAME, ChangeContext.class, I9_FORMS_PATH);

            var summaryEvent = JsonReaderUtil.readFromFile(testName, SUMMARY_FILENAME, I9_FORMS_PATH);
            var auditDetailEvents = JsonReaderUtil
                .readListFromFile(testName, AUDIT_DETAIL_EVENTS_FILENAME, I9_FORMS_PATH);
            testCase.expectedResult = ExpectedResult.of(summaryEvent, auditDetailEvents);
            return testCase;
        }

        @Override
        public String toString() {
            return name;
        }
    }

    @AllArgsConstructor(staticName = "of")
    static class ExpectedResult {

        final JSONObject summaryEvent;
        final List<JSONObject> detailEvents;
    }
}