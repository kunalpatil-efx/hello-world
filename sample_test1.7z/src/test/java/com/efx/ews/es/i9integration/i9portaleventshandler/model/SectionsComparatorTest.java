package com.efx.ews.es.i9integration.i9portaleventshandler.model;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.AdditionalInformation;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.AlienAuthorizedToWork;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.Attestation;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.Document;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.Employee;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.EmployeeInfo;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.LawfulPermanentResidentInfo;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.ListA;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.ListB;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.ListC;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.pdfGenerator.Employer;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.pdfGenerator.Metadata;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.pdfGenerator.Preparer;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.pdfGenerator.SectionOne;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.pdfGenerator.SectionTwo;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.pdfGenerator.SectionsComparator;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Slf4j
public class SectionsComparatorTest {
    private static final Long RECORD_VERSION = 2L;

    private static final List<String> IGNORED_FIELDS =  List.of(
        "preparers",
        "version",
        "additionalInformation",
        "signatureDate",
        "S2_CITIZEN_STATUS");

    private SectionOne sampleSectionOne() {
        SectionOne sectionOne = new SectionOne();
        sectionOne.setSignatureText("signatureText");
        sectionOne.setSignature("signature");
        sectionOne.setSignatureDate("08/27/2020");
        sectionOne.setEmployeeInfo(getEmployeeInfoData());
        sectionOne.setMetadata(getMetadata());
        sectionOne.setAttestation(getAttestationData());
        sectionOne.setPreparers(getPreparers());
        sectionOne.setVersion(RECORD_VERSION);
        return sectionOne;
    }

    private static Metadata getMetadata() {
        Metadata metadata = new Metadata();
        metadata.setEverify(false);
        metadata.setSpecialPlacement(true);
        metadata.setValidListBDocs(true);
        return metadata;
    }

    private static EmployeeInfo getEmployeeInfoData() {
        EmployeeInfo employeeInfo = new EmployeeInfo();
        employeeInfo.setFirstName("Jack");
        employeeInfo.setLastName("Test");
        employeeInfo.setMiddleInitial("E");
        employeeInfo.setSocialSecurityNumber("888888888");
        employeeInfo.setZipCode("12345");
        employeeInfo.setCity("Krakow");
        employeeInfo.setAddress("Opolska 110");
        employeeInfo.setState("MO");
        employeeInfo.setDateOfBirth("1924-02-12");
        return employeeInfo;
    }

    private static Attestation getAttestationData() {
        Attestation attestation = new Attestation();
        LawfulPermanentResidentInfo lawfulPermanentResident = new LawfulPermanentResidentInfo();
        attestation.setIsAlienAuthorizedToWork(false);
        attestation.setIsLawfulPermanentResident(true);
        attestation.setIsNonCitizenNational(false);
        attestation.setIsUnitedStatesCitizen(false);
        lawfulPermanentResident.setAlienRegistrationNumber("1234567");
        attestation.setLawfulPermanentResidentInfo(lawfulPermanentResident);
        return attestation;
    }

    private static List<Preparer> getPreparers() {
        Preparer preparer1 = new Preparer();
        preparer1.setSignature("preparersSignature");
        preparer1.setFirstName("John");
        preparer1.setLastName("Doe");
        preparer1.setState("MO");
        preparer1.setAddress("Opolska 144");
        preparer1.setCity("Krakow");
        preparer1.setRecordVersion(RECORD_VERSION - 1);
        Preparer preparer2 = new Preparer();
        preparer2.setSignature("preparersSignature");
        preparer2.setFirstName("Anna");
        preparer2.setLastName("Kowalska");
        preparer2.setState("IL");
        preparer2.setAddress("Opolska 144");
        preparer2.setCity("Chicago");
        preparer2.setRecordVersion(RECORD_VERSION - 1);
        final ArrayList<Preparer> preparers = new ArrayList<>();
        preparers.add(preparer1);
        preparers.add(preparer2);
        return preparers;
    }

    private static SectionOne emptySectionOne() {
        final SectionOne sectionOne = new SectionOne();
        Attestation attestation = new Attestation();
        attestation.setLawfulPermanentResidentInfo(new LawfulPermanentResidentInfo());
        sectionOne.setAttestation(attestation);
        final EmployeeInfo employeeInfo = new EmployeeInfo();
        sectionOne.setEmployeeInfo(employeeInfo);
        final Metadata metadata = new Metadata();
        sectionOne.setMetadata(metadata);
        sectionOne.setVersion(RECORD_VERSION);
        return sectionOne;
    }

    private void mapIgnoredField(SectionOne amendment, SectionOne expectedAmendment) {
        expectedAmendment.setSignatureDate(amendment.getSignatureDate());
    }

    @Test
    public void employeeInfoDiffers() {
        final SectionOne reference = sampleSectionOne();
        final SectionOne amendment = sampleSectionOne();
        final String employeeInfoDifference = "different@equifax.com";
        amendment.getEmployeeInfo().setEmail(employeeInfoDifference);
        final SectionOne expectedAmendment = emptySectionOne();
        mapIgnoredField(amendment, expectedAmendment);
        expectedAmendment.getEmployeeInfo().setEmail(employeeInfoDifference);
        assertSectionOneAmendment(reference, amendment, expectedAmendment);
    }

    @Test
    public void amendmentIsSame() {
        final SectionOne reference = sampleSectionOne();
        final SectionOne amendment = sampleSectionOne();
        final SectionOne expectedAmendment = emptySectionOne();
        mapIgnoredField(amendment, expectedAmendment);
        assertSectionOneAmendment(reference, amendment, expectedAmendment);
    }

    @Test
    public void attestationDiffers() {
        final SectionOne reference = sampleSectionOne();
        final SectionOne amendment = sampleSectionOne();
        // changing to false is not an amendment
        amendment.getAttestation().setIsLawfulPermanentResident(false);
        amendment.getAttestation().setIsUnitedStatesCitizen(true);
        // additional object in amendment
        AlienAuthorizedToWork alienAuthorizedToWorkData = new AlienAuthorizedToWork();
        alienAuthorizedToWorkData.setExpirationDate("08/27/2020");
        amendment.getAttestation().setAlienAuthorizedToWorkData(alienAuthorizedToWorkData);
        final SectionOne expectedAmendment = emptySectionOne();
        mapIgnoredField(amendment, expectedAmendment);
        expectedAmendment.getAttestation().setIsUnitedStatesCitizen(true);
        expectedAmendment.getAttestation().setAlienAuthorizedToWorkData(alienAuthorizedToWorkData);
        assertSectionOneAmendment(reference, amendment, expectedAmendment);
    }

    @Test
    public void rootObjectDiffers() {
        final SectionOne reference = sampleSectionOne();
        final SectionOne amendment = sampleSectionOne();
        amendment.setSignatureDate("08/01/2020");
        amendment.setSignatureText("noSignatureText");
        final SectionOne expectedAmendment = emptySectionOne();
        expectedAmendment.setSignatureDate("08/01/2020");
        expectedAmendment.setSignatureText("noSignatureText");
        mapIgnoredField(amendment, expectedAmendment);
        assertSectionOneAmendment(reference, amendment, expectedAmendment);
    }

    @Test
    public void preparerVersionIsRecordVersion() {
        final SectionOne reference = sampleSectionOne();
        final SectionOne amendment = sampleSectionOne();
        amendment.getPreparers().get(1).setRecordVersion(RECORD_VERSION);
        final SectionOne expectedAmendment = emptySectionOne();
        mapIgnoredField(amendment, expectedAmendment);
        expectedAmendment.setPreparers(Collections.singletonList(amendment.getPreparers().get(1)));

        assertSectionOneAmendment(reference, amendment, expectedAmendment);
    }

    @Test
    public void preparersHaveNoVersionAndDiffer() {
        final SectionOne reference = sampleSectionOne();
        reference.getPreparers().forEach(p -> p.setRecordVersion(null));
        final SectionOne amendment = sampleSectionOne();
        amendment.getPreparers().get(1).setCity("Oklahoma");
        amendment.getPreparers().forEach(p -> p.setRecordVersion(null));
        final SectionOne expectedAmendment = emptySectionOne();
        mapIgnoredField(amendment, expectedAmendment);
        expectedAmendment.setPreparers(getPreparers());
        expectedAmendment.getPreparers().get(1).setCity("Oklahoma");
        expectedAmendment.getPreparers().forEach(p -> p.setRecordVersion(null));
        assertSectionOneAmendment(reference, amendment, expectedAmendment);
    }

    @Test
    public void newPreparerIsAdded() {
        final SectionOne reference = sampleSectionOne();
        final SectionOne amendment = sampleSectionOne();
        Preparer newPreparer = new Preparer();
        newPreparer.setFirstName("Joe");
        newPreparer.setLastName("Black");
        newPreparer.setRecordVersion(RECORD_VERSION);
        amendment.getPreparers().add(newPreparer);
        final SectionOne expectedAmendment = emptySectionOne();
        mapIgnoredField(amendment, expectedAmendment);
        Preparer expectedAddedPreparer = new Preparer();
        expectedAddedPreparer.setFirstName("Joe");
        expectedAddedPreparer.setLastName("Black");
        expectedAddedPreparer.setRecordVersion(RECORD_VERSION);
        expectedAmendment.setPreparers(Collections.singletonList(expectedAddedPreparer));

        assertSectionOneAmendment(reference, amendment, expectedAmendment);
    }

    private void assertSectionOneAmendment(SectionOne reference, SectionOne amendment, SectionOne expectedAmendment) {
        SectionsComparator sectionsComparator = new SectionsComparator(IGNORED_FIELDS);
        sectionsComparator.eraseUnchanged(reference, amendment);
        Assert.assertEquals(expectedAmendment, amendment);
    }

    private SectionTwo sampleSectionTwo() {
        SectionTwo sectionTwo = new SectionTwo();
        sectionTwo.setListA(buildListA());
        sectionTwo.setListB(buildListB());
        sectionTwo.setListC(buildListC());
        sectionTwo.setEmployer(buildEmployerRepresentative());
        sectionTwo.setHireDate("2020-12-12");
        List<AdditionalInformation> additionalInformationList =new ArrayList<>();
        final AdditionalInformation additionalInformation = new AdditionalInformation();
        additionalInformation.setAdditionalInformationKey("i129FilingDate");
        additionalInformation.setAdditionalInformationValue("02-20-2020");
        additionalInformationList.add(additionalInformation);
        sectionTwo.setAdditionalInformation(additionalInformationList);
        return sectionTwo;
    }

    private static Employer buildEmployerRepresentative() {
        Employer er = new Employer();
        er.setFirstName("John");
        er.setLastName("Doe");
        er.setTitle("Mr");
        return er;
    }

    public static ListC buildListC() {
        ListC listC = new ListC();
        listC.setDocumentOne(buildDocumentOne());
        return listC;
    }

    public static ListB buildListB() {
        ListB listB = new ListB();
        listB.setDocumentOne(buildDocumentOne());
        return listB;
    }

    public static ListA buildListA() {
        ListA listA = new ListA();
        listA.setDocumentOne(buildDocumentOne());
        return listA;
    }

    private static Document buildDocumentOne() {
        Document document = new Document();
        document.setDocumentId("52A2276A-BDE3-4466-AA9B-D11022F2437F");
        document.setDocumentTitle("u.s.passport");
        document.setExpirationDate("2020-11-11");
        document.setDocumentNumber("45553113");
        document.setIssuingAuthority("IND");
        document.setIsReceipt(false);
        return document;
    }

    private static SectionTwo emptySectionTwo(){
        SectionTwo sectionTwo = new SectionTwo();
        sectionTwo.setEmployer(new Employer());
        final ListA listA = new ListA();
        listA.setDocumentOne(new Document());
        sectionTwo.setListA(listA);
        final ListB listB = new ListB();
        listB.setDocumentOne(new Document());
        sectionTwo.setListB(listB);
        final ListC listC = new ListC();
        listC.setDocumentOne(new Document());
        sectionTwo.setListC(listC);
        return sectionTwo;
    }

    @Test
    public void sectionTwo() {
        SectionTwo reference = sampleSectionTwo();
        SectionTwo amendment = sampleSectionTwo();
        SectionTwo expectedAmendment = emptySectionTwo();
        assertSectionTwoAmendment(reference, amendment, expectedAmendment);
    }

    @Test
    public void employer() {
        SectionTwo reference = sampleSectionTwo();
        SectionTwo amendment = sampleSectionTwo();
        final String amendedCity = "Las Vegas";
        amendment.getEmployer().setCity(amendedCity);
        SectionTwo expectedAmendment = emptySectionTwo();
        Employer amendedEmployer = new Employer();
        amendedEmployer.setCity(amendedCity);
        expectedAmendment.setEmployer(amendedEmployer);
        assertSectionTwoAmendment(reference, amendment, expectedAmendment);
    }

    @Test
    public void hireDate() {
        SectionTwo reference = sampleSectionTwo();
        SectionTwo amendment = sampleSectionTwo();
        final String amendedHireDate = "08/27/2020";
        amendment.setHireDate(amendedHireDate);
        SectionTwo expectedAmendment = emptySectionTwo();
        expectedAmendment.setHireDate(amendedHireDate);
        assertSectionTwoAmendment(reference, amendment, expectedAmendment);
    }

    @Test
    public void listADocumentChanged() {
        SectionTwo reference = sampleSectionTwo();
        SectionTwo amendment = sampleSectionTwo();
        final String listAdocumentOneTitle = "other title";
        amendment.getListA().getDocumentOne().setDocumentTitle(listAdocumentOneTitle);
        SectionTwo expectedAmendment = emptySectionTwo();
        expectedAmendment.getListA().getDocumentOne().setDocumentTitle(listAdocumentOneTitle);
        assertSectionTwoAmendment(reference, amendment, expectedAmendment);
    }

    @Test
    public void listADocumentAdded() {
        SectionTwo reference = sampleSectionTwo();
        SectionTwo amendment = sampleSectionTwo();
        Document amendedDocument = new Document();
        amendedDocument.setDocumentTitle("new document");
        amendment.getListA().setDocumentTwo(amendedDocument);
        SectionTwo expectedAmendment = emptySectionTwo();
        Document expectedAmendedDocument = new Document();
        expectedAmendedDocument.setDocumentTitle("new document");
        expectedAmendment.getListA().setDocumentTwo(expectedAmendedDocument);
        assertSectionTwoAmendment(reference, amendment, expectedAmendment);
    }

    @Test
    public void additionalInformation() {
        SectionTwo reference = sampleSectionTwo();
        SectionTwo amendment = sampleSectionTwo();
        AdditionalInformation additionalInformation = new AdditionalInformation();
        additionalInformation.setAdditionalInformationKey("key");
        additionalInformation.setAdditionalInformationValue("value");
        amendment.getAdditionalInformation().add(additionalInformation);
        SectionTwo expectedAmendment = emptySectionTwo();
        final List<AdditionalInformation> expectedAmendedAdditionalInformation = sampleSectionTwo().getAdditionalInformation();
        expectedAmendedAdditionalInformation.add(additionalInformation);
        expectedAmendment.setAdditionalInformation(expectedAmendedAdditionalInformation);

        assertSectionTwoAmendment(reference, amendment, expectedAmendment);
    }

    private void assertSectionTwoAmendment(SectionTwo reference, SectionTwo amendment, SectionTwo expectedAmendment) {
        SectionsComparator sectionsComparator = new SectionsComparator(IGNORED_FIELDS);
        sectionsComparator.eraseUnchanged(reference, amendment);
        Assert.assertEquals(expectedAmendment, amendment);
    }

    private static Employee sampleEmployee() {
        Employee employee = new Employee();
        employee.setFirstName("Jack");
        employee.setFirstName("Rabbit");
        return employee;
    }

    @Test
    public void sectionTwoEmployee(){
        Employee reference = sampleEmployee();
        Employee amendment = sampleEmployee();
        amendment.setLastName("Other");
        Employee expectedAmendment = new Employee();
        expectedAmendment.setLastName("Other");
        SectionsComparator sectionsComparator = new SectionsComparator(IGNORED_FIELDS);
        sectionsComparator.eraseUnchanged(reference, amendment);
        Assert.assertEquals(expectedAmendment, amendment);
    }
}
