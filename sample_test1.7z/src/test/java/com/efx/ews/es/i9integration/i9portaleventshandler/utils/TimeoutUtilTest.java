package com.efx.ews.es.i9integration.i9portaleventshandler.utils;

import org.junit.Assert;
import org.junit.Test;

import java.util.UUID;

public class TimeoutUtilTest {

    @Test
    public void testTimeouts() throws InterruptedException{
        String id = UUID.randomUUID().toString();
        TimeoutUtil util = new TimeoutUtil(500);
        Assert.assertTrue(util.isWithinTimeout(id));
        Assert.assertTrue(util.isWithinTimeout(id));
        Thread.sleep(600);
        Assert.assertFalse(util.isWithinTimeout(id));
        Assert.assertTrue(util.isWithinTimeout(id));
    }
}
