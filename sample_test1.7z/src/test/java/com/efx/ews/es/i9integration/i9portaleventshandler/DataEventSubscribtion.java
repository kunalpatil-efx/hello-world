package com.efx.ews.es.i9integration.i9portaleventshandler;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.stereotype.Component;

@Component
public class DataEventSubscribtion extends SinglePubSubMessagePublish {

    public DataEventSubscribtion(@Qualifier("DataEventSubscriberConfig") IntegrationFlow flow) {
        super(flow);
    }
}
