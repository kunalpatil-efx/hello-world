package com.efx.ews.es.i9integration.i9portaleventshandler;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.BytesToDocumentUpload;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.audit.IceAuditEntry;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.document.DocumentDownloadResponse;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.I9FormResponse;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.UpdateMetadataRequest;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.pdfGenerator.I9FormResponseToPdfGenerate;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.referenceapi.IssuingAuthorityLookup;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.ICEAuditProvider;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.DocumentApiCall;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.I9ApiCall;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.PdfGeneratorCall;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.ReferenceApiService;
import com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageConfirmation;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;

import static com.efx.ews.es.common.filter.CorrelationFilter.SESSION_ID_HEADER_NAME;
import static com.efx.ews.es.common.filter.CorrelationFilter.TRANSACTION_ID_HEADER_NAME;
import static org.junit.Assert.*;

import java.util.UUID;
import org.springframework.http.MediaType;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

public class S2UploadLaterPdfGenerationTest {

    private PdfGenerationSubscriber pdfGenerationSubscriber;

    @Mock
    private I9ApiCall i9ApiCall;

    private I9FormResponseToPdfGenerate i9FormResponseToPdfGenerate;

    @Mock
    private PdfGeneratorCall pdfGeneratorCall;

    @Mock
    private DocumentApiCall documentApiCall;

    @Mock
    private BytesToDocumentUpload bytesToDocumentUpload;

    @Mock
    private SubscriberErrorHandling errorHandling;

    @Mock
    private MessageConfirmation messageConfirmation;

    @Mock
    private ICEAuditProvider auditProvider;

    @Mock
    private ReferenceApiService referenceApiService;

//    String documentId;
//    I9FormResponse form;
//    PdfGenerationSubscriber.FormFixStatus formFixStatus;
//    UpdateMetadataRequest metadataRequest;
//    I9History history;

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    private static final String driverLicenseTitle = "Driver's License Issued by State or Possession with Photo";
    private static final String canadaDriverLicense = "Canadian Driver's license";
    private static final String stateIssuedIDCard = "ID Card Issued by State or Possession with Photo";
    private static final String foreignPassportTitle = "Foreign Passport";

    @Before
    public void setUp() {
        initMocks(this);
        i9FormResponseToPdfGenerate = new I9FormResponseToPdfGenerate(referenceApiService);
        pdfGenerationSubscriber = new PdfGenerationSubscriber(
            messageConfirmation, i9ApiCall,
            i9FormResponseToPdfGenerate, pdfGeneratorCall,
            documentApiCall, bytesToDocumentUpload,
            true, auditProvider
        );
//        documentId = UUID.randomUUID().toString();
//        history = new I9History(MockI9FormResponseData.createFormList(), null);
        Map<String, IssuingAuthorityLookup> lookupMap = new HashMap<>();
        lookupMap.put(driverLicenseTitle, new IssuingAuthorityLookup(driverLicenseTitle, "states"));
        lookupMap.put(stateIssuedIDCard, new IssuingAuthorityLookup(stateIssuedIDCard, "states"));
        lookupMap.put(canadaDriverLicense, new IssuingAuthorityLookup(canadaDriverLicense, "provinces"));
        lookupMap.put(foreignPassportTitle, new IssuingAuthorityLookup(foreignPassportTitle, "countries"));
        when(referenceApiService.getIssuingAuthorityMapByTitle(anyString()))
            .thenReturn(Mono.just(lookupMap));
        OBJECT_MAPPER.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        doNothing().when(messageConfirmation).acknowledge(any(Message.class));
    }

    @Test
    public void testSection2UploadLaterPDF() throws IOException {
        String updateEvent = IOUtils.toString(this.getClass().getResourceAsStream(
            "/i9-integration-test/s2-upload-later/s2uploadlater-updateEvent.json"), Charset.defaultCharset());
        assertNotNull(updateEvent);
        Map<String, Object> headerMap = new HashMap<>();
        headerMap.put("documentId", "W8CdnozROIXkb96He3fX");
        headerMap.put("sourceId", "packet-ui");
        headerMap.put("sourceRefId", "9b53ddec-abcc-4393-b985-038db1637492");
        headerMap.put("status", "Section2_Documents_Uploaded");
        headerMap.put("recordVersion", "7");
        headerMap.put("employeeFactId", "f24b63c1-a0ca-4a3b-82d7-27e1c653a310");
        headerMap.put("employeeId", "4b9b9b38-de43-4095-ad32-9f2786312f28");
        headerMap.put(TRANSACTION_ID_HEADER_NAME, UUID.randomUUID().toString());
        headerMap.put(SESSION_ID_HEADER_NAME, UUID.randomUUID().toString());
        MessageHeaders headers = new MessageHeaders(headerMap);
        Message message = mock(Message.class);
        when(message.getHeaders()).thenReturn(headers);
        String historyJson = IOUtils.toString(this.getClass().getResourceAsStream(
            "/i9-integration-test/s2-upload-later/s2uploadlater-history.json"), Charset.defaultCharset());
        List<I9FormResponse> historyResp = OBJECT_MAPPER.readValue(historyJson, new TypeReference<List<I9FormResponse>>() {});
        when(i9ApiCall.getHistory(anyString())).thenReturn(Mono.just(historyResp));
        when(i9ApiCall.patchMetadata(anyString(), any(UpdateMetadataRequest.class))).thenReturn(Mono.just(new I9FormResponse()));
        String iceJson = IOUtils.toString(this.getClass().getResourceAsStream(
            "/i9-integration-test/s2-upload-later/s2uploadlater-iceaudits.json"), Charset.defaultCharset());
        List<IceAuditEntry> iceentries = OBJECT_MAPPER.readValue(iceJson, new TypeReference<List<IceAuditEntry>>() {});
        when(auditProvider.getIceEntries(anyString(), anyString())).thenReturn(Mono.just(iceentries));
        InputStream is = this.getClass().getResourceAsStream(
            "/i9-integration-test/s2-upload-later/s2uploadlater-sig.png");
        byte[] sigbytes = IOUtils.readFully(is, is.available());

        DocumentDownloadResponse dresp = new DocumentDownloadResponse(sigbytes, MediaType.IMAGE_PNG, "docid");
        when(documentApiCall.getDocuments(any(),any())).thenReturn(Flux.just(dresp));

        pdfGenerationSubscriber.handleMessage(message);
        verify(i9ApiCall, times(1)).getHistory(anyString());
        verify(auditProvider, times(1)).getIceEntries(anyString(), anyString());
        verify(documentApiCall, atLeast(1)).getDocuments(any(),any());
        verify(message, atLeast(1)).getHeaders();
        verify(messageConfirmation, times(1)).acknowledge(any(Message.class));
    }

}