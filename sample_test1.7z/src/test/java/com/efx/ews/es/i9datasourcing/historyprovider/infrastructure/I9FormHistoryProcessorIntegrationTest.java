package com.efx.ews.es.i9datasourcing.historyprovider.infrastructure;

import static com.efx.ews.es.i9datasourcing.util.TestConstants.INTEGRATION_TEST;
import static org.assertj.core.api.AssertionsForClassTypes.assertThatCode;

import com.efx.ews.es.i9datasourcing.I9FormHistoryConverter;
import com.efx.ews.es.i9datasourcing.I9FormHistoryProcessorQuickMockImpl;
import com.efx.ews.es.i9datasourcing.constant.I9Event;
import com.efx.ews.es.i9datasourcing.model.ChangeContext;
import com.efx.ews.es.i9integration.i9portaleventshandler.I9PortalEventsHandlerApplication;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.I9Form;
import java.time.Instant;
import java.time.ZoneOffset;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = I9PortalEventsHandlerApplication.class)
@Slf4j
@Tag(INTEGRATION_TEST)
@ActiveProfiles({"local", "mocked"})
class I9FormHistoryProcessorIntegrationTest {

    @Autowired
    private I9FormHistoryProcessorQuickMockImpl processorQuickMock;

    @Autowired
    private I9FormHistoryConverter converter;

    @Test
    @SneakyThrows
    void processConversion() {
        ChangeContext changeContext = new ChangeContext();
        changeContext.setI9Event(I9Event.SECTION_1_COMPLETE);
        changeContext.setClientTransactionId("");
        changeContext.setCorrelationId("CR-1");
        changeContext.setSourceEventDateTime(Instant.parse("2020-10-10T16:57:57.817Z").atZone(ZoneOffset.UTC));

        I9Form i9Form = processorQuickMock.simulateReceivedSection1Creation();

        assertThatCode(() -> converter.convert(null, i9Form, changeContext))
            .doesNotThrowAnyException();
    }
}
