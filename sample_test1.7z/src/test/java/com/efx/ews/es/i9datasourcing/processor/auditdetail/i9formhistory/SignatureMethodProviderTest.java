package com.efx.ews.es.i9datasourcing.processor.auditdetail.i9formhistory;

import static com.efx.ews.es.i9datasourcing.processor.auditdetail.i9formhistory.SignatureMethodProvider.EMPLOYEE_SIGNATURE_DATE;
import static com.efx.ews.es.i9datasourcing.processor.auditdetail.i9formhistory.SignatureMethodProvider.EMPLOYER_SIGNATURE_DATE;
import static com.efx.ews.es.i9datasourcing.processor.auditdetail.i9formhistory.SignatureMethodProvider.SECTION_1_SIGNATURE_DATE;
import static com.efx.ews.es.i9datasourcing.processor.auditdetail.i9formhistory.SignatureMethodProvider.SECTION_2_SIGNATURE_DATE;
import static com.efx.ews.es.i9datasourcing.processor.auditdetail.i9formhistory.SignatureMethodProvider.SECTION_3_REVERIFICATION_SIGNATURE_DATE;
import static org.assertj.core.api.Assertions.assertThat;

import com.efx.ews.es.i9datasourcing.constant.I9Event;
import com.efx.ews.es.i9datasourcing.model.ChangeContext;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.Map;
import org.junit.jupiter.api.Test;

class SignatureMethodProviderTest {

    private final SignatureMethodProvider signatureMethodProvider = new SignatureMethodProvider();

    @Test
    void shouldReturnBlank() {
        //Given
        Map<String, String> convertedI9FormAfter = Map.of(
            ReportField.SSN.sourceLabel, "v1",
            ReportField.LAST_NAME.sourceLabel, "v2",
            ReportField.FIRST_NAME.sourceLabel, "v3",
            ReportField.MIDDLE_INITIAL.sourceLabel, "v4",
            ReportField.DATE_OF_BIRTH.sourceLabel, "v5",
            "SIGNATURE_METHOD", "v6",
            ReportField.LOCATION_CODE.sourceLabel, "v7",
            "SECTIONONE.EMPLOYEEINFO.SIGNATURE.EMPLOYEE_SIGNATURE_DATE", "");

        ChangeContext changeContext = new ChangeContext(
            "c1",
            "c2",
            I9Event.FORM_CREATED,
            "c3",
            "",
            "",
            ZonedDateTime.now(ZoneOffset.UTC),
            "c4",
            "messageId-1");

        //When
        String actualSignatureMethod = signatureMethodProvider.getSignatureMethod(convertedI9FormAfter, changeContext);

        //Then
        assertThat(actualSignatureMethod).isEmpty();
    }

    @Test
    void shouldReturnExpectedSignatureMethod() {
        String expectedSignatureMethod = "E-signature";

        assertThat(createSignatureMethod(I9Event.FORM_CREATED, SECTION_1_SIGNATURE_DATE))
            .isEqualTo(expectedSignatureMethod);
        assertThat(createSignatureMethod(I9Event.SECTION_1_COMPLETE, SECTION_1_SIGNATURE_DATE))
            .isEqualTo(expectedSignatureMethod);
        assertThat(createSignatureMethod(I9Event.SECTION_2_COMPLETE, SECTION_2_SIGNATURE_DATE))
            .isEqualTo(expectedSignatureMethod);
        assertThat(createSignatureMethod(I9Event.SECTION_3_COMPLETE, SECTION_3_REVERIFICATION_SIGNATURE_DATE))
            .isEqualTo(expectedSignatureMethod);
        assertThat(createSignatureMethod(I9Event.SECTION_1_AMENDED, EMPLOYEE_SIGNATURE_DATE))
            .isEqualTo(expectedSignatureMethod);
        assertThat(createSignatureMethod(I9Event.SECTION_2_AMENDED, EMPLOYER_SIGNATURE_DATE))
            .isEqualTo(expectedSignatureMethod);
    }

    private String createSignatureMethod(I9Event eventName, String key) {
        Map<String, String> convertedI9FormAfter = Map.of(
            ReportField.SSN.sourceLabel, "v1",
            ReportField.LAST_NAME.sourceLabel, "v2",
            ReportField.FIRST_NAME.sourceLabel, "v3",
            ReportField.MIDDLE_INITIAL.sourceLabel, "v4",
            ReportField.DATE_OF_BIRTH.sourceLabel, "v5",
            "SIGNATURE_METHOD", "v6",
            ReportField.LOCATION_CODE.sourceLabel, "v7",
            key, "v8");

        ChangeContext changeContext = new ChangeContext(
            "c1",
            "c2",
            eventName,
            "c3",
            "",
            "",
            ZonedDateTime.now(ZoneOffset.UTC),
            "c4",
            "messageId-1");

        return signatureMethodProvider.getSignatureMethod(convertedI9FormAfter, changeContext);
    }

    @Test
    void shouldReturnEmptyValueWhenThereIsNotSuchKey() {
        //Given
        Map<String, String> convertedI9FormAfter = Map.of(
            ReportField.SSN.sourceLabel, "v1",
            ReportField.LAST_NAME.sourceLabel, "v2",
            ReportField.FIRST_NAME.sourceLabel, "v3",
            ReportField.MIDDLE_INITIAL.sourceLabel, "v4",
            ReportField.DATE_OF_BIRTH.sourceLabel, "v5",
            "SIGNATURE_METHOD", "v6",
            ReportField.LOCATION_CODE.sourceLabel, "v7");

        ChangeContext changeContext = new ChangeContext(
            "c1",
            "c2",
            I9Event.FORM_CREATED,
            "c3",
            "",
            "",
            ZonedDateTime.now(ZoneOffset.UTC),
            "c4",
            "messageId-1");

        //When
        String actualSignatureMethod = signatureMethodProvider.getSignatureMethod(convertedI9FormAfter, changeContext);

        //Then
        assertThat(actualSignatureMethod).isEmpty();
    }
}