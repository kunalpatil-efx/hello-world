package com.efx.ews.es.i9integration.i9portaleventshandler;

import com.efx.ews.es.eev.barricade.common.model.BarricadeKeyStore;
import com.efx.ews.es.eev.barricade.common.service.CryptographyService;
import com.efx.ews.es.eev.barricade.common.service.PubSubEncryptionService;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.event.I9EventPayload;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.AuditDataFeed;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.DataBaseAuditDataFeedTest;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.TaskApiRemoteCallServiceImpl;
import com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageConfirmation;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.matching.RequestPatternBuilder;
import com.github.tomakehurst.wiremock.matching.StringValuePattern;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.messaging.Message;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static com.efx.ews.es.i9integration.i9portaleventshandler.utils.WireMockTestFile.testFileContent;
import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.*;

@SpringBootTest(properties = { "pubsub.sectionalPdfGenerationEnabled=true" })
@ExtendWith(SpringExtension.class)
@Slf4j
public class PdfSegmentedGenerationTest {
    @Autowired
    private MessagePublish messagePublish;

    @Autowired
    private ServiceCalls serviceCalls;

    @MockBean
    @Qualifier("messageConfirmation")
    private MessageConfirmation messageConfirmation;
    @MockBean
    @Qualifier("messageConfirmationForFlow")
    private MessageConfirmation messageConfirmationForFlow;

    @MockBean
    private TaskApiRemoteCallServiceImpl taskApiRemoteCallService;

    @MockBean
    List<BarricadeKeyStore> barricadeKeyStores;
    @MockBean
    CryptographyService cryptographyService;
    @MockBean
    private PubSubEncryptionService pubSubEncryptionService;
    @MockBean
    private AuditDataFeed auditFeed;

    private final String documentId = LocalDateTime.now().format(DateTimeFormatter.ISO_DATE_TIME);
    private final String sourceRefId = UUID.randomUUID().toString();
    private final Long recordVersion = 5L;

    @BeforeEach
    public void setup() throws Exception {
        // here be proper url
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/forms/" + documentId)
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("getForm.json")));
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/audits/" + documentId + "/ice")
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("i9IceResponse.json")));

        serviceCalls.documentApi.stubFor(
                get("/internal/eev/documents/v1/document/afa913ad-c494d28f-preparer1SignatureRef/object")
                        .willReturn(aResponse().withBody(Base64.getDecoder().decode("EncodedSignature")))
        );
        serviceCalls.documentApi.stubFor(
                get("/internal/eev/documents/v1/document/afa913ad-26a5e947-preparer2SignatureRef/object")
                        .willReturn(aResponse().withBody(Base64.getDecoder().decode("EncodedSignature")))
        );
        serviceCalls.documentApi.stubFor(
                get("/internal/eev/documents/v1/document/afa913ad-e07e07f1-sectionTwoSignatureRef/object")
                        .willReturn(aResponse().withBody(Base64.getDecoder().decode("EncodedSignature")))
        );
        serviceCalls.documentApi.stubFor(
                get("/internal/eev/documents/v1/document/afa913ad-e07e07f1-sectionThree1SignatureRef/object")
                        .willReturn(aResponse().withBody(Base64.getDecoder().decode("EncodedSignature")))
        );
        serviceCalls.documentApi.stubFor(
                get("/internal/eev/documents/v1/document/afa913ad-e07e07f1-sectionThree2SignatureRef/object")
                        .willReturn(aResponse().withBody(Base64.getDecoder().decode("EncodedSignature")))
        );
        serviceCalls.documentApi.stubFor(
                get("/internal/eev/documents/v1/document/afa913ad-e07e07f1-sectionThree3SignatureRef/object")
                        .willReturn(aResponse().withBody(Base64.getDecoder().decode("EncodedSignature")))
        );
        final Map<String, StringValuePattern> documentUploadQueryParameters = Map.of(
            "documentType", equalTo("application/pdf"),
            "securityModel", equalTo("basic"),
            "retentionPolicy", equalTo("90"),
            "dataClassification", equalTo("3"),
            "ownerId", equalTo("I9-form-owner"),
            "ownerReferenceId", matching("([a-z0-9-T:.]){20,27}"),
            "ownerReferenceVersion", equalTo("v1"),
            "documentName", equalTo("I9Report.pdf")
        );
        serviceCalls.documentApi.stubFor(
                post(urlPathMatching("/internal/eev/documents/v1/document"))
                        .willReturn(aResponse().withStatus(201).withHeader("Content-Type", "application/json")
                        .withBody("{\"documentId\":\"afa913ad-ed68dd7c-4498-4f71-a430-4d7aea04cf00\"}"))
        );
        serviceCalls.i9api.stubFor(
            patch(WireMock.urlEqualTo("/internal/eev/form-i9/v1/forms/" + documentId + "/metadata"))
                .willReturn(aResponse().withStatus(200).withHeader("Content-Type", "application/json").withBodyFile("getSegmentedForm.json")));

        serviceCalls.referenceApi.stubFor(
            get(WireMock.urlPathMatching("/internal/eev/reference-data/v1/countries"))
            .willReturn(ok().withHeader("Content-Type", "application/json").withBodyFile("countriesResponse.json"))
        );
        serviceCalls.referenceApi.stubFor(
            get(WireMock.urlPathMatching("/internal/eev/reference-data/v1/states"))
                .willReturn(ok().withHeader("Content-Type", "application/json").withBodyFile("statesResponse.json"))
        );
        serviceCalls.referenceApi.stubFor(
            get(WireMock.urlPathMatching("/internal/eev/reference-data/v1/provinces"))
                .willReturn(ok().withHeader("Content-Type", "application/json").withBodyFile("provincesResponse.json"))
        );
        serviceCalls.referenceApi.stubFor(
            get(WireMock.urlPathMatching("/internal/eev/reference-data/v1/documents/all-documents"))
                .willReturn(ok().withHeader("Content-Type", "application/json").withBodyFile("documentDefsResponse.json"))
        );

        when(auditFeed.fetchAuditData(sourceRefId))
                .thenReturn(Mono.just(List.of(DataBaseAuditDataFeedTest.createAuditMessage())));


        // all PDF Generator generate calls
        serviceCalls.pdfGenerator.stubFor(post(WireMock.urlEqualTo("/internal/eev/pdfgenerator/generate"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/pdf")
                        .withBodyFile("I9Report.pdf")));

        // all PDF generator merge calls
        serviceCalls.pdfGenerator.stubFor(post(WireMock.urlEqualTo("/internal/eev/pdfgenerator/merge"))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBodyFile("pdfGeneratorMergeIdResponse.json")));

        // all Document API GET calls
        serviceCalls.documentApi.stubFor(
                get(urlPathMatching("/internal/eev/documents/v1/document"))
                        .willReturn(aResponse()
                                .withStatus(200)
                                .withHeader("Content-Type", "application/pdf")
                                .withBodyFile("I9Report.pdf")));
    }

    private void generatesPdfOnStatus(String status) throws Exception {
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/forms/" + documentId + "/history")
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("getHistoryWithDocumentIds.json")));

        // when
        messagePublish.publishMessage(Map.of(
                "status", status,
                "documentId", documentId,
                "sourceRefId", sourceRefId,
                "recordVersion", recordVersion.toString()), new I9EventPayload());

        // there should be a call to generate a pdf
        final RequestPatternBuilder pdfGeneratorRequest =
                postRequestedFor(urlPathMatching("/internal/eev/pdfgenerator/generate"));
        serviceCalls.pdfGenerator.assertCall(pdfGeneratorRequest);

        // there should be a call to store a generated PDF in Document API
        final RequestPatternBuilder documentApiRequest =
                postRequestedFor(urlPathMatching("/internal/eev/documents/v1/document"))
                        .withQueryParam("documentType", equalTo("application/pdf"))
                        .withRequestBodyPart(
                                aMultipart().withBody(equalTo(testFileContent("I9Report.pdf"))).build());
        serviceCalls.documentApi.assertCall(documentApiRequest);

        // there should be a PATCH call to Form API that has our documentIds
        final RequestPatternBuilder patchRequest =
                patchRequestedFor(urlEqualTo("/internal/eev/form-i9/v1/forms/" + documentId + "/metadata"))
                        .withRequestBody(matchingJsonPath("$.documentApiDocumentId",
                                equalTo("afa913ad-a9969dba-2409-4fab-8bef-db7060561668")))
                        .withRequestBody(matchingJsonPath("$.documentApiAuditId",
                                equalTo("afa913ad-ed68dd7c-4498-4f71-a430-4d7aea04cf00")))
                        .withRequestBody(matchingJsonPath("$.documentApiRevisionId",
                                equalTo("afa913ad-ed68dd7c-4498-4f71-a430-4d7aea04cf00")));
        serviceCalls.i9api.assertCall(patchRequest);

        // there should be a call to the PDF Generator merge endpoint
        final RequestPatternBuilder pdfMergeRequest =
                postRequestedFor(urlEqualTo("/internal/eev/pdfgenerator/merge"));
        serviceCalls.pdfGenerator.assertCall(pdfMergeRequest);

        verify(messageConfirmation, atLeast(1)).acknowledge(any(Message.class));
    }

    private void generatesPdfOnStatusWhenNoPdfsPresent(String status) throws Exception {
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/forms/" + documentId + "/history")
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("getHistoryWithNoDocumentIds.json")));


        // when
        messagePublish.publishMessage(Map.of(
                "status", status,
                "documentId", documentId,
                "sourceRefId", sourceRefId,
                "recordVersion", recordVersion.toString()), new I9EventPayload());

        // there should be a call to generate a pdf
        final RequestPatternBuilder pdfGeneratorRequest =
                postRequestedFor(urlPathMatching("/internal/eev/pdfgenerator/generate"));
        serviceCalls.pdfGenerator.assertCall(pdfGeneratorRequest);

        // there should be a call to store a generated PDF in Document API
        final RequestPatternBuilder documentApiRequest =
                postRequestedFor(urlPathMatching("/internal/eev/documents/v1/document"))
                        .withQueryParam("documentType", equalTo("application/pdf"))
                        .withRequestBodyPart(
                                aMultipart().withBody(equalTo(testFileContent("I9Report.pdf"))).build());
        serviceCalls.documentApi.assertCall(documentApiRequest);

        // there should be a PATCH call to Form API that has our documentIds
        final RequestPatternBuilder patchRequest =
                patchRequestedFor(urlEqualTo("/internal/eev/form-i9/v1/forms/" + documentId + "/metadata"))
                        .withRequestBody(matchingJsonPath("$.documentApiDocumentId",
                                equalTo("afa913ad-a9969dba-2409-4fab-8bef-db7060561668")))
                        .withRequestBody(matchingJsonPath("$.documentApiAuditId",
                                equalTo("afa913ad-ed68dd7c-4498-4f71-a430-4d7aea04cf00")))
                        .withRequestBody(matchingJsonPath("$.documentApiRevisionId",
                                equalTo("afa913ad-ed68dd7c-4498-4f71-a430-4d7aea04cf00")));
        serviceCalls.i9api.assertCall(patchRequest);

        // there should be a call to the PDF Generator merge endpoint
        final RequestPatternBuilder pdfMergeRequest =
                postRequestedFor(urlEqualTo("/internal/eev/pdfgenerator/merge"));
        serviceCalls.pdfGenerator.assertCall(pdfMergeRequest);

        verify(messageConfirmation, atLeast(1)).acknowledge(any(Message.class));
    }

    @Test
    public void generatesPdfOnNewlyMigratedForm() throws Exception {
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/forms/" + documentId + "/history")
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("getNewlyMigratedFormHistory.json")));

        // when
        messagePublish.publishMessage(Map.of(
                "status", "Section2_Complete",
                "documentId", documentId,
                "sourceRefId", sourceRefId,
                "recordVersion", recordVersion.toString()), new I9EventPayload());

        // there should be a call to generate a pdf
        final RequestPatternBuilder pdfGeneratorRequest =
                postRequestedFor(urlPathMatching("/internal/eev/pdfgenerator/generate"));
        serviceCalls.pdfGenerator.assertCall(pdfGeneratorRequest);

        // there should be a call to store a generated PDF in Document API
        final RequestPatternBuilder documentApiRequest =
                postRequestedFor(urlPathMatching("/internal/eev/documents/v1/document"))
                        .withQueryParam("documentType", equalTo("application/pdf"))
                        .withRequestBodyPart(
                                aMultipart().withBody(equalTo(testFileContent("I9Report.pdf"))).build());
        serviceCalls.documentApi.assertCall(documentApiRequest);

        // there should be a PATCH call to Form API that has our documentId
        final RequestPatternBuilder patchRequest =
                patchRequestedFor(urlEqualTo("/internal/eev/form-i9/v1/forms/" + documentId + "/metadata"))
                        .withRequestBody(matchingJsonPath("$.documentApiDocumentId",
                                equalTo("afa913ad-a9969dba-2409-4fab-8bef-db7060561668")));
        serviceCalls.i9api.assertCall(patchRequest);

        verify(messageConfirmation, atLeast(1)).acknowledge(any(Message.class));
    }

    @Test
    public void generatesPdfOnLegacyForm() throws Exception {
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/forms/" + documentId + "/history")
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("getLegacyFormHistory.json")));


        // when
        messagePublish.publishMessage(Map.of(
                "status", "Section2_Complete",
                "documentId", documentId,
                "sourceRefId", sourceRefId,
                "recordVersion", recordVersion.toString()), new I9EventPayload());

        // there should be a call to generate a pdf
        final RequestPatternBuilder pdfGeneratorRequest =
                postRequestedFor(urlPathMatching("/internal/eev/pdfgenerator/generate"));
        serviceCalls.pdfGenerator.assertCall(pdfGeneratorRequest);

        // there should be a call to store a generated PDF in Document API
        final RequestPatternBuilder documentApiRequest =
                postRequestedFor(urlPathMatching("/internal/eev/documents/v1/document"))
                        .withQueryParam("documentType", equalTo("application/pdf"))
                        .withRequestBodyPart(
                                aMultipart().withBody(equalTo(testFileContent("I9Report.pdf"))).build());
        serviceCalls.documentApi.assertCall(documentApiRequest);

        // there should be a PATCH call to Form API that has our documentId
        final RequestPatternBuilder patchRequest =
                patchRequestedFor(urlEqualTo("/internal/eev/form-i9/v1/forms/" + documentId + "/metadata"))
                        .withRequestBody(matchingJsonPath("$.documentApiDocumentId",
                                equalTo("afa913ad-ed68dd7c-4498-4f71-a430-4d7aea04cf00")));
        serviceCalls.i9api.assertCall(patchRequest);

        verify(messageConfirmation, atLeast(1)).acknowledge(any(Message.class));
    }

    @Test
    public void generatesPdfOnSectionTwo() throws Exception {
        generatesPdfOnStatus("Section2_Complete");
        generatesPdfOnStatusWhenNoPdfsPresent("Section2_Complete");
    }

    @Test
    public void generatesPdfOnSectionTwoAmend() throws Exception {
        generatesPdfOnStatus("Section2_Amended");
        generatesPdfOnStatusWhenNoPdfsPresent("Section2_Amended");
    }

    @Test
    public void generatesPdfOnSectionOneAmend() throws Exception {
        generatesPdfOnStatus("Section1_Amended");
        generatesPdfOnStatusWhenNoPdfsPresent("Section1_Amended");
    }

    @Test
    public void generatesPdfOnSectionThreeComplete() throws Exception {
        generatesPdfOnStatus("Section3_Complete");
        generatesPdfOnStatusWhenNoPdfsPresent("Section3_Complete");
    }

    @Test
    @Disabled
    public void doesNotAttemptMergeWhenProcessingNewI9() throws Exception {
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/forms/" + documentId + "/history")
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("getHistory.json")));

        // when
        messagePublish.publishMessage(Map.of(
                "status", "Section1_Complete",
                "documentId", documentId,
                "sourceRefId", sourceRefId,
                "recordVersion", recordVersion.toString()), new I9EventPayload());

        verify(messageConfirmation, atLeast(1)).acknowledge(any(Message.class));
    }

    @Test
    public void acknowledgesOnClientsError() throws Exception {
        //given
        serviceCalls.pdfGenerator
                .stubFor(
                        // here be proper url
                        post(anyUrl())
                                .withRequestBody(equalToJson(testFileContent("pdfRequest.json"),
                                        true,
                                        true))
                                .willReturn(
                                        aResponse()
                                                .withStatus(400)
                                                .withStatusMessage("Bad request")));
        // when
        messagePublish.publishMessage(Map.of(
                "status", "Section2_Complete",
                "documentId", documentId,
                "sourceRefId", sourceRefId,
                "recordVersion", recordVersion.toString()), new I9EventPayload());
        verify(messageConfirmation, after(1000).atLeast(1)).acknowledge(any(Message.class));
    }
}
