package com.efx.ews.es.historyprovider.infrastructure;

import static com.efx.ews.es.historyprovider.infrastructure.TestMockDataProvider.MESSAGE_ID;
import static com.efx.ews.es.historyprovider.infrastructure.TestMockDataProvider.RECORD_REVISION_1;
import static com.efx.ews.es.historyprovider.infrastructure.TestMockDataProvider.RECORD_REVISION_2;
import static com.efx.ews.es.historyprovider.infrastructure.TestMockDataProvider.TEST_DOCUMENT_ID;
import static com.efx.ews.es.historyprovider.infrastructure.TestMockDataProvider.createAuditModelList;
import static com.efx.ews.es.historyprovider.infrastructure.TestMockDataProvider.createAuditModelListForMigratedI9;
import static com.efx.ews.es.historyprovider.infrastructure.TestMockDataProvider.createAuditModelListWithOtherEventKeyInCurrentAudit;
import static com.efx.ews.es.historyprovider.infrastructure.TestMockDataProvider.createAuditModelListWithoutAfterAudit;
import static com.efx.ews.es.historyprovider.infrastructure.TestMockDataProvider.createAuditModelListWithoutBeforeAudit;
import static com.efx.ews.es.historyprovider.infrastructure.TestMockDataProvider.createAuditModelListWithoutMigratedAudit;
import static com.efx.ews.es.historyprovider.infrastructure.TestMockDataProvider.createMockMessage;
import static com.efx.ews.es.historyprovider.infrastructure.TestMockDataProvider.createMockMessageForMigratedI9;
import static com.efx.ews.es.historyprovider.infrastructure.TestMockDataProvider.createNewFormMockMessage;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatCode;
import static org.assertj.core.api.Assertions.assertThatExceptionOfType;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.nullable;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import com.efx.ews.es.historyprovider.api.I9FormHistoryProvider;
import com.efx.ews.es.historyprovider.model.I9AuditModel;
import com.efx.ews.es.historyprovider.model.I9FormEventMessage;
import com.efx.ews.es.i9datasourcing.I9FormHistoryConverter;
import com.efx.ews.es.i9datasourcing.model.ChangeContext;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.I9Form;
import java.util.List;
import org.apache.commons.lang.StringUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.test.util.ReflectionTestUtils;

class I9FormHistoryProcessorTest {

    private I9FormHistoryProvider formHistoryProvider;
    private I9FormHistoryConverter formHistoryConverter;

    private I9FormHistoryProcessor historyProcessor;

    @BeforeEach
    public void init() {
        formHistoryProvider = mock(I9FormHistoryProvider.class);
        formHistoryConverter = mock(I9FormHistoryConverter.class);

        historyProcessor = new I9FormHistoryProcessor(formHistoryProvider, formHistoryConverter);
    }

    @Test
    void testInitProcessorWithDataSourcingEnabled() {
        //Given
        ReflectionTestUtils.setField(historyProcessor, "reportingDataSourcingEnabled", true);

        //Execute
        historyProcessor.init();

        //Verify
        verify(formHistoryProvider).registerEventListener(any());
    }

    @Test
    void testInitProcessorWithDataSourcingDisabled() {
        //Given
        ReflectionTestUtils.setField(historyProcessor, "reportingDataSourcingEnabled", false);

        //Execute
        historyProcessor.init();

        //Verify
        verifyNoInteractions(formHistoryProvider);
    }

    @Test
    void testProcessFormHistoryWithNewForm() {
        //Given
        I9FormEventMessage formEventMessage = createNewFormMockMessage();

        //Verify
        assertThatCode(() -> historyProcessor.processFormHistory(formEventMessage)).doesNotThrowAnyException();
    }

    @Test
    void testProcessFormHistory() {
        //Given
        I9FormEventMessage formEventMessage = createMockMessage();
        List<I9AuditModel> auditModelList = createAuditModelList();
        I9Form currentRevisionForm = mock(I9Form.class);
        I9Form previousRevisionForm = mock(I9Form.class);

        //When
        when(formHistoryProvider.getAudits(anyString())).thenReturn(auditModelList);
        when(formHistoryProvider.getRevision(TEST_DOCUMENT_ID, RECORD_REVISION_1)).thenReturn(previousRevisionForm);
        when(formHistoryProvider.getRevision(TEST_DOCUMENT_ID, RECORD_REVISION_2)).thenReturn(currentRevisionForm);
        doNothing().when(formHistoryConverter).convert(any(I9Form.class), any(I9Form.class), any(ChangeContext.class));

        //Execute
        historyProcessor.processFormHistory(formEventMessage);

        ArgumentCaptor<ChangeContext> argument = ArgumentCaptor.forClass(ChangeContext.class);
        verify(formHistoryConverter).convert(any(I9Form.class), any(I9Form.class), argument.capture());
        assertThat(argument.getValue().getDeduplicationId()).isEqualTo(MESSAGE_ID);
        verify(formHistoryProvider).getAudits(anyString());
        verify(formHistoryProvider, times(2)).getRevision(anyString(), anyLong());
    }

    @Test
    void testProcessFormHistoryWithMissingBeforeAudit() {
        //Given
        I9FormEventMessage formEventMessage = createMockMessage();
        List<I9AuditModel> auditModelList = createAuditModelListWithoutBeforeAudit();
        I9Form currentRevisionForm = mock(I9Form.class);
        I9Form previousRevisionForm = mock(I9Form.class);

        //When
        when(formHistoryProvider.getAudits(anyString())).thenReturn(auditModelList);
        when(formHistoryProvider.getRevision(TEST_DOCUMENT_ID, RECORD_REVISION_1)).thenReturn(previousRevisionForm);
        when(formHistoryProvider.getRevision(TEST_DOCUMENT_ID, RECORD_REVISION_2)).thenReturn(currentRevisionForm);
        doNothing().when(formHistoryConverter).convert(any(I9Form.class), any(I9Form.class), any(ChangeContext.class));

        //Execute
        historyProcessor.processFormHistory(formEventMessage);

        verify(formHistoryConverter).convert(any(I9Form.class), any(I9Form.class), any(ChangeContext.class));
        verify(formHistoryProvider).getAudits(anyString());
        verify(formHistoryProvider, times(2)).getRevision(anyString(), anyLong());
    }

    @Test
    void testProcessFormHistoryShouldSkipAfterAudit() {
        //Given
        I9FormEventMessage formEventMessage = createMockMessage();
        formEventMessage.getDocument().setStatus(StringUtils.EMPTY);
        List<I9AuditModel> auditModelList = createAuditModelListWithoutAfterAudit();

        //When
        when(formHistoryProvider.getAudits(anyString())).thenReturn(auditModelList);

        //Execute
        assertThatCode(()->historyProcessor.processFormHistory(formEventMessage))
        .doesNotThrowAnyException();


        verify(formHistoryProvider).getAudits(anyString());
    }

    @Test
    void testProcessFormHistoryShouldNotProcessIt_with_EventKeyNull() {
        //Given
        I9FormEventMessage formEventMessage = createMockMessage();
        List<I9AuditModel> auditModelList = createAuditModelListWithoutAfterAudit();
        auditModelList.get(0).setEventKey(null);

        //When
        when(formHistoryProvider.getAudits(anyString())).thenReturn(auditModelList);

        //Execute
        assertThatExceptionOfType(IllegalStateException.class)
            .isThrownBy(() -> historyProcessor.processFormHistory(formEventMessage));

        verify(formHistoryProvider).getAudits(anyString());
    }

    @Test
    void testProcessFormHistoryNotBeProcessedWithOtherEventKey() {
        //Given
        I9FormEventMessage formEventMessage = createMockMessage();
        List<I9AuditModel> auditModelList = createAuditModelListWithOtherEventKeyInCurrentAudit();

        //When
        when(formHistoryProvider.getAudits(anyString())).thenReturn(auditModelList);

        //Execute
        assertThatThrownBy(()-> historyProcessor.processFormHistory(formEventMessage))
            .isInstanceOf(IllegalStateException.class)
            .hasMessageContaining("There is no audit for current revision version!");


        //Verify
        verify(formHistoryConverter, never()).convert(any(I9Form.class), any(I9Form.class), any(ChangeContext.class));
        verify(formHistoryProvider).getAudits(anyString());
        verify(formHistoryProvider, never()).getRevision(anyString(), anyLong());
    }

    @Test
    void testProcessFormHistoryForMigratedI9() {
        //Given
        I9FormEventMessage formEventMessage = createMockMessageForMigratedI9();
        List<I9AuditModel> migratedAuditModelList = createAuditModelListForMigratedI9();
        I9Form migratedRevisionForm = mock(I9Form.class);

        //When
        when(formHistoryProvider.getAudits(anyString())).thenReturn(migratedAuditModelList);
        when(formHistoryProvider.getRevision(TEST_DOCUMENT_ID, RECORD_REVISION_1)).thenReturn(migratedRevisionForm);
        doNothing().when(formHistoryConverter).convert(nullable(I9Form.class), any(I9Form.class), any(ChangeContext.class));

        //Execute
        historyProcessor.processFormHistory(formEventMessage);

        verify(formHistoryConverter).convert(nullable(I9Form.class), any(I9Form.class), any(ChangeContext.class));
        verify(formHistoryProvider).getAudits(anyString());
        verify(formHistoryProvider, times(1)).getRevision(anyString(), anyLong());
    }

    @Test
    void testProcessFormHistoryShouldThrowOnMigrationAudit() {
        //Given
        I9FormEventMessage formEventMessage = createMockMessageForMigratedI9();
        List<I9AuditModel> auditModelList = createAuditModelListWithoutMigratedAudit();

        //When
        when(formHistoryProvider.getAudits(anyString())).thenReturn(auditModelList);

        //Execute
        assertThatExceptionOfType(IllegalStateException.class)
                .isThrownBy(() -> historyProcessor.processFormHistory(formEventMessage));

        verify(formHistoryProvider).getAudits(anyString());
    }
}
