package com.efx.ews.es.i9integration.i9portaleventshandler.model.pdfGenerator;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.I9FormResponse;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.referenceapi.IssuingAuthorityLookup;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.referenceapi.State;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.ReferenceApiConnector;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.ReferenceApiServiceImpl;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.Test;
import reactor.core.publisher.Mono;

public class I9FormResponseToPdfGenerateTest {

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    private ReferenceApiServiceImpl referenceApiService;
    private ReferenceApiConnector connector;

    @Before
    public void setup() {
        connector = mock(ReferenceApiConnector.class);
        referenceApiService = new ReferenceApiServiceImpl(connector);
        referenceApiService.initialize();
    }

    @Test
    public void testUpdateIssuingAuthority() throws Exception {
        String json = IOUtils.toString(this.getClass().getResourceAsStream("/__files/historyResponse2.json"),
            StandardCharsets.UTF_8);
        OBJECT_MAPPER.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        I9FormResponse i9FormResponse = OBJECT_MAPPER.readValue(json, I9FormResponse.class);
        assertNotNull(i9FormResponse);
        I9History i9History = new I9History(Arrays.asList(i9FormResponse), Collections.emptyList());

        Map<String, IssuingAuthorityLookup> lookupMap = new HashMap<>();
        String documentTitle = "Driver's License Issued by State or Possession with Photo";
        lookupMap.put(documentTitle, new IssuingAuthorityLookup(documentTitle, "states"));

        when(connector.getIssuingAuthorityMap(anyString())).thenReturn(Mono.just(lookupMap));
        Map<String, State> statesMap = new HashMap<>();
        statesMap.put("GA", new State("GA", "Georgia"));
        when(connector.getStateCodeMap(anyString())).thenReturn(Mono.just(statesMap));

        I9FormResponseToPdfGenerate generate = new I9FormResponseToPdfGenerate(referenceApiService);
        PdfServiceRequest request = generate.map(i9History);
        Mono<PdfServiceRequest> requestMono = generate.updateIssuingAuthorityToFullName(request);
        PdfServiceRequest r = requestMono.block();
        assertEquals("Georgia - GA", r.getSectionTwoAndThree()
            .getSectionTwo().getListA().getDocumentOne().getIssuingAuthority());
    }

    @Test
    public void testUpdateIssuingAuthority_NoSectionTwo() throws Exception {
        String json = IOUtils.toString(this.getClass().getResourceAsStream("/__files/historyResponse2.json"),
            StandardCharsets.UTF_8);
        OBJECT_MAPPER.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        I9FormResponse i9FormResponse = OBJECT_MAPPER.readValue(json, I9FormResponse.class);
        assertNotNull(i9FormResponse);
        I9History i9History = new I9History(Arrays.asList(i9FormResponse), Collections.emptyList());

        Map<String, IssuingAuthorityLookup> lookupMap = new HashMap<>();
        String documentTitle = "Driver's License Issued by State or Possession with Photo";
        lookupMap.put(documentTitle, new IssuingAuthorityLookup(documentTitle, "states"));

        when(connector.getIssuingAuthorityMap(anyString())).thenReturn(Mono.just(lookupMap));
        Map<String, State> statesMap = new HashMap<>();
        statesMap.put("GA", new State("GA", "Georgia"));
        when(connector.getStateCodeMap(anyString())).thenReturn(Mono.just(statesMap));

        I9FormResponseToPdfGenerate generate = new I9FormResponseToPdfGenerate(referenceApiService);
        PdfServiceRequest request = generate.map(i9History);
        //Set Section two and three to null - I9TRANSFOR-7598 bug fix
        request.setSectionTwoAndThree(null);
        Mono<PdfServiceRequest> requestMono = generate.updateIssuingAuthorityToFullName(request);
        PdfServiceRequest r = requestMono.block();
        assertNotNull(r);
        assertNull(r.getSectionTwoAndThree());
    }

    @Test
    public void testUpdateIssuingAuthority_NoLookupData() throws Exception {
        String json = IOUtils.toString(this.getClass().getResourceAsStream("/__files/historyResponse2.json"),
            StandardCharsets.UTF_8);
        OBJECT_MAPPER.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        I9FormResponse i9FormResponse = OBJECT_MAPPER.readValue(json, I9FormResponse.class);
        assertNotNull(i9FormResponse);
        I9History i9History = new I9History(Arrays.asList(i9FormResponse), Collections.emptyList());
        Map<String, IssuingAuthorityLookup> lookupMap = new HashMap<>();
        String documentTitle = "Driver's License Issued by State or Possession with Photo";
        lookupMap.put(documentTitle, new IssuingAuthorityLookup(documentTitle, "states"));
        when(connector.getIssuingAuthorityMap(anyString())).thenReturn(Mono.just(lookupMap));
        Map<String, State> statesMap = new HashMap<>();
        statesMap.put("WI", new State("WI", "Wisconsin"));
        when(connector.getStateCodeMap(anyString())).thenReturn(Mono.just(statesMap));

        I9FormResponseToPdfGenerate generate = new I9FormResponseToPdfGenerate(referenceApiService);
        PdfServiceRequest request = generate.map(i9History);
        Mono<PdfServiceRequest> requestMono = generate.updateIssuingAuthorityToFullName(request);
        PdfServiceRequest r = requestMono.block();
        assertEquals("GA", r.getSectionTwoAndThree()
            .getSectionTwo().getListA().getDocumentOne().getIssuingAuthority());
    }

}
