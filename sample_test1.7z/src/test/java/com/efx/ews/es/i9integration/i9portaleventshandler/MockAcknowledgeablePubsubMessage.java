package com.efx.ews.es.i9integration.i9portaleventshandler;

import com.google.protobuf.ByteString;
import com.google.pubsub.v1.ProjectSubscriptionName;
import com.google.pubsub.v1.PubsubMessage;
import java.util.Map;
import org.springframework.cloud.gcp.pubsub.support.AcknowledgeablePubsubMessage;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.MonoToListenableFutureAdapter;
import reactor.core.publisher.Mono;

public class MockAcknowledgeablePubsubMessage implements AcknowledgeablePubsubMessage {

    private final PubsubMessage message;

    public MockAcknowledgeablePubsubMessage(String messageId, Map<String, String> attrs, String data) {
        message = PubsubMessage.newBuilder().setMessageId(messageId).setData(ByteString.copyFromUtf8(data))
            .putAllAttributes(attrs).build();
    }

    @Override
    public String getAckId() {
        return "MockId";
    }

    @Override
    public ListenableFuture<Void> modifyAckDeadline(int ackDeadlineSeconds) {
        return null;
    }

    @Override
    public ProjectSubscriptionName getProjectSubscriptionName() {
        return null;
    }

    @Override
    public PubsubMessage getPubsubMessage() {
        return this.message;
    }

    @Override
    public ListenableFuture<Void> ack() {
        return new MonoToListenableFutureAdapter(Mono.empty());
    }

    @Override
    public ListenableFuture<Void> nack() {
        return new MonoToListenableFutureAdapter(Mono.empty());
    }
}
