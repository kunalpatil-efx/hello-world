package com.efx.ews.es.i9integration.i9portaleventshandler;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.efx.ews.es.i9integration.i9portaleventshandler.TasksSubscriberConfig.TaskHandlerObject;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.employer.person.EmployeeForFactId;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.Audit;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.I9Form;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.I9FormResponse;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.Task;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.UpdateMetadataRequest;
import com.efx.ews.es.i9integration.i9portaleventshandler.pubsub.ReactiveSubscriber;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.EmployerPersonCall;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.I9ApiCall;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.PacketPubSubPublisherService;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.TaskApiConnector;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.TaskApiRemoteCallService;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.TaskApiRemoteCallServiceImpl;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.TaskApiProperties;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.TaskApiProperties.TaskType;
import com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageConfirmation;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.cloud.gcp.pubsub.support.AcknowledgeablePubsubMessage;
import reactor.core.publisher.Mono;

public class TasksSubscriberConfigTest {
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();
    private I9ApiCall i9ApiCall;
    private TaskApiRemoteCallService taskApiRemoteCallService;
    private TaskApiConnector taskApiConnector;
    private PacketPubSubPublisherService publisherService;
    private ObjectProvider<MessageConfirmation> messageConfirmationForFlow;
    private TaskApiProperties properties;
    private EmployerPersonCall employerPersonCall;
    private ReactiveSubscriber reactiveSubscriber;

    @BeforeEach
    private void setup() {
        i9ApiCall = mock(I9ApiCall.class);
        properties = mock(TaskApiProperties.class);
        taskApiConnector = mock(TaskApiConnector.class);
        taskApiRemoteCallService = mock(TaskApiRemoteCallService.class);
        publisherService = mock(PacketPubSubPublisherService .class);
        messageConfirmationForFlow = mock(ObjectProvider.class);
        employerPersonCall = mock(EmployerPersonCall.class);
        reactiveSubscriber = mock(ReactiveSubscriber.class);
        OBJECT_MAPPER.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        TaskType taskType = new TaskType(); taskType.setCode("I9:ReceiptUpdate");
        when(properties.getReceiptUpdateSectionTwo()).thenReturn(taskType);
    }

    @Test
    public void testCreateReceiptUpdateTask_FFEnabled() throws IOException {
        I9Form resp = OBJECT_MAPPER.readValue(
            IOUtils.toString(this.getClass().getResourceAsStream(
                "/i9-integration-test/receipt_update/i9form.json"), Charset.defaultCharset()),
            new TypeReference<I9Form>(){});
        Task receiptUpdateTask = new Task();
        receiptUpdateTask.setTaskId("1");
        receiptUpdateTask.setTaskType("I9:ReceiptUpdate");
        receiptUpdateTask.setTaskStatus("NEW");

        Task section2Task = new Task();
        section2Task.setTaskId("2");
        section2Task.setTaskType("I9:Section2");
        section2Task.setTaskStatus("COMPLETED");
        List<Task> tasks = new ArrayList<>();
        tasks.add(section2Task);

        when(i9ApiCall.getFeature(anyString())).thenReturn(Mono.just(Boolean.TRUE));
        when(taskApiRemoteCallService.createReceiptUpdateTask(anyString(), any(I9Form.class))).thenReturn(Mono.just(receiptUpdateTask));
        MyTaskSubscriberConfig taskSubscriberConfig = new MyTaskSubscriberConfig(i9ApiCall, taskApiRemoteCallService,
            publisherService, messageConfirmationForFlow, properties, employerPersonCall,reactiveSubscriber);
        TaskHandlerObject taskObj = new TaskHandlerObject(null, tasks);
        taskObj.addI9FormResponse(resp);
        TaskHandlerObject ret =taskSubscriberConfig.createReceiptUpdateTask("doc123", "SECTION2_COMPLETE", taskObj).block();
        assertNotNull(ret);
        assertEquals(2, ret.getTasks().size());
        verify(i9ApiCall, times(1)).getFeature("receiptUpdate");
        verify(properties, times(1)).getReceiptUpdateSectionTwo();
        verify(taskApiRemoteCallService, times(1)).createReceiptUpdateTask(anyString(), any(I9Form.class));
    }

    @Test
    public void testCreateReceiptUpdateTask_FFDisabled() throws IOException {
        I9Form resp = OBJECT_MAPPER.readValue(
            IOUtils.toString(this.getClass().getResourceAsStream(
                "/i9-integration-test/receipt_update/i9form.json"), Charset.defaultCharset()),
            new TypeReference<I9Form>(){});
        List<Task> tasks = new ArrayList<>();

        Task t2 = new Task();
        t2.setTaskId("2");
        t2.setTaskType("I9:Section2");
        t2.setTaskStatus("COMPLETED");
        tasks.add(t2);

        when(i9ApiCall.getFeature(anyString())).thenReturn(Mono.just(Boolean.FALSE));
        MyTaskSubscriberConfig taskSubscriberConfig = new MyTaskSubscriberConfig(i9ApiCall, taskApiRemoteCallService,
            publisherService, messageConfirmationForFlow, properties, employerPersonCall,reactiveSubscriber);
        TaskHandlerObject taskObj = new TaskHandlerObject(null, tasks);
        taskObj.addI9FormResponse(resp);
        TaskHandlerObject ret =taskSubscriberConfig.createReceiptUpdateTask("doc123", "SECTION2_COMPLETE", taskObj).block();
        assertNotNull(ret);
        assertEquals(1, ret.getTasks().size());
        verify(i9ApiCall, times(1)).getFeature("receiptUpdate");
        verify(properties, times(1)).getReceiptUpdateSectionTwo();
    }

    @Test
    public void testReceiptUpdate_CloseTask() throws IOException {
        String docid = "0fL2CZBpDKxjwvxA2aue";
        when(messageConfirmationForFlow.getObject(any())).thenReturn(new MessageConfirmation());
        TasksSubscriberConfig tc = new TasksSubscriberConfig(i9ApiCall, taskApiRemoteCallService,publisherService,
            messageConfirmationForFlow,properties,employerPersonCall,reactiveSubscriber);
        List<Task> tasks = new ArrayList<>();
        Task t1 = new Task();
        t1.setTaskId("1");
        t1.setTaskType("I9:ReceiptUpdate");
        t1.setTaskStatus("NEW");

        Task t2 = new Task();
        t2.setTaskId("2");
        t2.setTaskType("I9:Section2");
        t2.setTaskStatus("COMPLETED");
        tasks.add(t1); tasks.add(t2);
        when(i9ApiCall.getTasks(docid)).thenReturn(Mono.just(tasks));
        I9Form i9Form = OBJECT_MAPPER.readValue(
            IOUtils.toString(this.getClass().getResourceAsStream(
                "/i9-integration-test/receipt_update/0fL2CZBpDKxjwvxA2aue_version9.json"), Charset.defaultCharset()),
            new TypeReference<I9Form>() {
            });
        when(i9ApiCall.getFormByRevision(docid, "9")).thenReturn(Mono.just(i9Form));
        TaskType taskType = new TaskType(); taskType.setCode("I9:ReceiptUpdate");
        when(properties.getReceiptUpdateSectionTwo()).thenReturn(taskType);
        Audit audit = new Audit();
        audit.setRecordRevision(9L); audit.setEventKey("Section2_Amended");
        when(i9ApiCall.getAudit(docid, 9L)).thenReturn(Mono.just(audit));

        I9FormResponse i9FormResponse = new I9FormResponse();
        when(i9ApiCall.patchMetadata(anyString(), any(UpdateMetadataRequest.class))).thenReturn(Mono.just(i9FormResponse));
//        Task taskClosed = new Task();
//        taskClosed.setTaskId("1");
//        taskClosed.setTaskType("I9:ReceiptUpdate");
//        taskClosed.setTaskStatus("COMPLETED");
        when(taskApiRemoteCallService.completeTask(docid, t1, null)).thenAnswer((Answer<Task>) invocation -> {
             t1.setTaskStatus("COMPLETED");
             return t1;
        });

        Map<String, String> attrs = Map.of("efx-session-id", "59cb1b39-a439-4ea9-86f0-830bd78f5b7f",
            "recordVersion", "9",
            "sourceRefId", "e6e58751-19a8-485e-9a64-055afde187f2",
            "employeeFactId", "456",
            "sourceId", "packet-ui",
            "documentId", docid,
            "status", "Section2_Amended",
            "efx-transaction-id", "fffe9efc-c395-4251-9b7e-f65d015830f5",
            "employeeId", "6362064d-5549-45a3-8841-d584266d11fb");
        String data = "{\"document\":{\"employerId\":\"a1020597-e66c-479b-aac4-c00e26fa9282\",\"recordVersion\":9,\"employerLocationId\":\"dc032101-bbb5-4e0a-aae8-3344589d096e\",\"sourceRefId\":\"e6e58751-19a8-485e-9a64-055afde187f2\",\"sourceId\":\"packet-ui\",\"formRevDate\":\"i9v102119\",\"employeeId\":\"6362064d-5549-45a3-8841-d584266d11fb\",\"employeeFactId\":\"c0230bc7-f6e7-4ed1-b38a-0c0ca932f7ee\",\"status\":\"Section2_Complete\",\"projectedStartDate\":\"2021-02-27\"},\"form\":{\"specialPlacement\":false,\"ssnApplied\":false,\"ssnRefused\":false,\"isMinor\":false},\"audit\":{\"date\":\"2021-02-15T18:27:26.625Z\",\"sourceKey\":\"aef4196a-a2d0-4958-adef-ad3e35ef7448\",\"source\":{\"encryptedData\":\"9jVC79p+VXNq+g9Z84J991qRMyGYH8BoJw7xm7Cru0NAthF7++I=\",\"keyStoreId\":\"E5uThQWPaanI8vHExNTN\",\"hmacValue\":\"tkKXLoByWnQ0KZkisVIKdWELUaWl9OMADWxe/mVvrCiS8LeEl3qi/v2Ah+JSGdaTJjCZqPX81yOlcQHtbz4Q+Q==\"},\"sourceIp\":{\"encryptedData\":\"MWpWg46Joeij6tZsml53qZtvUvUGlIcJxfv8bDDaHUfwusCS+6XQx2Tr+w==\",\"keyStoreId\":\"E5uThQWPaanI8vHExNTN\",\"hmacValue\":\"MUCkcn/qPcLPEeoKmFqrzlMgb9L1iEIM8azesdVQrru3OrE4gxCANRzyBTN4T1eRQgJ3vkR8ilWiAszibqeNnQ==\"},\"eventKey\":\"Section2_Amended\",\"eventDescription\":\"Section 2 Amended\",\"dataUpdate\":true,\"dataRevision\":9}}";
        AcknowledgeablePubsubMessage message = new MockAcknowledgeablePubsubMessage("123", attrs, data);
        tc.withTaskCreatedMessage(message).block();
        verify(i9ApiCall, times(1)).getTasks(docid);
        verify(i9ApiCall, times(1)).getFormByRevision(docid, "9");
        verify(properties, atLeastOnce()).getReceiptUpdateSectionTwo();
        verify(i9ApiCall, times(1)).getAudit(docid, 9L);
    }


    private static class MyTaskSubscriberConfig extends TasksSubscriberConfig {

        public MyTaskSubscriberConfig(I9ApiCall i9ApiCall,
            TaskApiRemoteCallService taskApiRemoteCallService,
            PacketPubSubPublisherService publisherService,
            ObjectProvider<MessageConfirmation> messageConfirmationForFlow,
            TaskApiProperties properties,
            EmployerPersonCall employerPersonCall,
            ReactiveSubscriber reactiveSubscriber) {
            super(i9ApiCall, taskApiRemoteCallService, publisherService, messageConfirmationForFlow, properties,
                employerPersonCall, reactiveSubscriber);
        }
    }

}
