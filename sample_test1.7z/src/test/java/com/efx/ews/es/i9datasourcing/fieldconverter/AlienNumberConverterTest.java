package com.efx.ews.es.i9datasourcing.fieldconverter;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Map;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.Test;

class AlienNumberConverterTest {

    final AlienNumberConverter converter = AlienNumberConverter.INSTANCE;

    @Test
    public void shouldConvertAlienNumber() {
        {
            Map<String, String> mockedFlattenedI9Form = Map.of("irrelevant.key", "true");

            String convertedValue = converter.convert(mockedFlattenedI9Form);

            assertThat(convertedValue).isEqualTo(StringUtils.EMPTY);
        }
        { // values are in the map, but do not fulfill the conditions
            Map<String, String> mockedFlattenedI9Form = Map.of(
                "formData.sectionOne.attestation.isAlienAuthorizedToWork", "false",
                "formData.sectionOne.attestation.alienAuthorizedToWorkData.alienRegistrationNumber", "987654321",
                "formData.sectionOne.attestation.isLawfulPermanentResident", "false",
                "formData.sectionOne.attestation.lawfulPermanentResidentInfo.alienRegistrationNumber", "123456XXX");

            String convertedValue = converter.convert(mockedFlattenedI9Form);

            assertThat(convertedValue).isEqualTo(StringUtils.EMPTY);
        }
        { // isAlienAuthorizedToWork = true, but no alienAuthorizedToWorkData.alienRegistrationNumber in map
            Map<String, String> mockedFlattenedI9Form = Map.of(
                "formData.sectionOne.attestation.isAlienAuthorizedToWork", "true",
                "formData.sectionOne.attestation.isLawfulPermanentResident", "false",
                "formData.sectionOne.attestation.lawfulPermanentResidentInfo.alienRegistrationNumber", "123456XXX");

            String convertedValue = converter.convert(mockedFlattenedI9Form);

            assertThat(convertedValue).isEqualTo(StringUtils.EMPTY);
        }
        {
            Map<String, String> mockedFlattenedI9Form = Map.of(
                "formData.sectionOne.attestation.isAlienAuthorizedToWork", "true",
                "formData.sectionOne.attestation.alienAuthorizedToWorkData.alienRegistrationNumber", "987654321",
                "formData.sectionOne.attestation.isLawfulPermanentResident", "false",
                "formData.sectionOne.attestation.lawfulPermanentResidentInfo.alienRegistrationNumber", "123456XXX");

            String convertedValue = converter.convert(mockedFlattenedI9Form);

            assertThat(convertedValue).isEqualTo("987654321");
        }
        { // isLawfulPermanentResident = true, but no lawfulPermanentResidentInfo.alienRegistrationNumber in map
            Map<String, String> mockedFlattenedI9Form = Map.of(
                "formData.sectionOne.attestation.isAlienAuthorizedToWork", "false",
                "formData.sectionOne.attestation.alienAuthorizedToWorkData.alienRegistrationNumber", "987654321",
                "formData.sectionOne.attestation.isLawfulPermanentResident", "true");

            String convertedValue = converter.convert(mockedFlattenedI9Form);

            assertThat(convertedValue).isEqualTo(StringUtils.EMPTY);
        }
        {
            Map<String, String> mockedFlattenedI9Form = Map.of(
                "formData.sectionOne.attestation.isAlienAuthorizedToWork", "false",
                "formData.sectionOne.attestation.alienAuthorizedToWorkData.alienRegistrationNumber", "987654321",
                "formData.sectionOne.attestation.isLawfulPermanentResident", "true",
                "formData.sectionOne.attestation.lawfulPermanentResidentInfo.alienRegistrationNumber", "123456XXX");

            String convertedValue = converter.convert(mockedFlattenedI9Form);

            assertThat(convertedValue).isEqualTo("123456XXX");
        }
    }
}