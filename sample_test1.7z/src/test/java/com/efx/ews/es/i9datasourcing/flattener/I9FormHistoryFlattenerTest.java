package com.efx.ews.es.i9datasourcing.flattener;

import static org.assertj.core.api.Assertions.assertThat;

import com.efx.ews.es.i9datasourcing.data.MockI9FormData;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.I9Form;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class I9FormHistoryFlattenerTest {

    private static final int I_9_FORM_BASIC_FIELDS = 16;
    private static final int FORM_DATA_BASIC_FIELDS = 6;

    // SECTION ONE
    private static final int SECTION_ONE_BASIC_FIELDS = 2;
    private static final int EMPLOYEE_INFO_FIELDS = 13;
    private static final int ATTESTATION_BASIC_FIELDS = 4;
    private static final int LAWFUL_PERMANENT_RESIDENT_INFO_FIELDS = 1;
    private static final int ALIEN_AUTHORIZED_TO_WORK_DATA_BASIC_FIELDS = 3;
    private static final int FOREIGN_PASSPORT_DATA_FIELDS = 2;
    private static final int ALIEN_AUTHORIZED_TO_WORK_DATA_FIELDS =
        ALIEN_AUTHORIZED_TO_WORK_DATA_BASIC_FIELDS + FOREIGN_PASSPORT_DATA_FIELDS;
    private static final int ATTESTATION_FIELDS =
        ATTESTATION_BASIC_FIELDS + LAWFUL_PERMANENT_RESIDENT_INFO_FIELDS + ALIEN_AUTHORIZED_TO_WORK_DATA_FIELDS;
    private static final int SIGNATURE_DATA_FIELDS = 8;
    private static final int PREPARERS_BASIC_FIELDS = 7;
    private static final int PREPARERS_FIELDS = PREPARERS_BASIC_FIELDS + SIGNATURE_DATA_FIELDS;

    private static final int HOW_MANY_IN_PREPARERS_LIST = 2;
    private static final int ALL_PREPARERS_FIELDS_IN_LIST = HOW_MANY_IN_PREPARERS_LIST * PREPARERS_FIELDS;

    private static final int SECTION_ONE_FIELDS =
        SECTION_ONE_BASIC_FIELDS + EMPLOYEE_INFO_FIELDS + ATTESTATION_FIELDS + ALL_PREPARERS_FIELDS_IN_LIST
            + SIGNATURE_DATA_FIELDS;

    // SECTION TWO
    private static final int SECTION_TWO_BASIC_FIELDS = 2;
    private static final int EMPLOYEE_FIELDS = 4;
    private static final int EMPLOYER_REPRESENTATIVE_FIELDS = 3;

    private static final int DOCUMENT_FIELDS = 7;
    private static final int LIST_A_FIELDS = 3 * DOCUMENT_FIELDS;
    private static final int LIST_B_FIELDS = 1 * DOCUMENT_FIELDS;
    private static final int LIST_C_FIELDS = 1 * DOCUMENT_FIELDS;
    private static final int ORGANIZATION_FIELDS = 5;
    private static final int HOW_MANY_IN_ADDITIONAL_INFORMATION_LIST = 2;
    private static final int ADDITIONAL_INFORMATION_FIELDS = 2;
    private static final int ALL_ADDITIONAL_INFORMATION_FIELDS_IN_LIST =
        HOW_MANY_IN_ADDITIONAL_INFORMATION_LIST * ADDITIONAL_INFORMATION_FIELDS;

    private static final int SECTION_TWO_FIELDS =
        SECTION_TWO_BASIC_FIELDS + EMPLOYEE_FIELDS + EMPLOYER_REPRESENTATIVE_FIELDS + LIST_A_FIELDS + LIST_B_FIELDS
            + LIST_C_FIELDS + ORGANIZATION_FIELDS + ALL_ADDITIONAL_INFORMATION_FIELDS_IN_LIST + SIGNATURE_DATA_FIELDS;

    // SECTION THREE
    private static final int SECTION_THREE_BASIC_FIELDS = 9;
    private static final int HOW_MANY_IN_SECTION_THREE_LIST = 1;
    private static final int SECTION_THREE_FIELDS =
        SECTION_THREE_BASIC_FIELDS + DOCUMENT_FIELDS + SIGNATURE_DATA_FIELDS;
    private static final int ALL_SECTION_THREE_FIELDS_IN_LIST = HOW_MANY_IN_SECTION_THREE_LIST * SECTION_THREE_FIELDS;

    private static final int FORM_DATA_FIELDS =
        FORM_DATA_BASIC_FIELDS + SECTION_ONE_FIELDS + SECTION_TWO_FIELDS + ALL_SECTION_THREE_FIELDS_IN_LIST;

    private I9FormHistoryFlattener i9FormHistoryFlattener;

    @BeforeEach
    public void init() {
        i9FormHistoryFlattener = new I9FormHistoryFlattener();
    }

    @Test
    void shouldFlatenNotAppliedValuesToEmpty() {
        I9Form i9Form = new I9Form();
        i9Form.setEverifyVersion("N/A");
        i9Form.setDocumentId("n/a");

        final Map<String, String> flattenedI9Form = i9FormHistoryFlattener.process(i9Form);

        assertThat(flattenedI9Form)
            .containsEntry("everifyVersion", StringUtils.EMPTY)
            .containsEntry("documentId", StringUtils.EMPTY);
    }

    @Test
    void shouldFlattenWholeI9Form() {
        //given
        I9Form i9Form = MockI9FormData.createI9FormToFlatten();

        //when
        final Map<String, String> flattenedI9Form = i9FormHistoryFlattener.process(i9Form);

        int expectedMapSize = I_9_FORM_BASIC_FIELDS + FORM_DATA_FIELDS;

        //then
        assertThat(EMPLOYEE_INFO_FIELDS)
            .isEqualTo(countKeysStartingWith(flattenedI9Form, "formData.sectionOne.employeeInfo"));
        assertThat(ATTESTATION_FIELDS)
            .isEqualTo(countKeysStartingWith(flattenedI9Form, "formData.sectionOne.attestation"));
        assertThat(PREPARERS_FIELDS)
            .isEqualTo(countKeysStartingWith(flattenedI9Form, "formData.sectionOne.preparers[0]"));
        assertThat(PREPARERS_FIELDS)
            .isEqualTo(countKeysStartingWith(flattenedI9Form, "formData.sectionOne.preparers[1]"));
        assertThat(SIGNATURE_DATA_FIELDS)
            .isEqualTo(countKeysStartingWith(flattenedI9Form, "formData.sectionOne.signature"));
        assertThat(SECTION_ONE_FIELDS).isEqualTo(countKeysStartingWith(flattenedI9Form, "formData.sectionOne"));

        assertThat(EMPLOYEE_FIELDS).isEqualTo(countKeysStartingWith(flattenedI9Form, "formData.sectionTwo.employee"));
        assertThat(EMPLOYER_REPRESENTATIVE_FIELDS).isEqualTo(
            countKeysStartingWith(flattenedI9Form, "formData.sectionTwo.employerRepresentative"));
        assertThat(DOCUMENT_FIELDS)
            .isEqualTo(countKeysStartingWith(flattenedI9Form, "formData.sectionTwo.listA.documentOne"));
        assertThat(DOCUMENT_FIELDS)
            .isEqualTo(countKeysStartingWith(flattenedI9Form, "formData.sectionTwo.listA.documentTwo"));
        assertThat(DOCUMENT_FIELDS).isEqualTo(
            countKeysStartingWith(flattenedI9Form, "formData.sectionTwo.listA.documentThree"));
        assertThat(LIST_A_FIELDS).isEqualTo(countKeysStartingWith(flattenedI9Form, "formData.sectionTwo.listA"));
        assertThat(DOCUMENT_FIELDS)
            .isEqualTo(countKeysStartingWith(flattenedI9Form, "formData.sectionTwo.listB.documentOne"));
        assertThat(LIST_B_FIELDS).isEqualTo(countKeysStartingWith(flattenedI9Form, "formData.sectionTwo.listB"));
        assertThat(DOCUMENT_FIELDS)
            .isEqualTo(countKeysStartingWith(flattenedI9Form, "formData.sectionTwo.listC.documentOne"));
        assertThat(LIST_C_FIELDS).isEqualTo(countKeysStartingWith(flattenedI9Form, "formData.sectionTwo.listC"));
        assertThat(ORGANIZATION_FIELDS)
            .isEqualTo(countKeysStartingWith(flattenedI9Form, "formData.sectionTwo.organization"));
        assertThat(ADDITIONAL_INFORMATION_FIELDS).isEqualTo(
            countKeysStartingWith(flattenedI9Form, "formData.sectionTwo.additionalInformation[0]"));
        assertThat(SIGNATURE_DATA_FIELDS)
            .isEqualTo(countKeysStartingWith(flattenedI9Form, "formData.sectionTwo.signature"));
        assertThat(SECTION_TWO_FIELDS).isEqualTo(countKeysStartingWith(flattenedI9Form, "formData.sectionTwo"));

        assertThat(DOCUMENT_FIELDS).isEqualTo(
            countKeysStartingWith(flattenedI9Form, "formData.sectionThreeList[0].reverificationDocument"));
        assertThat(SIGNATURE_DATA_FIELDS).isEqualTo(
            countKeysStartingWith(flattenedI9Form, "formData.sectionThreeList[0].employerSignature"));
        assertThat(ALL_SECTION_THREE_FIELDS_IN_LIST)
            .isEqualTo(countKeysStartingWith(flattenedI9Form, "formData.sectionThreeList["));

        assertThat(FORM_DATA_FIELDS).isEqualTo(countKeysStartingWith(flattenedI9Form, "formData"));

        assertThat(expectedMapSize).isEqualTo(flattenedI9Form.size());
    }

    private static long countKeysStartingWith(Map<String, String> map, String prefix) {
        return map.keySet().stream().filter(key -> key.startsWith(prefix)).count();
    }
}