package com.efx.ews.es.i9datasourcing.dep.util;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

import com.efx.ews.es.eev.barricade.common.model.PubSubEncryptedData;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.pubsub.PubSubEvent;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.configuration.DataPurgeProperties;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.configuration.PubSubProperties;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

class PubSubEventBuilderTest {
    @InjectMocks
    private PubSubEventBuilder instance;
    @Mock
    private PubSubProperties pubSubProperties;

    @BeforeEach
    void init() {
        initMocks(this);
        when(pubSubProperties.getDataPurge()).thenReturn(mockDataPurgeProperties());
        mockDataPurgeProperties();
    }

    @Test
    void testConvertOk() {
        String jsonPayload = "Test-jsonPayload";
        PubSubEncryptedData encrptionPayload = new PubSubEncryptedData(new String(jsonPayload), "encryptionMetadata",
            "gcsBucketPath");
        PubSubEvent pubsubEvent = instance.buildDataPurgeBillingEvent(encrptionPayload, "employeeId");
        assertThat(pubsubEvent).isNotNull();
        assertEquals("eventName", pubsubEvent.getEventName());

    }
    private DataPurgeProperties mockDataPurgeProperties() {
        DataPurgeProperties dataPurgeProperties = new DataPurgeProperties();
        dataPurgeProperties.setEnabled(true);
        dataPurgeProperties.setProjectId("projectId");
        dataPurgeProperties.setEventTopicId("eventTopicId");
        dataPurgeProperties.setAppId("appId");
        dataPurgeProperties.setEventName("eventName");
        dataPurgeProperties.setEventType("type");
       return dataPurgeProperties;
    }

}
