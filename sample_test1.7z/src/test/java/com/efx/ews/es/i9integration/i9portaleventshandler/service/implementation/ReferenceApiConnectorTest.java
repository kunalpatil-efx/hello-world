package com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.referenceapi.Country;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.referenceapi.DocumentDefinition;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.referenceapi.IssuingAuthorityLookup;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.referenceapi.Province;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.referenceapi.State;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.referenceapi.response.CountriesResponse;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.referenceapi.response.ProvincesResponse;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.referenceapi.response.StatesResponse;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.AbstractRemoteServiceProperties;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.ReferenceApiProperties;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.WireMockServer;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ReferenceApiConnectorTest {

    private static final int MOCK_PORT = 16067;
    private static final WireMockServer MOCK_SERVER = new WireMockServer(MOCK_PORT);
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    private ReferenceApiConnector referenceApiConnector;
    private ReferenceApiProperties referenceApiProperties;

    @BeforeClass
    public static void init() throws Exception {
        StatesResponse states = new StatesResponse();
        states.setI9Versions(Collections.singletonList("i9v071717"));
        states.setStates(Collections.singletonList(new State("GA", "Georgia")));
        MOCK_SERVER.stubFor(
                get(urlPathMatching("/internal/eev/reference-data/v1/states")).withQueryParams(Map.of("i9Version", equalTo("i9v071717")))
                        .willReturn(
                                aResponse()
                                        .withStatus(200)
                                        .withHeader("Content-Type", "application/json")
                                        .withBody(OBJECT_MAPPER.writeValueAsString(states))
                        ));
        CountriesResponse countries = new CountriesResponse();
        countries.setI9Versions(Collections.singletonList("i9v071717"));
        countries.setCountries(Collections.singletonList(new Country("India", "IND", true)));
        MOCK_SERVER.stubFor(
                get(urlPathMatching("/internal/eev/reference-data/v1/countries")).withQueryParams(Map.of("i9Version", equalTo("i9v071717")))
                        .willReturn(
                                aResponse()
                                        .withStatus(200)
                                        .withHeader("Content-Type", "application/json")
                                        .withBody(OBJECT_MAPPER.writeValueAsString(countries))
                        ));
        ProvincesResponse provinces = new ProvincesResponse();
        provinces.setI9Versions(Collections.singletonList("i9v071717"));
        provinces.setProvinces(Collections.singletonList(new Province("Province1", "PRV1")));
        MOCK_SERVER.stubFor(
                get(urlPathMatching("/internal/eev/reference-data/v1/provinces")).withQueryParams(Map.of("i9Version", equalTo("i9v071717")))
                        .willReturn(
                                aResponse()
                                        .withStatus(200)
                                        .withHeader("Content-Type", "application/json")
                                        .withBody(OBJECT_MAPPER.writeValueAsString(provinces))
                        ));
        InputStream is = ReferenceApiConnectorTest.class
            .getResourceAsStream("/__files/referenceApiDocumentsResponse.json");
        assertNotNull(is);
        String documents = IOUtils.toString(is, StandardCharsets.UTF_8);
        assertTrue(StringUtils.isNotEmpty(documents));
        MOCK_SERVER.stubFor(
            get(urlPathMatching("/internal/eev/reference-data/v1/documents/all-documents")).withQueryParams(Map.of("i9Version", equalTo("i9v071717")))
                .willReturn(
                    aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(documents)
                ));
        MOCK_SERVER.start();
    }

    @AfterClass
    public static void destroy() {
        MOCK_SERVER.stop();
    }

    @Before
    public void setup() {
        AbstractRemoteServiceProperties.RemoteResource countriesResource = mock(AbstractRemoteServiceProperties.RemoteResource.class);
        when(countriesResource.getPath()).thenReturn("countries");
        AbstractRemoteServiceProperties.RemoteResource statesResource = mock(AbstractRemoteServiceProperties.RemoteResource.class);
        when(statesResource.getPath()).thenReturn("states");
        AbstractRemoteServiceProperties.RemoteResource provincesResource = mock(AbstractRemoteServiceProperties.RemoteResource.class);
        when(provincesResource.getPath()).thenReturn("provinces");
        AbstractRemoteServiceProperties.RemoteResource documentsResource = mock(AbstractRemoteServiceProperties.RemoteResource.class);
        when(documentsResource.getPath()).thenReturn("documents/all-documents");

        referenceApiProperties = mock(ReferenceApiProperties.class);
        when(referenceApiProperties.getCountries()).thenReturn(countriesResource);
        when(referenceApiProperties.getStates()).thenReturn(statesResource);
        when(referenceApiProperties.getProvinces()).thenReturn(provincesResource);
        when(referenceApiProperties.getDocuments()).thenReturn(documentsResource);
        when(referenceApiProperties.getI9Version()).thenReturn("i9v071717");
        when(referenceApiProperties.getHost()).thenReturn("localhost");
        when(referenceApiProperties.getPort()).thenReturn(MOCK_PORT);
        when(referenceApiProperties.getScheme()).thenReturn("http");
        when(referenceApiProperties.getPath()).thenReturn("/internal/eev/reference-data/v1");
        referenceApiConnector = new ReferenceApiConnector(referenceApiProperties, 1024*1024);
    }

    @Test
    public void testGetCountries() {
        assertNotNull(referenceApiConnector);
        List<Country> countryList = referenceApiConnector.getCountries("i9v071717").block();
        assertNotNull(countryList);
        assertTrue(countryList.size() > 0);
        Country country = countryList.get(0);
        assertNotNull(country);
        assertEquals(new Country("India", "IND", true), country);

        Map<String, Country> map = referenceApiConnector.getCountryCodeMap("i9v071717").block();
        assertNotNull(map);
        assertTrue(map.size() > 0);
        assertNotNull(map.get("IND"));
        assertEquals(new Country("India", "IND", true), map.get("IND"));
    }

    @Test
    public void testGetCountries_NoData() {
        assertNotNull(referenceApiConnector);
        List<Country> countryList = referenceApiConnector.getCountries("invalid").block();
        assertNull(countryList);
    }

    @Test
    public void testGetStates() {
        assertNotNull(referenceApiConnector);
        List<State> states = referenceApiConnector.getStates("i9v071717").block();
        assertNotNull(states);
        assertTrue(states.size() > 0);
        State state = states.get(0);
        assertNotNull(state);
        assertEquals(new State("GA", "Georgia"), state);

        Map<String, State> map = referenceApiConnector.getStateCodeMap("i9v071717").block();
        assertNotNull(map);
        assertNotNull(map.get("GA"));
        assertEquals(new State("GA", "Georgia"), map.get("GA"));
    }

    @Test
    public void testGetStates_NoData() {
        assertNotNull(referenceApiConnector);
        List<State> states = referenceApiConnector.getStates("invalid").block();
        assertNull(states);
    }

    @Test
    public void testGetStatesMap_NoData() {
        Map<String, State> map = referenceApiConnector.getStateCodeMap("invalid").block();
        assertNull(map);
    }

    @Test
    public void testGetProvinces() {
        assertNotNull(referenceApiConnector);
        List<Province> provinces = referenceApiConnector.getProvinces("i9v071717").block();
        assertNotNull(provinces);
        assertTrue(provinces.size() > 0);
        Province province = provinces.get(0);
        assertNotNull(province);
        assertEquals(new Province("Province1", "PRV1"), province);

        Map<String, Province> map = referenceApiConnector.getProvinceCodeMap("i9v071717").block();
        assertNotNull(map);
        assertNotNull(map.get("PRV1"));
        assertEquals(new Province("Province1", "PRV1"), map.get("PRV1"));
    }

    @Test
    public void testGetProvinces_NoData() {
        assertNotNull(referenceApiConnector);
        List<Province> provinces = referenceApiConnector.getProvinces("invalid").block();
        assertNull(provinces);
    }

    @Test
    public void testGetProvincesMap_NoData() {
        Map<String, Province> map = referenceApiConnector.getProvinceCodeMap("invalid").block();
        assertNull(map);
    }

    @Test
    public void testDocumentDefinitions() {
        assertNotNull(referenceApiConnector);
        List<DocumentDefinition> docdefs = referenceApiConnector.getDocumentDefinitions("i9v071717").block();
        assertNotNull(docdefs);
        assertFalse(docdefs.isEmpty());

        Map<String, IssuingAuthorityLookup> lookupMap = referenceApiConnector.getIssuingAuthorityMap("i9v071717").block();
        assertNotNull(lookupMap);
        String[] documentTitles = {"Driver's License Issued by State or Possession with Photo",
            "ID Card Issued by State or Possession with Photo",
            "Canadian Driver's license",
            "Foreign Passport"};

        for(String title: documentTitles) {
            assertNotNull(lookupMap.get(title));
        }
    }

    @Test
    public void testError500() {
        MOCK_SERVER.stubFor(
            get(urlPathMatching("/internal/eev/reference-data/v1/countries/err500"))
                .withQueryParams(Map.of("i9Version", equalTo("i9v071717")))
                .willReturn(aResponse().withStatus(500).withBody("Error getting countries")));

        AbstractRemoteServiceProperties.RemoteResource res = mock(AbstractRemoteServiceProperties.RemoteResource.class);
        when(res.getPath()).thenReturn("countries/err500");

        ReferenceApiProperties props = mock(ReferenceApiProperties.class);
        when(props.getScheme()).thenReturn("http");
        when(props.getHost()).thenReturn("localhost");
        when(props.getPort()).thenReturn(MOCK_PORT);
        when(props.getPath()).thenReturn("/internal/eev/reference-data/v1");
        when(props.getCountries()).thenReturn(res);

        ReferenceApiConnector conn = new ReferenceApiConnector(props, 1024*1024);
        List<Country> countryList = conn.getCountries("i9v071717").block();
        assertNull(countryList);
    }

}
