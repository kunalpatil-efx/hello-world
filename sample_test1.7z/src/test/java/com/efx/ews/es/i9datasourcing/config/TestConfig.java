package com.efx.ews.es.i9datasourcing.config;

import com.efx.ews.es.i9datasourcing.provider.CountryCodeProvider;
import com.efx.ews.es.i9datasourcing.provider.CountryCodeProviderMock;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;

@TestConfiguration
public class TestConfig {

    @Primary
    @Bean
    public CountryCodeProvider countryCodeProvider() {
        return new CountryCodeProviderMock();
    }
}