package com.efx.ews.es.i9integration.i9portaleventshandler;

import com.efx.ews.es.eev.barricade.common.model.BarricadeKeyStore;
import com.efx.ews.es.eev.barricade.common.model.PubSubEncryptedData;
import com.efx.ews.es.eev.barricade.common.service.CryptographyService;
import com.efx.ews.es.eev.barricade.common.service.PubSubEncryptionService;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.pubsub.Event;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.pubsub.PubSubEvent;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.GooglePublisherService;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.configuration.PubSubProperties;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.I9FormDao;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.ReferenceApiService;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.gcp.pubsub.support.BasicAcknowledgeablePubsubMessage;
import org.springframework.cloud.gcp.pubsub.support.GcpPubSubHeaders;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.util.concurrent.ListenableFuture;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.UUID;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@SpringBootTest
class BillingTest {

    private final String documentId = "HFW3f5BppZMXIWB6MZGt";

    @Autowired
    private ServiceCalls serviceCalls;
    @Autowired
    private BillingSubscriberConfig config;
    @Autowired
    private PubSubProperties pubSubProperties;

    @MockBean
    private I9FormDao i9FormDao;
    @MockBean
    private GooglePublisherService pubSubService;

    @MockBean
    List<BarricadeKeyStore> barricadeKeyStores;
    @MockBean
    CryptographyService cryptographyService;
    @MockBean
    private PubSubEncryptionService pubSubEncryptionService;
    @MockBean
    private ReferenceApiService referenceApiService;

    private BasicAcknowledgeablePubsubMessage ackMessage = mock(BasicAcknowledgeablePubsubMessage.class);
    private Message message = mock(Message.class);
    private MessageHeaders headers = mock(MessageHeaders.class);
    private ListenableFuture<Void> nackFuture = mock(ListenableFuture.class);
    private ListenableFuture<Void> ackFuture = mock(ListenableFuture.class);

    @BeforeEach
    public void setup() {
        when(message.getHeaders()).thenReturn(headers);
        when(headers.get(GcpPubSubHeaders.ORIGINAL_MESSAGE, BasicAcknowledgeablePubsubMessage.class))
                .thenReturn(ackMessage);
        when(headers.getOrDefault(any(), any())).thenReturn(UUID.randomUUID().toString());
        when(ackMessage.nack()).thenReturn(nackFuture);
        when(ackMessage.ack()).thenReturn(ackFuture);
        when(headers.get("documentId", String.class)).thenReturn(documentId);
        when(pubSubEncryptionService.encrypt(any())).thenReturn(mock(PubSubEncryptedData.class));

        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/forms/" + documentId)
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("getForm.json")));
        serviceCalls.employerConfigApi
                .stubFor(get("/internal/es-platform/employer-configuration/v1/employers/27733c9f-a64a-417e-9c47-659d16a4bf8a")
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("employer.json")));
    }

    @Test
    public void testBilling() {
        when(pubSubService.sendEventAsync(any())).thenReturn(Mono.just("123"));
        when(i9FormDao.updateEvent(eq(documentId), any(Event.class))).thenReturn(Mono.just("2020-08-20T00:00:00.00Z"));
        config.handleMessage(message);
        verify(ackMessage, never()).nack();
        verify(ackMessage).ack();
        verify(i9FormDao, atLeast(1)).updateEvent(eq(documentId), any(Event.class));
        verify(pubSubService, atLeastOnce()).sendEventAsync(any(PubSubEvent.class));
    }

    @Test
    public void eventEncryptionFails() {
        when(pubSubEncryptionService.encrypt(any()))
                .thenThrow(
                        new IllegalStateException("PubSub - wrappedKey or encryptor or gcsBucketPath is empty. Can not encrypt eventPayload"));
        config.handleMessage(message);
        verify(ackMessage, times(1)).nack();
    }

    @Test
    public void testErrorOnI9() {
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/forms/" + documentId)
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withStatus(404)));
        config.handleMessage(message);
        verify(ackMessage, times(1)).nack();
        verify(ackMessage, never()).ack();
    }

    @Test
    public void testErrorOnEmployerConfiguration() {
        serviceCalls.employerConfigApi
                .stubFor(get("/internal/es-platform/employer-configuration/v1/employers/27733c9f-a64a-417e-9c47-659d16a4bf8a")
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withStatus(404)));
        config.handleMessage(message);
        verify(ackMessage, times(1)).nack();
        verify(ackMessage, never()).ack();
    }

    @Test
    public void testFilter_S2() {
        when(headers.get("status", String.class)).thenReturn("Section2_Complete");
        Assert.assertTrue(config.shouldExecute(message));
    }

    @Test
    public void testFilter_S1() {
        when(headers.get("status", String.class)).thenReturn("Section1_Complete");
        Assert.assertFalse(config.shouldExecute(message));
        config.noBillingForThisMessage(message);
        verify(ackMessage, never()).nack();
        verify(ackMessage, times(1)).ack();
    }

    @Test
    public void testFilter_Disabled() {
        pubSubProperties.setEnabled(false);
        when(headers.get("status", String.class)).thenReturn("Section2_Complete");
        Assert.assertFalse(config.shouldExecute(message));
        config.noBillingForThisMessage(message);
        verify(ackMessage, never()).nack();
        verify(ackMessage, times(1)).ack();
    }

    @Test
    public void testFilter_I9Anywhere() {
        when(headers.get("status", String.class)).thenReturn("Section2_Complete");
        when(headers.get("sourceId", String.class)).thenReturn("packet-ui-I9ANYWHERE");
        Assert.assertFalse(config.shouldExecute(message));
        config.noBillingForThisMessage(message);
        verify(ackMessage, never()).nack();
        verify(ackMessage, times(1)).ack();

    }
}
