package com.efx.ews.es.i9datasourcing.fieldconverter;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.efx.ews.es.dto.LocationDto;
import com.efx.ews.es.i9datasourcing.provider.LocationDataProvider;
import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import reactor.core.publisher.Mono;

class LocationNameConverterTest {

    private static final String EMPLOYER_ID_NAME = "employerId";
    private static final String EMPLOYER_LOCATION_ID_NAME = "employerLocationId";

    private final LocationDataProvider locationDataProvider = mock(LocationDataProvider.class);
    private final LocationNameConverter instance
        = new LocationNameConverter(EMPLOYER_ID_NAME, EMPLOYER_LOCATION_ID_NAME, locationDataProvider);

    @Test
    void convert() {
        var employerId = UUID.randomUUID();
        var employerLocationId = UUID.randomUUID();

        var locationName = "locationName";

        when(locationDataProvider.getLocation(employerId, employerLocationId))
            .thenReturn(Mono.just(new LocationDto().setLocationName(locationName)));

        var source = Map.of(
            EMPLOYER_ID_NAME, employerId.toString(),
            EMPLOYER_LOCATION_ID_NAME, employerLocationId.toString()
        );

        var actual = instance.convert(source);

        assertThat(actual).isEqualTo(locationName);
    }
}