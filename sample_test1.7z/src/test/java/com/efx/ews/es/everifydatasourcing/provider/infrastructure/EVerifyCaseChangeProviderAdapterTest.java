package com.efx.ews.es.everifydatasourcing.provider.infrastructure;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.efx.ews.es.everifydatasourcing.model.pubsub.EventMessage;
import com.efx.ews.es.everifydatasourcing.provider.api.EVerifyCaseChangeEventListener;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.EVerifyApiCall;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.pubsub.v1.PubsubMessage;
import java.util.function.Consumer;
import lombok.SneakyThrows;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.cloud.gcp.pubsub.core.subscriber.PubSubSubscriberTemplate;
import org.springframework.cloud.gcp.pubsub.support.BasicAcknowledgeablePubsubMessage;

public class EVerifyCaseChangeProviderAdapterTest {

    private static final String MESSAGE_ID = "messageId-55";

    private EVerifyCaseChangeProviderAdapter providerAdapter;
    private EVerifyCaseChangeEventListener eventListener;
    private PubSubSubscriberTemplate pubSubTemplate;
    private ObjectMapper objectMapper;

    @BeforeEach
    public void setUp() {
        eventListener = mock(EVerifyCaseChangeEventListener.class);
        EVerifyApiCall apiCall = mock(EVerifyApiCall.class);
        objectMapper = mock(ObjectMapper.class);
        pubSubTemplate = mock(PubSubSubscriberTemplate.class);
        providerAdapter = new EVerifyCaseChangeProviderAdapter(apiCall, objectMapper, pubSubTemplate);
    }

    @Test
    public void registerEventListenerSmokeTest() {

        providerAdapter.registerEventListener(eventListener);
        verify(pubSubTemplate).subscribe(any(), any(Consumer.class));
    }

    @Test
    @SneakyThrows
    void shouldHandleEVerifyMessageSettingMessageId() {
        // given/when
        PubsubMessage pubsubMessage = PubsubMessage.newBuilder()
            .setMessageId(MESSAGE_ID)
            .build();

        BasicAcknowledgeablePubsubMessage basicAcknowledgeablePubsubMessage = mock(
            BasicAcknowledgeablePubsubMessage.class);
        when(basicAcknowledgeablePubsubMessage.getPubsubMessage()).thenReturn(pubsubMessage);

        EventMessage eventMessage = new EventMessage();

        when(objectMapper.readValue(any(String.class), any(Class.class))).thenReturn(eventMessage);

        when(pubSubTemplate.subscribe(any(), any(Consumer.class))).thenAnswer(invocation -> {
            Consumer<BasicAcknowledgeablePubsubMessage> msgConsumer = invocation.getArgument(1);
            msgConsumer.accept(basicAcknowledgeablePubsubMessage);
            return null;
        });

        // execute
        providerAdapter.registerEventListener(eventListener);

        // verify
        verify(basicAcknowledgeablePubsubMessage).ack();
        assertThat(eventMessage.getMessageId()).isEqualTo(MESSAGE_ID);
    }
}
