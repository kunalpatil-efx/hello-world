package com.efx.ews.es.i9datasourcing.provider;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.efx.ews.es.i9datasourcing.client.EmployerLocationApi;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import reactor.core.publisher.Mono;

@ExtendWith(MockitoExtension.class)
class LocationDataProviderImplTest {

    @Mock
    private EmployerLocationApi employerLocationApi;
    @InjectMocks
    private LocationDataProviderImpl instance;

    @Test
    void getLocation() {
        var employerId = UUID.randomUUID();
        var employerLocationId = UUID.randomUUID();
        var locationMono = mock(Mono.class);

        when(employerLocationApi.getLocationByIdInternal(employerId, employerLocationId)).thenReturn(locationMono);

        var actual = instance.getLocation(employerId, employerLocationId);

        assertThat(actual).isEqualTo(locationMono);
    }
}