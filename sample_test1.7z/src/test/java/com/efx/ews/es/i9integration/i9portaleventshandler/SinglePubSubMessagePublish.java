package com.efx.ews.es.i9integration.i9portaleventshandler;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.GenericMessage;

import java.util.Map;

public abstract class SinglePubSubMessagePublish {

    private final IntegrationFlow flow;
    private ObjectMapper objectMapper = new ObjectMapper();

    public SinglePubSubMessagePublish(IntegrationFlow flow) {
        this.flow = flow;
    }

    public void publishMessage(Map<String, String> attributes, Object payload) throws JsonProcessingException {
        Message<?> message = new GenericMessage<Object>(objectMapper.writeValueAsBytes(payload), (Map) attributes);
        flow.getInputChannel().send(message);
    }
}
