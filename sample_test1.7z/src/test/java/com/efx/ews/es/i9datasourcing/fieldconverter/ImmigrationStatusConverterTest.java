package com.efx.ews.es.i9datasourcing.fieldconverter;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Map;
import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.Test;

class ImmigrationStatusConverterTest {

    final ImmigrationStatusConverter converter = ImmigrationStatusConverter.INSTANCE;

    @Test
    public void shouldConvertImmigrationStatus() {
        {
            Map<String, String> mockedFlattenedI9Form = Map.of("irrelevant.key", "true");

            String convertedValue = converter.convert(mockedFlattenedI9Form);

            assertThat(convertedValue).isEqualTo(StringUtils.EMPTY);
        }
        { // none of the values is true
            Map<String, String> mockedFlattenedI9Form = Map.of(
                "formData.sectionOne.attestation.isAlienAuthorizedToWork", "false",
                "formData.sectionOne.attestation.isLawfulPermanentResident", "false",
                "formData.sectionOne.attestation.isNonCitizenNational", "false",
                "formData.sectionOne.attestation.isUnitedStatesCitizen", "false");

            String convertedValue = converter.convert(mockedFlattenedI9Form);

            assertThat(convertedValue).isEqualTo(StringUtils.EMPTY);
        }
        { // all of the values are true
            Map<String, String> mockedFlattenedI9Form = Map.of(
                "formData.sectionOne.attestation.isAlienAuthorizedToWork", "true",
                "formData.sectionOne.attestation.isLawfulPermanentResident", "true",
                "formData.sectionOne.attestation.isNonCitizenNational", "true",
                "formData.sectionOne.attestation.isUnitedStatesCitizen", "true");

            String convertedValue = converter.convert(mockedFlattenedI9Form);

            assertThat(convertedValue).isEqualTo("An Alien Authorized to Work");
        }
        {
            Map<String, String> mockedFlattenedI9Form = Map.of(
                "formData.sectionOne.attestation.isAlienAuthorizedToWork", "true",
                "formData.sectionOne.attestation.isLawfulPermanentResident", "false",
                "formData.sectionOne.attestation.isNonCitizenNational", "false",
                "formData.sectionOne.attestation.isUnitedStatesCitizen", "false");

            String convertedValue = converter.convert(mockedFlattenedI9Form);

            assertThat(convertedValue).isEqualTo("An Alien Authorized to Work");
        }
        {
            Map<String, String> mockedFlattenedI9Form = Map.of(
                "formData.sectionOne.attestation.isAlienAuthorizedToWork", "false",
                "formData.sectionOne.attestation.isLawfulPermanentResident", "true",
                "formData.sectionOne.attestation.isNonCitizenNational", "false",
                "formData.sectionOne.attestation.isUnitedStatesCitizen", "false");

            String convertedValue = converter.convert(mockedFlattenedI9Form);

            assertThat(convertedValue).isEqualTo("A Lawful Permanent Resident");
        }
        {
            Map<String, String> mockedFlattenedI9Form = Map.of(
                "formData.sectionOne.attestation.isAlienAuthorizedToWork", "false",
                "formData.sectionOne.attestation.isLawfulPermanentResident", "false",
                "formData.sectionOne.attestation.isNonCitizenNational", "true",
                "formData.sectionOne.attestation.isUnitedStatesCitizen", "false");

            String convertedValue = converter.convert(mockedFlattenedI9Form);

            assertThat(convertedValue).isEqualTo("A Non Citizen National of the United States");
        }
        {
            Map<String, String> mockedFlattenedI9Form = Map.of(
                "formData.sectionOne.attestation.isAlienAuthorizedToWork", "false",
                "formData.sectionOne.attestation.isLawfulPermanentResident", "false",
                "formData.sectionOne.attestation.isNonCitizenNational", "false",
                "formData.sectionOne.attestation.isUnitedStatesCitizen", "true");

            String convertedValue = converter.convert(mockedFlattenedI9Form);

            assertThat(convertedValue).isEqualTo("A Citizen of the United States");
        }
    }
}