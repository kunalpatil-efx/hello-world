package com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.pubsub.PubSubEvent;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.GooglePublisherService;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.configuration.DataPurgeProperties;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.configuration.PubSubProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import java.util.concurrent.ExecutionException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class GooglePublisherServiceTest {

    GooglePublisherService service;
    PubSubProperties pubSubProperties;

    @BeforeEach
    public void setup() {
        pubSubProperties = mock(PubSubProperties.class);
        when(pubSubProperties.getProjectId()).thenReturn("project-1");
        service = new GooglePublisherServiceImpl(pubSubProperties);
    }

    @Test
    public void testSendEvent_Exception() throws Exception {
        assertThrows(IllegalArgumentException.class, () -> service.sendEvent(new PubSubEvent()));
    }

    @Test
    public void testSendEventAsync_Exception() throws Exception {
        assertThrows(IllegalArgumentException.class, () -> service.sendEventAsync(new PubSubEvent()));
    }

    @Test
    public void testSendDataPurgeEventAsync_Exception() throws Exception {
        DataPurgeProperties purgeProperties = new DataPurgeProperties();
        purgeProperties.setEventTopicId("topic");
        when(pubSubProperties.getDataPurge()).thenReturn(new DataPurgeProperties());
        assertThrows(NullPointerException.class, () -> service.sendDataPurgeEvent(new PubSubEvent()));
    }

}
