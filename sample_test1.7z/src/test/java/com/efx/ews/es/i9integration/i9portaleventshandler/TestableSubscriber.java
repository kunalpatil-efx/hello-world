package com.efx.ews.es.i9integration.i9portaleventshandler;

import com.efx.ews.es.i9integration.i9portaleventshandler.pubsub.ReactiveSubscriber;
import com.efx.ews.es.i9integration.i9portaleventshandler.pubsub.ReactiveSubscription;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.protobuf.ByteString;
import com.google.pubsub.v1.PubsubMessage;
import lombok.SneakyThrows;
import org.mockito.Mockito;
import org.springframework.cloud.gcp.pubsub.core.subscriber.PubSubSubscriberOperations;
import org.springframework.cloud.gcp.pubsub.reactive.PubSubReactiveFactory;
import org.springframework.cloud.gcp.pubsub.support.AcknowledgeablePubsubMessage;
import org.springframework.context.annotation.Primary;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Component;
import reactor.core.Disposable;
import reactor.core.publisher.Flux;
import reactor.test.scheduler.VirtualTimeScheduler;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@Component
@Primary
public class TestableSubscriber extends ReactiveSubscriber {
    private final ObjectMapper objectMapper = new ObjectMapper();
    private Disposable subscription;
    private Flux<?> flux;
    private PubSubSubscriberOperations subscriberOperations;

    public TestableSubscriber(PubSubReactiveFactory reactiveFactory) {
        super(reactiveFactory);
    }

    @Override
    public void subscribe(ReactiveSubscription reactiveSubscription, String subscriptionName) {
        subscriberOperations = mock(PubSubSubscriberOperations.class);
        PubSubReactiveFactory reactiveFactory = new PubSubReactiveFactory(subscriberOperations, VirtualTimeScheduler.getOrSet());
        final Flux<AcknowledgeablePubsubMessage> subscriptionFlux = reactiveFactory.poll(subscriptionName, 100);
        this.flux = reactiveSubscription.processing(subscriptionFlux);
    }

    @Override
    public void dispose() {
        if (subscription != null) {
            subscription.dispose();
        }
    }

    @SneakyThrows
    public void publishMessage(Map<String, String> attributes, Object message) {
        String payload = objectMapper.writeValueAsString(message);
        setUpMessages(attributes, payload);
        subscription = flux.subscribe();
    }

    public void setUpMessages(Map<String, String> attributes, String... messages) {
        List<String> msgList = new ArrayList<>(Arrays.asList(messages));
        when(subscriberOperations.pullAsync(anyString(), Mockito.any(Integer.class), Mockito.any(Boolean.class))).then(invocationOnMock -> {
            List<AcknowledgeablePubsubMessage> result = new ArrayList<>();
            for (int i = 0; i < (Integer) invocationOnMock.getArgument(1) && !msgList.isEmpty(); i++) {
                String nextPayload = msgList.remove(0);
                AcknowledgeablePubsubMessage msg = mock(AcknowledgeablePubsubMessage.class);
                PubsubMessage pubsubMessage = PubsubMessage.newBuilder()
                        .setData(ByteString.copyFrom((nextPayload).getBytes()))
                        .putAllAttributes(attributes)
                        .build();
                when(msg.getPubsubMessage()).thenReturn(pubsubMessage);
                result.add(msg);
            }
            return AsyncResult.forValue(result);
        });
    }
}
