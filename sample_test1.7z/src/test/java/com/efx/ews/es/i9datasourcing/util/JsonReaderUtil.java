package com.efx.ews.es.i9datasourcing.util;

import java.util.ArrayList;
import java.util.List;
import lombok.SneakyThrows;
import org.json.JSONArray;
import org.json.JSONObject;
import org.skyscreamer.jsonassert.JSONParser;

public class JsonReaderUtil {

    @SneakyThrows
    public static JSONObject readFromFile(String testName, String filename, String rootFolder) {
        return parseJSONObject(ReaderUtil.readStringFromFile(testName, filename, rootFolder));
    }

    @SneakyThrows
    public static JSONObject parseJSONObject(String jsonString) {
        Object json = JSONParser.parseJSON(jsonString);
        if (json instanceof JSONObject) {
            return (JSONObject) json;
        }
        throw new IllegalArgumentException("json is not a JSONObject");
    }

    @SneakyThrows
    public static List<JSONObject> readListFromFile(String testName, String filename, String rootFolder) {
        JSONArray jsonArray = parseJSONArray(testName, filename, rootFolder);
        return toJSONObjectList(jsonArray);
    }

    @SneakyThrows
    private static List<JSONObject> toJSONObjectList(JSONArray jsonArray) {
        List<JSONObject> result = new ArrayList<>();
        for (int i = 0; i < jsonArray.length(); i++) {
            result.add(jsonArray.getJSONObject(i));
        }
        return result;
    }

    @SneakyThrows
    private static JSONArray parseJSONArray(String testName, String filename, String rootFolder) {
        Object json = JSONParser.parseJSON(ReaderUtil.readStringFromFile(testName, filename, rootFolder));
        if (json instanceof JSONArray) {
            return (JSONArray) json;
        }
        throw new IllegalArgumentException("json is not a JSONArray");
    }
}