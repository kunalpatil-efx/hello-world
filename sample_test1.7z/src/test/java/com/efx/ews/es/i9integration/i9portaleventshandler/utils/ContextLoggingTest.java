package com.efx.ews.es.i9integration.i9portaleventshandler.utils;

import org.junit.jupiter.api.Test;
import org.slf4j.MDC;

import static com.efx.ews.es.i9integration.i9portaleventshandler.utils.ContextLogging.CONTEXT_PROPERTY;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class ContextLoggingTest {
    boolean isCalled = false;

    @Test
    public void runnableRunsWhenContextIsSet() {
        ContextLogging contextLogging = new ContextLogging(IllegalArgumentException.class);
        contextLogging.logWithContext(() -> {
            assertEquals("IllegalArgumentException", MDC.get(CONTEXT_PROPERTY));
            isCalled = true;
        });
        assertTrue(isCalled);
    }
}
