package com.efx.ews.es.i9integration.i9portaleventshandler;

import com.fasterxml.jackson.core.JsonProcessingException;

import java.io.IOException;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

public interface MessagePublish {
    void publishMessage(Map<String, String> attributes, Object payload) throws InterruptedException, ExecutionException, TimeoutException, JsonProcessingException;
    void publishMessageToI9AnywhereTaskFlow(Map<String, String> attributes) throws InterruptedException, ExecutionException, TimeoutException, JsonProcessingException;

    default int flowsCount() {
        return 3;
    }
}
