package com.efx.ews.es.i9datasourcing;

import static java.util.Collections.emptyMap;
import static org.mockito.ArgumentMatchers.nullable;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

import com.efx.ews.es.i9datasourcing.fieldconverter.FormConverterImpl;
import com.efx.ews.es.i9datasourcing.flattener.Flattener;
import com.efx.ews.es.i9datasourcing.model.ChangeContext;
import com.efx.ews.es.i9datasourcing.processor.AuditSummarySingleI9FormHistoryProcessor;
import com.efx.ews.es.i9datasourcing.processor.auditdetail.i9formhistory.AuditDetailI9FormHistoryProcessor;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.I9Form;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;

public class I9FormHistoryConverterTest {

    private I9FormHistoryConverter formHistoryConverter;

    @Mock
    private Flattener flattener;
    @Mock
    private FormConverterImpl formConverter;
    @Mock
    private AuditSummarySingleI9FormHistoryProcessor auditSummarySingleI9FormHistoryProcessor;
    @Mock
    private AuditDetailI9FormHistoryProcessor auditDetailI9FormHistoryProcessor;

    @BeforeEach
    void init() {
        initMocks(this);
        formHistoryConverter = new I9FormHistoryConverter(flattener, formConverter,
            auditSummarySingleI9FormHistoryProcessor, auditDetailI9FormHistoryProcessor);
    }

    @Test
    void testConvertOk() {
        //Given
        I9Form i9before = mock(I9Form.class);
        I9Form i9after = mock(I9Form.class);
        ChangeContext changeContext = mock(ChangeContext.class);

        Map<String, String> flattenedI9formBefore = emptyMap();
        Map<String, String> flattenedI9formAfter = emptyMap();

        Map<String, String> convertedI9formBefore = emptyMap();
        Map<String, String> convertedI9formAfter = emptyMap();

        //When
        when(flattener.process(i9before)).thenReturn(flattenedI9formBefore);
        when(flattener.process(i9after)).thenReturn(flattenedI9formAfter);

        when(formConverter.convertForm(flattenedI9formBefore, changeContext)).thenReturn(convertedI9formBefore);
        when(formConverter.convertForm(flattenedI9formAfter, changeContext)).thenReturn(convertedI9formAfter);

        //Execute
        formHistoryConverter.convert(i9before, i9after, changeContext);

        //Verify
        verify(auditSummarySingleI9FormHistoryProcessor)
            .process(convertedI9formBefore, convertedI9formAfter, changeContext);
        verify(auditDetailI9FormHistoryProcessor).process(convertedI9formBefore, convertedI9formAfter, changeContext);
    }

    @Test
    void testMigratedAuditEventSuccess() {
        //Given
        I9Form migratedI9 = mock(I9Form.class);
        ChangeContext changeContext = mock(ChangeContext.class);

        Map<String, String> flattenedI9formBefore = emptyMap();
        Map<String, String> flattenedI9formAfter = emptyMap();

        Map<String, String> convertedI9formBefore = emptyMap();
        Map<String, String> convertedI9formAfter = emptyMap();

        //When
        when(flattener.process(nullable(I9Form.class))).thenReturn(flattenedI9formBefore);
        when(flattener.process(migratedI9)).thenReturn(flattenedI9formAfter);

        when(formConverter.convertForm(flattenedI9formBefore, changeContext)).thenReturn(convertedI9formBefore);
        when(formConverter.convertForm(flattenedI9formAfter, changeContext)).thenReturn(convertedI9formAfter);

        //Execute
        formHistoryConverter.convert(nullable(I9Form.class), migratedI9, changeContext);

        //Verify
        verify(auditSummarySingleI9FormHistoryProcessor)
                .process(convertedI9formBefore, convertedI9formAfter, changeContext);
        verify(auditDetailI9FormHistoryProcessor).process(convertedI9formBefore, convertedI9formAfter, changeContext);
    }
}
