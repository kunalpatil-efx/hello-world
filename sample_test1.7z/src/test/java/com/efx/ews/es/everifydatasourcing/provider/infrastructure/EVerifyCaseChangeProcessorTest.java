package com.efx.ews.es.everifydatasourcing.provider.infrastructure;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isA;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import com.efx.ews.es.everifydatasourcing.EVerifyCaseConverter;
import com.efx.ews.es.everifydatasourcing.model.EVerifyCase;
import com.efx.ews.es.everifydatasourcing.model.pubsub.EventMessage;
import com.efx.ews.es.everifydatasourcing.provider.api.EVerifyCaseChangeEventListener;
import com.efx.ews.es.everifydatasourcing.provider.api.EVerifyCaseChangeProvider;
import com.efx.ews.es.i9datasourcing.model.ChangeContext;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

class EVerifyCaseChangeProcessorTest {

    public static final String MESSAGE_ID = "messageId-3";
    public static final String CASE_ID = "caseId";
    public static final String SOURCE_ID = "8766";
    public static final String SOURCE_NAME = "source-1";
    private static final String EVENT_TIME = "2020-10-30T15:44:57.182048Z";
    private EVerifyCaseChangeProvider changeProvider;
    private EVerifyCaseConverter caseConverter;
    private EVerifyCaseChangeProcessor changeProcessor;

    @BeforeEach
    private void setUp() {
        changeProvider = mock(EVerifyCaseChangeProvider.class);
        caseConverter = mock(EVerifyCaseConverter.class);
        changeProcessor = new EVerifyCaseChangeProcessor(changeProvider, caseConverter);
    }

    @Test
    void testInitProcessorDataSourcingEnabled() {
        // Given
        ReflectionTestUtils.setField(changeProcessor, "reportingDataSourcingEnabled", true);

        // Execute
        changeProcessor.init();

        // Verify
        verify(changeProvider).registerEventListener(any(EVerifyCaseChangeEventListener.class));
    }

    @Test
    void testInitProcessorDataSourcingDisabled() {
        // Given
        ReflectionTestUtils.setField(changeProcessor, "reportingDataSourcingEnabled", false);

        // Execute
        changeProcessor.init();

        // Verify
        verifyNoInteractions(changeProvider);
    }

    @Test
    void processEVerifyCaseTest() {
        EventMessage message = createEventMockMessage();
        EVerifyCase eVerifyCase = createEverifyMockCase();
        when(changeProvider.getCaseById(CASE_ID)).thenReturn(eVerifyCase);

        changeProcessor.processEVerifyCase(message);

        verify(caseConverter).convert(eq(eVerifyCase), isA(
            ChangeContext.class));
    }

    @Test
    void createChangeContextTest() {
        EventMessage message = createEventMockMessage();
        EVerifyCase eVerifyCase = createEverifyMockCase();

        ChangeContext actualResult = changeProcessor.createChangeContext(message);

        assertThat(actualResult.getSource()).isEqualTo(SOURCE_NAME);
        assertThat(actualResult.getCorrelationId()).isEqualTo(SOURCE_ID);
        assertThat(actualResult.getSourceEventDateTime()).isNotNull();
        assertThat(actualResult.getDeduplicationId()).isEqualTo(MESSAGE_ID);
    }

    private EventMessage createEventMockMessage() {
        return EventMessage.builder()
            .everifyCaseId(CASE_ID)
            .sourceId(SOURCE_ID)
            .sourceName(SOURCE_NAME)
            .eventTime(EVENT_TIME)
            .messageId(MESSAGE_ID)
            .build();
    }

    private EVerifyCase createEverifyMockCase() {
        return EVerifyCase.builder().caseId(CASE_ID).build();
    }
}
