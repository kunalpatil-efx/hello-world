package com.efx.ews.es.i9integration.i9portaleventshandler;

import static com.efx.ews.es.i9integration.i9portaleventshandler.utils.WireMockTestFile.testFileContent;
import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.equalToJson;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.getRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.matchingJsonPath;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.postRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.internal.verification.VerificationModeFactory.atLeast;

import com.efx.ews.es.eev.barricade.common.model.BarricadeKeyStore;
import com.efx.ews.es.eev.barricade.common.service.CryptographyService;
import com.efx.ews.es.eev.barricade.common.service.PubSubEncryptionService;
import com.efx.ews.es.i9integration.i9portaleventshandler.EmployeeChangeSubscriberConfig.EmployeeChangeException;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.ReferenceApiService;
import com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageConfirmation;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.matching.RequestPatternBuilder;
import java.time.LocalDateTime;
import java.util.List;
import lombok.SneakyThrows;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.gcp.pubsub.support.BasicAcknowledgeablePubsubMessage;
import org.springframework.cloud.gcp.pubsub.support.GcpPubSubHeaders;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.web.reactive.function.client.WebClientResponseException;

@SpringBootTest
@ExtendWith(SpringExtension.class)
public class EmployeeChangeSubscriberConfigTest {

    private final String mockEmployeeId = "3fa85f64-5717-4562-b3fc-2c963f66afa6";
    private final String mockEvent = "CHANGED";

    @Autowired
    private ServiceCalls serviceCalls;

    @Autowired
    private EmployeeChangeSubscriberConfig employeeChangeSubscriberConfig;

    @MockBean
    List<BarricadeKeyStore> barricadeKeyStores;
    @MockBean
    CryptographyService cryptographyService;
    @MockBean
    private PubSubEncryptionService pubSubEncryptionService;

    @MockBean
    private ReferenceApiService referenceApiService;

    @MockBean
    @Qualifier("messageConfirmation")
    private MessageConfirmation messageConfirmation;

    private BasicAcknowledgeablePubsubMessage ackMessage = mock(BasicAcknowledgeablePubsubMessage.class);
    private Message message = mock(Message.class);
    private ListenableFuture<Void> nackFuture = mock(ListenableFuture.class);
    private ListenableFuture<Void> ackFuture = mock(ListenableFuture.class);

    @SneakyThrows
    private byte[] buildEventBody(String employeeId) {
        EmployeeChangeSubscriberConfig.EmployeeChangeMessageBody body = new EmployeeChangeSubscriberConfig.EmployeeChangeMessageBody();
        body.setEmployee_id(employeeId);
        body.setAs_of(LocalDateTime.now().toString());
        body.setEvent(mockEvent);
        return new ObjectMapper().writeValueAsBytes(body);
    }

    @BeforeEach
    public void setUpMocks() {
        MessageHeaders headers = mock(MessageHeaders.class);
        when(message.getHeaders()).thenReturn(headers);
        when(headers.get(GcpPubSubHeaders.ORIGINAL_MESSAGE, BasicAcknowledgeablePubsubMessage.class))
            .thenReturn(ackMessage);
        when(ackMessage.nack()).thenReturn(nackFuture);
        when(ackMessage.ack()).thenReturn(ackFuture);
    }

    @Test
    public void testEmployeeChangeEvent_success() throws Exception {
        when(message.getPayload()).thenReturn(buildEventBody(mockEmployeeId));

        serviceCalls.i9api
            .stubFor(post("/internal/eev/form-i9/v1/data-maintenance/" + mockEmployeeId + "/termination-detail")
                .withRequestBody(equalToJson(testFileContent("terminationDetailRequest.json"),
                    true,
                    true))
                .willReturn(aResponse().withStatus(200)));

        serviceCalls.employerPersonApi
            .stubFor(get("/internal/es-platform/employer-person/v1/employees/" + mockEmployeeId)
                .willReturn(aResponse().withHeader("Content-Type", "application/json")
                    .withBodyFile("employeeDetails.json")));

        employeeChangeSubscriberConfig.handleMessage(message);
        RequestPatternBuilder getRequest =
            getRequestedFor(
                urlEqualTo("/internal/es-platform/employer-person/v1/employees/" + mockEmployeeId));

        RequestPatternBuilder postRequest =
            postRequestedFor(
                urlEqualTo(
                    "/internal/eev/form-i9/v1/data-maintenance/" + mockEmployeeId + "/termination-detail"))
                .withRequestBody(matchingJsonPath("$.separationDate"));

        serviceCalls.employerPersonApi.assertCall(getRequest);
        serviceCalls.i9api.assertCall(postRequest);
        verify(messageConfirmation, atLeast(1)).acknowledge(any(Message.class));
    }

    @Test
    public void testEmployeeChangeEvent_EmployeeNotFound() throws InterruptedException {
        when(message.getPayload()).thenReturn(buildEventBody(mockEmployeeId));
        serviceCalls.employerPersonApi
            .stubFor(get("/internal/es-platform/employer-person/v1/employees/" + mockEmployeeId)
                .willReturn(aResponse().withHeader("Content-Type", "application/json")
                ).willReturn(aResponse().withStatus(404)));

        Assertions
            .assertThrows(WebClientResponseException.class,
                () -> employeeChangeSubscriberConfig.handleMessage(message));

        RequestPatternBuilder getRequest =
            getRequestedFor(
                urlEqualTo("/internal/es-platform/employer-person/v1/employees/" + mockEmployeeId));

        RequestPatternBuilder postRequest =
            postRequestedFor(
                urlEqualTo(
                    "/internal/eev/form-i9/v1/data-maintenance/" + mockEmployeeId + "/termination-detail"))
                .withRequestBody(
                    equalToJson(testFileContent("terminationDetailRequest.json")));

        serviceCalls.employerPersonApi.assertCall(getRequest);
        serviceCalls.i9api.assertNotCalled(postRequest);
        verify(messageConfirmation, atLeast(1)).nAcknowledge(any(Message.class));
    }

    @Test
    public void testEmployeeChangeEvent_EmployeeIdNull() {
        when(message.getPayload()).thenReturn(buildEventBody(null));
        Assertions
            .assertThrows(EmployeeChangeException.class, () -> employeeChangeSubscriberConfig.handleMessage(message));
        verify(messageConfirmation, atLeast(1)).nAcknowledge(any(Message.class));
    }

    @Test
    public void testInvalidPayload() {
        when(message.getPayload()).thenReturn("This is invalid body.".getBytes());
        Assertions
            .assertThrows(EmployeeChangeException.class, () -> employeeChangeSubscriberConfig.handleMessage(message));
        verify(messageConfirmation, atLeast(1)).acknowledge(any(Message.class));
    }

    @Test
    public void testEmployeeChangeEvent_NullSeparationDate() throws Exception {
        when(message.getPayload()).thenReturn(buildEventBody(mockEmployeeId));

        serviceCalls.i9api
            .stubFor(post("/internal/eev/form-i9/v1/data-maintenance/" + mockEmployeeId + "/termination-detail")
                .withRequestBody(equalToJson(testFileContent("terminationDetailRequest.json"),
                    true,
                    true))
                .willReturn(aResponse().withStatus(200)));

        serviceCalls.employerPersonApi
            .stubFor(get("/internal/es-platform/employer-person/v1/employees/" + mockEmployeeId)
                .willReturn(aResponse().withHeader("Content-Type", "application/json")
                    .withBodyFile("employeeDetails_NULL.json")));

        RequestPatternBuilder getRequest =
            getRequestedFor(
                urlEqualTo("/internal/es-platform/employer-person/v1/employees/" + mockEmployeeId));

        RequestPatternBuilder postRequest =
            postRequestedFor(
                urlEqualTo(
                    "/internal/eev/form-i9/v1/data-maintenance/" + mockEmployeeId + "/termination-detail"))
                .withRequestBody(
                    equalToJson(testFileContent("terminationDetailNull.json")));

        Assertions
            .assertDoesNotThrow(() -> employeeChangeSubscriberConfig.handleMessage(message));

        serviceCalls.employerPersonApi.assertCall(getRequest);
        serviceCalls.i9api.assertCall(postRequest);
        verify(messageConfirmation, atLeast(1)).acknowledge(any(Message.class));
    }
}