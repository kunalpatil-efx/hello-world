package com.efx.ews.es.i9integration.i9portaleventshandler;

import com.efx.ews.es.eev.barricade.common.model.BarricadeKeyStore;
import com.efx.ews.es.eev.barricade.common.service.CryptographyService;
import com.efx.ews.es.eev.barricade.common.service.PubSubEncryptionService;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.event.I9EventDocumentData;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.event.I9EventFormData;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.event.I9EventPayload;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.AuditDataFeed;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.DataBaseAuditDataFeedTest;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.ReferenceApiService;
import com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageConfirmation;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.matching.RequestPatternBuilder;
import com.github.tomakehurst.wiremock.matching.UrlPattern;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.gcp.pubsub.support.AcknowledgeablePubsubMessage;
import org.springframework.http.HttpStatus;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.*;

@SpringBootTest
@Slf4j
public class CreateUploadLaterTaskTest {
    @Autowired
    private TestableSubscriber testableSubscriber;
    @Autowired
    private ServiceCalls serviceCalls;

    @MockBean
    @Qualifier("messageConfirmation")
    private MessageConfirmation messageConfirmation;
    @MockBean
    @Qualifier("messageConfirmationForFlow")
    private MessageConfirmation messageConfirmationForFlow;
    @MockBean
    private PubSubEncryptionService pubSubEncryptionService;

    @MockBean
    List<BarricadeKeyStore> barricadeKeyStores;
    @MockBean
    CryptographyService cryptographyService;
    @MockBean
    private ReferenceApiService referenceApiService;

    private Map<String, String> attributes;
    private String documentId;
    @MockBean
    private AuditDataFeed auditFeed;

    @BeforeEach
    public void setup() throws Exception {
        documentId = UUID.randomUUID().toString();
        attributes = Map.of(
                "status", "Section2_Complete",
                "documentId", documentId,
                "sourceId", "packet-ui");
        when(auditFeed.fetchAuditData(null))
                .thenReturn(Mono.just(List.of(DataBaseAuditDataFeedTest.createAuditMessage())));
    }

    @Test
    public void testCreatingSection2_uploadLater_Task_ListA() throws Exception {
        // given
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/tasks/"+documentId)
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("taskFormI9-DocumentUploadLater.json")));
        serviceCalls.taskApi
                .stubFor(post("/internal/es-platform/task-management/v1/tasks")
                        .willReturn(aResponse().withStatus(HttpStatus.CREATED.value())
                                .withHeader("Content-Type", "application/json")
                                .withBodyFile("taskApiResponseDocumentUploadLater.json")));
        serviceCalls.i9api
                .stubFor(post(WireMock.urlEqualTo("/internal/eev/form-i9/v1/tasks/" + documentId))
                        .willReturn(aResponse().withStatus(201)));
        serviceCalls.i9api
            .stubFor(get("/internal/eev/form-i9/v1/forms/" + documentId)
                    .willReturn(aResponse().withHeader("Content-Type", "application/json")
                            .withBodyFile("getForm_ListADoc1UploadLater.json")));
        serviceCalls.i9api
            .stubFor(get("/internal/eev/form-i9/v1/forms/" + documentId+ "/history/2")
                .willReturn(aResponse().withHeader("Content-Type", "application/json")
                    .withBodyFile("getForm_ListADoc1UploadLater.json")));

        // when
        testableSubscriber.publishMessage(attributes, getMessagePayload());
        //expected
        final RequestPatternBuilder markCreatedRequest =
                postRequestedFor(WireMock.urlEqualTo("/internal/eev/form-i9/v1/tasks/" + documentId));
        serviceCalls.i9api.assertCall(markCreatedRequest);
        verify(messageConfirmationForFlow, after(2000).atLeast(1)).acknowledge(any(AcknowledgeablePubsubMessage.class));
    }

    @Test
    public void testCreatingSection2_uploadLater_Task_ListA_DocumentTwo() throws Exception {
        // given
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/tasks/"+documentId)
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("taskFormI9-DocumentUploadLater.json")));
        serviceCalls.taskApi
                .stubFor(post("/internal/es-platform/task-management/v1/tasks")
                        .willReturn(aResponse().withStatus(HttpStatus.CREATED.value())
                                .withHeader("Content-Type", "application/json")
                                .withBodyFile("taskApiResponseDocumentUploadLater.json")));
        serviceCalls.i9api
                .stubFor(post(WireMock.urlEqualTo("/internal/eev/form-i9/v1/tasks/" + documentId))
                        .willReturn(aResponse().withStatus(201)));
        serviceCalls.i9api
            .stubFor(get("/internal/eev/form-i9/v1/forms/" + documentId)
                    .willReturn(aResponse().withHeader("Content-Type", "application/json")
                            .withBodyFile("getForm_ListADoc2UploadLater.json")));
        serviceCalls.i9api
            .stubFor(get("/internal/eev/form-i9/v1/forms/" + documentId+ "/history/2")
                .willReturn(aResponse().withHeader("Content-Type", "application/json")
                    .withBodyFile("getForm_ListADoc2UploadLater.json")));
        // when
        testableSubscriber.publishMessage(attributes, getMessagePayloadforDocumentTwo());
        //expected
        final RequestPatternBuilder markCreatedRequest =
                postRequestedFor(WireMock.urlEqualTo("/internal/eev/form-i9/v1/tasks/" + documentId));
        serviceCalls.i9api.assertCall(markCreatedRequest);
        verify(messageConfirmationForFlow, after(2000).atLeast(1)).acknowledge(any(AcknowledgeablePubsubMessage.class));
    }

    @Test
    public void testCreatingSection2_uploadLater_Task_ListB() throws Exception {
        // given
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/tasks/"+documentId)
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("taskFormI9-DocumentUploadLater.json")));
        serviceCalls.taskApi
                .stubFor(post("/internal/es-platform/task-management/v1/tasks")
                        .willReturn(aResponse().withStatus(HttpStatus.CREATED.value())
                                .withHeader("Content-Type", "application/json")
                                .withBodyFile("taskApiResponseDocumentUploadLater.json")));
        serviceCalls.i9api
                .stubFor(post(WireMock.urlEqualTo("/internal/eev/form-i9/v1/tasks/" + documentId))
                        .willReturn(aResponse().withStatus(201)));
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/forms/" + documentId)
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("getForm_ListBUploadLater.json")));
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/forms/" + documentId + "/history/2")
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("getForm_ListBUploadLater.json")));
        // when
        testableSubscriber.publishMessage(attributes, getMessagePayloadforListB());
        //expected
        final RequestPatternBuilder markCreatedRequest =
                postRequestedFor(WireMock.urlEqualTo("/internal/eev/form-i9/v1/tasks/" + documentId));
        serviceCalls.i9api.assertCall(markCreatedRequest);
        verify(messageConfirmationForFlow, after(2000).atLeast(1)).acknowledge(any(AcknowledgeablePubsubMessage.class));
    }

    @Test
    public void testCreatingSection2_uploadLater_Task_ListC() throws Exception {
        // given
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/tasks/"+documentId)
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("taskFormI9-DocumentUploadLater.json")));
        serviceCalls.taskApi
                .stubFor(post("/internal/es-platform/task-management/v1/tasks")
                        .willReturn(aResponse().withStatus(HttpStatus.CREATED.value())
                                .withHeader("Content-Type", "application/json")
                                .withBodyFile("taskApiResponseDocumentUploadLater.json")));
        serviceCalls.i9api
                .stubFor(post(WireMock.urlEqualTo("/internal/eev/form-i9/v1/tasks/" + documentId))
                        .willReturn(aResponse().withStatus(201)));
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/forms/" + documentId)
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("getForm_ListCUploadLater.json")));
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/forms/" + documentId + "/history/2")
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("getForm_ListCUploadLater.json")));
        // when
        testableSubscriber.publishMessage(attributes, getMessagePayloadforListC());
        //expected
        final RequestPatternBuilder markCreatedRequest =
                postRequestedFor(WireMock.urlEqualTo("/internal/eev/form-i9/v1/tasks/" + documentId));
        serviceCalls.i9api.assertCall(markCreatedRequest);
        verify(messageConfirmationForFlow, after(2000).atLeast(1)).acknowledge(any(AcknowledgeablePubsubMessage.class));
    }

    @Test
    public void testCreatingSection2Task_uploadLater_404() throws Exception {
        // given
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/tasks/"+documentId)
                        .willReturn(aResponse().withStatus(404)));
        serviceCalls.taskApi
                .stubFor(post("/internal/es-platform/task-management/v1/tasks")
                        .willReturn(aResponse().withStatus(HttpStatus.CREATED.value())
                                .withHeader("Content-Type", "application/json")
                                .withBodyFile("taskApiResponse.json")));
        serviceCalls.i9api
                .stubFor(post(WireMock.urlEqualTo("/internal/eev/form-i9/v1/tasks/" + documentId))
                        .willReturn(aResponse().withStatus(201)));
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/forms/" + documentId)
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("getForm_ListADoc1UploadLater.json")));
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/forms/" + documentId + "/history/2")
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("getForm_ListADoc1UploadLater.json")));
        // when
        testableSubscriber.publishMessage(attributes, getMessagePayload());
        //expected
        final RequestPatternBuilder markCreatedRequest =
                postRequestedFor(WireMock.urlEqualTo("/internal/eev/form-i9/v1/tasks/" + documentId));
        serviceCalls.i9api.assertCall(markCreatedRequest);
        verify(messageConfirmationForFlow, after(2000).atLeast(1)).acknowledge(any(AcknowledgeablePubsubMessage.class));
    }

    @Test
    public void testCreatingSection2Task_503fromTaskAPI_uploadLater() throws Exception {
        // given
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/tasks/"+documentId)
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("tasksFromI9-NoTasks.json")));
        serviceCalls.taskApi
                .stubFor(post("/internal/es-platform/task-management/v1/tasks")
                        .willReturn(aResponse().withStatus(503)));
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/forms/" + documentId)
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("getForm_ListADoc1UploadLater.json")));
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/forms/" + documentId + "/history/2")
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("getForm_ListADoc1UploadLater.json")));
        // when
        testableSubscriber.publishMessage(attributes, getMessagePayload());
        //expected
        verify(messageConfirmationForFlow, after(2000).atLeast(1)).nAcknowledge(any(AcknowledgeablePubsubMessage.class));
    }

    @Test
    public void testOutOfScope_uploadLater() throws Exception {
        //given
        serviceCalls.taskApi.stubFor(WireMock.any(UrlPattern.ANY).willReturn(aResponse().withStatus(500)));
        serviceCalls.i9api.stubFor(WireMock.any(UrlPattern.ANY).willReturn(aResponse().withStatus(500)));
        //when
        testableSubscriber.publishMessage(Map.of(
                "status", "Section2_Complete",
                "documentId", documentId,
                "sourceId", UUID.randomUUID().toString()), getMessagePayload());
        //expected
        verify(messageConfirmationForFlow, after(2000).atLeast(1)).acknowledge(any(AcknowledgeablePubsubMessage.class));
    }

    static I9EventPayload getMessagePayload() {
        I9EventPayload payload = new I9EventPayload();
        I9EventDocumentData documentData = new I9EventDocumentData();
        documentData.setEmployeeFactId("27733c9f-a64a-417e-9c47-659d16a4bf8a");
        documentData.setEmployerId("27733c9f-a64a-417e-9c47-659d16a4bf8a");
        documentData.setEmployerLocationId("27733c9f-a64a-417e-9c47-659d16a4bf8a");
        documentData.setSourceRefId("27733c9f-a64a-417e-9c47-659d16a4bf8a");
        documentData.setSourceId("packet-ui");
        documentData.setStatus("Section2_Complete");
        documentData.setProjectedStartDate("2020-02-01");
        documentData.setRecordVersion(2L);
        payload.setDocument(documentData);
        I9EventFormData formData = new I9EventFormData();
        formData.setIsMinor(Boolean.FALSE);
        formData.setSpecialPlacement(Boolean.FALSE);
        formData.setValidListBDocs(Boolean.FALSE);
        formData.setSsnApplied(Boolean.FALSE);
        formData.setSsnRefused(Boolean.FALSE);
        payload.setForm(formData);
        return payload;
    }

    static I9EventPayload getMessagePayloadforDocumentTwo() {
        I9EventPayload payload = new I9EventPayload();
        I9EventDocumentData documentData = new I9EventDocumentData();
        documentData.setEmployeeFactId("27733c9f-a64a-417e-9c47-659d16a4bf8a");
        documentData.setEmployerId("27733c9f-a64a-417e-9c47-659d16a4bf8a");
        documentData.setEmployerLocationId("27733c9f-a64a-417e-9c47-659d16a4bf8a");
        documentData.setSourceRefId("27733c9f-a64a-417e-9c47-659d16a4bf8a");
        documentData.setSourceId("packet-ui");
        documentData.setStatus("Section2_Complete");
        documentData.setProjectedStartDate("2020-02-01");
        documentData.setRecordVersion(2L);
        payload.setDocument(documentData);
        I9EventFormData formData = new I9EventFormData();
        formData.setIsMinor(Boolean.FALSE);
        formData.setSpecialPlacement(Boolean.FALSE);
        formData.setValidListBDocs(Boolean.FALSE);
        formData.setSsnApplied(Boolean.FALSE);
        formData.setSsnRefused(Boolean.FALSE);
        payload.setForm(formData);
        return payload;
    }

    static I9EventPayload getMessagePayloadforListB() {
        I9EventPayload payload = new I9EventPayload();
        I9EventDocumentData documentData = new I9EventDocumentData();
        documentData.setEmployeeFactId("27733c9f-a64a-417e-9c47-659d16a4bf8a");
        documentData.setEmployerId("27733c9f-a64a-417e-9c47-659d16a4bf8a");
        documentData.setEmployerLocationId("27733c9f-a64a-417e-9c47-659d16a4bf8a");
        documentData.setSourceRefId("27733c9f-a64a-417e-9c47-659d16a4bf8a");
        documentData.setSourceId("packet-ui");
        documentData.setStatus("Section2_Complete");
        documentData.setProjectedStartDate("2020-02-01");
        documentData.setRecordVersion(2L);
        payload.setDocument(documentData);
        I9EventFormData formData = new I9EventFormData();
        formData.setIsMinor(Boolean.FALSE);
        formData.setSpecialPlacement(Boolean.FALSE);
        formData.setValidListBDocs(Boolean.FALSE);
        formData.setSsnApplied(Boolean.FALSE);
        formData.setSsnRefused(Boolean.FALSE);
        payload.setForm(formData);
        return payload;
    }

    static I9EventPayload getMessagePayloadforListC() {
        I9EventPayload payload = new I9EventPayload();
        I9EventDocumentData documentData = new I9EventDocumentData();
        documentData.setEmployeeFactId("27733c9f-a64a-417e-9c47-659d16a4bf8a");
        documentData.setEmployerId("27733c9f-a64a-417e-9c47-659d16a4bf8a");
        documentData.setEmployerLocationId("27733c9f-a64a-417e-9c47-659d16a4bf8a");
        documentData.setSourceRefId("27733c9f-a64a-417e-9c47-659d16a4bf8a");
        documentData.setSourceId("packet-ui");
        documentData.setStatus("Section2_Complete");
        documentData.setRecordVersion(2L);
        documentData.setProjectedStartDate("2020-02-01");
        payload.setDocument(documentData);
        I9EventFormData formData = new I9EventFormData();
        formData.setIsMinor(Boolean.FALSE);
        formData.setSpecialPlacement(Boolean.FALSE);
        formData.setValidListBDocs(Boolean.FALSE);
        formData.setSsnApplied(Boolean.FALSE);
        formData.setSsnRefused(Boolean.FALSE);
        payload.setForm(formData);
        return payload;
    }
}
