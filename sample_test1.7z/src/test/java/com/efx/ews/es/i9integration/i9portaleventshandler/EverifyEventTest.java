package com.efx.ews.es.i9integration.i9portaleventshandler;

import com.efx.ews.es.eev.barricade.common.model.BarricadeKeyStore;
import com.efx.ews.es.eev.barricade.common.service.CryptographyService;
import com.efx.ews.es.eev.barricade.common.service.PubSubEncryptionService;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.PacketEvent;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.PacketEvent.EventType;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.PacketEventMetadata;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.ReferenceApiService;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.PacketPubSubProperties;
import com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageConfirmation;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.matching.RequestPatternBuilder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.messaging.Message;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.postRequestedFor;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.after;
import static org.mockito.Mockito.verify;

@SpringBootTest
@ExtendWith(SpringExtension.class)
@Slf4j
public class EverifyEventTest {
    @Autowired
    private EVerifyPubSub messagePublish;
    @Autowired
    private PacketPubSubProperties properties;
    @Autowired
    private ServiceCalls serviceCalls;

    @MockBean
    @Qualifier("messageConfirmation")
    private MessageConfirmation messageConfirmation;
    @MockBean
    @Qualifier("messageConfirmationForFlow")
    private MessageConfirmation messageConfirmationForFlow;
    @MockBean
    private PubSubEncryptionService pubSubEncryptionService;
    @MockBean
    private List<BarricadeKeyStore> barricadeKeyStores;
    @MockBean
    private CryptographyService cryptographyService;
    @MockBean
    private ReferenceApiService referenceApiService;

    private Map<String, String> attributes;
    private String taskId = UUID.randomUUID().toString();
    private String packetId = UUID.randomUUID().toString();

    @Test
    public void testEverifyEvent() throws InterruptedException, ExecutionException, TimeoutException, IOException {
        serviceCalls.taskApi
                .stubFor(post("/internal/es-platform/task-management/v1/tasks")
                        .willReturn(aResponse().withStatus(HttpStatus.CREATED.value())
                                .withHeader("Content-Type", "application/json")
                                .withBodyFile("taskApiResponse.json")));

        serviceCalls.taskApi
                .stubFor(get("/internal/es-platform/task-management/v1/tasks/"+taskId)
                        .willReturn(aResponse().withStatus(HttpStatus.OK.value())
                                .withHeader("Content-Type", "application/json")
                                .withBodyFile("taskDetailsResponse.json")));

        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/forms/query?sourceRefId="+packetId)
                        .willReturn(aResponse().withStatus(HttpStatus.OK.value())
                                .withHeader("Content-Type", "application/json")
                                .withBodyFile("singleI9id.json")));
        serviceCalls.i9api
                .stubFor(post(WireMock.urlEqualTo("/internal/eev/form-i9/v1/tasks/uAcCCIg8S4jbQh6OzA4y"))
                        .willReturn(aResponse().withStatus(201)));

        ExtendedPacketEvent payload = new ExtendedPacketEvent();
        payload.setMessageId(UUID.randomUUID().toString());
        payload.setPacketId(packetId);
        payload.setMetadata(new PacketEventMetadata());
        payload.getMetadata().setTaskId(taskId);
        payload.setEventType(EventType.UNCONFIRMED_DATA);
        messagePublish.publishMessage(attributes, payload);

        final RequestPatternBuilder markAsCompletedRequest =
                postRequestedFor(WireMock.urlEqualTo("/internal/eev/form-i9/v1/tasks/uAcCCIg8S4jbQh6OzA4y"));

        serviceCalls.i9api.assertCall(markAsCompletedRequest);
    }

    @Test
    public void testEverifyInvalidTaskType() throws InterruptedException, ExecutionException, TimeoutException, IOException {
        serviceCalls.taskApi
                .stubFor(post("/internal/es-platform/task-management/v1/tasks")
                        .willReturn(aResponse().withStatus(HttpStatus.CREATED.value())
                                .withHeader("Content-Type", "application/json")
                                .withBodyFile("taskApiResponse.json")));

        serviceCalls.taskApi
                .stubFor(get("/internal/es-platform/task-management/v1/tasks/"+taskId)
                        .willReturn(aResponse().withStatus(HttpStatus.OK.value())
                                .withHeader("Content-Type", "application/json")
                                .withBodyFile("taskInvalidCode.json")));

        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/forms/query?sourceRefId="+packetId)
                        .willReturn(aResponse().withStatus(HttpStatus.OK.value())
                                .withHeader("Content-Type", "application/json")
                                .withBodyFile("singleI9id.json")));

        PacketEvent payload = new PacketEvent();
        payload.setPacketId(packetId);
        payload.setMetadata(new PacketEventMetadata());
        payload.getMetadata().setTaskId(taskId);
        payload.setEventType(EventType.UNCONFIRMED_DATA);
        messagePublish.publishMessage(attributes, payload);
    }

    @Test
    public void testEverify404From() throws InterruptedException, ExecutionException, TimeoutException, IOException {
        serviceCalls.taskApi
                .stubFor(post("/internal/es-platform/task-management/v1/tasks")
                        .willReturn(aResponse().withStatus(HttpStatus.CREATED.value())
                                .withHeader("Content-Type", "application/json")
                                .withBodyFile("taskApiResponse.json")));

        serviceCalls.taskApi
                .stubFor(get("/internal/es-platform/task-management/v1/tasks/"+taskId)
                        .willReturn(aResponse().withStatus(HttpStatus.NOT_FOUND.value())
                                .withHeader("Content-Type", "application/json")
                                .withBodyFile("taskInvalidCode.json")));

        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/forms/query?sourceRefId="+packetId)
                        .willReturn(aResponse().withStatus(HttpStatus.OK.value())
                                .withHeader("Content-Type", "application/json")
                                .withBodyFile("singleI9id.json")));

        PacketEvent payload = new PacketEvent();
        payload.setPacketId(packetId);
        payload.setMetadata(new PacketEventMetadata());
        payload.getMetadata().setTaskId(taskId);
        payload.setEventType(EventType.UNCONFIRMED_DATA);
        messagePublish.publishMessage(attributes, payload);
    }

    @Test
    public void nacknowledgesOnServerError() throws Exception {
        // given
        serviceCalls.taskApi
                .stubFor(post("/internal/es-platform/task-management/v1/tasks")
                        .willReturn(aResponse().withStatus(HttpStatus.CREATED.value())
                                .withHeader("Content-Type", "application/json")
                                .withBodyFile("taskApiResponse.json")));

        serviceCalls.taskApi
                .stubFor(get("/internal/es-platform/task-management/v1/tasks/"+taskId)
                        .willReturn(aResponse().withStatus(HttpStatus.INTERNAL_SERVER_ERROR.value())
                                .withHeader("Content-Type", "application/json")
                                .withBodyFile("taskInvalidCode.json")));
        // when
        PacketEvent payload = new PacketEvent();
        payload.setPacketId(packetId);
        payload.setMetadata(new PacketEventMetadata());
        payload.getMetadata().setTaskId(taskId);
        payload.setEventType(EventType.UNCONFIRMED_DATA);
        messagePublish.publishMessage(attributes, payload);
        //expected
        verify(messageConfirmation, after(500).atLeast(1)).nAcknowledge(any(Message.class));
    }

    @Test
    public void acknowledgesOnClientsError() throws Exception {
        // given
        serviceCalls.taskApi
                .stubFor(post("/internal/es-platform/task-management/v1/tasks")
                        .willReturn(aResponse().withStatus(HttpStatus.CREATED.value())
                                .withHeader("Content-Type", "application/json")
                                .withBodyFile("taskApiResponse.json")));

        serviceCalls.taskApi
                .stubFor(get("/internal/es-platform/task-management/v1/tasks/"+taskId)
                        .willReturn(aResponse().withStatus(400)
                                .withHeader("Content-Type", "application/json")
                                .withBodyFile("taskInvalidCode.json")));
        // when
        PacketEvent payload = new PacketEvent();
        payload.setPacketId(packetId);
        payload.setMetadata(new PacketEventMetadata());
        payload.getMetadata().setTaskId(taskId);
        payload.setEventType(EventType.UNCONFIRMED_DATA);
        messagePublish.publishMessage(attributes, payload);
        //expected
        verify(messageConfirmation, after(500).atLeast(1)).acknowledge(any(Message.class));
    }
    @EqualsAndHashCode(callSuper = true)
    @Data
    private static class ExtendedPacketEvent extends PacketEvent{
        private String messageId;
    }
}
