package com.efx.ews.es.i9integration.i9portaleventshandler;

import com.google.api.gax.core.CredentialsProvider;
import com.google.api.gax.core.NoCredentialsProvider;
import com.google.api.gax.grpc.GrpcTransportChannel;
import com.google.api.gax.rpc.AlreadyExistsException;
import com.google.api.gax.rpc.FixedTransportChannelProvider;
import com.google.api.gax.rpc.TransportChannelProvider;
import com.google.cloud.pubsub.v1.*;
import com.google.pubsub.v1.*;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import lombok.Data;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Configuration
public class PubSubConfiguration {
    @Bean
    @Profile("emulator")
    public Publisher setupTopic(PubSubEmulator pubSubEmulator) {
        return pubSubEmulator.setupAndCreatePublisher();
    }

    @SneakyThrows
    @Bean
    @Profile("realEnv")
    public Publisher devEnvPubSubPublisher(PubSubProperties pubSubProperties){
        TopicName topicName = TopicName.of(pubSubProperties.getProjectId(), pubSubProperties.getTopic());
        return Publisher.newBuilder(topicName).build();
    }

    @Component
    @Data
    @ConfigurationProperties
    public static class PubSubProperties {
        @Value("${spring.cloud.gcp.project-id}")
        private String projectId;
        @Value("${i9portalEventsHandler.subscription}")
        private String subscriptionId;
        @Value("${i9portalEventsHandler.topic}")
        private String topic;
        @Value("${spring.cloud.gcp.pubsub.emulator-host:\"\"}")
        private String emulatorHost;
    }

    @Component
    @Profile("emulator")
    @Slf4j
    public static class PubSubEmulator implements AutoCloseable {
        private final PubSubProperties properties;
        private final TopicName topicName;
        private ManagedChannel channel;

        private PubSubEmulator(PubSubProperties properties) {
            this.properties = properties;
            topicName = TopicName.of(properties.getProjectId(), "the-topic");
        }

        @SneakyThrows
        private Publisher setupAndCreatePublisher() {
            channel = ManagedChannelBuilder.forTarget(properties.getEmulatorHost()).usePlaintext().build();
            TransportChannelProvider channelProvider =
                    FixedTransportChannelProvider.create(GrpcTransportChannel.create(channel));
            CredentialsProvider credentialsProvider = NoCredentialsProvider.create();

            try (TopicAdminClient topicClient =
                         TopicAdminClient.create(
                                 TopicAdminSettings.newBuilder()
                                         .setTransportChannelProvider(channelProvider)
                                         .setCredentialsProvider(credentialsProvider)
                                         .build())) {
                createTopic(topicClient, topicName);
            }
            try (SubscriptionAdminClient subscriptionAdminClient = SubscriptionAdminClient.create(
                    SubscriptionAdminSettings
                            .newBuilder()
                            .setTransportChannelProvider(channelProvider)
                            .setCredentialsProvider(credentialsProvider)
                            .build())) {
                createSubscription(topicName, subscriptionAdminClient);
            }

            return Publisher.newBuilder(topicName)
                    .setChannelProvider(channelProvider)
                    .setCredentialsProvider(credentialsProvider)
                    .build();
        }

        private static void createTopic(TopicAdminClient topicClient, TopicName topicName) {
            try {
                Topic topic = topicClient.getTopic(topicName);
                log.info("topic {} already exists", topic.getName());
            } catch (Exception ex) {
                Topic topic = topicClient.createTopic(topicName);
                log.info("topic {} created", topic.getName());
            }
        }

        private void createSubscription(TopicName topicName, SubscriptionAdminClient subscriptionAdminClient) {
            ProjectSubscriptionName subscriptionName =
                    ProjectSubscriptionName.of(properties.getProjectId(), properties.getSubscriptionId());
            try {
                Subscription subscription =
                        subscriptionAdminClient.createSubscription(
                                subscriptionName, topicName, PushConfig.getDefaultInstance(), 10);
                log.info("Created pull subscription: {}", subscription.getName());
            } catch (AlreadyExistsException ex) {
                log.info("Subscription {} already exists", subscriptionName.getSubscription());
            }
        }

        @Override
        public void close() {
            if (channel != null) {
                channel.shutdown();
            }
        }
    }
}
