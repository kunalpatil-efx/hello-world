package com.efx.ews.es.i9datasourcing.dep.infrastructure;

import static com.efx.ews.es.i9datasourcing.util.TestConstants.INTEGRATION_TEST;
import static org.assertj.core.api.Assertions.assertThatCode;

import com.efx.ews.es.i9datasourcing.constant.DepEventName;
import com.efx.ews.es.i9datasourcing.dep.model.DepEventPayload;
import com.efx.ews.es.i9datasourcing.dep.model.DepEventPayloadField;
import com.efx.ews.es.i9datasourcing.model.ChangeContext;
import com.efx.ews.es.i9integration.i9portaleventshandler.I9PortalEventsHandlerApplication;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.List;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = I9PortalEventsHandlerApplication.class)
@Slf4j
@Tag(INTEGRATION_TEST)
class DepEventPayloadSenderAdapterIntegrationTest {

    @Autowired
    private DepEventPayloadSenderAdapter depEventPayloadSender;

    @Test
    @SneakyThrows
    void publishPayload() {

        List<DepEventPayloadField> eventPayloadFields = List.of(
            new DepEventPayloadField("I9_ID", "I9_ID_Value_1"),
            new DepEventPayloadField("EVENT_CREATE_TS", "2020-08-24 19:42:40.234"),
            new DepEventPayloadField("SIGNATURE_METHOD", "SIGNATURE_METHOD_Value"),
            new DepEventPayloadField("LOCATION_CODE", "LOCATION_CODE_Value"),
            new DepEventPayloadField("IP_ADDRESS", "IP_ADDRESS_Value"),

            new DepEventPayloadField("EMPLOYEE.SSN", "SSN_String"),
            new DepEventPayloadField("EMPLOYEE.LAST_NAME", "LNString"),
            new DepEventPayloadField("EMPLOYEE.FIRST_NAME", "FNString"),
            new DepEventPayloadField("EMPLOYEE.MIDDLE_INITIAL", "MNString"),
            new DepEventPayloadField("EMPLOYEE.DATE_OF_BIRTH", "2020-11-30"),

            new DepEventPayloadField("EVENT.CREATE_TS", "2020-08-24 19:42:40.234"),
            new DepEventPayloadField("EVENT.NAME", "NameValue"),
            new DepEventPayloadField("EVENT.SOURCE", "SourceValue"),
            new DepEventPayloadField("EVENT.DESCRIPTION", "Description"),

            new DepEventPayloadField("UPDATE_DTLS.FIELD_NAME", "FieldN"),
            new DepEventPayloadField("UPDATE_DTLS.VALUE_BEFORE", "ValueBef"),
            new DepEventPayloadField("UPDATE_DTLS.VALUE_AFTER", "ValueAfter"));

        ChangeContext changeContext = new ChangeContext();
        changeContext.setClientTransactionId("");
        changeContext.setCorrelationId("CR-1");
        changeContext.setSourceEventDateTime(Instant.parse("2020-10-10T16:57:57.817Z").atZone(ZoneOffset.UTC));

        DepEventPayload depEventPayload = new DepEventPayload(eventPayloadFields);

        assertThatCode(
            () -> depEventPayloadSender.publish(depEventPayload, changeContext, DepEventName.I9_AUDIT_DETAIL))
            .doesNotThrowAnyException();
    }
}
