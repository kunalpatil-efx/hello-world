package com.efx.ews.es.i9datasourcing.provider;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.referenceapi.Country;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;

class CountryCodeProviderImplTest {

    @Mock
    private CachedCountryProvider cachedCountryProvider;

    @BeforeEach
    public void init() {
        initMocks(this);
    }

    @Test
    public void countryNameProviderShouldReturnExpectedValue() {
        //Given
        CountryCodeProvider countryCodeProvider = new CountryCodeProviderImpl(cachedCountryProvider);
        String countryCode = UUID.randomUUID().toString();
        String countryName = "Poland";
        Country expectedCountry = new Country(countryName, countryCode, true);
        when(cachedCountryProvider.getCountryByName(countryName)).thenReturn(expectedCountry);

        //When
        String actualCountryCode = countryCodeProvider.getCountryCode(countryName);

        //Then
        assertThat(actualCountryCode).isEqualTo(countryCode);
    }
}