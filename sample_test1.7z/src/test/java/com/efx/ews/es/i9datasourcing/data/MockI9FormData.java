package com.efx.ews.es.i9datasourcing.data;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.AdditionalInformation;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.AlienAuthorizedToWork;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.Attestation;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.Document;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.Employee;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.EmployeeInfo;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.EmployerRepresentative;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.ForeignPassport;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.FormData;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.I9Form;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.LawfulPermanentResidentInfo;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.ListA;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.ListB;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.ListC;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.Organization;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.Preparer;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.SectionOne;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.SectionThree;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.SectionTwo;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.SignatureData;
import java.util.List;
import java.util.UUID;

public final class MockI9FormData {

    private MockI9FormData() {
    }

    public static I9Form createI9FormToFlatten() {
        var result = new I9Form();

        result.setEmployeeId("dd7d260c-4498-4f71-a430-4d7aea04cf4c");
        result.setEmployeeFactId("5678");
        result.setEmployerId("27733c9f-a64a-417e-9c47-659d16a4bf8a");
        result.setEmployerLocationId("099");
        result.setFormRevDate("0876");
        result.setEverifyVersion("v30");
        result.setSourceRefId("09-99-1994");
        result.setSourceId("AQWSDERF1234");
        result.setRecordVersion(898L);
        result.setStatus("new");
        result.setProjectedStartDate("09-11-2019");

        var formData = new FormData();
        formData.setSectionOne(createSectionOneData());
        formData.setSectionTwo(createSectionTwo());
        formData.setSectionThreeList(List.of(createSectionThree()));
        formData.setSpecialPlacement(false);
        formData.setSsnApplied(false);
        formData.setSsnRefused(false);
        formData.setIsMinor(false);
        formData.setDocumentApiDocumentId("584275475842");
        formData.setValidListBDocs(true);

        result.setFormData(formData);
        return result;
    }

    private static SectionThree createSectionThree() {
        var result = new SectionThree();
        result.setFirstName("Joan");
        result.setLastName("Arc");
        result.setMiddleInitial("D'");
        result.setIsNameChange(true);
        result.setIsRehire(false);
        result.setIsReverification(false);
        result.setProjectedStartDate("13-12-2019");
        result.setReverificationDocument(createDocument("sectionThree-1"));
        result.setEmployerSignature(createSignatureData());
        result.setFormRevDate("i9v071717");
        result.setTimestamp(15857285);
        return result;
    }

    private static SectionOne createSectionOneData() {
        var preparer1 = createPreparer();
        var preparer2 = createPreparer();

        var result = new SectionOne();
        result.setEmployeeInfo(createEmployeeInfoData());
        result.setAttestation(createAttestationData());
        result.setPreparers(List.of(preparer1, preparer2));
        result.setSignature(createSignatureData());
        result.setDate("2020-02-12T05:59:59.999Z");
        return result;
    }

    private static Preparer createPreparer() {
        Preparer result = new Preparer();
        result.setFirstName("Jonny");
        result.setLastName("Lastname");
        result.setAddress("Opolska 144");
        result.setCity("Krakow");
        result.setState("State");
        result.setZipCode("76543");
        result.setSignature(createSignatureData());
        return result;
    }

    private static EmployeeInfo createEmployeeInfoData() {
        var result = new EmployeeInfo();
        result.setLastName("Test");
        result.setFirstName("I9form employee");
        result.setMiddleInitial("ET");
        result.setOtherLastName(null);
        result.setAddress("Krakow Opolska 114");
        result.setApartmentNumber("12");
        result.setCity("Krakow");
        result.setState("CA");
        result.setZipCode("12345");
        result.setDateOfBirth("2020-07-07");
        result.setSocialSecurityNumber("888888888");
        result.setTelephoneNumber("654987321");
        result.setEmail("test@test.com");
        return result;
    }

    private static Attestation createAttestationData() {
        var lawfulPermanentResident = new LawfulPermanentResidentInfo();
        lawfulPermanentResident.setAlienRegistrationNumber("Lawful Permanent Resident");

        var result = new Attestation();
        result.setIsAlienAuthorizedToWork(false);
        result.setIsLawfulPermanentResident(false);
        result.setIsNonCitizenNational(false);
        result.setIsUnitedStatesCitizen(true);
        result.setLawfulPermanentResidentInfo(lawfulPermanentResident);
        result.setAlienAuthorizedToWorkData(createAlienAuthorizedToWork());
        return result;
    }

    private static AlienAuthorizedToWork createAlienAuthorizedToWork() {
        var result = new AlienAuthorizedToWork();
        result.setExpirationDate("2020-07-13");
        result.setAlienRegistrationNumber("r3642ada");
        result.setFormI94AdmissionNumber("656gg565");
        result.setForeignPassportObject(createForeignPassport());
        return result;
    }

    private static ForeignPassport createForeignPassport() {
        var result = new ForeignPassport();
        result.setCountryOfIssuance("USA");
        result.setNumber("fgd54453fd");
        return result;
    }

    private static SectionTwo createSectionTwo() {
        var additionalInformation1 = createAdditionalInformation("additionalInfo1", "additionalInfo1");
        var additionalInformation2 = createAdditionalInformation("additionalInfo2", "additionalInfo2");

        var result = new SectionTwo();
        result.setEmployee(createEmployee());
        result.setEmployerRepresentative(createEmployerRepresentative());
        result.setListA(createListA());
        result.setListB(createListB());
        result.setListC(createListC());
        result.setOrganization(createOrganization());
        result.setAdditionalInformation(List.of(additionalInformation1, additionalInformation2));
        result.setSignature(createSignatureData());
        result.setHireDate("2020-02-12T05:59:59.999Z");
        return result;
    }

    private static AdditionalInformation createAdditionalInformation(String key, String value) {
        var result = new AdditionalInformation();
        result.setAdditionalInformationKey(key);
        result.setAdditionalInformationValue(value);
        return result;
    }

    private static Organization createOrganization() {
        var result = new Organization();
        result.setAddress("2355 ball drive");
        result.setCity("st.louis");
        result.setName("abcd");
        result.setState("MO");
        result.setZipCode("09097");
        return result;
    }

    private static Employee createEmployee() {
        var result = new Employee();
        result.setFirstName("Johnny");
        result.setLastName("Doey");
        result.setMiddleInitial("A.");
        result.setCitizenshipImmigrationStatus("exists");
        return result;
    }

    private static EmployerRepresentative createEmployerRepresentative() {
        var result = new EmployerRepresentative();
        result.setFirstName("Ann");
        result.setLastName("Doey");
        result.setTitle("Emperor");
        return result;
    }

    private static ListA createListA() {
        var result = new ListA();
        result.setDocumentOne(createDocument("listA-1"));
        result.setDocumentTwo(createDocument("listA-2"));
        result.setDocumentThree(createDocument("listA-3"));
        return result;
    }

    private static Document createDocument(String documentId) {
        var result = new Document();
        result.setDocumentId(documentId);
        result.setDocumentNumber(documentId + "/123");
        result.setDocumentTitle("title");
        result.setExpirationDate("2021-01-01");
        result.setIssuingAuthority("issuing-authority");
        result.setIsReceipt(true);
        return result;
    }

    private static ListB createListB() {
        var result = new ListB();
        result.setDocumentOne(createDocument("listB-1"));
        return result;
    }

    private static ListC createListC() {
        var result = new ListC();
        result.setDocumentOne(createDocument("listC-1"));
        return result;
    }

    private static SignatureData createSignatureData() {
        var result = new SignatureData();
        result.setMethod(SignatureData.Method.IMAGE);
        result.setName(UUID.randomUUID().toString());
        result.setDate("2020-04-06");
        result.setImageData(UUID.randomUUID().toString().getBytes());
        result.setImageType("image/png");
        result.setValue("val");
        result.setSignatureRef("afa913ad-b7cc2f21-5f6b-4351-9588-2f9131107725");
        result.setOwner("Owl Ner");
        return result;
    }

    public static List<String> buildExpectedResultI9FormChange() {
        return List.of(
            "{\"SIGNATURE_METHOD\":\"E-signature\",\"LOCATION_CODE\":\"v7\",\"EMPLOYEE\":{\"MIDDLE_INITIAL\":\"v4\",\"LAST_NAME\":\"v2-changed\",\"DATE_OF_BIRTH\":\"v5\",\"FIRST_NAME\":\"v3\",\"SSN\":\"v1\"},\"EVENT_CREATE_TS\":\"*\",\"I9_ID\":\"c1\",\"IP_ADDRESS\":\"c2\",\"UPDATE_DTLS\":{\"VALUE_AFTER\":\"v2-changed\",\"FIELD_NAME\":\"EMPLOYEE.LAST_NAME\",\"VALUE_BEFORE\":\"v2\"},\"I9_EMPLOYER_ID\":\"c4\",\"EVENT\":{\"CREATE_TS\":\"*\",\"DESCRIPTION\":\"Section 1 Data Entered \\\"EMPLOYEE.LAST_NAME\\\"-\\\"v2-changed\\\"\",\"SOURCE\":\"c3\",\"NAME\":\"Section1_Complete\"}}",
            "{\"SIGNATURE_METHOD\":\"E-signature\",\"LOCATION_CODE\":\"v7\",\"EMPLOYEE\":{\"MIDDLE_INITIAL\":\"v4\",\"LAST_NAME\":\"v2-changed\",\"DATE_OF_BIRTH\":\"v5\",\"FIRST_NAME\":\"v3\",\"SSN\":\"v1\"},\"EVENT_CREATE_TS\":\"*\",\"I9_ID\":\"c1\",\"IP_ADDRESS\":\"c2\",\"UPDATE_DTLS\":{\"VALUE_AFTER\":\"v8-changed\",\"FIELD_NAME\":\"FIELD_1\",\"VALUE_BEFORE\":\"v8\"},\"I9_EMPLOYER_ID\":\"c4\",\"EVENT\":{\"CREATE_TS\":\"*\",\"DESCRIPTION\":\"Section 1 Data Entered \\\"FIELD_1\\\"-\\\"v8-changed\\\"\",\"SOURCE\":\"c3\",\"NAME\":\"Section1_Complete\"}}",
            "{\"SIGNATURE_METHOD\":\"E-signature\",\"LOCATION_CODE\":\"v7\",\"EMPLOYEE\":{\"MIDDLE_INITIAL\":\"v4\",\"LAST_NAME\":\"v2-changed\",\"DATE_OF_BIRTH\":\"v5\",\"FIRST_NAME\":\"v3\",\"SSN\":\"v1\"},\"EVENT_CREATE_TS\":\"*\",\"I9_ID\":\"c1\",\"IP_ADDRESS\":\"c2\",\"UPDATE_DTLS\":{\"VALUE_AFTER\":\"v11\",\"FIELD_NAME\":\"FIELD_4\",\"VALUE_BEFORE\":null},\"I9_EMPLOYER_ID\":\"c4\",\"EVENT\":{\"CREATE_TS\":\"*\",\"DESCRIPTION\":\"Section 1 Data Entered \\\"FIELD_4\\\"-\\\"v11\\\"\",\"SOURCE\":\"c3\",\"NAME\":\"Section1_Complete\"}}",
            "{\"SIGNATURE_METHOD\":\"E-signature\",\"LOCATION_CODE\":\"v7\",\"EMPLOYEE\":{\"MIDDLE_INITIAL\":\"v4\",\"LAST_NAME\":\"v2-changed\",\"DATE_OF_BIRTH\":\"v5\",\"FIRST_NAME\":\"v3\",\"SSN\":\"v1\"},\"EVENT_CREATE_TS\":\"*\",\"I9_ID\":\"c1\",\"IP_ADDRESS\":\"c2\",\"UPDATE_DTLS\":{\"VALUE_AFTER\":null,\"FIELD_NAME\":\"FIELD_3\",\"VALUE_BEFORE\":\"v10\"},\"I9_EMPLOYER_ID\":\"c4\",\"EVENT\":{\"CREATE_TS\":\"*\",\"DESCRIPTION\":\"Section 1 Data Entered \\\"FIELD_3\\\"-\\\"\\\"\",\"SOURCE\":\"c3\",\"NAME\":\"Section1_Complete\"}}"
        );
    }

    public static List<String> buildI9FormCreatedPubSubPayloads() {
        return List.of(
            "{\"SIGNATURE_METHOD\":\"E-signature\",\"LOCATION_CODE\":\"v7\",\"EMPLOYEE\":{\"MIDDLE_INITIAL\":\"v4\",\"LAST_NAME\":\"v2\",\"DATE_OF_BIRTH\":\"v5\",\"FIRST_NAME\":\"v3\",\"SSN\":\"v1\"},\"EVENT_CREATE_TS\":\"*\",\"I9_ID\":\"c1\",\"IP_ADDRESS\":\"c2\",\"UPDATE_DTLS\":{\"VALUE_AFTER\":\"v8\",\"FIELD_NAME\":\"SECTION_ONE.EMPLOYEE_INFO.SIGNATURE.SIGNATURE_DATE\",\"VALUE_BEFORE\":null},\"I9_EMPLOYER_ID\":\"c4\",\"EVENT\":{\"CREATE_TS\":\"*\",\"DESCRIPTION\":\"Section 1 Data Entered \\\"SECTION_ONE.EMPLOYEE_INFO.SIGNATURE.SIGNATURE_DATE\\\"-\\\"v8\\\"\",\"SOURCE\":\"c3\",\"NAME\":\"Section1_Complete\"}}",
            "{\"SIGNATURE_METHOD\":\"E-signature\",\"LOCATION_CODE\":\"v7\",\"EMPLOYEE\":{\"MIDDLE_INITIAL\":\"v4\",\"LAST_NAME\":\"v2\",\"DATE_OF_BIRTH\":\"v5\",\"FIRST_NAME\":\"v3\",\"SSN\":\"v1\"},\"EVENT_CREATE_TS\":\"*\",\"I9_ID\":\"c1\",\"IP_ADDRESS\":\"c2\",\"UPDATE_DTLS\":{\"VALUE_AFTER\":\"v4\",\"FIELD_NAME\":\"EMPLOYEE.MIDDLE_INITIAL\",\"VALUE_BEFORE\":null},\"I9_EMPLOYER_ID\":\"c4\",\"EVENT\":{\"CREATE_TS\":\"*\",\"DESCRIPTION\":\"Section 1 Data Entered \\\"EMPLOYEE.MIDDLE_INITIAL\\\"-\\\"v4\\\"\",\"SOURCE\":\"c3\",\"NAME\":\"Section1_Complete\"}}",
            "{\"SIGNATURE_METHOD\":\"E-signature\",\"LOCATION_CODE\":\"v7\",\"EMPLOYEE\":{\"MIDDLE_INITIAL\":\"v4\",\"LAST_NAME\":\"v2\",\"DATE_OF_BIRTH\":\"v5\",\"FIRST_NAME\":\"v3\",\"SSN\":\"v1\"},\"EVENT_CREATE_TS\":\"*\",\"I9_ID\":\"c1\",\"IP_ADDRESS\":\"c2\",\"UPDATE_DTLS\":{\"VALUE_AFTER\":\"v3\",\"FIELD_NAME\":\"EMPLOYEE.FIRST_NAME\",\"VALUE_BEFORE\":null},\"I9_EMPLOYER_ID\":\"c4\",\"EVENT\":{\"CREATE_TS\":\"*\",\"DESCRIPTION\":\"Section 1 Data Entered \\\"EMPLOYEE.FIRST_NAME\\\"-\\\"v3\\\"\",\"SOURCE\":\"c3\",\"NAME\":\"Section1_Complete\"}}",
            "{\"SIGNATURE_METHOD\":\"E-signature\",\"LOCATION_CODE\":\"v7\",\"EMPLOYEE\":{\"MIDDLE_INITIAL\":\"v4\",\"LAST_NAME\":\"v2\",\"DATE_OF_BIRTH\":\"v5\",\"FIRST_NAME\":\"v3\",\"SSN\":\"v1\"},\"EVENT_CREATE_TS\":\"*\",\"I9_ID\":\"c1\",\"IP_ADDRESS\":\"c2\",\"UPDATE_DTLS\":{\"VALUE_AFTER\":\"v6\",\"FIELD_NAME\":\"SIGNATURE_METHOD\",\"VALUE_BEFORE\":null},\"I9_EMPLOYER_ID\":\"c4\",\"EVENT\":{\"CREATE_TS\":\"*\",\"DESCRIPTION\":\"Section 1 Data Entered \\\"SIGNATURE_METHOD\\\"-\\\"v6\\\"\",\"SOURCE\":\"c3\",\"NAME\":\"Section1_Complete\"}}",
            "{\"SIGNATURE_METHOD\":\"E-signature\",\"LOCATION_CODE\":\"v7\",\"EMPLOYEE\":{\"MIDDLE_INITIAL\":\"v4\",\"LAST_NAME\":\"v2\",\"DATE_OF_BIRTH\":\"v5\",\"FIRST_NAME\":\"v3\",\"SSN\":\"v1\"},\"EVENT_CREATE_TS\":\"*\",\"I9_ID\":\"c1\",\"IP_ADDRESS\":\"c2\",\"UPDATE_DTLS\":{\"VALUE_AFTER\":\"v5\",\"FIELD_NAME\":\"EMPLOYEE.DATE_OF_BIRTH\",\"VALUE_BEFORE\":null},\"I9_EMPLOYER_ID\":\"c4\",\"EVENT\":{\"CREATE_TS\":\"*\",\"DESCRIPTION\":\"Section 1 Data Entered \\\"EMPLOYEE.DATE_OF_BIRTH\\\"-\\\"v5\\\"\",\"SOURCE\":\"c3\",\"NAME\":\"Section1_Complete\"}}",
            "{\"SIGNATURE_METHOD\":\"E-signature\",\"LOCATION_CODE\":\"v7\",\"EMPLOYEE\":{\"MIDDLE_INITIAL\":\"v4\",\"LAST_NAME\":\"v2\",\"DATE_OF_BIRTH\":\"v5\",\"FIRST_NAME\":\"v3\",\"SSN\":\"v1\"},\"EVENT_CREATE_TS\":\"*\",\"I9_ID\":\"c1\",\"IP_ADDRESS\":\"c2\",\"UPDATE_DTLS\":{\"VALUE_AFTER\":\"v7\",\"FIELD_NAME\":\"LOCATION_CODE\",\"VALUE_BEFORE\":null},\"I9_EMPLOYER_ID\":\"c4\",\"EVENT\":{\"CREATE_TS\":\"*\",\"DESCRIPTION\":\"Section 1 Data Entered \\\"LOCATION_CODE\\\"-\\\"v7\\\"\",\"SOURCE\":\"c3\",\"NAME\":\"Section1_Complete\"}}",
            "{\"SIGNATURE_METHOD\":\"E-signature\",\"LOCATION_CODE\":\"v7\",\"EMPLOYEE\":{\"MIDDLE_INITIAL\":\"v4\",\"LAST_NAME\":\"v2\",\"DATE_OF_BIRTH\":\"v5\",\"FIRST_NAME\":\"v3\",\"SSN\":\"v1\"},\"EVENT_CREATE_TS\":\"*\",\"I9_ID\":\"c1\",\"IP_ADDRESS\":\"c2\",\"UPDATE_DTLS\":{\"VALUE_AFTER\":\"v2\",\"FIELD_NAME\":\"EMPLOYEE.LAST_NAME\",\"VALUE_BEFORE\":null},\"I9_EMPLOYER_ID\":\"c4\",\"EVENT\":{\"CREATE_TS\":\"*\",\"DESCRIPTION\":\"Section 1 Data Entered \\\"EMPLOYEE.LAST_NAME\\\"-\\\"v2\\\"\",\"SOURCE\":\"c3\",\"NAME\":\"Section1_Complete\"}}",
            "{\"SIGNATURE_METHOD\":\"E-signature\",\"LOCATION_CODE\":\"v7\",\"EMPLOYEE\":{\"MIDDLE_INITIAL\":\"v4\",\"LAST_NAME\":\"v2\",\"DATE_OF_BIRTH\":\"v5\",\"FIRST_NAME\":\"v3\",\"SSN\":\"v1\"},\"EVENT_CREATE_TS\":\"*\",\"I9_ID\":\"c1\",\"IP_ADDRESS\":\"c2\",\"UPDATE_DTLS\":{\"VALUE_AFTER\":\"v1\",\"FIELD_NAME\":\"EMPLOYEE.SSN\",\"VALUE_BEFORE\":null},\"I9_EMPLOYER_ID\":\"c4\",\"EVENT\":{\"CREATE_TS\":\"*\",\"DESCRIPTION\":\"Section 1 Data Entered \\\"EMPLOYEE.SSN\\\"-\\\"v1\\\"\",\"SOURCE\":\"c3\",\"NAME\":\"Section1_Complete\"}}"
        );
    }
}