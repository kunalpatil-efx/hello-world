package com.efx.ews.es.i9datasourcing.processor.auditdetail.i9formhistory;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ConvertedI9FormDiffProcessorTest {

    private ConvertedI9FormDiffProcessor convertedI9FormDiffProcessor;
    private I9FormSingleChangeProcessor i9FormSingleChangeProcessor;

    @BeforeEach
    public void setUp() {
        convertedI9FormDiffProcessor = new ConvertedI9FormDiffProcessor();
        i9FormSingleChangeProcessor = mock(I9FormSingleChangeProcessor.class);
    }

    @Test
    void shouldProcessWithoutConvertedFormBefore() {

        Map<String, String> convertedI9FormAfter = Map.of(
            "SECTION_ONE.EMPLOYEE_INFO.SSN", "123"
        );

        convertedI9FormDiffProcessor.process(null, convertedI9FormAfter, i9FormSingleChangeProcessor);

        verify(i9FormSingleChangeProcessor).publishDepEventForFieldChange(any());

        // TODO write assertions
    }

    @Test
    void shouldProcessBothForms() {

        Map<String, String> convertedI9FormBefore = Map.of(
            "SECTION_ONE.EMPLOYEE_INFO.SSN", "123",
            "LOCATION_CODE", "8999"
        );
        Map<String, String> convertedI9FormAfter = Map.of(
            "SECTION_ONE.EMPLOYEE_INFO.SSN", "456",
            "SECTION_ONE.EMPLOYEE_INFO.FIRST_NAME", "Mark"
        );

        convertedI9FormDiffProcessor.process(convertedI9FormBefore, convertedI9FormAfter, i9FormSingleChangeProcessor);

        verify(i9FormSingleChangeProcessor, times(3)).publishDepEventForFieldChange(any());

        // TODO write assertions
    }
}