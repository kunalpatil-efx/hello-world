package com.efx.ews.es.i9datasourcing.fieldconverter;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Map;
import org.junit.jupiter.api.Test;

class SsnNotSuppliedConverterTest {

    final SsnNotSuppliedConverter converter = SsnNotSuppliedConverter.INSTANCE;

    @Test
    public void shouldConvertSsnNotSupplied() {
        {
            Map<String, String> mockedFlattenedI9Form = Map.of("irrelevant.key", "true");

            String convertedValue = converter.convert(mockedFlattenedI9Form);

            assertThat(convertedValue).isEqualTo("true");
        }
        { // social security number is present
            Map<String, String> mockedFlattenedI9Form = Map.of(
                "formData.sectionOne.employeeInfo.socialSecurityNumber", "7654321");

            String convertedValue = converter.convert(mockedFlattenedI9Form);

            assertThat(convertedValue).isEqualTo("false");
        }
        {
            Map<String, String> mockedFlattenedI9Form = Map.of(
                "formData.sectionOne.employeeInfo.socialSecurityNumber", " ");

            String convertedValue = converter.convert(mockedFlattenedI9Form);

            assertThat(convertedValue).isEqualTo("true");
        }
        {
            Map<String, String> mockedFlattenedI9Form = Map.of(
                "formData.sectionOne.employeeInfo.socialSecurityNumber", "");

            String convertedValue = converter.convert(mockedFlattenedI9Form);

            assertThat(convertedValue).isEqualTo("true");
        }
    }
}