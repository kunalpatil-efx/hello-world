package com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.audit.AuditDbEntity;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.audit.AuditMessage;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.event.I9EventAuditData;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.event.I9EventPayload;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.FirestoreProperties;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.api.core.ApiFuture;
import com.google.api.core.ApiFutures;
import com.google.cloud.firestore.*;
import lombok.SneakyThrows;
import org.junit.Before;
import org.junit.Test;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class DataBaseAuditDataFeedTest {

    private static final ObjectMapper converter = new ObjectMapper();

    DataBaseAuditDataFeed feed;
    String id;
    QuerySnapshot snapshot;

    @Before
    public void setUp() {
        id = UUID.randomUUID().toString();
        String collection = UUID.randomUUID().toString();
        Firestore firestore = mock(Firestore.class);
        FirestoreProperties properties = mock(FirestoreProperties.class);
        FirestoreProperties.Collections collections = new FirestoreProperties.Collections();
        collections.setAudits(collection);
        when(properties.getCollections()).thenReturn(collections);
        CollectionReference reference = mock(CollectionReference.class);
        when(firestore.collection(collection)).thenReturn(reference);
        Query query = mock(Query.class);
        when(reference.whereEqualTo("message.attributes.sourceRefId", id)).thenReturn(query);
        snapshot = mock(QuerySnapshot.class);
        ApiFuture<QuerySnapshot> future = ApiFutures.immediateFuture(snapshot);
        when(query.get()).thenReturn(future);
        feed = new DataBaseAuditDataFeed(firestore, properties);
    }

    private void prepopulate(QuerySnapshot snap, List<AuditDbEntity> entities) {
        List<QueryDocumentSnapshot> documents = new ArrayList<>();
        entities.forEach(entity -> {
            QueryDocumentSnapshot doc = mock(QueryDocumentSnapshot.class);
            when(doc.toObject(AuditDbEntity.class)).thenReturn(entity);
            documents.add(doc);
        });
        when(snap.getDocuments()).thenReturn(documents);
    }

    @Test
    public void testSuccess() {
        prepopulate(snapshot, List.of(createEntity(), createEntity()));
        List<AuditMessage> audits = feed.fetchAuditData(id).block();
        assertEquals(2, audits.size());
    }

    private AuditDbEntity createEntity() {
        AuditDbEntity entity = new AuditDbEntity();
        entity.setMessage(createAuditMessage());
        return entity;
    }

    @SneakyThrows
    public static AuditMessage createAuditMessage() {
        AuditMessage message = new AuditMessage();
//        message.setPublishTime(LocalDateTime.now().format(DateTimeFormatter.ISO_DATE_TIME));
        message.setData(Base64.getEncoder().encodeToString(converter.writeValueAsBytes(createPayload())));
        message.setMessageId(UUID.randomUUID().toString());
//        message.setAttributes(Map.of());
        return message;
    }

    static I9EventPayload createPayload() {
        I9EventAuditData audit = new I9EventAuditData();
        audit.setEventKey("PDF_Generated");
        audit.setDate(LocalDateTime.now().minusMinutes(10).format(DateTimeFormatter.ISO_DATE_TIME));
        audit.setEventDescription(UUID.randomUUID().toString());
        I9EventPayload payload = new I9EventPayload();
        payload.setAudit(audit);
        return payload;
    }
}
