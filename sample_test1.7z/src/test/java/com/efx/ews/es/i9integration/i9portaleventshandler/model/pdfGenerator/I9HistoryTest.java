package com.efx.ews.es.i9integration.i9portaleventshandler.model.pdfGenerator;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.efx.ews.es.historyprovider.util.I9FormUtility;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.I9FormResponse;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.List;
import java.util.Optional;
import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.Test;

public class I9HistoryTest {

    List<I9FormResponse> section1History;
    List<I9FormResponse> section2CompleteHistory;
    List<I9FormResponse> section2CompleteHistory_ListBC;
    List<I9FormResponse> section2ReceiptUpdateHistory;
    List<I9FormResponse> section2NoReceiptUpdateHistory;

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();
    static {
        OBJECT_MAPPER.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    @Test
    public void testI9History_NoSection2() throws IOException {
        section1History = OBJECT_MAPPER.readValue(
            IOUtils.toString(I9HistoryTest.class.getResourceAsStream(
                "/i9History-test/i9History_Section1.json"), Charset.defaultCharset()),
            new TypeReference<List<I9FormResponse>>() {
            });
        I9History i9History = new I9History(section1History, null);
        assertTrue(i9History.getOldestI9formWithSectionOne().isPresent());
        assertFalse(i9History.getOldestI9formWithSectionTwo().isPresent());
        assertFalse(i9History.hasReceiptChange());
    }

    @Test
    public void testI9History_hasReceipt() throws IOException {
        section2CompleteHistory = OBJECT_MAPPER.readValue(
            IOUtils.toString(I9HistoryTest.class.getResourceAsStream(
                "/i9History-test/i9History_Section2_Receipt.json"), Charset.defaultCharset()),
            new TypeReference<List<I9FormResponse>>() {
            });
        I9History i9History = new I9History(section2CompleteHistory, null);
        Optional<I9FormResponse> resp = i9History.getOldestI9formWithSectionTwo();
        assertTrue(resp.isPresent());
        assertTrue(I9FormUtility.hasReceipt(resp.get().getFormData().getSectionTwo()));
        assertFalse(i9History.hasReceiptChange());
    }

    @Test
    public void testI9History_hasReceipt_ListBC() throws IOException {
        section2CompleteHistory_ListBC = OBJECT_MAPPER.readValue(
            IOUtils.toString(I9HistoryTest.class.getResourceAsStream(
                "/i9History-test/i9History_Section2_Receipt_ListBC.json"), Charset.defaultCharset()),
            new TypeReference<List<I9FormResponse>>() {
            });
        I9History i9History = new I9History(section2CompleteHistory_ListBC, null);
        Optional<I9FormResponse> resp = i9History.getOldestI9formWithSectionTwo();
        assertTrue(resp.isPresent());
        assertTrue(I9FormUtility.hasReceipt(resp.get().getFormData().getSectionTwo()));
        assertFalse(i9History.hasReceiptChange());
    }

    @Test
    public void testI9History_ReceiptUpdate() throws IOException {
        section2ReceiptUpdateHistory = OBJECT_MAPPER.readValue(
            IOUtils.toString(I9HistoryTest.class.getResourceAsStream(
                "/i9History-test/i9History_Section2_ReceiptUpdate.json"), Charset.defaultCharset()),
            new TypeReference<List<I9FormResponse>>() {
            });
        I9History i9History = new I9History(section2ReceiptUpdateHistory, null);
        Optional<I9FormResponse> resp = i9History.getOldestI9formWithSectionTwo();
        assertTrue(resp.isPresent());
        assertTrue(I9FormUtility.hasReceipt(resp.get().getFormData().getSectionTwo()));
        assertTrue(i9History.hasReceiptChange());
    }

    @Test
    public void testI9History_NoReceiptUpdate() throws IOException {
        section2NoReceiptUpdateHistory = OBJECT_MAPPER.readValue(
            IOUtils.toString(I9HistoryTest.class.getResourceAsStream(
                "/i9History-test/i9History_Section2_NoReceiptUpdate.json"), Charset.defaultCharset()),
            new TypeReference<List<I9FormResponse>>() {
            });
        I9History i9History = new I9History(section2NoReceiptUpdateHistory, null);
        Optional<I9FormResponse> resp = i9History.getOldestI9formWithSectionTwo();
        assertTrue(resp.isPresent());
        assertTrue(I9FormUtility.hasReceipt(resp.get().getFormData().getSectionTwo()));
        assertFalse(i9History.hasReceiptChange());
    }

    @Test
    public void testI9History_NullHistory() {
        I9History i9History = new I9History(null, null);
        assertFalse(i9History.hasReceiptChange());
    }

}
