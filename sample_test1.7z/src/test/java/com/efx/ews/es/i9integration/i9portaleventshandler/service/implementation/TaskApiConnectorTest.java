package com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation;

import com.efx.ews.es.eev.barricade.common.model.BarricadeKeyStore;
import com.efx.ews.es.eev.barricade.common.service.CryptographyService;
import com.efx.ews.es.eev.barricade.common.service.PubSubEncryptionService;
import com.efx.ews.es.i9integration.i9portaleventshandler.ServiceCalls;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.Task;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.task.TaskCreateRequest;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.TaskApiProperties;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.io.IOException;
import java.util.List;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.patch;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.urlMatching;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathMatching;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

@SpringBootTest
@ExtendWith(SpringExtension.class)
class TaskApiConnectorTest {

    @Autowired
    private ServiceCalls serviceCalls;
    @Autowired
    private TaskApiProperties taskApiProperties;

    @MockBean
    List<BarricadeKeyStore> barricadeKeyStores;
    @MockBean
    CryptographyService cryptographyService;
    @MockBean
    private PubSubEncryptionService pubSubEncryptionService;
    @MockBean
    private ReferenceApiService referenceApiService;

    @Test
    void testSetUpShouldReturn_5xx() {
        serviceCalls.taskApi
            .stubFor(get(urlMatching("/internal/es-platform/task-management/v1/task-families/[A-Za-z0-9%-]+"))
                .willReturn(aResponse().withStatus(HttpStatus.NOT_FOUND.value())
                    .withHeader("Content-Type", "application/json")
                    .withBodyFile("taskInvalidCode.json")));

        serviceCalls.taskApi
                .stubFor(post("/internal/es-platform/task-management/v1/task-families")
                        .willReturn(aResponse().withStatus(HttpStatus.INTERNAL_SERVER_ERROR.value())
                                .withHeader("Content-Type", "application/json")
                                .withBodyFile("taskFamilyResponse.json")));

        var taskApi = new TaskApiConnector(taskApiProperties);

        assertThatThrownBy(taskApi::checkAndRegisterTaskType)
                .isInstanceOf(IOException.class)
                .hasMessageContaining("Unable to set-up Task API.");
    }

    @Test
    void testSetUpShouldReturn_IllegalStateException() {

        serviceCalls.taskApi
            .stubFor(get(urlMatching("/internal/es-platform/task-management/v1/task-families/[A-Za-z0-9%-]+"))
                .willReturn(aResponse().withStatus(HttpStatus.NOT_FOUND.value())
                    .withHeader("Content-Type", "application/json")
                    .withBodyFile("taskInvalidCode.json")));

        serviceCalls.taskApi
                .stubFor(post("/internal/es-platform/task-management/v1/task-families")
                        .willReturn(aResponse().withStatus(HttpStatus.NOT_ACCEPTABLE.value())
                                .withHeader("Content-Type", "application/json")
                                .withBodyFile("taskFamilyResponse.json")));

        var taskApi = new TaskApiConnector(taskApiProperties);

        assertThatThrownBy(taskApi::checkAndRegisterTaskType)
                .isInstanceOf(IOException.class)
                .hasMessageContaining("Unable to set-up Task API.")
                .hasCauseInstanceOf(IllegalStateException.class);
    }

    @Test
    public void testCreateReceiptUpdateTask() {
        serviceCalls.taskApi
            .stubFor(post(urlMatching("/internal/es-platform/task-management/v1/tasks"))
                .willReturn(aResponse().withStatus(HttpStatus.OK.value())
                    .withHeader("Content-Type", "application/json")
                    .withBodyFile("taskApiResponse.json")));

        TaskApiConnector taskApi = new TaskApiConnector(taskApiProperties);
        Task task = taskApi.createReceiptUpdateTask(new TaskCreateRequest()).block();
        assertNotNull(task);
        assertEquals("494bf787-2a6b-4d53-894a-d306f4cb28ff", task.getTaskId());
    }

    @Test
    public void testCompleteTask_Error() {
        serviceCalls.taskApi
            .stubFor(patch(urlMatching("/internal/es-platform/task-management/v1/tasks"))
                .willReturn(aResponse().withStatus(HttpStatus.INTERNAL_SERVER_ERROR.value())
                    .withHeader("Content-Type", "application/json")
                    .withBody("Error")));

        TaskApiConnector taskApi = new TaskApiConnector(taskApiProperties);
        Task closeTask = new Task(); closeTask.setTaskId("123");
        assertThrows(WebClientResponseException.class, () -> taskApi.completeTask(closeTask, UUID.randomUUID().toString()).block());
    }

    @Test
    public void testCompleteTask_Success() {
        serviceCalls.taskApi
            .stubFor(patch(urlPathMatching("/internal/es-platform/task-management/v1/tasks/123"))
                .willReturn(aResponse().withStatus(HttpStatus.OK.value())
                    .withHeader("Content-Type", "application/json")
                    .withBody("Success")));

        TaskApiConnector taskApi = new TaskApiConnector(taskApiProperties);
        Task task = new Task(); task.setTaskId("123"); task.setTaskStatus("NEW");
        Task rettask = taskApi.completeTask(task, UUID.randomUUID().toString()).block();
        assertNotNull(rettask);
        assertEquals("COMPLETED", rettask.getTaskStatus());
    }
}
