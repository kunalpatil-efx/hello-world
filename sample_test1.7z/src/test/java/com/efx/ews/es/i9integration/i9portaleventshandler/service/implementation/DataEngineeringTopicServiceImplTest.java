package com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.efx.ews.es.eev.barricade.common.service.PubSubEncryptionService;
import com.efx.ews.es.i9datasourcing.dep.model.DepEventDataHolder;
import com.efx.ews.es.i9datasourcing.dep.util.PubSubEventBuilder;
import com.efx.ews.es.i9datasourcing.model.ChangeContext;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.pubsub.PubSubEvent;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.GooglePublisherService;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.configuration.DataPurgeProperties;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.configuration.PubSubProperties;
import java.io.IOException;
import java.time.ZonedDateTime;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class DataEngineeringTopicServiceImplTest {
    DataEngineeringTopicServiceImpl service;

    private PubSubEncryptionService encryptionService;
    private PubSubProperties pubSubProperties;
    private GooglePublisherService pubSubService;
    private PubSubEventBuilder pubSubEventBuilder;

    @BeforeEach
    public void setup() {
        encryptionService = mock(PubSubEncryptionService.class);
        pubSubProperties = mock(PubSubProperties.class);
        pubSubService = mock(GooglePublisherService.class);
        pubSubEventBuilder = mock(PubSubEventBuilder.class);
        service =
            new DataEngineeringTopicServiceImpl(encryptionService, pubSubProperties, pubSubService, pubSubEventBuilder);
    }

    @Test
    public void testSendEvent() throws IOException {
        ChangeContext cc = getChangeContext();
        DepEventDataHolder depevent = DepEventDataHolder.builder().payloadJson("test").eventName("event").changeContext(cc).build();
        service.sendEvent(depevent, (depEventDataHolder, pubSubEncryptedData) -> { return new PubSubEvent(); });
    }

    @Test
    public void testSendEvent_Exception() throws Exception {
        when(encryptionService.encrypt(any())).thenThrow(new RuntimeException("error"));
        ChangeContext cc = getChangeContext();
        DepEventDataHolder depevent = DepEventDataHolder.builder().payloadJson("test").eventName("event").changeContext(cc).build();
        assertThrows(IOException.class, () -> service.sendEvent(depevent, (depEventDataHolder, pubSubEncryptedData) -> { return new PubSubEvent(); }));
    }

    @Test
    public void testSendDataPurgeEvent() {
        DataPurgeProperties purgeProperties = new DataPurgeProperties();
        purgeProperties.setEventTopicId("topic");
        when(pubSubProperties.getDataPurge()).thenReturn(purgeProperties);
        ChangeContext cc = getChangeContext();
        DepEventDataHolder depevent = DepEventDataHolder.builder().payloadJson("test").eventName("event").changeContext(cc).build();
        service.sendDataPurgeEvent(depevent, "employeeid");
    }

    private ChangeContext getChangeContext() {
        ChangeContext cc = new ChangeContext();
        cc.setCorrelationId("corr");
        cc.setDeduplicationId("dedup");
        cc.setEmployerId("employerid");
        cc.setI9FormId("formid");
        cc.setIpAddress("ip");
        cc.setSourceEventDateTime(ZonedDateTime.now());
        return cc;
    }
}
