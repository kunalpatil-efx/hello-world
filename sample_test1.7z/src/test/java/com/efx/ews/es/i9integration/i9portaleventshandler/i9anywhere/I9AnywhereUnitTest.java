package com.efx.ews.es.i9integration.i9portaleventshandler.i9anywhere;

import static com.github.tomakehurst.wiremock.client.WireMock.deleteRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.patchRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.postRequestedFor;

import com.efx.ews.es.eev.barricade.common.model.BarricadeKeyStore;
import com.efx.ews.es.eev.barricade.common.service.CryptographyService;
import com.efx.ews.es.eev.barricade.common.service.PubSubEncryptionService;
import com.efx.ews.es.i9integration.i9portaleventshandler.MessagePublish;
import com.efx.ews.es.i9integration.i9portaleventshandler.ServiceCalls;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.ReferenceApiService;
import com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageConfirmation;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.matching.RequestPatternBuilder;
import com.github.tomakehurst.wiremock.matching.UrlPattern;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@SpringBootTest
@ExtendWith(SpringExtension.class)
public class I9AnywhereUnitTest {
    @Autowired protected MessagePublish messagePublish;
    @Autowired protected ServiceCalls serviceCalls;
    @MockBean @Qualifier("messageConfirmation") protected MessageConfirmation messageConfirmation;
    @MockBean @Qualifier("messageConfirmationForFlow") protected MessageConfirmation messageConfirmationForFlow;
    @MockBean protected PubSubEncryptionService pubSubEncryptionService;
    @MockBean List<BarricadeKeyStore> barricadeKeyStores;
    @MockBean CryptographyService cryptographyService;
    @MockBean protected ReferenceApiService referenceApiService;

    protected Map<String, String> attributes;
    protected String appointmentId;
    protected String documentId;

    protected final static String I9_ANYWHERE_TASK_ID = "1e0a5898-90f5-408a-afd3-cff1d0fcde41";
    protected final static String I9_PENDING_TASK_ID = "7e0a5898-90f5-408a-afd3-cff1d0fcde41";

    protected RequestPatternBuilder createTaskRequest;
    protected RequestPatternBuilder linkTaskRequest;

    protected RequestPatternBuilder deleteI9AnywhereTaskRequest;
    protected RequestPatternBuilder completeI9AnywhereTaskRequest;
    protected RequestPatternBuilder unlinkI9AnywhereTaskRequest;
    protected RequestPatternBuilder markAsCompleteI9AnywhereTaskRequest;

    protected RequestPatternBuilder deleteI9PendingTaskRequest;
    protected RequestPatternBuilder completeI9PendingTaskRequest;
    protected RequestPatternBuilder unlinkI9PendingTaskRequest;
    protected RequestPatternBuilder markAsCompleteI9PendingTaskRequest;

    protected void setupWireMock() {
        UrlPattern createTask = WireMock.urlEqualTo("/internal/es-platform/task-management/v1/tasks");
        UrlPattern linkTaskToI9 = WireMock.urlEqualTo("/internal/eev/form-i9/v1/tasks/" + documentId);
        createTaskRequest = postRequestedFor(createTask);
        linkTaskRequest = postRequestedFor(linkTaskToI9);
        setupI9AnywhereWireMock();
        setupI9PendingWireMock();
    }

    private void setupI9AnywhereWireMock() {
        UrlPattern deleteTask = WireMock.urlEqualTo("/internal/es-platform/task-management/v1/tasks/" + I9_ANYWHERE_TASK_ID);
        UrlPattern completeTask = WireMock.urlEqualTo("/internal/es-platform/task-management/v1/tasks/" + I9_ANYWHERE_TASK_ID);
        UrlPattern unlinkTaskToI9 = WireMock.urlEqualTo("/internal/eev/form-i9/v1/tasks/" + documentId + "/" + I9_ANYWHERE_TASK_ID);
        UrlPattern markAsComplete = WireMock.urlEqualTo("/internal/eev/form-i9/v1/tasks/" + documentId + "/" + I9_ANYWHERE_TASK_ID);
        deleteI9AnywhereTaskRequest = deleteRequestedFor(deleteTask);
        completeI9AnywhereTaskRequest = patchRequestedFor(completeTask);
        unlinkI9AnywhereTaskRequest = deleteRequestedFor(unlinkTaskToI9);
        markAsCompleteI9AnywhereTaskRequest = patchRequestedFor(markAsComplete);
    }

    private void setupI9PendingWireMock() {
        UrlPattern deleteTask = WireMock.urlEqualTo("/internal/es-platform/task-management/v1/tasks/" + I9_PENDING_TASK_ID);
        UrlPattern completeTask = WireMock.urlEqualTo("/internal/es-platform/task-management/v1/tasks/" + I9_PENDING_TASK_ID);
        UrlPattern unlinkTaskToI9 = WireMock.urlEqualTo("/internal/eev/form-i9/v1/tasks/" + documentId + "/" + I9_PENDING_TASK_ID);
        UrlPattern markAsComplete = WireMock.urlEqualTo("/internal/eev/form-i9/v1/tasks/" + documentId + "/" + I9_PENDING_TASK_ID);
        deleteI9PendingTaskRequest = deleteRequestedFor(deleteTask);
        completeI9PendingTaskRequest = patchRequestedFor(completeTask);
        unlinkI9PendingTaskRequest = deleteRequestedFor(unlinkTaskToI9);
        markAsCompleteI9PendingTaskRequest = patchRequestedFor(markAsComplete);
    }
}
