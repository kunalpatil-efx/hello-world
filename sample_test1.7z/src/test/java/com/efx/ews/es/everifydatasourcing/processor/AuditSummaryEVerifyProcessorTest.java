package com.efx.ews.es.everifydatasourcing.processor;

import static com.efx.ews.es.everifydatasourcing.processor.AuditSummaryEVerifyProcessor.MODIFICATION_TS;
import static com.efx.ews.es.i9datasourcing.constant.DepEventName.AUDIT_SUMMARY_EVERIFY;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.only;
import static org.mockito.Mockito.verify;
import static org.mockito.MockitoAnnotations.initMocks;

import com.efx.ews.es.everifydatasourcing.mock.MockData;
import com.efx.ews.es.everifydatasourcing.model.TestCase;
import com.efx.ews.es.i9datasourcing.dep.api.DepEventPayloadSender;
import com.efx.ews.es.i9datasourcing.dep.model.DepEventPayload;
import com.efx.ews.es.i9datasourcing.dep.model.DepEventPayloadField;
import com.efx.ews.es.i9datasourcing.formatter.DefaultTemporalFormatter;
import com.efx.ews.es.i9datasourcing.formatter.TemporalFormatter;
import com.efx.ews.es.i9datasourcing.model.ChangeContext;
import java.util.List;
import java.util.stream.Collectors;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;

class AuditSummaryEVerifyProcessorTest {

    private static final String TEST_NAME = "test-01";
    private static final int EXPECTED_LENGTH = 25;
    private static final int EXPECTED_EVENT_LENGTH = 1;

    @Mock
    private DepEventPayloadSender depEventPayloadSender;

    @Spy
    private final TemporalFormatter temporalFormatter = new DefaultTemporalFormatter();

    @InjectMocks
    private AuditSummaryEVerifyProcessor auditSummaryEVerifyProcessor;

    @Captor
    private ArgumentCaptor<DepEventPayload> depEventPayloadArgumentCaptor;

    private ChangeContext changeContext;

    @BeforeEach
    void setUp() {
        initMocks(this);
        changeContext = TestCase.create(TEST_NAME).getChangeContext();
    }

    @Test
    void itShouldProcessEVerifyConvertedCase() {
        //GIVEN
        var convertedEVerifyCase = MockData.readExpectedConvertedEVerifyForm();

        // EXECUTE
        auditSummaryEVerifyProcessor.process(convertedEVerifyCase, changeContext);

        // ASSERT
        verify(depEventPayloadSender, only())
            .publish(depEventPayloadArgumentCaptor.capture(),
                eq(changeContext),
                eq(AUDIT_SUMMARY_EVERIFY));

        var payloadEvents = depEventPayloadArgumentCaptor.getAllValues();
        List<DepEventPayloadField> payloadFields = payloadEvents.get(0).getFields();
        var expectedEVerifyEventNames = buildExpectedEVerifyEventNames();

        assertAll(
            () -> assertThat(payloadEvents)
                .isNotEmpty()
                .hasSize(EXPECTED_EVENT_LENGTH),

            () -> {
                var actualEVerifyEventNames = payloadFields
                    .stream()
                    .map(DepEventPayloadField::getName)
                    .collect(Collectors.toList());

                assertThat(actualEVerifyEventNames)
                    .hasSize(EXPECTED_LENGTH)
                    .containsExactlyInAnyOrderElementsOf(expectedEVerifyEventNames);
            },

            () -> {
                var sourceEventDateTimeExpected = temporalFormatter
                    .formatDateTime(changeContext.getSourceEventDateTime());

                assertThat(payloadFields)
                    .filteredOn(field -> field.getName().equals(MODIFICATION_TS))
                    .flatExtracting(DepEventPayloadField::getValue)
                    .allMatch(value -> value.equals(sourceEventDateTimeExpected));
            }
        );
    }

    private List<String> buildExpectedEVerifyEventNames() {
        return List.of("DHS_REFERRAL_2_USER", "INITIAL_RESPONSE", "E_VERIFY_COMPANY_ID", "REFERRAL",
            "RESUBMIT_VERIFICATION_DATE", "FINAL_RESPONSE", "I9_ID", "INITIAL_SUBMISSION_DATE",
            "E_VERIFY_EXPECTED_RESPONSE_DATE_FOR_REFERRALS", "FINAL_RESPONSE_DATE",
            "CURRENT_E_VERIFY_STATUS", "OVERDUE_VERIFY_REASON", "SSA_TNC_REASON", "DHS_ADDITIONAL_VERIFICATION_REASON",
            "RESUBMIT_VERIFICATION_USER", "DHS_REFERRAL_USER", "E_VERIFY_CASE_NUMBER", "INITIAL_RESPONSE_DATE",
            "SSA_REFERRAL_DATE", "SSA_REFERRAL_USER", "DHS_REFERRAL_2_DATE", "DHS_REFERRAL_DATE", "FAR_E_VERIFY_STATUS",
            "INITIAL_SUBMISSION_USER", "MODIFICATION_TS");
    }
}