package com.efx.ews.es.i9integration.i9portaleventshandler;

import com.efx.ews.es.eev.barricade.common.model.BarricadeKeyStore;
import com.efx.ews.es.eev.barricade.common.service.CryptographyService;
import com.efx.ews.es.eev.barricade.common.service.PubSubEncryptionService;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.event.I9EventPayload;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.AuditDataFeed;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.DataBaseAuditDataFeedTest;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.I9FormDao;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.PacketPubSubPublisherServiceImpl;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.ReferenceApiService;
import com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageConfirmation;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.matching.RequestPatternBuilder;
import com.github.tomakehurst.wiremock.matching.UrlPattern;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.gcp.pubsub.support.AcknowledgeablePubsubMessage;
import org.springframework.http.HttpStatus;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.*;

@SpringBootTest
@Slf4j
public class RestartPacketTest {
    @Autowired
    private TestableSubscriber testableSubscriber;

    @Autowired
    private ServiceCalls serviceCalls;

    @MockBean
    @Qualifier("messageConfirmation")
    private MessageConfirmation messageConfirmation;
    @MockBean
    @Qualifier("messageConfirmationForFlow")
    private MessageConfirmation messageConfirmationForFlow;

    @MockBean
    private I9FormDao i9FormDao;
    @MockBean
    private PacketPubSubPublisherServiceImpl publisherService;
    @MockBean
    private ReferenceApiService referenceApiService;

    @MockBean
    List<BarricadeKeyStore> barricadeKeyStores;
    @MockBean
    CryptographyService cryptographyService;
    @MockBean
    private PubSubEncryptionService pubSubEncryptionService;
    @MockBean
    private AuditDataFeed auditFeed;

    private Map<String, String> attributes;
    private String documentId;
    private final static String TASK_ID = "39668771-f8b4-48a6-b02e-0d0200bd3651";

    @BeforeEach
    public void setup() throws Exception {
        documentId = LocalDateTime.now().format(DateTimeFormatter.ISO_DATE_TIME);
        attributes = Map.of(
                "status", "Section1_Complete",
                "documentId", documentId,
                "sourceId", "packet-ui");
        when(auditFeed.fetchAuditData(null))
                .thenReturn(Mono.just(List.of(DataBaseAuditDataFeedTest.createAuditMessage())));
    }

    @Test
    public void testPacketApiRestartEvent() throws Exception {
        // given
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/tasks/"+documentId)
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("tasksFromI9-NoTasks.json")));
        when(publisherService.restartPacketForSSN(anyString(),anyString())).thenReturn(Mono.empty());
        serviceCalls.taskApi
                .stubFor(post("/internal/es-platform/task-management/v1/tasks")
                        .willReturn(aResponse().withStatus(HttpStatus.CREATED.value())
                                .withHeader("Content-Type", "application/json")
                                .withBodyFile("taskApiResponse.json")));
        serviceCalls.i9api
                .stubFor(post(WireMock.urlEqualTo("/internal/eev/form-i9/v1/tasks/" + documentId))
                        .willReturn(aResponse().withStatus(201)));

        // when
        I9EventPayload payload = CreateSection2TaskTest.getMessagePayload();
        payload.getForm().setSsnRefused(Boolean.TRUE);
        payload.getForm().setSsnApplied(Boolean.TRUE);
        testableSubscriber.publishMessage(attributes, payload);
        //expected
        final RequestPatternBuilder markCreatedRequest =
                postRequestedFor(WireMock.urlEqualTo("/internal/eev/form-i9/v1/tasks/" + documentId));
        serviceCalls.i9api.assertCall(markCreatedRequest);
        serviceCalls.i9api.assertCall(markCreatedRequest);
        verify(publisherService, after(3000).times(1)).restartPacketForSSN(anyString(), anyString());
        verify(messageConfirmationForFlow, after(1000).atLeast(1)).acknowledge(any(AcknowledgeablePubsubMessage.class));
    }

    @Test
    public void testClosePacket() throws InterruptedException, ExecutionException, TimeoutException, JsonProcessingException {
        when(publisherService.closePacketForSSN(anyString())).thenReturn(Mono.empty());
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/tasks/"+documentId)
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("tasksFromI9-SSNActive.json")));

        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/audits/"+documentId+"/revision/2")
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("auditResponse.json")));

        serviceCalls.taskApi
                .stubFor(patch(WireMock.urlEqualTo("/internal/es-platform/task-management/v1/tasks/" + TASK_ID))
                        .willReturn(aResponse()
                                .withBodyFile("taskIdResponse.json")
                                .withHeader("Content-Type", "application/json").withStatus(200)));
        serviceCalls.i9api
                .stubFor(patch(WireMock.urlEqualTo("/internal/eev/form-i9/v1/tasks/" + documentId +"/" + TASK_ID))
                        .willReturn(aResponse().withStatus(200)));

        // when
        I9EventPayload payload = CreateSection2TaskTest.getMessagePayload();
        payload.getDocument().setRecordVersion(2L);
        attributes = Map.of(
                "status", "Section1_Amended",
                "documentId", documentId,
                "sourceId", "packet-ui");
        testableSubscriber.publishMessage(attributes, payload);
        //expected

        verify(publisherService, after(3000).times(1)).closePacketForSSN(anyString());
    }

    @Test
    public void testClosePacketForUnconfirmedData() throws InterruptedException, ExecutionException, TimeoutException, JsonProcessingException {
        when(publisherService.closePacketForUnconfirmedData(anyString())).thenReturn(Mono.empty());
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/tasks/"+documentId)
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("tasksFromI9-EV.json")));

        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/audits/"+documentId+"/revision/2")
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("auditResponse.json")));

        serviceCalls.taskApi
                .stubFor(patch(WireMock.urlEqualTo("/internal/es-platform/task-management/v1/tasks/" + TASK_ID))
                        .willReturn(aResponse()
                                .withBodyFile("taskIdResponse.json")
                                .withHeader("Content-Type", "application/json").withStatus(200)));
        serviceCalls.i9api
                .stubFor(patch(WireMock.urlEqualTo("/internal/eev/form-i9/v1/tasks/" + documentId +"/" + TASK_ID))
                        .willReturn(aResponse().withStatus(200)));

        // when
        I9EventPayload payload = CreateSection2TaskTest.getMessagePayload();
        payload.getDocument().setRecordVersion(2L);
        attributes = Map.of(
                "status", "Section1_Amended",
                "documentId", documentId,
                "sourceId", "packet-ui");
        testableSubscriber.publishMessage(attributes, payload);
        //expected
        log.info("testClosePacketForUnconfirmedData document id {} close packet mock", documentId);
        verify(publisherService, after(3000).times(1)).closePacketForUnconfirmedData(anyString());
    }

    @Test
    public void testOutOfScope() throws Exception {
        //given
        serviceCalls.taskApi.stubFor(WireMock.any(UrlPattern.ANY).willReturn(aResponse().withStatus(500)));
        serviceCalls.i9api.stubFor(WireMock.any(UrlPattern.ANY).willReturn(aResponse().withStatus(500)));
        //when
        testableSubscriber.publishMessage(Map.of(
                "status", "Section1_Complete",
                "documentId", documentId,
                "sourceId", UUID.randomUUID().toString()), new I9EventPayload());
        //expected
        verify(publisherService, after(3000).times(0)).restartPacketForSSN(anyString(),anyString());
        verify(messageConfirmationForFlow, after(1000).atLeast(1)).acknowledge(any(AcknowledgeablePubsubMessage.class));
    }

//    @Test()
//    @Ignore // ignored until https://equifax.atlassian.net/browse/I9TRANSFOR-6711 is introduced
    public void testPacketApiRestartEvent_AvoidDuplication() throws Exception {
        // given
        when(publisherService.restartPacketForSSN(anyString(),anyString())).thenReturn(Mono.empty());
        serviceCalls.taskApi
                .stubFor(post("/internal/es-platform/task-management/v1/tasks")
                        .willReturn(aResponse().withStatus(HttpStatus.CREATED.value())
                                .withHeader("Content-Type", "application/json")
                                .withBodyFile("taskApiResponse.json")));
        serviceCalls.i9api
                .stubFor(post(WireMock.urlEqualTo("/internal/eev/form-i9/v1/tasks/" + documentId))
                        .willReturn(aResponse().withStatus(201)));

        // when
        I9EventPayload payload = CreateSection2TaskTest.getMessagePayload();
        payload.getForm().setSsnRefused(Boolean.TRUE);
        payload.getForm().setSsnApplied(Boolean.TRUE);
        testableSubscriber.publishMessage(attributes, payload);
        //expected
        final RequestPatternBuilder markCreatedRequest =
                postRequestedFor(WireMock.urlEqualTo("/internal/eev/form-i9/v1/tasks/" + documentId));
        serviceCalls.i9api.assertCall(markCreatedRequest);
        verify(publisherService, after(1000).times(0)).restartPacketForSSN(anyString(), anyString());
        verify(messageConfirmation, after(1000).atLeast(1)).acknowledge(any(AcknowledgeablePubsubMessage.class));
    }

}
