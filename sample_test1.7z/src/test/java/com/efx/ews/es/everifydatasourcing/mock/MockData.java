package com.efx.ews.es.everifydatasourcing.mock;

import com.efx.ews.es.i9datasourcing.util.ReaderUtil;
import java.util.HashMap;
import java.util.Map;

public class MockData {

    private static final String EXPECTED_CONVERTED_FILENAME = "eVerifyConvertedForm.json";
    private static final String PATH = "classpath:__files/";

    public static Map<String, String> readExpectedConvertedEVerifyForm() {
        return ReaderUtil.readFromFile(PATH, EXPECTED_CONVERTED_FILENAME, HashMap.class);
    }
}
