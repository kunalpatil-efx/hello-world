package com.efx.ews.es.i9integration.i9portaleventshandler;

import com.efx.ews.es.eev.barricade.common.model.BarricadeKeyStore;
import com.efx.ews.es.eev.barricade.common.service.CryptographyService;
import com.efx.ews.es.eev.barricade.common.service.PubSubEncryptionService;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.I9EventStatus;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.event.I9EventPayload;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.AuditDataFeed;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.DataBaseAuditDataFeedTest;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.PacketPubSubPublisherService;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.ReferenceApiService;
import com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageConfirmation;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.matching.RequestPatternBuilder;
import com.github.tomakehurst.wiremock.matching.UrlPattern;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeoutException;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@SpringBootTest
@Slf4j
public class CompleteTaskTest {

    @Autowired
    private ServiceCalls serviceCalls;

    @Autowired
    private TestableSubscriber testableSubscriber;

    @MockBean
    @Qualifier("messageConfirmation")
    private MessageConfirmation messageConfirmation;
    @MockBean
    @Qualifier("messageConfirmationForFlow")
    private MessageConfirmation messageConfirmationForFlow;
    @MockBean
    private PubSubEncryptionService pubSubEncryptionService;
    @MockBean
    List<BarricadeKeyStore> barricadeKeyStores;
    @MockBean
    CryptographyService cryptographyService;
    @MockBean
    private PacketPubSubPublisherService publisherService;
    @MockBean
    private ReferenceApiService referenceApiService;
    @MockBean
    private AuditDataFeed auditFeed;

    private Map<String, String> attributes;
    private String documentId;
    private final static String TASK_ID = "39668771-f8b4-48a6-b02e-0d0200bd3651";

    @BeforeEach
    public void setup() throws Exception {
        documentId = LocalDateTime.now().format(DateTimeFormatter.ISO_DATE_TIME);
        attributes = Map.of("status", I9EventStatus.SECTION1_AMENDED.toString(),
                "sourceId", "packet-ui",
                "documentId", documentId,
                "recordVersion","2");

        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/forms/"+documentId+"/history/2")
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("historyResponse.json")));
        when(auditFeed.fetchAuditData(null))
                .thenReturn(Mono.just(List.of(DataBaseAuditDataFeedTest.createAuditMessage())));
    }

    @Test
    public void testCompleteTask() throws InterruptedException, ExecutionException, TimeoutException, JsonProcessingException {
        when(publisherService.closePacketForSSN(anyString())).thenReturn(Mono.just("test"));
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/tasks/"+documentId)
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("tasksFromI9-SSNActive-S2Active.json")));

        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/audits/"+documentId+"/revision/2")
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("auditResponse.json")));

        serviceCalls.taskApi
                .stubFor(patch(WireMock.urlEqualTo("/internal/es-platform/task-management/v1/tasks/" + TASK_ID))
                                .willReturn(aResponse()
                                        .withBodyFile("taskIdResponse.json")
                                        .withHeader("Content-Type", "application/json").withStatus(200)));
        serviceCalls.i9api
                .stubFor(patch(WireMock.urlEqualTo("/internal/eev/form-i9/v1/tasks/" + documentId +"/" + TASK_ID))
                .willReturn(aResponse().withStatus(200)));

        // when
        I9EventPayload payload = CreateSection2TaskTest.getMessagePayload();
        payload.getDocument().setRecordVersion(2L);
        testableSubscriber.publishMessage(attributes, payload);
        //expected

        final RequestPatternBuilder completeTaskRequest =
                patchRequestedFor(WireMock.urlEqualTo("/internal/es-platform/task-management/v1/tasks/" + TASK_ID));

        serviceCalls.taskApi.assertCall(completeTaskRequest);
        final RequestPatternBuilder markAsCompletedRequest =
                patchRequestedFor(WireMock.urlEqualTo("/internal/eev/form-i9/v1/tasks/" + documentId +"/" + TASK_ID));

        serviceCalls.i9api.assertCall(markAsCompletedRequest);
    }

    @Test
    public void testCompleteTaskForSectionThree() throws InterruptedException, ExecutionException, TimeoutException, JsonProcessingException {
        String taskId = "7e0a5898-90f5-408a-afd3-cff1d0fcde41";
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/tasks/"+documentId)
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("tasksFromI9-s3Active.json")));

        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/audits/"+documentId+"/revision/2")
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("auditResponse.json")));

        serviceCalls.taskApi
                .stubFor(patch(WireMock.urlEqualTo("/internal/es-platform/task-management/v1/tasks/" + taskId))
                        .willReturn(aResponse()
                                .withBodyFile("taskIdResponseS2.json")
                                .withHeader("Content-Type", "application/json").withStatus(200)));
        serviceCalls.i9api
                .stubFor(patch(WireMock.urlEqualTo("/internal/eev/form-i9/v1/tasks/" + documentId +"/" + taskId))
                        .willReturn(aResponse().withStatus(200)));

        serviceCalls.i9api
            .stubFor(get("/internal/eev/form-i9/v1/forms/" + documentId)
                .willReturn(aResponse().withHeader("Content-Type", "application/json")
                    .withBodyFile("getForm.json")));
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/forms/"+documentId+"/history/2")
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("S3HistoryResponse.json")));
        // when
        I9EventPayload payload = CreateSection2TaskTest.getMessagePayload();
        payload.getDocument().setRecordVersion(2L);
        attributes = Map.of("status", I9EventStatus.SECTION3_COMPLETE.toString(),
                "sourceId", "packet-ui",
                "documentId", documentId);
        testableSubscriber.publishMessage(attributes, payload);
        //expected

        final RequestPatternBuilder completeTaskRequest =
                patchRequestedFor(WireMock.urlEqualTo("/internal/es-platform/task-management/v1/tasks/" + taskId));

        log.info("testCompleteTaskForSectionThree documentId {} verifying /internal/es-platform/task-management/v1/tasks/", documentId);
        serviceCalls.taskApi.assertCall(completeTaskRequest);
        final RequestPatternBuilder markAsCompletedRequest =
                patchRequestedFor(WireMock.urlEqualTo("/internal/eev/form-i9/v1/tasks/" + documentId +"/" + taskId));

        log.info("testCompleteTaskForSectionThree documentId {} verifying /internal/eev/form-i9/v1/tasks/", documentId);
        serviceCalls.i9api.assertCall(markAsCompletedRequest);
    }

    @Test
    public void testCompleteTaskForSectionTwo() throws InterruptedException, ExecutionException, TimeoutException, JsonProcessingException {
        String taskId = "7e0a5898-90f5-408a-afd3-cff1d0fcde41";
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/tasks/"+documentId)
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("tasksFromI9-SSNActive-S2Active.json")));

        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/audits/"+documentId+"/revision/2")
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("auditResponse.json")));

        serviceCalls.taskApi
                .stubFor(patch(WireMock.urlEqualTo("/internal/es-platform/task-management/v1/tasks/" + taskId))
                        .willReturn(aResponse()
                                .withBodyFile("taskIdResponseS2.json")
                                .withHeader("Content-Type", "application/json").withStatus(200)));
        serviceCalls.i9api
                .stubFor(patch(WireMock.urlEqualTo("/internal/eev/form-i9/v1/tasks/" + documentId +"/" + taskId))
                        .willReturn(aResponse().withStatus(200)));

        serviceCalls.i9api
            .stubFor(get("/internal/eev/form-i9/v1/forms/" + documentId)
                    .willReturn(aResponse().withHeader("Content-Type", "application/json")
                            .withBodyFile("getForm.json")));

        serviceCalls.i9api
            .stubFor(get("/internal/eev/form-i9/v1/forms/" + documentId+"/history/2")
                .willReturn(aResponse().withHeader("Content-Type", "application/json")
                    .withBodyFile("getForm.json")));

        // when
        I9EventPayload payload = CreateSection2TaskTest.getMessagePayload();
        payload.getDocument().setRecordVersion(2L);
        attributes = Map.of("status", I9EventStatus.SECTION2_COMPLETE.toString(),
                "sourceId", "packet-ui",
                "documentId", documentId);
        testableSubscriber.publishMessage(attributes, payload);
        //expected

        final RequestPatternBuilder completeTaskRequest =
                patchRequestedFor(WireMock.urlEqualTo("/internal/es-platform/task-management/v1/tasks/" + taskId));

        log.info("testCompleteTaskForSectionTwo documentId {} verifying /internal/es-platform/task-management/v1/tasks/", documentId);
        serviceCalls.taskApi.assertCall(completeTaskRequest);
        final RequestPatternBuilder markAsCompletedRequest =
                patchRequestedFor(WireMock.urlEqualTo("/internal/eev/form-i9/v1/tasks/" + documentId +"/" + taskId));

        log.info("testCompleteTaskForSectionTwo documentId {} verifying /internal/eev/form-i9/v1/tasks/", documentId);
        serviceCalls.i9api.assertCall(markAsCompletedRequest);
    }

    @Test
    public void testClosePacket() throws InterruptedException, ExecutionException, TimeoutException, JsonProcessingException {
        String taskId = "7e0a5898-90f5-408a-afd3-cff1d0fcde41";
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/tasks/"+documentId)
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("tasksFromI9-SSNActive-S2Active.json")));

        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/audits/"+documentId+"/revision/2")
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("auditResponse.json")));

        serviceCalls.taskApi
                .stubFor(patch(WireMock.urlEqualTo("/internal/es-platform/task-management/v1/tasks/" + taskId))
                        .willReturn(aResponse()
                                .withBodyFile("taskIdResponseS2.json")
                                .withHeader("Content-Type", "application/json").withStatus(200)));
        serviceCalls.i9api
                .stubFor(patch(WireMock.urlEqualTo("/internal/eev/form-i9/v1/tasks/" + documentId +"/" + taskId))
                        .willReturn(aResponse().withStatus(200)));

        serviceCalls.i9api
            .stubFor(get("/internal/eev/form-i9/v1/forms/" + documentId + "/history/2")
                .willReturn(aResponse().withHeader("Content-Type", "application/json")
                    .withBodyFile("getForm.json")));

        // when
        I9EventPayload payload = CreateSection2TaskTest.getMessagePayload();
        payload.getDocument().setRecordVersion(2L);
        attributes = Map.of("status", I9EventStatus.SECTION2_COMPLETE.toString(),
                "sourceId", "packet-ui",
                "documentId", documentId);
        testableSubscriber.publishMessage(attributes, payload);
        //expected

        final RequestPatternBuilder completeTaskRequest =
                patchRequestedFor(WireMock.urlEqualTo("/internal/es-platform/task-management/v1/tasks/" + taskId));

        serviceCalls.taskApi.assertCall(completeTaskRequest);
        final RequestPatternBuilder markAsCompletedRequest =
                patchRequestedFor(WireMock.urlEqualTo("/internal/eev/form-i9/v1/tasks/" + documentId +"/" + taskId));

        serviceCalls.i9api.assertCall(markAsCompletedRequest);
    }

    @Test
    public void testSkippedStatus() throws InterruptedException, ExecutionException, TimeoutException, JsonProcessingException {
        // when
        testableSubscriber.publishMessage(Map.of("status", I9EventStatus.NEW.toString(),
                "sourceId", "packet-ui",
                "documentId", documentId), CreateSection2TaskTest.getMessagePayload());
        //expected
        serviceCalls.taskApi.stubFor(WireMock.any(UrlPattern.ANY).willReturn(aResponse().withStatus(500)));
        serviceCalls.i9api.stubFor(WireMock.any(UrlPattern.ANY).willReturn(aResponse().withStatus(500)));
    }

    @Test
    public void testCompleteTaskForSectionTwoUploadLater() throws InterruptedException, ExecutionException, TimeoutException, JsonProcessingException {
        String taskId = "39668771-f8b4-48a6-b02e-0d0200bd3651";
        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/tasks/"+documentId)
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("tasksFromI9-S2Active-S2UploadActive.json")));

        serviceCalls.i9api
                .stubFor(get("/internal/eev/form-i9/v1/audits/"+documentId+"/revision/2")
                        .willReturn(aResponse().withHeader("Content-Type", "application/json")
                                .withBodyFile("auditResponse.json")));

        serviceCalls.taskApi
                .stubFor(patch(WireMock.urlEqualTo("/internal/es-platform/task-management/v1/tasks/" + taskId))
                        .willReturn(aResponse()
                                .withBodyFile("taskIdResponseS2.json")
                                .withHeader("Content-Type", "application/json").withStatus(200)));
        serviceCalls.i9api
                .stubFor(patch(WireMock.urlEqualTo("/internal/eev/form-i9/v1/tasks/" + documentId +"/" + taskId))
                        .willReturn(aResponse().withStatus(200)));

        // when
        I9EventPayload payload = CreateUploadLaterTaskTest.getMessagePayload();
        payload.getDocument().setRecordVersion(2L);
        attributes = Map.of("status", I9EventStatus.SECTION2_DOCUMENT_UPLOADED.toString(),
                "sourceId", "packet-ui",
                "documentId", documentId);
        testableSubscriber.publishMessage(attributes, payload);
        //expected

        final RequestPatternBuilder completeTaskRequest =
                patchRequestedFor(WireMock.urlEqualTo("/internal/es-platform/task-management/v1/tasks/" + taskId));

        log.info("testCompleteTaskForSectionTwoUploadLater documentId {} verifying /internal/es-platform/task-management/v1/tasks/", documentId);
        serviceCalls.taskApi.assertCall(completeTaskRequest);
        final RequestPatternBuilder markAsCompletedRequest =
                patchRequestedFor(WireMock.urlEqualTo("/internal/eev/form-i9/v1/tasks/" + documentId +"/" + taskId));

        log.info("testCompleteTaskForSectionTwoUploadLater documentId {} verifying /internal/eev/form-i9/v1/tasks/", documentId);
        serviceCalls.i9api.assertCall(markAsCompletedRequest);
    }
}
