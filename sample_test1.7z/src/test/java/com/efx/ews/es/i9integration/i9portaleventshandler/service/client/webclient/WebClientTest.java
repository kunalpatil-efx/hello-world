package com.efx.ews.es.i9integration.i9portaleventshandler.service.client.webclient;

import com.efx.ews.es.eev.barricade.common.model.BarricadeKeyStore;
import com.efx.ews.es.eev.barricade.common.service.CryptographyService;
import com.efx.ews.es.eev.barricade.common.service.PubSubEncryptionService;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.common.Slf4jNotifier;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import reactor.util.context.Context;

import java.util.List;

import static com.efx.ews.es.common.filter.CorrelationFilter.SESSION_ID_HEADER_NAME;
import static com.efx.ews.es.common.filter.CorrelationFilter.TRANSACTION_ID_HEADER_NAME;
import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.anyUrl;
import static com.github.tomakehurst.wiremock.client.WireMock.equalTo;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.client.WireMock.postRequestedFor;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.options;

@SpringBootTest
@Slf4j
class WebClientTest {
    @MockBean
    List<BarricadeKeyStore> barricadeKeyStores;
    @MockBean
    CryptographyService cryptographyService;
    @MockBean
    private PubSubEncryptionService pubSubEncryptionService;


    @Autowired
    HttpCallClient httpCallClient;

    private WireMockServer server;

    @Test
    void testBuilder() {
        try {
            server = new WireMockServer(
                    options().port(5678)
                            .notifier(new Slf4jNotifier(true)));
            server.stubFor(post("/").willReturn(aResponse().withStatus(200)));
            server.start();

            httpCallClient
                    .doCall(webClient -> webClient
                            .post()
                            .uri("http://127.0.0.1:5678")
                            .retrieve()
                            .toBodilessEntity())
                    .subscriberContext(doOnContext ->
                            Context.of(TRANSACTION_ID_HEADER_NAME, "trx-01",
                                    SESSION_ID_HEADER_NAME, "session-01"))
                    .block();

            httpCallClient
                    .doCall(webClient -> webClient
                            .post()
                            .uri("http://127.0.0.1:5678")
                            .retrieve()
                            .toBodilessEntity())
                    .subscriberContext(doOnContext ->
                            Context.of(TRANSACTION_ID_HEADER_NAME, "trx-02",
                                    SESSION_ID_HEADER_NAME, "session-02"))
                    .block();

            server.verify(postRequestedFor(anyUrl())
                    .withHeader(TRANSACTION_ID_HEADER_NAME, equalTo("trx-01"))
                    .withHeader(SESSION_ID_HEADER_NAME, equalTo("session-01"))
            );

            server.verify(postRequestedFor(anyUrl())
                    .withHeader(TRANSACTION_ID_HEADER_NAME, equalTo("trx-02"))
                    .withHeader(SESSION_ID_HEADER_NAME, equalTo("session-02"))
            );
        } finally {
            server.shutdown();
        }
    }
}
