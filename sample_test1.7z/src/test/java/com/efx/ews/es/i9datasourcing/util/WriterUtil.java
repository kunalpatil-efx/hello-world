package com.efx.ews.es.i9datasourcing.util;

import java.io.File;
import java.io.FileOutputStream;
import lombok.SneakyThrows;

public class WriterUtil {

    private static final String I9_TEST_PATH = "target/i9-integration-test";
    private static final String E_VERIFY_PATH = "target/everify-integration-test";
    private static final String I9_SUMMARY_EVENT_FILENAME = "summary_event.json";
    private static final String I9_AUDIT_DETAIL_EVENTS_FILENAME = "audit_detail_events.json";
    private static final String E_VERIFY_FILENAME = "expected-event.json";

    @SneakyThrows
    public static void writeActualI9SummaryEvent(String testName, String data) {
        writeToFile(I9_TEST_PATH, testName, I9_SUMMARY_EVENT_FILENAME, data);
    }

    @SneakyThrows
    public static void writeActualI9AuditDetailEvents(String testName, String data) {
        writeToFile(I9_TEST_PATH, testName, I9_AUDIT_DETAIL_EVENTS_FILENAME, data);
    }

    public static void writeActualEVerifyEvent(String testName, String data) {
        writeToFile(E_VERIFY_PATH, testName, E_VERIFY_FILENAME, data);
    }

    @SneakyThrows
    public static void writeToFile(String folder, String testName, String fileName, String data) {
        String actualFolder = folder + "/" + testName + "/actual/";
        createDirectory(actualFolder);
        var fileFullName = actualFolder + fileName;
        File file = new File(fileFullName);
        file.createNewFile();
        try (FileOutputStream fileOutputStream = new FileOutputStream(file)) {
            fileOutputStream.write(data.getBytes());
        }
    }

    private static void createDirectory(String folder) {
        File destinationFolder = new File(folder);
        if (!destinationFolder.exists()) {
            destinationFolder.mkdirs();
        }
    }
}