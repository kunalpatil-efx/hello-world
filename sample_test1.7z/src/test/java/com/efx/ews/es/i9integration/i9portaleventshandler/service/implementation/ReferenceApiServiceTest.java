package com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.Document;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.referenceapi.Country;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.referenceapi.DocumentDefinition;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.referenceapi.IssuingAuthorityLookup;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.referenceapi.Province;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.referenceapi.State;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.Before;
import org.junit.Test;
import reactor.core.publisher.Mono;
import reactor.test.StepVerifier;

public class ReferenceApiServiceTest {

    private static final String driverLicenseTitle = "Driver's License Issued by State or Possession with Photo";
    private static final String canadaDriverLicense = "Canadian Driver's license";
    private static final String stateIssuedIDCard = "ID Card Issued by State or Possession with Photo";
    private static final String foreignPassportTitle = "Foreign Passport";
    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();
    private ReferenceApiServiceImpl referenceApiService;
    private ReferenceApiConnector referenceApiConnector;
    private List<DocumentDefinition> docDefResponse;

    @Before
    public void setup() throws IOException {
        referenceApiConnector = mock(ReferenceApiConnector.class);
        referenceApiService = new ReferenceApiServiceImpl(referenceApiConnector);
        InputStream is = this.getClass()
            .getResourceAsStream("/__files/referenceApiDocumentsResponse.json");
        docDefResponse = OBJECT_MAPPER.readValue(is, new TypeReference<List<DocumentDefinition>>() {});
    }

    @Test
    public void testGetData() {
        when(referenceApiConnector.getCountryCodeMap(anyString())).thenReturn(
            Mono.just(Map.of("AFG", new Country("Afghanistan", "AFG", true))));
        when(referenceApiConnector.getStateCodeMap(anyString())).thenReturn(Mono.just(Map.of("AK", new State("AK", "Alaska"))));
        when(referenceApiConnector.getProvinceCodeMap(anyString())).thenReturn(Mono.just(Map.of("BC", new Province("British Columbia", "BC"))));
        Map<String, IssuingAuthorityLookup> lookupMap = new HashMap<>();
        lookupMap.put(driverLicenseTitle, new IssuingAuthorityLookup(driverLicenseTitle, "states"));
        lookupMap.put(stateIssuedIDCard, new IssuingAuthorityLookup(stateIssuedIDCard, "states"));
        lookupMap.put(canadaDriverLicense, new IssuingAuthorityLookup(canadaDriverLicense, "provinces"));
        lookupMap.put(foreignPassportTitle, new IssuingAuthorityLookup(foreignPassportTitle, "countries"));
        when(referenceApiConnector.getIssuingAuthorityMap(anyString()))
            .thenReturn(Mono.just(lookupMap));
        referenceApiService.initialize();

        StepVerifier.create(referenceApiService.getCountryName("AFG", "i9v071717"))
            .expectNext("Afghanistan")
            .expectComplete();

        StepVerifier.create(referenceApiService.getProvinceName("BC", "i9v071717"))
            .expectNext("British Columbia")
            .expectComplete();

        StepVerifier.create(referenceApiService.getStateName("AK", "i9v071717"))
            .expectNext("Alaska")
            .expectComplete();

        StepVerifier.create(referenceApiService.getIssuingAuthorityMapByTitle("i9v071717"))
            .expectNext(lookupMap)
            .expectComplete();
    }

    @Test
    public void testBadLookup() {
        when(referenceApiConnector.getCountryCodeMap(anyString())).thenReturn(
            Mono.just(Map.of("AFG", new Country("Afghanistan", "AFG", true))));
        when(referenceApiConnector.getStateCodeMap(anyString())).thenReturn(Mono.just(Map.of("AK", new State("AK", "Alaska"))));
        when(referenceApiConnector.getProvinceCodeMap(anyString())).thenReturn(Mono.just(Map.of("BC", new Province("British Columbia", "BC"))));
        when(referenceApiConnector.getIssuingAuthorityMap(anyString()))
            .thenReturn(Mono.just(Map.of(driverLicenseTitle, new IssuingAuthorityLookup(driverLicenseTitle, "states"))));
        referenceApiService.initialize();

        StepVerifier.create(referenceApiService.getCountryName("IND", "i9v071717"))
            .expectComplete();

        StepVerifier.create(referenceApiService.getProvinceName("XY", "i9v071717"))
            .expectComplete();

        StepVerifier.create(referenceApiService.getStateName("PQ", "i9v071717"))
            .expectComplete();

    }

    @Test
    public void testNoData() {
        when(referenceApiConnector.getCountryCodeMap(anyString())).thenReturn(Mono.empty());
        when(referenceApiConnector.getStateCodeMap(anyString())).thenReturn(Mono.empty());
        when(referenceApiConnector.getProvinceCodeMap(anyString())).thenReturn(Mono.empty());
        when(referenceApiConnector.getIssuingAuthorityMap(anyString())).thenReturn(Mono.empty());
        referenceApiService.initialize();

        StepVerifier.create(referenceApiService.getCountryName("IND", "i9v071717"))
            .expectComplete();

        StepVerifier.create(referenceApiService.getProvinceName("XY", "i9v071717"))
            .expectComplete();

        StepVerifier.create(referenceApiService.getStateName("PQ", "i9v071717"))
            .expectComplete();

    }

    @Test
    public void testUpdateIssuingAuthorityByTitle() {
        when(referenceApiConnector.getCountryCodeMap(anyString())).thenReturn(
            Mono.just(Map.of("AFG", new Country("Afghanistan", "AFG", true))));
        when(referenceApiConnector.getStateCodeMap(anyString())).thenReturn(Mono.just(Map.of("AK", new State("AK", "Alaska"))));
        when(referenceApiConnector.getProvinceCodeMap(anyString())).thenReturn(Mono.just(Map.of("BC", new Province("British Columbia", "BC"))));
        Map<String, IssuingAuthorityLookup> lookupMap = new HashMap<>();
        lookupMap.put(driverLicenseTitle, new IssuingAuthorityLookup(driverLicenseTitle, "states"));
        lookupMap.put(stateIssuedIDCard, new IssuingAuthorityLookup(stateIssuedIDCard, "states"));
        lookupMap.put(canadaDriverLicense, new IssuingAuthorityLookup(canadaDriverLicense, "provinces"));
        lookupMap.put(foreignPassportTitle, new IssuingAuthorityLookup(foreignPassportTitle, "countries"));
        when(referenceApiConnector.getIssuingAuthorityMap(anyString()))
            .thenReturn(Mono.just(lookupMap));
        referenceApiService.initialize();

        Document document = new Document();
        document.setDocumentTitle(driverLicenseTitle);
        document.setIssuingAuthority("AK");

        // Test updating state
        List<Document> list =
            referenceApiService.updateIssuingAuthorityByTitle(lookupMap, Arrays.asList(document), "i9v071717").block();
        assertNotNull(list);
        Document updatedDoc = list.get(0);
        assertNotNull(updatedDoc);
        assertEquals("Alaska - AK", document.getIssuingAuthority()); //assert that we updated

        document.setIssuingAuthority("IL");
        list =
            referenceApiService.updateIssuingAuthorityByTitle(lookupMap, Arrays.asList(document), "i9v071717").block();
        assertNotNull(list);
        updatedDoc = list.get(0);
        assertNotNull(updatedDoc);
        assertEquals("IL", document.getIssuingAuthority()); //assert that we did not update

        // Test updating country
        document.setDocumentTitle(foreignPassportTitle);
        document.setIssuingAuthority("AFG");
        list =
            referenceApiService.updateIssuingAuthorityByTitle(lookupMap, Arrays.asList(document), "i9v071717").block();
        assertNotNull(list);
        updatedDoc = list.get(0);
        assertNotNull(updatedDoc);
        assertEquals("Afghanistan - AFG", document.getIssuingAuthority());

        document.setIssuingAuthority("IND");
        list =
            referenceApiService.updateIssuingAuthorityByTitle(lookupMap, Arrays.asList(document), "i9v071717").block();
        assertNotNull(list);
        updatedDoc = list.get(0);
        assertNotNull(updatedDoc);
        assertEquals("IND", document.getIssuingAuthority());

        // Test updating province
        document.setDocumentTitle(canadaDriverLicense);
        document.setIssuingAuthority("BC");
        list =
            referenceApiService.updateIssuingAuthorityByTitle(lookupMap, Arrays.asList(document), "i9v071717").block();
        assertNotNull(list);
        updatedDoc = list.get(0);
        assertNotNull(updatedDoc);
        assertEquals("British Columbia - BC", document.getIssuingAuthority());

        document.setIssuingAuthority("AB");
        list =
            referenceApiService.updateIssuingAuthorityByTitle(lookupMap, Arrays.asList(document), "i9v071717").block();
        assertNotNull(list);
        updatedDoc = list.get(0);
        assertNotNull(updatedDoc);
        assertEquals("AB", document.getIssuingAuthority());

    }
}
