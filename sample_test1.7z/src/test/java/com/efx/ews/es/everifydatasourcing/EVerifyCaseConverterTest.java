package com.efx.ews.es.everifydatasourcing;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.only;
import static org.mockito.Mockito.verify;
import static org.mockito.MockitoAnnotations.initMocks;

import com.efx.ews.es.everifydatasourcing.fieldconverter.EVerifyConverterImpl;
import com.efx.ews.es.everifydatasourcing.model.EVerifyCase;
import com.efx.ews.es.everifydatasourcing.processor.AuditSummaryEVerifyProcessor;
import com.efx.ews.es.i9datasourcing.flattener.Flattener;
import com.efx.ews.es.i9datasourcing.model.ChangeContext;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

class EVerifyCaseConverterTest {

    @Mock
    private Flattener flattener;
    @Mock
    private EVerifyConverterImpl eVerifyFormConverter;
    @Mock
    private AuditSummaryEVerifyProcessor auditSummaryEVerifyProcessor;

    @InjectMocks
    private EVerifyCaseConverter eVerifyCaseConverter;

    @BeforeEach
    public void setUp() {
        initMocks(this);
    }

    @Test
    void itShouldCallConvertEVerifyCase() {
        //GIVEN
        var eVerifyCase = mock(EVerifyCase.class);
        var changeContext = mock(ChangeContext.class);

        //EXECUTE
        eVerifyCaseConverter.convert(eVerifyCase, changeContext);

        //ASSERT
        verify(flattener, only()).process(eVerifyCase);
        verify(eVerifyFormConverter, only()).convertForm(any(Map.class), any(ChangeContext.class));
        verify(auditSummaryEVerifyProcessor, only()).process(any(Map.class), any(ChangeContext.class));
    }

    @Test
    void itShouldCallConvertEVerifyCaseWithNullInputAndReturnException() {
        //ASSERT
        var changeContext = mock(ChangeContext.class);
        assertThatThrownBy(() -> eVerifyCaseConverter.convert(null, changeContext))
            .isInstanceOf(NullPointerException.class);
    }
}


