package com.efx.ews.es.i9integration.i9portaleventshandler;


import com.efx.ews.es.eev.barricade.common.model.BarricadeKeyStore;
import com.efx.ews.es.eev.barricade.common.service.CryptographyService;
import com.efx.ews.es.eev.barricade.common.service.PubSubEncryptionService;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.event.I9EventDocumentData;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.event.I9EventFormData;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.event.I9EventPayload;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.AuditDataFeed;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.DataBaseAuditDataFeedTest;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.ReferenceApiService;
import com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageConfirmation;
import com.github.tomakehurst.wiremock.matching.RequestPatternBuilder;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import reactor.core.publisher.Mono;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static com.efx.ews.es.i9integration.i9portaleventshandler.utils.WireMockTestFile.testFileContent;
import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static org.mockito.Mockito.when;

@SuppressWarnings("unused")
@SpringBootTest
@ExtendWith(SpringExtension.class)
@Slf4j
public class TaskSubscriberTest {
    @Autowired
    private MessagePublish messagePublish;

    @Autowired
    private ServiceCalls serviceCalls;

    @Autowired
    private TestableSubscriber testableSubscriber;

    @MockBean
    @Qualifier("messageConfirmation")
    private MessageConfirmation messageConfirmation;

    @MockBean
    @Qualifier("messageConfirmationForFlow")
    private MessageConfirmation messageConfirmationForFlow;

    @MockBean
    private PubSubEncryptionService pubSubEncryptionService;

    @MockBean
    List<BarricadeKeyStore> barricadeKeyStores;

    @MockBean
    CryptographyService cryptographyService;

    @MockBean
    private ReferenceApiService referenceApiService;
    @MockBean
    private AuditDataFeed auditFeed;

    private final long recordVersion = 3L;
    private String factId;
    private String documentId;

    @BeforeEach
    public void setup() {
        factId = LocalDateTime.now().format(DateTimeFormatter.ISO_DATE_TIME);
        documentId = LocalDateTime.now().format(DateTimeFormatter.ISO_DATE_TIME);
        serviceCalls.employerPersonApi.stubFor(
                get("/internal/es-platform/employer-person/v1/employees/by-fact-id/" + factId)
                        .willReturn(
                                aResponse()
                                        .withHeader("Content-Type", "application/json")
                                        .withBodyFile("getEmployeeByFactId.json")));
        serviceCalls.i9api.stubFor(
                patch(urlEqualTo("/internal/eev/form-i9/v1/forms/" + documentId + "/metadata"))
                        .willReturn(aResponse().withStatus(200))
        );
        when(auditFeed.fetchAuditData(null))
                .thenReturn(Mono.just(List.of(DataBaseAuditDataFeedTest.createAuditMessage())));
    }

    @Test
    public void noTaskCreationMessageUpdatesI9WithEmployeeId() throws Exception {
        //given
        Map<String, String> noTaskCreationAttributes = Map.of(
                "status", "Section1_Complete",
                "documentId", documentId,
                "employeeFactId", factId,
                "employeeId", "");
        // when
        testableSubscriber.publishMessage(noTaskCreationAttributes, new I9EventPayload());
        // expect
        final RequestPatternBuilder patchEmployeeId = patchRequestedFor(anyUrl())
                .withRequestBody(
                        equalToJson(testFileContent("patchMetadataEmployeeId.json"),
                                true,
                                true));
        serviceCalls.i9api.assertCall(patchEmployeeId, documentId);
    }

    @Test
    public void taskCreationMessageUpdatesI9WithEmployeeId() throws Exception {
        //given
        final String taskId = "7e0a5898-90f5-408a-afd3-cff1d0fcde41";
        serviceCalls.i9api.stubFor(
                get("/internal/eev/form-i9/v1/tasks/" + documentId)
                        .willReturn(
                                aResponse().withHeader("Content-Type", "application/json")
                                        // has i9 section 2 task with status new
                                        .withBodyFile("tasksFromI9-SSNActive-S2Active.json")));
        serviceCalls.taskApi.stubFor(
                post("/internal/es-platform/task-management/v1/tasks")
                        .willReturn(
                                aResponse().withHeader("Content-Type", "application/json")
                                        .withBody("{ \"id\": \"58a8b247-486c-46f3-9389-f6920e8cec74\" }")));
        serviceCalls.i9api
            .stubFor(get("/internal/eev/form-i9/v1/forms/" + documentId+ "/history/3")
                .willReturn(aResponse().withHeader("Content-Type", "application/json")
                    .withBodyFile("getForm.json")));

        serviceCalls.i9api.stubFor(
                get("/internal/eev/form-i9/v1/audits/" + documentId + "/revision/" + recordVersion)
                        .willReturn(
                                aResponse().withHeader("Content-Type", "application/json")
                                        .withBodyFile("auditResponse.json")
                        ));
        serviceCalls.taskApi.stubFor(
                patch(urlEqualTo("/internal/es-platform/task-management/v1/tasks/" + taskId))
                        .willReturn(
                                aResponse().withStatus(200)
                        ));
        serviceCalls.i9api.stubFor(
                patch(urlEqualTo("/internal/eev/form-i9/v1/tasks/" + documentId + "/" + taskId))
                        .willReturn(
                                aResponse().withStatus(200)
                        ));
        Map<String, String> taskCreatedForSourceIdAttributes = Map.of(
                "status", "Section2_Complete",
                "documentId", documentId,
                "employeeFactId", factId,
                "employeeId", "",
                "sourceId", "packet-ui"
        );
        // when
        testableSubscriber.publishMessage(taskCreatedForSourceIdAttributes, getI9EventPayload());
        // expect
        final RequestPatternBuilder patchEmployeeId = patchRequestedFor(anyUrl())
                .withRequestBody(
                        equalToJson(testFileContent("patchMetadataEmployeeId.json"),
                                true,
                                true));
        serviceCalls.i9api.assertCall(patchEmployeeId, documentId);
    }

    private I9EventPayload getI9EventPayload() {
        final I9EventDocumentData document = new I9EventDocumentData();
        document.setEmployerId(UUID.randomUUID().toString());
        document.setEmployeeFactId(UUID.randomUUID().toString());
        document.setProjectedStartDate(LocalDate.now().toString());
        document.setEmployerLocationId(UUID.randomUUID().toString());
        document.setRecordVersion(recordVersion);
        final I9EventPayload payload = new I9EventPayload();
        payload.setDocument(document);
        final I9EventFormData form = new I9EventFormData();
        form.setSsnApplied(false);
        payload.setForm(form);
        return payload;
    }
}
