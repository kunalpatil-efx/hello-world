package com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation;

import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.PacketPubSubProperties;
import org.junit.Before;
import org.junit.Test;
import org.springframework.cloud.gcp.pubsub.core.publisher.PubSubPublisherTemplate;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.concurrent.ListenableFuture;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class PacketPubSubPublisherServiceImplTest {
    private PacketPubSubPublisherService publisherService;
    private PacketPubSubProperties packerPubSubPropertiesMock;
    private PubSubPublisherTemplate publisherTemplateMock;
    @Before
    public void setup() {
        packerPubSubPropertiesMock = mock(PacketPubSubProperties.class);
        publisherTemplateMock = mock(PubSubPublisherTemplate.class);
        when(packerPubSubPropertiesMock.getProjectId()).thenReturn("pro_id");
        when(packerPubSubPropertiesMock.getTopic()).thenReturn("topic_id");
        publisherService = new PacketPubSubPublisherServiceImpl(packerPubSubPropertiesMock);
        ReflectionTestUtils.setField(publisherService, "publisher", publisherTemplateMock);
    }

    @Test
    public void publishRestartPacket_success() throws ExecutionException, InterruptedException {
        ListenableFuture<String> listenableMock = mock(ListenableFuture.class);
        when(listenableMock.get()).thenReturn("123");
        when(listenableMock.completable()).thenReturn(mock(CompletableFuture.class));
        when(publisherTemplateMock.publish(anyString(), anyString())).thenReturn(listenableMock);
        publisherService.restartPacketForSSN("ABC", "123");
        verify(publisherTemplateMock, times(1)).publish(anyString(), anyString());
    }

    @Test
    public void closePacketForSSN_success() throws ExecutionException, InterruptedException {
        ListenableFuture<String> listenableMock = mock(ListenableFuture.class);
        when(listenableMock.get()).thenReturn("123");
        when(listenableMock.completable()).thenReturn(mock(CompletableFuture.class));
        when(publisherTemplateMock.publish(anyString(), anyString())).thenReturn(listenableMock);
        publisherService.closePacketForSSN("ABC");
        verify(publisherTemplateMock, times(1)).publish(anyString(), anyString());
    }

    @Test
    public void closePacketForUnconfirmedData_success() throws ExecutionException, InterruptedException {
        ListenableFuture<String> listenableMock = mock(ListenableFuture.class);
        when(listenableMock.get()).thenReturn("123");
        when(listenableMock.completable()).thenReturn(mock(CompletableFuture.class));
        when(publisherTemplateMock.publish(anyString(), anyString())).thenReturn(listenableMock);
        publisherService.closePacketForUnconfirmedData("ABC");
        verify(publisherTemplateMock, times(1)).publish(anyString(), anyString());
    }
}
