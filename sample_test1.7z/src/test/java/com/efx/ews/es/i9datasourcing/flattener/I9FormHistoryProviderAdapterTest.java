package com.efx.ews.es.i9datasourcing.flattener;

import com.efx.ews.es.historyprovider.api.HistoryEventListener;
import com.efx.ews.es.historyprovider.infrastructure.I9FormHistoryProviderAdapter;
import com.efx.ews.es.historyprovider.model.EventMessageDocument;
import com.efx.ews.es.historyprovider.model.I9AuditModel;
import com.efx.ews.es.historyprovider.model.I9FormEventMessage;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.I9Form;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.I9ApiCall;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.pubsub.v1.PubsubMessage;
import lombok.SneakyThrows;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.cloud.gcp.pubsub.core.subscriber.PubSubSubscriberTemplate;
import org.springframework.cloud.gcp.pubsub.support.BasicAcknowledgeablePubsubMessage;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.concurrent.ListenableFuture;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

import static com.efx.ews.es.common.filter.CorrelationFilter.SESSION_ID_HEADER_NAME;
import static com.efx.ews.es.common.filter.CorrelationFilter.TRANSACTION_ID_HEADER_NAME;
import static java.util.Collections.singletonList;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

class I9FormHistoryProviderAdapterTest {

    private static final String I9_DOCUMENT_ID = "gWtqIKBSvzxsp4AhW0Ie";
    private static final String MESSAGE_ID = "messageId-465";

    private I9FormHistoryProviderAdapter i9FormHistoryProviderAdapter;
    private I9ApiCall i9ApiCall;
    private ObjectMapper objectMapper;
    private PubSubSubscriberTemplate pubSubSubscriberTemplate;

    @BeforeEach
    public void setUp() {
        i9ApiCall = mock(I9ApiCall.class);
        objectMapper = mock(ObjectMapper.class);
        pubSubSubscriberTemplate = mock(PubSubSubscriberTemplate.class);
        i9FormHistoryProviderAdapter = new I9FormHistoryProviderAdapter(i9ApiCall, objectMapper,
            pubSubSubscriberTemplate);

        Map<String, String> headers = Map.of(TRANSACTION_ID_HEADER_NAME, "trx01", SESSION_ID_HEADER_NAME, "session-01");
        ReflectionTestUtils.setField(i9FormHistoryProviderAdapter, "headers", headers);
    }

    @Test
    void shouldReturnAudits() {
        String documentId = "23gdd-wer5";
        Mono<ResponseEntity<List<I9AuditModel>>> monoEntity = Mono
            .just(new ResponseEntity<>(singletonList(new I9AuditModel()), HttpStatus.OK));
        when(i9ApiCall.getFormDataAudits(documentId)).thenReturn(monoEntity);

        List<I9AuditModel> result = i9FormHistoryProviderAdapter.getAudits(documentId);

        verify(i9ApiCall).getFormDataAudits(documentId);
        assertThat(result).isNotEmpty();
    }

    @Test
    void shouldReturnFormByRevision() {
        String documentId = "11fre-908gdd-wer5";
        int revision = 2;
        when(i9ApiCall.getFormByRevision(documentId, String.valueOf(revision))).thenReturn(Mono.just(new I9Form()));

        I9Form resultForm = i9FormHistoryProviderAdapter.getRevision(documentId, revision);

        verify(i9ApiCall).getFormByRevision(documentId, String.valueOf(revision));
        assertNotNull(resultForm);
    }

    @Test
    void shouldRegisterEventListener() {
        HistoryEventListener historyEventListener = mock(HistoryEventListener.class);

        i9FormHistoryProviderAdapter.registerEventListener(historyEventListener);

        verify(pubSubSubscriberTemplate).subscribe(any(),
            any(Consumer.class));
    }

    @Test
    void shouldNotRegisterNullEventListener() {
        HistoryEventListener historyEventListener = null;

        i9FormHistoryProviderAdapter.registerEventListener(historyEventListener);

        verifyNoInteractions(pubSubSubscriberTemplate);
    }

    @Test
    @SneakyThrows
    void shouldHandleI9MessageSettingMessageId() {

        // given/when

        PubsubMessage pubsubMessage = PubsubMessage.newBuilder()
            .setMessageId(MESSAGE_ID)
            .putAttributes("documentId", I9_DOCUMENT_ID)
            .build();

        ListenableFuture<Void> listenableFuture = mock(ListenableFuture.class);

        BasicAcknowledgeablePubsubMessage basicAcknowledgeablePubsubMessage = mock(
            BasicAcknowledgeablePubsubMessage.class);
        when(basicAcknowledgeablePubsubMessage.getPubsubMessage()).thenReturn(pubsubMessage);
        when(basicAcknowledgeablePubsubMessage.ack()).thenReturn(listenableFuture);
        when(basicAcknowledgeablePubsubMessage.nack()).thenReturn(listenableFuture);

        I9FormEventMessage i9FormEventMessage = new I9FormEventMessage();
        i9FormEventMessage.setDocument(new EventMessageDocument());

        when(objectMapper.readValue(any(String.class), any(Class.class))).thenReturn(i9FormEventMessage);

        when(pubSubSubscriberTemplate.subscribe(any(), any(Consumer.class))).thenAnswer(invocation -> {
            Consumer<BasicAcknowledgeablePubsubMessage> msgConsumer = invocation.getArgument(1);
            msgConsumer.accept(basicAcknowledgeablePubsubMessage);
            return null;
        });

        HistoryEventListener historyEventListener = mock(HistoryEventListener.class);

        // execute

        i9FormHistoryProviderAdapter.registerEventListener(historyEventListener);

        // verify

        verify(basicAcknowledgeablePubsubMessage).ack();
        assertThat(i9FormEventMessage.getDocument().getDocumentId()).isEqualTo(I9_DOCUMENT_ID);
        assertThat(i9FormEventMessage.getMessageId()).isEqualTo(MESSAGE_ID);
    }

    @Test
    @SneakyThrows
    void shouldThrowExceptionOnIncorrectPubSubMessageData() {

        // given/when

        PubsubMessage pubsubMessage = PubsubMessage.newBuilder()
            .setMessageId("1587184718171756")
            .putAttributes("documentId", "gWtqIKBSvzxsp4AhW0Ie")
            .build();

        ListenableFuture<Void> listenableFuture = mock(ListenableFuture.class);

        BasicAcknowledgeablePubsubMessage basicAcknowledgeablePubsubMessage = mock(
            BasicAcknowledgeablePubsubMessage.class);
        when(basicAcknowledgeablePubsubMessage.getPubsubMessage()).thenReturn(pubsubMessage);
        when(basicAcknowledgeablePubsubMessage.ack()).thenReturn(listenableFuture);
        when(basicAcknowledgeablePubsubMessage.nack()).thenReturn(listenableFuture);

        when(objectMapper.readValue(any(String.class), any(Class.class))).thenThrow(JsonProcessingException.class);

        when(pubSubSubscriberTemplate.subscribe(any(), any(Consumer.class))).thenAnswer(invocation -> {
            Consumer<BasicAcknowledgeablePubsubMessage> msgConsumer = invocation.getArgument(1);
            msgConsumer.accept(basicAcknowledgeablePubsubMessage);
            return null;
        });

        HistoryEventListener historyEventListener = mock(HistoryEventListener.class);

        // execute

        i9FormHistoryProviderAdapter.registerEventListener(historyEventListener);

        // verify

        verify(basicAcknowledgeablePubsubMessage).nack();
    }

    @Test
    @SneakyThrows
    void shouldThrowExceptionOnMessageHandlingError() {

        // given/when

        PubsubMessage pubsubMessage = PubsubMessage.newBuilder()
            .setMessageId("1587184718171756")
            .putAttributes("documentId", "gWtqIKBSvzxsp4AhW0Ie")
            .build();

        ListenableFuture<Void> listenableFuture = mock(ListenableFuture.class);

        BasicAcknowledgeablePubsubMessage basicAcknowledgeablePubsubMessage = mock(
            BasicAcknowledgeablePubsubMessage.class);
        when(basicAcknowledgeablePubsubMessage.getPubsubMessage()).thenReturn(pubsubMessage);
        when(basicAcknowledgeablePubsubMessage.ack()).thenReturn(listenableFuture);
        when(basicAcknowledgeablePubsubMessage.nack()).thenReturn(listenableFuture);

        I9FormEventMessage i9FormEventMessage = new I9FormEventMessage();
        i9FormEventMessage.setDocument(new EventMessageDocument());

        when(objectMapper.readValue(any(String.class), any(Class.class))).thenReturn(i9FormEventMessage);

        when(pubSubSubscriberTemplate.subscribe(any(), any(Consumer.class))).thenAnswer(invocation -> {
            Consumer<BasicAcknowledgeablePubsubMessage> msgConsumer = invocation.getArgument(1);
            msgConsumer.accept(basicAcknowledgeablePubsubMessage);
            return null;
        });

        HistoryEventListener historyEventListener = mock(HistoryEventListener.class);
        doThrow(RuntimeException.class).when(historyEventListener).onEventReceived(any());

        // execute

        i9FormHistoryProviderAdapter.registerEventListener(historyEventListener);

        // verify

        verify(basicAcknowledgeablePubsubMessage).nack();
    }
}
