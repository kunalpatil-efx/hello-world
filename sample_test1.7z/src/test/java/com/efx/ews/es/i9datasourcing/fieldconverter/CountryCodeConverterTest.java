package com.efx.ews.es.i9datasourcing.fieldconverter;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

import com.efx.ews.es.i9datasourcing.provider.CountryCodeProvider;
import java.util.Collections;
import java.util.Map;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;

class CountryCodeConverterTest {

    @Mock
    CountryCodeProvider countryCodeProvider;

    @BeforeEach
    public void init() {
        initMocks(this);
    }

    @Test
    void converterShouldReturnExpectedValue() {
        //Given
        String fieldName = "country.name";
        String countryName = "Poland";
        String expectedCountryCode = "POL";
        CountryCodeConverter countryCodeConverter = new CountryCodeConverter(countryCodeProvider, fieldName);
        Map<String, String> flattenedForm = Map.of(fieldName, countryName);
        when(countryCodeProvider.getCountryCode(countryName)).thenReturn(expectedCountryCode);

        //When
        String actualCountryCode = countryCodeConverter.convert(flattenedForm);

        //Then
        assertThat(actualCountryCode).isEqualTo(expectedCountryCode);
    }

    @Test
    void converterShouldReturnEmptyStringWhenCountryNameIsNull() {
        //Given
        String fieldName = "country.name";
        String expectedCountryCode = "";
        CountryCodeConverter countryCodeConverter = new CountryCodeConverter(countryCodeProvider, fieldName);
        Map<String, String> flattenedForm = Collections.emptyMap();

        //When
        String actualCountryCode = countryCodeConverter.convert(flattenedForm);

        //Then
        assertThat(actualCountryCode).isEqualTo(expectedCountryCode);
    }
}