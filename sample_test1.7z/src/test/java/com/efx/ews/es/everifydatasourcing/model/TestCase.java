package com.efx.ews.es.everifydatasourcing.model;

import com.efx.ews.es.i9datasourcing.model.ChangeContext;
import com.efx.ews.es.i9datasourcing.util.JsonReaderUtil;
import com.efx.ews.es.i9datasourcing.util.ReaderUtil;
import lombok.Data;
import org.json.JSONObject;

@Data
public class TestCase {

    private static final String CHANGE_CTX_FILENAME = "change-context.json";
    private static final String EVERIFY_FILENAME = "everify-case.json";
    private static final String EXPECTED_EVENT_FILENAME = "expected-event.json";
    private String name;
    private EVerifyCase everifyCase;
    private ChangeContext changeContext;
    private JSONObject expectedEvent;

    public static TestCase create(final String testName) {
        TestCase testCase = new TestCase();
        testCase.name = testName;
        testCase.everifyCase = ReaderUtil
            .readFromFile(testName, EVERIFY_FILENAME, EVerifyCase.class, ReaderUtil.E_VERIFY_FORMS_PATH);
        testCase.changeContext = ReaderUtil
            .readFromFile(testName, CHANGE_CTX_FILENAME, ChangeContext.class, ReaderUtil.E_VERIFY_FORMS_PATH);
        testCase.expectedEvent = JsonReaderUtil
            .readFromFile(testName, EXPECTED_EVENT_FILENAME, ReaderUtil.E_VERIFY_FORMS_PATH);

        return testCase;
    }

    @Override
    public String toString() {
        return name;
    }
}
