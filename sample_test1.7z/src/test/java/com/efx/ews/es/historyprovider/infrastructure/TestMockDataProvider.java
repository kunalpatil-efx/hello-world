package com.efx.ews.es.historyprovider.infrastructure;

import com.efx.ews.es.historyprovider.model.EventMessageDocument;
import com.efx.ews.es.historyprovider.model.EventMessageForm;
import com.efx.ews.es.historyprovider.model.I9AuditModel;
import com.efx.ews.es.historyprovider.model.I9FormEventMessage;
import java.util.Collections;
import java.util.List;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class TestMockDataProvider {

    public static final String TEST_DOCUMENT_ID = "TEST_DOCUMENT_ID";
    public static final int RECORD_REVISION_1 = 1;
    public static final int RECORD_REVISION_2 = 2;
    public static final String TEST_STATUS = "TEST_STATUS";
    public static final String SECTION_1_COMPLETE = "Section1_Complete";
    public static final String SOME_EVENT_KEY = "SOME_EVENT_KEY";
    public static final String STATUS_NEW = "NEW";
    public static final String MIGRATED_I9 = "Migrated_I9";
    public static final String MESSAGE_ID = "messageId-7";
    private static final String EVENT_DATE = "2020-10-30T15:44:57.182Z";

    public static List<I9AuditModel> createAuditModelList() {
        I9AuditModel previousAuditModel = new I9AuditModel();
        previousAuditModel.setDate(EVENT_DATE);
        previousAuditModel.setDataUpdate(true);
        previousAuditModel.setRecordRevision(RECORD_REVISION_1);
        previousAuditModel.setEventKey(StringUtils.EMPTY);

        I9AuditModel currentAuditModel = new I9AuditModel();
        currentAuditModel.setDate(EVENT_DATE);
        currentAuditModel.setDataUpdate(true);
        currentAuditModel.setRecordRevision(RECORD_REVISION_2);
        currentAuditModel.setEventKey(SECTION_1_COMPLETE);

        return List.of(previousAuditModel, currentAuditModel);
    }

    public static List<I9AuditModel> createAuditModelListWithOtherEventKeyInCurrentAudit() {
        I9AuditModel previousAuditModel = new I9AuditModel();
        previousAuditModel.setDate(EVENT_DATE);
        previousAuditModel.setDataUpdate(true);
        previousAuditModel.setRecordRevision(RECORD_REVISION_1);
        previousAuditModel.setEventKey(StringUtils.EMPTY);

        I9AuditModel currentAuditModel = new I9AuditModel();
        currentAuditModel.setDate(EVENT_DATE);
        currentAuditModel.setDataUpdate(true);
        currentAuditModel.setRecordRevision(RECORD_REVISION_2);
        currentAuditModel.setEventKey(SOME_EVENT_KEY);

        return List.of(previousAuditModel, currentAuditModel);
    }

    public static List<I9AuditModel> createAuditModelListWithoutBeforeAudit() {
        I9AuditModel previousAuditModel = new I9AuditModel();
        previousAuditModel.setDate(EVENT_DATE);
        previousAuditModel.setDataUpdate(true);
        previousAuditModel.setRecordRevision(RECORD_REVISION_2);
        previousAuditModel.setEventKey(SECTION_1_COMPLETE);

        return Collections.singletonList(previousAuditModel);
    }

    public static List<I9AuditModel> createAuditModelListWithoutAfterAudit() {
        I9AuditModel previousAuditModel = new I9AuditModel();
        previousAuditModel.setDate(EVENT_DATE);
        previousAuditModel.setDataUpdate(true);
        previousAuditModel.setRecordRevision(RECORD_REVISION_1);
        previousAuditModel.setEventKey(SECTION_1_COMPLETE);

        return Collections.singletonList(previousAuditModel);
    }

    public static I9FormEventMessage createMockMessage() {

        I9FormEventMessage formEventMessage = new I9FormEventMessage();
        formEventMessage.setStatus(SECTION_1_COMPLETE);

        EventMessageDocument document = new EventMessageDocument();
        document.setDocumentId(TEST_DOCUMENT_ID);
        document.setStatus(SECTION_1_COMPLETE);
        document.setRecordVersion(RECORD_REVISION_2);

        EventMessageForm form = new EventMessageForm();

        formEventMessage.setDocument(document);
        formEventMessage.setForm(form);
        formEventMessage.setMessageId(MESSAGE_ID);
        return formEventMessage;
    }

    public static I9FormEventMessage createMockMessageForMigratedI9() {

        I9FormEventMessage formEventMessage = new I9FormEventMessage();

        EventMessageDocument document = new EventMessageDocument();
        document.setDocumentId(TEST_DOCUMENT_ID);
        document.setStatus(MIGRATED_I9);
        document.setRecordVersion(RECORD_REVISION_1);

        EventMessageForm form = new EventMessageForm();

        formEventMessage.setDocument(document);
        formEventMessage.setStatus(MIGRATED_I9);
        formEventMessage.setForm(form);
        return formEventMessage;
    }

    public static List<I9AuditModel> createAuditModelListForMigratedI9() {
        I9AuditModel currentAuditModel = new I9AuditModel();
        currentAuditModel.setDate(EVENT_DATE);
        currentAuditModel.setDataUpdate(true);
        currentAuditModel.setRecordRevision(RECORD_REVISION_1);
        currentAuditModel.setEventKey(MIGRATED_I9);

        return Collections.singletonList(currentAuditModel);
    }

    public static List<I9AuditModel> createAuditModelListWithoutMigratedAudit() {
        I9AuditModel currentAuditModel = new I9AuditModel();
        currentAuditModel.setDate(EVENT_DATE);
        currentAuditModel.setDataUpdate(true);
        currentAuditModel.setRecordRevision(RECORD_REVISION_1);
        currentAuditModel.setEventKey(TEST_STATUS);

        return Collections.singletonList(currentAuditModel);
    }

    public static I9FormEventMessage createNewFormMockMessage() {
        I9FormEventMessage formEventMessage = new I9FormEventMessage();

        EventMessageDocument document = new EventMessageDocument();
        document.setStatus(STATUS_NEW);
        EventMessageForm form = new EventMessageForm();

        formEventMessage.setDocument(document);
        formEventMessage.setForm(form);
        return formEventMessage;
    }
}
