package com.efx.ews.es.i9integration.i9portaleventshandler.utils;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.Assert.assertEquals;

@RunWith(JUnit4.class)
public class DateUtilsTest {

    @Test
    public void testFormatDateTimeWithOffset_checkExpectedDateTime() {
        final String date = "2020-08-20T15:59:48.014Z";
        final String expected = "08/20/2020";

        var actual = DateUtils.formatDateTimeWithOffset(date, "+02:00");
        assertEquals(expected, actual);
    }

    @Test
    public void testFormatToOffsetDate_checkExpectedDateTime() {
        final String date = "2020-08-20";
        final String expected = "08/20/2020";

        var actual = DateUtils.formatToOffsetDate(date, "+02:00");
        assertEquals(expected, actual);
    }

    @Test
    public void testFormatToOffsetDate_checkWhenOffsetIsNull() {
        final String date = "2020-08-20";
        final String expected = "08/20/2020";

        var actual = DateUtils.formatToOffsetDate(date, null);
        assertEquals(expected, actual);
    }

    @Test
    public void testFormatDateTimeWithOffset_checkWhenOffsetIsNull_withDateInput() {
        final String date = "2020-08-20";
        final String expected = "08/20/2020";

        var actual = DateUtils.formatDateTimeWithOffset(date, null);
        assertEquals(expected, actual);
    }

    @Test
    public void testFormatDateTimeWithOffset_checkWhenOffsetIsNull_withDateTimeInput() {
        var date = "2020-08-20T10:15:30+01:00";
        var expected = "08/20/2020";

        var actual = DateUtils.formatDateTimeWithOffset(date, null);
        assertThat(actual).isEqualTo(expected);
    }

    @Test
    public void testParseIsoToUsDateCheckExpectedDate() {
        final String date = "2021-01-13";
        final String expected = "01/13/2021";

        var actual = DateUtils.parseIsoToUsDate(date);
        assertEquals(expected, actual);
    }
}
