package com.efx.ews.es.i9integration.i9portaleventshandler.utils;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.PacketEvent;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.messaging.Message;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.PacketEvent.EventType;
import org.junit.jupiter.api.Test;
import reactor.test.StepVerifier;

class MessageReaderTest {

    private final static ObjectMapper converter = new ObjectMapper() ;

    @Test
    public void readPayloadPacketEventTest() throws JsonProcessingException {
        @SuppressWarnings("unchecked")
        Message<byte[]> message = mock(Message.class);
        PacketEvent restartPacketEvent = PacketEvent.createRestartEvent("packetId-1", "taskId-1", "url-1");
        when(message.getPayload()).thenReturn(converter.writeValueAsString(restartPacketEvent).getBytes());

        StepVerifier.create(MessageReader.readPayload(message, PacketEvent.class))
            .expectNext(restartPacketEvent)
            .expectComplete()
            .verify();
    }

    @Test
    public void readPayloadWithCorrectEnumValueTest() {
        @SuppressWarnings("unchecked")
        Message<byte[]> message = mock(Message.class);
        when(message.getPayload()).thenReturn("\"APPLIED_FOR_SSN\"".getBytes());

        StepVerifier.create(MessageReader.readPayload(message, EventType.class))
            .expectNext(EventType.APPLIED_FOR_SSN)
            .expectComplete()
            .verify();
    }

    @Test
    public void readPayloadWithIncorrectEnumValueTest() {
        @SuppressWarnings("unchecked")
        Message<byte[]> message = mock(Message.class);
        when(message.getPayload()).thenReturn("\"Not existing enum value\"".getBytes());

        StepVerifier.create(MessageReader.readPayload(message, EventType.class))
            .expectNext(EventType.UNKNOWN)
            .expectComplete()
            .verify();
    }

}