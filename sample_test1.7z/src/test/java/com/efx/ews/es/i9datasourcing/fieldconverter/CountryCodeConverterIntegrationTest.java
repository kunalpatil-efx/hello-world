package com.efx.ews.es.i9datasourcing.fieldconverter;

import static com.efx.ews.es.i9datasourcing.util.TestConstants.INTEGRATION_TEST;
import static org.assertj.core.api.Assertions.assertThat;

import com.efx.ews.es.i9datasourcing.provider.CachedCountryProvider;
import com.efx.ews.es.i9datasourcing.provider.CountryCodeProvider;
import com.efx.ews.es.i9datasourcing.provider.CountryCodeProviderImpl;
import com.efx.ews.es.i9integration.i9portaleventshandler.I9PortalEventsHandlerApplication;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.referenceapi.Country;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.ReferenceApiConnector;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.AbstractRemoteServiceProperties;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.AbstractRemoteServiceProperties.RemoteResource;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.ReferenceApiProperties;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@Tag(INTEGRATION_TEST)
@SpringBootTest(classes = I9PortalEventsHandlerApplication.class)
class CountryCodeConverterIntegrationTest {

    private CountryCodeProvider countryCodeProvider;

    @BeforeEach
    public void init() {
        Cache<String, Optional<Country>> cache = CacheBuilder
            .newBuilder()
            .expireAfterWrite(5, TimeUnit.MINUTES)
            .build();
        ReferenceApiConnector referenceApiConnector = new ReferenceApiConnector(getReferenceApiProperties(), 1024 *1024);
        CachedCountryProvider cachedCountryProvider = new CachedCountryProvider(referenceApiConnector, cache, getReferenceApiProperties());
        countryCodeProvider = new CountryCodeProviderImpl(cachedCountryProvider);
    }

    @Test
    public void converterShouldReturnExpectedValueObtainedFromApi() {
        //Given
        String fieldName = "country.name";
        String countryCode = "POL";
        String countryName = "Poland";
        FieldDataConverter countryCodeConverter = new CountryCodeConverter(countryCodeProvider, fieldName);
        Map<String, String> flattenedI9Form = new LinkedHashMap<>();
        flattenedI9Form.put(fieldName, countryName);

        //When
        String actualCountryCode = countryCodeConverter.convert(flattenedI9Form);

        //Then
        assertThat(actualCountryCode).isEqualTo(countryCode);
    }

    private ReferenceApiProperties getReferenceApiProperties() {
        ReferenceApiProperties referenceApiProperties = new ReferenceApiProperties();
        referenceApiProperties.setScheme("https");
        referenceApiProperties.setHost("dev-workforce-api-internal.ews.npe.east.gcp.efx");
        referenceApiProperties.setPort(443);
        referenceApiProperties.setPath("/internal/eev/reference-data/v1");
        referenceApiProperties.setI9Version("i9v102119");
        referenceApiProperties.setCountries(getRemoteResources());
        return referenceApiProperties;
    }

    private RemoteResource getRemoteResources() {
        AbstractRemoteServiceProperties.RemoteResource remoteResource = new RemoteResource();
        remoteResource.setPath("countries");
        return remoteResource;
    }
}