package com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation;

import java.io.IOException;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@SpringBootTest
@ExtendWith(SpringExtension.class)
@Slf4j
public class TaskApiSetupTestExistingTaskTypes extends TaskApiUnitTest {

    @Test
    public void checkAndRegisterTaskType_whenTaskDefinitionsAlreadyExists_thenDoNotCreateNewTaskDefinitions() throws Exception {
        setupWireMock();
        setupExistingTaskDefinitions();
        try {
            taskApiProperties.getSection2Anywhere().setEnabled(Boolean.TRUE);
            taskApiProperties.getSection2CovidFollowUp().setEnabled(Boolean.TRUE);
            taskApiProperties.getSection2CovidDocumentInspection().setEnabled(Boolean.TRUE);
            new TaskApiConnector(taskApiProperties).checkAndRegisterTaskType();

            serviceCalls.taskApi.assertCall(checkTaskFamilyExistence);
            serviceCalls.taskApi.assertCall(checkTaskGroupExistence);
            serviceCalls.taskApi.assertCall(checkSection2TaskTypeExistence);
            serviceCalls.taskApi.assertCall(checkSSNAppliedTaskTypeExistence);
            serviceCalls.taskApi.assertCall(checkSection2UploadLaterTaskTypeExistence);
            serviceCalls.taskApi.assertCall(checkReceiptUpdateSectionTwoTaskTypeExistence);
            serviceCalls.taskApi.assertCall(checkSection2AnywhereTaskTypeExistence);

            serviceCalls.taskApi.assertNotCalled(createSection2TaskType);
            serviceCalls.taskApi.assertNotCalled(createSSNAppliedTaskType);
            serviceCalls.taskApi.assertNotCalled(createSection2UploadLaterTaskType);
            serviceCalls.taskApi.assertNotCalled(createReceiptUpdateSectionTwoTaskType);
            serviceCalls.taskApi.assertNotCalled(createSection2AnywhereTaskType);
        } catch (IOException e) {
            Assert.fail(e.getMessage());
        }
    }
}
