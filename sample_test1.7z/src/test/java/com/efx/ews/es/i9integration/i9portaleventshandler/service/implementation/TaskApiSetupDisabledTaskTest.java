package com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@SpringBootTest
@ExtendWith(SpringExtension.class)
public class TaskApiSetupDisabledTaskTest extends TaskApiUnitTest {

    @Test
    void checkAndRegisterTaskType_withSection2RemoteDisabled_shouldNotCreateSection2RemoteTask() throws Exception {
        // given
        setupWireMock();
        setupNonExistingTaskDefinitions();

        // when
        taskApiProperties.getSection2Anywhere().setEnabled(Boolean.FALSE);
        taskApiProperties.getSection2CovidFollowUp().setEnabled(Boolean.FALSE);
        taskApiProperties.getSection2CovidDocumentInspection().setEnabled(Boolean.FALSE);
        new TaskApiConnector(taskApiProperties).checkAndRegisterTaskType();

        // then
        serviceCalls.taskApi.assertCall(createSection2TaskType);
        serviceCalls.taskApi.assertCall(createSSNAppliedTaskType);
        serviceCalls.taskApi.assertCall(createSection2UploadLaterTaskType);
        serviceCalls.taskApi.assertCall(schedulerDateUpdatedTaskType);
        serviceCalls.taskApi.assertNotCalled(createSection2AnywhereTaskType);
        serviceCalls.taskApi.assertNotCalled(createSection2CovidFollowUpTaskType);
        serviceCalls.taskApi.assertNotCalled(createCovidDocumentInspectionTaskType);
    }
}
