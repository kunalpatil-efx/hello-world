package com.efx.ews.es.i9integration.i9portaleventshandler;


import static org.mockito.Mockito.any;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.efx.ews.es.eev.barricade.common.model.BarricadeKeyStore;
import com.efx.ews.es.eev.barricade.common.model.PubSubEncryptedData;
import com.efx.ews.es.eev.barricade.common.service.CryptographyService;
import com.efx.ews.es.eev.barricade.common.service.PubSubEncryptionService;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.Document;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.ListA;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.ListB;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.ListC;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.SectionTwo;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.event.I9EventDocumentData;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.event.I9EventFormData;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.event.I9EventPayload;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.pubsub.Event;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.DataEngineeringTopicService;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.configuration.DataPurgeProperties;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.configuration.PubSubProperties;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.I9FormDao;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.List;
import java.util.UUID;
import org.junit.Assert;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.gcp.pubsub.support.BasicAcknowledgeablePubsubMessage;
import org.springframework.cloud.gcp.pubsub.support.GcpPubSubHeaders;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.util.concurrent.ListenableFuture;
import reactor.core.publisher.Mono;

@SpringBootTest
class DataPurgeSubscriberConfigTest {

    private final String documentId = "HFW3f5BppZMXIWB6MZGt";

    @Autowired
    private DataPurgeSubscriberConfig config;
    @Autowired
    private PubSubProperties pubSubProperties;
    @MockBean
    private I9FormDao i9FormDao;
    @MockBean
    private DataEngineeringTopicService dataEngineeringTopicService;
    @MockBean
    List<BarricadeKeyStore> barricadeKeyStores;
    @MockBean
    CryptographyService cryptographyService;
    @MockBean
    private PubSubEncryptionService pubSubEncryptionService;

    private BasicAcknowledgeablePubsubMessage ackMessage = mock(BasicAcknowledgeablePubsubMessage.class);
    private Message message = mock(Message.class);
    private MessageHeaders headers = mock(MessageHeaders.class);
    private ListenableFuture<Void> nackFuture = mock(ListenableFuture.class);
    private ListenableFuture<Void> ackFuture = mock(ListenableFuture.class);

    @BeforeEach
    public void setup() throws JsonProcessingException {
        when(message.getHeaders()).thenReturn(headers);
        when(message.getPayload()).thenReturn(mockPayload());
        when(headers.get(GcpPubSubHeaders.ORIGINAL_MESSAGE, BasicAcknowledgeablePubsubMessage.class))
                .thenReturn(ackMessage);
        when(headers.getOrDefault(any(), any())).thenReturn(UUID.randomUUID().toString());
        when(ackMessage.nack()).thenReturn(nackFuture);
        when(ackMessage.ack()).thenReturn(ackFuture);
        when(headers.get("documentId", String.class)).thenReturn(documentId);
        when(pubSubEncryptionService.encrypt(any())).thenReturn(mock(PubSubEncryptedData.class));
        mockDataPurgeProperties();
    }

    private void mockDataPurgeProperties() {
        DataPurgeProperties dataPurgeProperties = new DataPurgeProperties();
        dataPurgeProperties.setEnabled(true);
        dataPurgeProperties.setProjectId("projectId");
        dataPurgeProperties.setEventTopicId("eventTopicId");
        pubSubProperties.setDataPurge(dataPurgeProperties);
    }

    @Test
    public void testHandleMessage() {
        when(i9FormDao.updateEvent(eq(documentId), any(Event.class))).thenReturn(Mono.just("2020-08-20T00:00:00.00Z"));
        config.handleMessage(message);
        verify(dataEngineeringTopicService, atLeastOnce()).sendDataPurgeEvent(any(),any());
    }

    @Test
    public void testFilter_Disabled() {
        pubSubProperties.setEnabled(false);
        when(headers.get("status", String.class)).thenReturn("Deleted");
        Assert.assertTrue(config.shouldExecute(message));
        config.noDataPurgeEventForThisMessage(message);
        verify(ackMessage, never()).nack();
        verify(ackMessage, times(1)).ack();
    }

    @Test
    public void testFilter_DataPurge() {
        when(headers.get("status", String.class)).thenReturn("!Deleted");
        Assert.assertFalse(config.shouldExecute(message));
        config.noDataPurgeEventForThisMessage(message);
        verify(ackMessage, never()).nack();
        verify(ackMessage, times(1)).ack();
    }

    private Object mockPayload() throws JsonProcessingException {
        I9EventPayload payload = new I9EventPayload();
        I9EventDocumentData documentData = new I9EventDocumentData();
        documentData.setEmployeeFactId("27733c9f-a64a-417e-9c47-659d16a4bf8a");
        documentData.setEmployerId("27733c9f-a64a-417e-9c47-659d16a4bf8a");
        documentData.setEmployerLocationId("27733c9f-a64a-417e-9c47-659d16a4bf8a");
        documentData.setSourceRefId("27733c9f-a64a-417e-9c47-659d16a4bf8a");
        documentData.setSourceId("packet-ui");
        documentData.setStatus("Section2_Complete");
        documentData.setProjectedStartDate("2020-02-01");
        payload.setDocument(documentData);
        SectionTwo sectionTwo = new SectionTwo();
        sectionTwo.setEmployee(null);
        sectionTwo.setAdditionalInformation(null);
        sectionTwo.setEmployerRepresentative(null);
        ListA listA = new ListA();
        ListB listB =  new ListB();
        ListC listC = new ListC();
        listA.setDocumentOne( new Document());
        listA.setDocumentTwo(new Document());
        listA.setDocumentThree(new Document());
        listB.setDocumentOne(new Document());
        listC.setDocumentOne(new Document());
        sectionTwo.setListA(listA);
        sectionTwo.setListB(listB);
        sectionTwo.setListC(listC);
        sectionTwo.getListA().getDocumentOne().setUploadLater(Boolean.FALSE);
        sectionTwo.getListA().getDocumentTwo().setUploadLater(Boolean.FALSE);
        sectionTwo.getListA().getDocumentThree().setUploadLater(Boolean.FALSE);
        sectionTwo.getListB().getDocumentOne().setUploadLater(Boolean.TRUE);
        I9EventFormData formData = new I9EventFormData();
        formData.setIsMinor(Boolean.FALSE);
        formData.setSpecialPlacement(Boolean.FALSE);
        formData.setValidListBDocs(Boolean.FALSE);
        formData.setSsnApplied(Boolean.FALSE);
        formData.setSsnRefused(Boolean.FALSE);
        payload.setForm(formData);
        return new ObjectMapper().writeValueAsBytes(payload);
    }

}
