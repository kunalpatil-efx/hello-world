package com.efx.ews.es.i9integration.i9portaleventshandler.service.client;

import com.google.pubsub.v1.PubsubMessage;
import org.junit.jupiter.api.Test;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.support.GenericMessage;

import java.util.Map;

import static com.efx.ews.es.common.filter.CorrelationFilter.SESSION_ID_HEADER_NAME;
import static com.efx.ews.es.common.filter.CorrelationFilter.TRANSACTION_ID_HEADER_NAME;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class I9HeaderBuilderTest {

    @Test
    void build_With_Message() {
        Map<String, Object> headers = Map.of(TRANSACTION_ID_HEADER_NAME, "id01", SESSION_ID_HEADER_NAME, "id02");
        MessageHeaders messageHeaders = new MessageHeaders(headers);
        Message message = new GenericMessage(mock(Object.class), messageHeaders);

        Map<String, String> response = I9HeaderBuilder.build(message);

        assertThat(response)
                .containsEntry(TRANSACTION_ID_HEADER_NAME, "id01")
                .containsEntry(SESSION_ID_HEADER_NAME, "id02");

    }

    @Test
    void build_With_PubSubMessage() {
        //given
        PubsubMessage message = mock(PubsubMessage.class);
        Map<String, String> expectedHeaders = Map.of(TRANSACTION_ID_HEADER_NAME, "id01", SESSION_ID_HEADER_NAME, "id02");
        when(message.getAttributesMap()).thenReturn(expectedHeaders);

        Map<String, String> response = I9HeaderBuilder.build(message);

        //assert
        assertThat(response).containsAllEntriesOf(expectedHeaders);

    }
}