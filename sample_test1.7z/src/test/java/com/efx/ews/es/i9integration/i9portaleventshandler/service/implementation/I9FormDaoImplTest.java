package com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.pubsub.Event;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.FirestoreProperties;
import com.google.api.core.ApiFuture;
import com.google.api.core.ApiFutures;
import com.google.cloud.Timestamp;
import com.google.cloud.firestore.CollectionReference;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.WriteResult;
import org.junit.Test;
import org.springframework.util.ReflectionUtils;
import reactor.test.StepVerifier;

import java.time.Duration;
import java.time.Instant;
import java.util.Date;
import java.util.UUID;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class I9FormDaoImplTest {
    private Event event = mock(Event.class);
    private DocumentReference eventRef;
    private I9FormDaoImpl i9FormDao;
    private String i9Id = UUID.randomUUID().toString();

    public I9FormDaoImplTest() {
        Firestore firestore = mock(Firestore.class);
        i9FormDao = new I9FormDaoImpl(firestore, getProps());
        CollectionReference events = mock(CollectionReference.class);
        when(firestore.collection("events")).thenReturn(events);
        eventRef = mock(DocumentReference.class);
        when(events.document()).thenReturn(eventRef);
    }

    private FirestoreProperties getProps() {
        FirestoreProperties props = new FirestoreProperties();
        FirestoreProperties.Collections cols = new FirestoreProperties.Collections();
        cols.setAudits("audits");
        cols.setEvents("events");
        props.setCollections(cols);
        return props;
    }

    @Test
    public void testUpdateEvent() throws Exception {
        final Timestamp timestamp = Timestamp.of(Date.from(Instant.parse("2020-08-20T00:00:00.00Z")));
        final WriteResult writeResult = ReflectionUtils.accessibleConstructor(WriteResult.class, Timestamp.class).newInstance(timestamp);
        ApiFuture<WriteResult> apiFuture = ApiFutures.immediateFuture(writeResult);
        when(eventRef.set(event)).thenReturn(apiFuture);
        StepVerifier.create(i9FormDao.updateEvent(i9Id, event))
                .expectNext(timestamp.toString())
                .expectComplete()
                .verify();
    }

    @Test
    public void testFail() {
        ApiFuture<WriteResult> apiFuture = ApiFutures.immediateFailedFuture(new InterruptedException());
        when(eventRef.set(event)).thenReturn(apiFuture);
        StepVerifier.create(i9FormDao.updateEvent(i9Id, event))
                .expectError(InterruptedException.class)
                .verify(Duration.ofSeconds(1));
    }
}
