package com.efx.ews.es.i9datasourcing.processor.auditdetail.i9formhistory;

import static org.assertj.core.api.Assertions.assertThat;

import com.efx.ews.es.i9datasourcing.constant.I9Event;
import com.efx.ews.es.i9datasourcing.model.ChangeContext;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import org.junit.jupiter.api.Test;

class SectionDescriptionProviderTest {

    private final SectionDescriptionProvider sectionDescriptionProvider = new SectionDescriptionProvider();

    @Test
    void allDescriptionsTest() {
        assertThat(createDescription(I9Event.FORM_CREATED)).isEqualTo("Section 1 initiated");
        assertThat(createDescription(I9Event.SECTION_1_COMPLETE))
            .isEqualTo("Section 1 Data Entered \"field\"-\"after\"");
        assertThat(createDescription(I9Event.SECTION_2_COMPLETE))
            .isEqualTo("Section 2 Data Entered \"field\"-\"after\"");
        assertThat(createDescription(I9Event.SECTION_3_COMPLETE))
            .isEqualTo("Section 3 Data Entered \"field\"-\"after\"");
        assertThat(createDescription(I9Event.SECTION_1_AMENDED))
            .isEqualTo("Section 1 Data Updated \"field\" - from \"before\" to \"after\"");
        assertThat(createDescription(I9Event.SECTION_2_AMENDED))
            .isEqualTo("Section 2 Data Updated \"field\" - from \"before\" to \"after\"");
    }

    private String createDescription(I9Event i9Event) {
        ChangeContext changeContext = new ChangeContext("id", "ip", i9Event, "Helen", "", "",
            ZonedDateTime.now(ZoneOffset.UTC), "c4", "messageId-1");
        FieldDiff fieldDiff = new FieldDiff("field", "before", "after");
        return sectionDescriptionProvider.createDescription(fieldDiff, changeContext);
    }
}