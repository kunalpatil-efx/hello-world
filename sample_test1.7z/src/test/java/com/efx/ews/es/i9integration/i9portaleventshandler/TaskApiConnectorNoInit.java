package com.efx.ews.es.i9integration.i9portaleventshandler;

import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.TaskApiConnector;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.TaskApiProperties;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component
@Primary
@Slf4j
public class TaskApiConnectorNoInit extends TaskApiConnector {
    public TaskApiConnectorNoInit(TaskApiProperties taskApiProperties) {
        super(taskApiProperties);
    }

    @Override
    protected synchronized void checkAndRegisterTaskType() {
        log.info("Ignoring init call");
    }
}