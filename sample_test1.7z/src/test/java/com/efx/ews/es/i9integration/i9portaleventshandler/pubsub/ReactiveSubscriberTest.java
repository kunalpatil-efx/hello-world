package com.efx.ews.es.i9integration.i9portaleventshandler.pubsub;

import org.junit.jupiter.api.Test;
import org.springframework.cloud.gcp.pubsub.reactive.PubSubReactiveFactory;
import org.springframework.cloud.gcp.pubsub.support.AcknowledgeablePubsubMessage;
import reactor.core.Disposable;
import reactor.core.publisher.Flux;

import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

public class ReactiveSubscriberTest {
    @Test
    public void subscribesAndDisposesFlux() {
        // given
        ReactiveSubscription reactiveSubscription = new ReactiveSubscriptionTest();
        PubSubReactiveFactory reactiveFactory = mock(PubSubReactiveFactory.class);
        final String subscriptionName = "subscription-name";
        final Flux<AcknowledgeablePubsubMessage> messageFlux = mock(Flux.class);
        final Disposable subscription = mock(Disposable.class);
        when(messageFlux.subscribe()).thenReturn(subscription);
        when(reactiveFactory.poll(eq(subscriptionName), anyLong())).thenReturn(messageFlux);
        ReactiveSubscriber reactiveSubscriber = new ReactiveSubscriber(reactiveFactory);
        // when
        reactiveSubscriber.subscribe(reactiveSubscription, subscriptionName);
        reactiveSubscriber.dispose();
        // expect
        verify(subscription).dispose();
    }

    private static class ReactiveSubscriptionTest implements ReactiveSubscription {

        @Override
        public Flux<?> processing(Flux<AcknowledgeablePubsubMessage> flux) {
            return flux;
        }
    }
}
