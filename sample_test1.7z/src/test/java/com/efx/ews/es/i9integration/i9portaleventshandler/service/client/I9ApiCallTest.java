package com.efx.ews.es.i9integration.i9portaleventshandler.service.client;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.getRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.efx.ews.es.eev.barricade.common.model.BarricadeKeyStore;
import com.efx.ews.es.eev.barricade.common.service.CryptographyService;
import com.efx.ews.es.eev.barricade.common.service.PubSubEncryptionService;
import com.efx.ews.es.historyprovider.model.I9AuditModel;
import com.efx.ews.es.i9integration.i9portaleventshandler.ServiceCalls;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.webclient.HttpCallClient;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.I9FormApiProperties;
import com.github.tomakehurst.wiremock.matching.AnythingPattern;
import com.github.tomakehurst.wiremock.matching.RequestPatternBuilder;
import java.util.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;
import org.springframework.web.reactive.function.client.WebClientResponseException;

@SpringBootTest
public class I9ApiCallTest {

    @MockBean
    List<BarricadeKeyStore> barricadeKeyStores;
    @MockBean
    CryptographyService cryptographyService;
    @MockBean
    private PubSubEncryptionService pubSubEncryptionService;

    @Autowired
    private ServiceCalls serviceCalls;
    @Autowired
    private I9FormApiProperties i9FormApiProperties;
    @Autowired
    private HttpCallClient httpCallClient;

    @Test
    public void testGetFormDataAudits() throws Exception {
        // here be proper url
        serviceCalls.i9api
            .stubFor(get("/internal/eev/form-i9/v1/forms/audits/query").withQueryParam("i9Id", new AnythingPattern())
                .willReturn(aResponse().withHeader("Content-Type", "application/json")
                    .withBodyFile("i9Audits.json")));

        I9ApiCall i9ApiCall = new I9ApiCall(i9FormApiProperties, httpCallClient);
        ResponseEntity<List<I9AuditModel>> responseEntity = i9ApiCall.getFormDataAudits("doc123").block();
        assertNotNull(responseEntity);
        assertTrue(responseEntity.getStatusCode().is2xxSuccessful());

        final RequestPatternBuilder auditsQuery = getRequestedFor(urlEqualTo("/internal/eev/form-i9/v1/audits/query?i9Id=doc123&type=data"));
        serviceCalls.i9api.assertCall(auditsQuery);
    }

    @Test
    public void testGetFeatureReceiptUpdate() throws Exception {
        // here be proper url
        serviceCalls.i9api
            .stubFor(get("/internal/eev/form-i9/v1/forms/feature/receiptUpdate")
                .willReturn(aResponse().withHeader("Content-Type", "application/json")
                    .withBody("true")));

        I9ApiCall i9ApiCall = new I9ApiCall(i9FormApiProperties, httpCallClient);
        Boolean resp = i9ApiCall.getFeature("receiptUpdate").block();
        assertNotNull(resp);
        assertTrue(resp);

        final RequestPatternBuilder featureQuery = getRequestedFor(urlEqualTo("/internal/eev/form-i9/v1/forms/feature/receiptUpdate"));
        serviceCalls.i9api.assertCall(featureQuery);
    }

    @Test
    public void testGetFeatureReceiptUpdate_Error() throws Exception {
        // here be proper url
        serviceCalls.i9api
            .stubFor(get("/internal/eev/form-i9/v1/forms/feature/receiptUpdate")
                .willReturn(aResponse().withStatus(404).withBody("Not Found")));

        I9ApiCall i9ApiCall = new I9ApiCall(i9FormApiProperties, httpCallClient);
        Boolean resp = i9ApiCall.getFeature("receiptUpdate").block();
        assertNotNull(resp);
        assertFalse(resp);

        final RequestPatternBuilder featureQuery = getRequestedFor(urlEqualTo("/internal/eev/form-i9/v1/forms/feature/receiptUpdate"));
        serviceCalls.i9api.assertCall(featureQuery);
    }

    @Test
    public void testGetFeatureReceiptUpdate_Error2() throws Exception {
        // here be proper url
        serviceCalls.i9api
            .stubFor(get("/internal/eev/form-i9/v1/forms/feature/receiptUpdate")
                .willReturn(aResponse().withStatus(500).withBody("Not Found")));

        I9ApiCall i9ApiCall = new I9ApiCall(i9FormApiProperties, httpCallClient);
        assertThrows(WebClientResponseException.class, () -> i9ApiCall.getFeature("receiptUpdate").block());

        final RequestPatternBuilder featureQuery = getRequestedFor(urlEqualTo("/internal/eev/form-i9/v1/forms/feature/receiptUpdate"));
        serviceCalls.i9api.assertCall(featureQuery);
    }

}
