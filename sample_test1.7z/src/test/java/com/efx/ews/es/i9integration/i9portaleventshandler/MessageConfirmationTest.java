package com.efx.ews.es.i9integration.i9portaleventshandler;

import com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageConfirmation;
import com.google.common.util.concurrent.MoreExecutors;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.Mockito;
import org.springframework.cloud.gcp.pubsub.support.AcknowledgeablePubsubMessage;
import org.springframework.util.concurrent.ListenableFutureTask;

import java.util.concurrent.ExecutorService;
import java.util.stream.Stream;

import static org.mockito.Mockito.*;

@Slf4j
public class MessageConfirmationTest {
    @ParameterizedTest
    @MethodSource("acknowledgeRunnable")
    public void acknowledge(Runnable acknowledgeRunnable) {
        // given
        MessageConfirmation messageConfirmation = new MessageConfirmation();
        AcknowledgeablePubsubMessage message = setupMessage(acknowledgeRunnable);
        // when
        messageConfirmation.acknowledge(message);
        // expect
        verify(message, Mockito.times(1)).ack();
    }

    @ParameterizedTest
    @MethodSource("acknowledgeRunnable")
    public void nAcknowledge(Runnable acknowledgeRunnable) {
        // given
        MessageConfirmation messageConfirmation = new MessageConfirmation();
        AcknowledgeablePubsubMessage message = setupMessage(acknowledgeRunnable);
        // when
        messageConfirmation.nAcknowledge(message);
        // expect
        verify(message, Mockito.times(1)).nack();
    }

    private static Stream<Runnable> acknowledgeRunnable() {
        return Stream.of(
                () -> {
                },
                () -> {
                    throw new RuntimeException("something wrong happened");
                }
        );
    }

    private AcknowledgeablePubsubMessage setupMessage(Runnable acknowledgeRunnable) {
        AcknowledgeablePubsubMessage message = mock(AcknowledgeablePubsubMessage.class);
        ExecutorService executorService = MoreExecutors.newDirectExecutorService();
        final ListenableFutureTask<Void> futureTask = new ListenableFutureTask<>(acknowledgeRunnable, null);
        executorService.execute(futureTask);
        when(message.ack()).thenReturn(futureTask);
        when(message.nack()).thenReturn(futureTask);
        return message;
    }
}
