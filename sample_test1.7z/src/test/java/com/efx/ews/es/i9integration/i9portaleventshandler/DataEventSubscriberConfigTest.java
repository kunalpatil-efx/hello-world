package com.efx.ews.es.i9integration.i9portaleventshandler;

import com.efx.ews.es.eev.barricade.common.model.BarricadeKeyStore;
import com.efx.ews.es.eev.barricade.common.service.CryptographyService;
import com.efx.ews.es.eev.barricade.common.service.PubSubEncryptionService;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.event.I9EventAuditData;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.event.I9EventDocumentData;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.event.I9EventFormData;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.event.I9EventPayload;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.AuditPubSubPublisherService;
import java.util.TreeMap;

import com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageConfirmation;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.gcp.pubsub.integration.inbound.PubSubInboundChannelAdapter;
import org.springframework.cloud.gcp.pubsub.support.AcknowledgeablePubsubMessage;
import org.springframework.cloud.gcp.pubsub.support.converter.ConvertedBasicAcknowledgeablePubsubMessage;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@SpringBootTest
public class DataEventSubscriberConfigTest {

    @Autowired
    private MessagePublish messagePublish;
    @Autowired
    private TestableSubscriber testableSubscriber;
    @Autowired
    private DataEventSubscribtion dataEventSubscribtion;
    @Autowired
    private DataEventSubscriberConfig dataEventSubscriberConfig;
    @MockBean
    @Qualifier("messageConfirmation")
    private MessageConfirmation messageConfirmation;
    @MockBean
    @Qualifier("messageConfirmationForFlow")
    private MessageConfirmation messageConfirmationForFlow;
    @MockBean
    private PubSubEncryptionService pubSubEncryptionService;
    @MockBean
    List<BarricadeKeyStore> barricadeKeyStores;
    @MockBean
    CryptographyService cryptographyService;
    @MockBean
    private AuditPubSubPublisherService publisherService;

    private String eventKey;
    private Map<String, String> attributes;
    private I9EventPayload payload;

    @BeforeEach
    public void setup() {
        eventKey = UUID.randomUUID().toString();
        attributes = Map.of("status", eventKey);
        payload = getMessagePayload();
    }

    @Test
    public void testNoAudits() throws Exception {
        payload.setAudit(null);
        messagePublish.publishMessage(attributes, payload);
        testableSubscriber.publishMessage(attributes, payload);
        verify(publisherService, times(0)).sendAuditMessage(anyMap(),any(I9EventPayload.class));
        verify(messageConfirmation, times(messagePublish.flowsCount())).acknowledge(any(Message.class));
        verify(messageConfirmationForFlow, times(1)).acknowledge(any(AcknowledgeablePubsubMessage.class));
    }

    @Test
    public void testSuccess() throws Exception{
        when(publisherService.sendAuditMessage(anyMap(),any(I9EventPayload.class))).thenReturn(Mono.just(eventKey));
        messagePublish.publishMessage(attributes, payload);
        testableSubscriber.publishMessage(attributes, payload);
        verify(publisherService).sendAuditMessage(anyMap(), any(I9EventPayload.class));
        verify(messageConfirmation, times(messagePublish.flowsCount())).acknowledge(any(Message.class));
        verify(messageConfirmationForFlow, times(1)).acknowledge(any(AcknowledgeablePubsubMessage.class));
    }

    @Test
    public void testNPE() throws Exception{
        when(publisherService.sendAuditMessage(anyMap(),any(I9EventPayload.class))).thenReturn(Mono.error(new NullPointerException()));
        dataEventSubscribtion.publishMessage(attributes, payload);
        verify(publisherService).sendAuditMessage(anyMap(), any(I9EventPayload.class));
        verify(messageConfirmation).acknowledge(any(Message.class));
    }

    @Test
    public void testAIOBE() throws Exception{
        when(publisherService.sendAuditMessage(anyMap(),any(I9EventPayload.class))).thenThrow(new ArrayIndexOutOfBoundsException());
        dataEventSubscribtion.publishMessage(attributes, payload);
        verify(publisherService).sendAuditMessage(anyMap(), any(I9EventPayload.class));
        verify(messageConfirmation).nAcknowledge(any(Message.class));

    }

    private I9EventPayload getMessagePayload() {
        I9EventPayload payload = new I9EventPayload();
        payload.setDocument(new I9EventDocumentData());
        payload.setForm(new I9EventFormData());
        payload.setAudit(new I9EventAuditData());
        payload.getAudit().setEventKey(eventKey);
        return payload;
    }

    @Test
    public void testHeadersConversion() {
        // given
        Map<String, Object> receivedHeaders = Map.of(
                "sourceId", "packet-ui",
                "gcp_pubsub_acknowledgement", mock(PubSubInboundChannelAdapter.class),
                "b3", "a069ef0cf1b18746-655803e5c707d45f-1",
                "recordVersion", 1L,
                "sourceRefId", "ef297df9-9cad-4be0-90c5-9777f031bb50",
                "employeeFactId", "a294befa-2ce6-4562-8d61-d164c4f165f2",
                "documentId", "q4gbrLCpoOKmXRFbbSmO",
                "id", "08b9ecab-a750-60d4-a6fb-f683a126954c",
                "gcp_pubsub_original_message", mock(ConvertedBasicAcknowledgeablePubsubMessage.class),
                "status", "new"
        );

        // when
        Map<String, String> preparedHeaders = dataEventSubscriberConfig.prepareHeaders(new MessageHeaders(receivedHeaders));

        // then
        Map<String, Object> expectedHeaders = Map.of(
            "sourceId", "packet-ui",
            "recordVersion", "1",
            "sourceRefId", "ef297df9-9cad-4be0-90c5-9777f031bb50",
            "documentId", "q4gbrLCpoOKmXRFbbSmO",
            "status", "new",
            "system","I9"
        );
        assertEquals(new TreeMap<>(expectedHeaders), new TreeMap<>(preparedHeaders));
    }

}
