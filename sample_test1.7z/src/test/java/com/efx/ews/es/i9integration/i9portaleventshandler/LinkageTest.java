package com.efx.ews.es.i9integration.i9portaleventshandler;

import com.efx.ews.es.eev.barricade.common.model.BarricadeKeyStore;
import com.efx.ews.es.eev.barricade.common.service.CryptographyService;
import com.efx.ews.es.eev.barricade.common.service.PubSubEncryptionService;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.UpdateMetadataRequest;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.ReferenceApiService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.tomakehurst.wiremock.client.WireMock;
import com.github.tomakehurst.wiremock.matching.RequestPatternBuilder;
import lombok.SneakyThrows;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.cloud.gcp.pubsub.support.BasicAcknowledgeablePubsubMessage;
import org.springframework.cloud.gcp.pubsub.support.GcpPubSubHeaders;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import org.springframework.util.concurrent.ListenableFuture;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import static com.efx.ews.es.i9integration.i9portaleventshandler.utils.WireMockTestFile.testFileContent;
import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.equalToJson;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.okJson;
import static com.github.tomakehurst.wiremock.client.WireMock.patch;
import static com.github.tomakehurst.wiremock.client.WireMock.patchRequestedFor;
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo;
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathMatching;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@SpringBootTest
class LinkageTest {

    @Autowired
    private ServiceCalls serviceCalls;

    @Autowired
    private LinkageSubscriberConfig linkageSubscriber;

    @MockBean
    List<BarricadeKeyStore> barricadeKeyStores;
    @MockBean
    CryptographyService cryptographyService;
    @MockBean
    private PubSubEncryptionService pubSubEncryptionService;
    @MockBean
    private ReferenceApiService referenceApiService;

    private final String factIdGood = UUID.randomUUID().toString();
    private final String factIdNone = UUID.randomUUID().toString();
    private final String factIdTooMany = UUID.randomUUID().toString();
    private final String employeeId = UUID.randomUUID().toString();
    private final String linkageDate = LocalDateTime.now().toString();

    private BasicAcknowledgeablePubsubMessage ackMessage = mock(BasicAcknowledgeablePubsubMessage.class);
    private Message message = mock(Message.class);
    private ListenableFuture<Void> nackFuture = mock(ListenableFuture.class);
    private ListenableFuture<Void> ackFuture = mock(ListenableFuture.class);
    private String patchJson = String.format("{" +
            "\"employeeId\":\"%s\"," +
            "\"factIdToEmployeeIdSyncDate\":\"%s\"" +
            "}", employeeId, linkageDate);

    @SneakyThrows
    private byte[] buildEventBody(String factId) {
        LinkageSubscriberConfig.LinkageMessageBody body = new LinkageSubscriberConfig.LinkageMessageBody();
        body.setFact_id(factId);
        body.setAs_of(linkageDate);
        body.setEmployee_id(employeeId);
        return new ObjectMapper().writeValueAsBytes(body);
    }

    @BeforeEach
    public void setUpMocks() {
        MessageHeaders headers = mock(MessageHeaders.class);
        when(message.getHeaders()).thenReturn(headers);
        when(headers.get(GcpPubSubHeaders.ORIGINAL_MESSAGE, BasicAcknowledgeablePubsubMessage.class))
                .thenReturn(ackMessage);
        when(headers.getOrDefault(any(), any())).thenReturn(UUID.randomUUID().toString());
        when(ackMessage.nack()).thenReturn(nackFuture);
        when(ackMessage.ack()).thenReturn(ackFuture);
    }

    @Test
    public void testLinkage() throws Exception {
        when(message.getPayload()).thenReturn(buildEventBody(factIdGood));
        serviceCalls.i9api.stubFor(
                get("/internal/eev/form-i9/v1/forms/query?employeeFactId=" + factIdGood)
                        .willReturn(
                                okJson(testFileContent("singleI9id.json"))
                        )
        );
        serviceCalls.i9api.stubFor(
                patch(WireMock.urlEqualTo("/internal/eev/form-i9/v1/forms/uAcCCIg8S4jbQh6OzA4y/metadata"))
                        .willReturn(okJson(""))
        );
        linkageSubscriber.handleMessage(message);
        verify(ackMessage, times(0)).nack();
        verify(ackMessage, times(1)).ack();
        final RequestPatternBuilder patchRequest =
                patchRequestedFor(
                        WireMock.urlEqualTo("/internal/eev/form-i9/v1/forms/uAcCCIg8S4jbQh6OzA4y/metadata"))
                        .withRequestBody(
                                equalToJson(patchJson));
        serviceCalls.i9api.assertCall(patchRequest);
    }

    @Test
    public void testNoI9s() throws InterruptedException {
        when(message.getPayload()).thenReturn(buildEventBody(factIdNone));
        serviceCalls.i9api.stubFor(
                get("/internal/eev/form-i9/v1/forms/query?employeeFactId=" + factIdNone)
                        .willReturn(
                                okJson("[]")
                        )
        );
        linkageSubscriber.handleMessage(message);
        verify(ackMessage, times(1)).nack();
        verify(ackMessage, times(0)).ack();
        Thread.sleep(200);
        linkageSubscriber.handleMessage(message);
        verify(ackMessage, times(1)).ack();
    }

    @Test
    public void test500fromI9api() throws InterruptedException {
        when(message.getPayload()).thenReturn(buildEventBody(factIdNone));
        serviceCalls.i9api.stubFor(
                get("/internal/eev/form-i9/v1/forms/query?employeeFactId=" + factIdNone)
                        .willReturn(
                                aResponse().withStatus(500)
                        )
        );
        linkageSubscriber.handleMessage(message);
        verify(ackMessage, times(1)).ack();
    }

    @Test
    public void testManyI9s() {
        when(message.getPayload()).thenReturn(buildEventBody(factIdTooMany));
        serviceCalls.i9api.stubFor(
                get("/internal/eev/form-i9/v1/forms/query?employeeFactId=" + factIdTooMany)
                        .willReturn(
                                okJson(testFileContent("manyI9Ids.json"))
                        )
        );
        serviceCalls.i9api.stubFor(
                patch(urlPathMatching("/internal/eev/form-i9/v1/forms/[a-zA-Z0-9]*/metadata"))
                        //some sample json that looks alike
                        .willReturn(okJson(testFileContent("i9FormDataResponse.json")))
        );
        linkageSubscriber.handleMessage(message);
        verify(ackMessage, times(0)).nack();
        verify(ackMessage, times(1)).ack();
        final ObjectMapper objectMapper = new ObjectMapper();
        List.of("00XelobvWpmv4BeNNTIQ", "01UD7XqHfT67g9nnTq8f", "021gBjGLyclh8bGr8RZY")
                .stream()
                .map(i9Id -> (Runnable) () -> {
                    final UpdateMetadataRequest updateMetadataRequest = new UpdateMetadataRequest();
                    updateMetadataRequest.setEmployeeId(employeeId);
                    String expectedPayload = null;
                    try {
                        expectedPayload = objectMapper.writeValueAsString(updateMetadataRequest);
                        final RequestPatternBuilder patchRequest =
                                patchRequestedFor(
                                        urlEqualTo("/internal/eev/form-i9/v1/forms/" + i9Id + "/metadata"))
                                        .withRequestBody(
                                                equalToJson(expectedPayload, true, true));
                        serviceCalls.i9api.assertCall(patchRequest);
                    } catch (InterruptedException | JsonProcessingException ignored) {
                    }
                })
                .forEach(Runnable::run);
    }

    @Test
    public void testInvalidPayload() {
        when(message.getPayload()).thenReturn("This is invalid body.".getBytes());
        linkageSubscriber.handleMessage(message);
        verify(ackMessage, times(0)).nack();
        verify(ackMessage, times(1)).ack();
    }
}
