package com.efx.ews.es.i9integration.i9portaleventshandler.i9anywhere;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.verify;

import java.util.Map;
import java.util.UUID;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.messaging.Message;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@SpringBootTest
@ExtendWith(SpringExtension.class)
public class OtherAppointmentEventTest extends I9AnywhereUnitTest {
    @BeforeEach
    public void setup() {
        appointmentId = UUID.randomUUID().toString();
        documentId = UUID.randomUUID().toString();
        attributes = Map.of(
            "appointmentId", appointmentId,
            "i9Id", documentId,
            "event", "NoAction");
        setupWireMock();
    }

    @Test
    public void noActionMessage_acknowledgeMessage() throws Exception {
        // when
        messagePublish.publishMessageToI9AnywhereTaskFlow(attributes);

        // expected
        verify(messageConfirmation, atLeast(1)).acknowledge(any(Message.class));
        Thread.sleep(1000);
        serviceCalls.taskApi.assertNotCalled(createTaskRequest);
        serviceCalls.i9api.assertNotCalled(linkTaskRequest);

        serviceCalls.taskApi.assertNotCalled(deleteI9AnywhereTaskRequest);
        serviceCalls.taskApi.assertNotCalled(completeI9AnywhereTaskRequest);
        serviceCalls.i9api.assertNotCalled(unlinkI9AnywhereTaskRequest);
        serviceCalls.i9api.assertNotCalled(markAsCompleteI9AnywhereTaskRequest);

        serviceCalls.taskApi.assertNotCalled(deleteI9PendingTaskRequest);
        serviceCalls.taskApi.assertNotCalled(completeI9PendingTaskRequest);
        serviceCalls.i9api.assertNotCalled(unlinkI9PendingTaskRequest);
        serviceCalls.i9api.assertNotCalled(markAsCompleteI9PendingTaskRequest);
    }
}
