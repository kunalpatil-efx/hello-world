package com.efx.ews.es.i9datasourcing.provider;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.mockito.MockitoAnnotations.initMocks;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.referenceapi.Country;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.ReferenceApiConnector;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.ReferenceApiProperties;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import reactor.core.publisher.Mono;

class CachedCountryProviderTest {

    @Mock
    private ReferenceApiConnector referenceApiConnector;

    @Mock
    private ReferenceApiProperties referenceApiProperties;

    private Cache<String, Optional<Country>> cache;

    @BeforeEach
    public void init() {
        initMocks(this);
        cache = CacheBuilder.newBuilder().build();
        when(referenceApiProperties.getI9Version()).thenReturn("i9v071717");
    }

    @Test
    public void countryProviderShouldReturnExpectedValue() {
        //Given
        Country country = new Country( "Poland", "test-code", true);
        CachedCountryProvider cachedCountryProvider = new CachedCountryProvider(referenceApiConnector, cache, referenceApiProperties);
        when(referenceApiConnector.getCountries(anyString()))
            .thenReturn(Mono.just(List.of(country)));

        //When
        Country actualCountry = cachedCountryProvider.getCountryByName(country.getName());

        //Then
        assertThat(actualCountry).isEqualTo(country);
    }

    @Test
    public void countryProviderShouldGetCountriesOnlyOnceFromApi() {
        //Given
        CachedCountryProvider cachedCountryProvider = new CachedCountryProvider(referenceApiConnector, cache, referenceApiProperties);
        List<Country> countries = getCountries();

        //When
        when(referenceApiConnector.getCountries(anyString())).thenReturn(Mono.just(countries));

        //Execute
        cachedCountryProvider.init();
        cachedCountryProvider.getCountryByName("Poland");
        cachedCountryProvider.getCountryByName("Finland");

        //Then
        verify(referenceApiConnector).getCountries("i9v071717");
    }

    @Test
    public void countryProviderThrowsExceptionWhenCodeIsNotFound() {
        //Given
        String countryName = "not-existing-name";
        CachedCountryProvider cachedCountryProvider = new CachedCountryProvider(referenceApiConnector, cache, referenceApiProperties);
        List<Country> countries = getCountries();
        when(referenceApiConnector.getCountries(anyString())).thenReturn(Mono.just(countries));
        //Verify
        assertThatThrownBy(() -> cachedCountryProvider.getCountryByName(countryName))
            .isInstanceOf(IllegalArgumentException.class)
            .hasMessage("There is no country with name: not-existing-name");
    }

    @Test
    public void getCountryWithNullData() {
        CachedCountryProvider cachedCountryProvider = new CachedCountryProvider(referenceApiConnector, cache, referenceApiProperties);
        when(referenceApiConnector.getCountries(anyString())).thenReturn(Mono.empty());
        assertThatThrownBy(() -> cachedCountryProvider.getCountryByName("Afghanistan"))
            .isInstanceOf(IllegalArgumentException.class)
            .hasMessage("There is no country with name: Afghanistan");
    }

    private List<Country> getCountries() {
        return List.of(
            new Country("Poland", "test-code", true),
            new Country("Finland", "123-abc", false),
            new Country("Russia", "aaa-bbb-123", true)
        );
    }
}