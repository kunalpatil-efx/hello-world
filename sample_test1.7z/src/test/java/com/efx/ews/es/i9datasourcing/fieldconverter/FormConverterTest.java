package com.efx.ews.es.i9datasourcing.fieldconverter;

import static com.efx.ews.es.i9datasourcing.constant.I9Event.SECTION_2_AMENDED;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static reactor.core.publisher.Mono.just;

import com.efx.ews.es.dto.LocationDto;
import com.efx.ews.es.i9datasourcing.I9FormHistoryProcessorQuickMockImpl;
import com.efx.ews.es.i9datasourcing.flattener.I9FormHistoryFlattener;
import com.efx.ews.es.i9datasourcing.formatter.DefaultTemporalFormatter;
import com.efx.ews.es.i9datasourcing.formatter.TemporalFormatter;
import com.efx.ews.es.i9datasourcing.model.ChangeContext;
import com.efx.ews.es.i9datasourcing.provider.CountryCodeProvider;
import com.efx.ews.es.i9datasourcing.provider.LocationDataProvider;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.I9Form;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.Map;
import java.util.UUID;
import lombok.SneakyThrows;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class FormConverterTest {

    private final TemporalFormatter temporalFormatter = new DefaultTemporalFormatter();
    private final String LOCATION_NAME = "locationName";
    private I9FormHistoryFlattener i9FormHistoryFlattener;
    private FormConverter converter;

    @Mock
    private LocationDataProvider locationDataProvider;
    @Mock
    private CountryCodeProvider countryCodeProvider;

    @BeforeEach
    public void setUp() {

        when(locationDataProvider.getLocation(any(UUID.class), any(UUID.class)))
            .thenReturn(just(new LocationDto().setLocationName(LOCATION_NAME)));

        var i9FormFieldConverterConfigProvider = new I9FormFieldConverterConfigProviderImpl(
            locationDataProvider, countryCodeProvider, temporalFormatter);

        i9FormHistoryFlattener = new I9FormHistoryFlattener();
        converter = new FormConverterImpl(i9FormFieldConverterConfigProvider);
    }

    @Test
    @SneakyThrows
    public void shouldConvertI9Form() {
        I9Form i9Form = new I9FormHistoryProcessorQuickMockImpl().simulateReceivedSection2Creation();
        Map<String, String> i9FlattenedForm = i9FormHistoryFlattener.process(i9Form);
        ChangeContext changeContext = new ChangeContext(
            "i9FormId",
            "90.0.1.1.201",
            SECTION_2_AMENDED,
            "user1",
            "",
            "",
            ZonedDateTime.now(ZoneOffset.UTC),
            "c4",
            "messageId-1");

        when(countryCodeProvider.getCountryCode("USA")).thenReturn("US");

        Map<String, String> convertedI9Form = converter.convertForm(i9FlattenedForm, changeContext);
        assertThat(convertedI9Form).isNotEmpty();
        assertThat(convertedI9Form.get("GROUP_CODE")).isEqualTo("");
        assertThat(convertedI9Form.get("LOCATION_CODE")).isEqualTo("07a8edf4-bbdb-4c75-a3cd-fe66e1277702");
        assertThat(convertedI9Form.get("LOCATION_NAME")).isEqualTo(LOCATION_NAME);
        assertThat(convertedI9Form.get("SECTION_ONE.EMPLOYEE_INFO.SSN")).isEqualTo("888888888");
        assertThat(convertedI9Form.get("SECTION_ONE.EMPLOYEE_INFO.FIRST_NAME")).isEqualTo("Joe");
        assertThat(convertedI9Form.get("SECTION_ONE.EMPLOYEE_INFO.MI")).isEqualTo("J");
        assertThat(convertedI9Form.get("SECTION_ONE.EMPLOYEE_INFO.OTHER_NAMES_USED")).isEqualTo("James");
        assertThat(convertedI9Form.get("SECTION_ONE.EMPLOYEE_INFO.DATE_OF_BIRTH")).isEqualTo("2001-11-20");
        assertThat(convertedI9Form.get("SECTION_ONE.EMPLOYEE_INFO.E_MAIL_ADDRESS")).isEqualTo("test@test.com");
        assertThat(convertedI9Form.get("SECTION_ONE.EMPLOYEE_INFO.TELEPHONE_NUMBER")).isEqualTo("4888888888");
        assertThat(convertedI9Form.get("SECTION_ONE.ATTESTATION.IMMIGRATION_STATUS"))
            .isEqualTo("A Lawful Permanent Resident");
        assertThat(convertedI9Form.get("SECTION_ONE.ATTESTATION.ALIEN_NUMBER")).isEqualTo("te5454sss");
        assertThat(convertedI9Form.get("SECTION_ONE.ATTESTATION.WORK_EXPIRATION_DATE"))
            .isEqualTo("2022-08-09");
        assertThat(convertedI9Form.get("SECTION_ONE.ATTESTATION.I94_NUMBER")).isEqualTo("656gg565");
        assertThat(convertedI9Form.get("SECTION_ONE.ATTESTATION.SECTION_1_FOREIGN_PASSPORT_NUMBER"))
            .isEqualTo("fgd54453fd");
        assertThat(convertedI9Form.get("SECTION_ONE.ATTESTATION.SECTION_1_FOREIGN_PASSPORT_COUNTRY"))
            .isEqualTo("USA");
        assertThat(convertedI9Form.get("SECTION_ONE.ATTESTATION.SECTION_1_FOREIGN_PASSPORT_COUNTRY_CODE"))
            .isEqualTo("US");
        assertThat(convertedI9Form.get("SECTION_ONE.EMPLOYEE_INFO.SSN_APPLIED_FOR")).isEqualTo("false");
        assertThat(convertedI9Form.get("SECTION_ONE.EMPLOYEE_INFO.SSN_NOT_SUPPLIED")).isEqualTo("false");
        assertThat(convertedI9Form.get("SECTION_ONE.EMPLOYEE_INFO.ADDRESS_LINE_1")).isEqualTo("Krakow Opolska 114");
        assertThat(convertedI9Form.get("SECTION_ONE.EMPLOYEE_INFO.ADDRESS_LINE_2")).isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_ONE.EMPLOYEE_INFO.APARTMENT_NUMBER"))
            .isEqualTo("3");
        assertThat(convertedI9Form.get("SECTION_ONE.EMPLOYEE_INFO.CITY")).isEqualTo("Krakow");
        assertThat(convertedI9Form.get("SECTION_ONE.EMPLOYEE_INFO.STATE_PROVINCE")).isEqualTo("CA");
        assertThat(convertedI9Form.get("SECTION_ONE.EMPLOYEE_INFO.ZIP_POSTAL_CODE")).isEqualTo("12345");
        assertThat(convertedI9Form.get("SECTION_ONE.EMPLOYEE_INFO.I9_ENTRY_DATE"))
            .isEqualTo("2020-08-10 16:57:57.817");
        assertThat(convertedI9Form.get("SECTION_ONE.EMPLOYEE_INFO.SIGNATURE.SIGNATURE_DATE"))
            .isEqualTo("2020-12-12");
        assertThat(convertedI9Form.get("SECTION_ONE.EMPLOYEE_INFO.SIGNATURE.SIGNATURE_METHOD"))
            .isEqualTo("E-signature");
        assertThat(convertedI9Form.get("SECTION_ONE.PREPARERS.PREPARER_ONE.NAME")).isEqualTo("Joe Smith");
        assertThat(convertedI9Form.get("SECTION_ONE.PREPARERS.PREPARER_ONE.ADDRESS_1"))
            .isEqualTo("Opolska, 12");
        assertThat(convertedI9Form.get("SECTION_ONE.PREPARERS.PREPARER_ONE.ADDRESS_2"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_ONE.PREPARERS.PREPARER_ONE.CITY")).isEqualTo("Krakow");
        assertThat(convertedI9Form.get("SECTION_ONE.PREPARERS.PREPARER_ONE.STATE_PROVINCE"))
            .isEqualTo("CA");
        assertThat(convertedI9Form.get("SECTION_ONE.PREPARERS.PREPARER_ONE.ZIP_POSTAL_CODE"))
            .isEqualTo("40-781");
        assertThat(convertedI9Form.get("SECTION_ONE.PREPARERS.PREPARER_ONE.SIGNATURE.SIGNATURE_DATE"))
            .isEqualTo("2019-12-31");
        assertThat(convertedI9Form.get("SECTION_ONE.PREPARERS.PREPARER_ONE.SIGNATURE.SIGNATURE_METHOD"))
            .isEqualTo("E-signature");
        assertThat(convertedI9Form.get("SECTION_ONE.PREPARERS.PREPARER_TWO.NAME")).isEqualTo("Sam Michael");
        assertThat(convertedI9Form.get("SECTION_ONE.PREPARERS.PREPARER_TWO.ADDRESS_1"))
            .isEqualTo("Chorzowska, 12");
        assertThat(convertedI9Form.get("SECTION_ONE.PREPARERS.PREPARER_TWO.ADDRESS_2"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_ONE.PREPARERS.PREPARER_TWO.CITY")).isEqualTo("Katowice");
        assertThat(convertedI9Form.get("SECTION_ONE.PREPARERS.PREPARER_TWO.STATE_PROVINCE"))
            .isEqualTo("NN");
        assertThat(convertedI9Form.get("SECTION_ONE.PREPARERS.PREPARER_TWO.ZIP_POSTAL_CODE"))
            .isEqualTo("40-101");
        assertThat(convertedI9Form.get("SECTION_ONE.PREPARERS.PREPARER_TWO.SIGNATURE.SIGNATURE_DATE"))
            .isEqualTo("2019-12-31");
        assertThat(convertedI9Form.get("SECTION_ONE.PREPARERS.PREPARER_TWO.SIGNATURE.SIGNATURE_METHOD"))
            .isEqualTo("E-signature");
        assertThat(convertedI9Form.get("SECTION_ONE.PREPARERS.PREPARER_THREE.NAME")).isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_ONE.PREPARERS.PREPARER_THREE.ADDRESS_1"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_ONE.PREPARERS.PREPARER_THREE.ADDRESS_2"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_ONE.PREPARERS.PREPARER_THREE.CITY")).isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_ONE.PREPARERS.PREPARER_THREE.STATE_PROVINCE"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_ONE.PREPARERS.PREPARER_THREE.ZIP_POSTAL_CODE"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_ONE.PREPARERS.PREPARER_THREE.SIGNATURE.SIGNATURE_DATE"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_ONE.PREPARERS.PREPARER_THREE.SIGNATURE.SIGNATURE_METHOD"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_TWO.RECEIPT_CODE")).isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_TWO.EMPLOYEE_TERMED_BEFORE_COMPLETING_I_9"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_A.DOC_ONE.TITLE"))
            .isEqualTo("U.S. Passport or U.S. Passport Card");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_A.DOC_ONE.FIELD_1_TITLE"))
            .isEqualTo("Document Number");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_A.DOC_ONE.FIELD_1_VALUE"))
            .isEqualTo("961467055");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_A.DOC_ONE.FIELD_2_TITLE"))
            .isEqualTo("Expiration Date");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_A.DOC_ONE.FIELD_2_VALUE"))
            .isEqualTo("2050-10-23");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_A.DOC_ONE.FIELD_3_TITLE"))
            .isEqualTo("Is Receipt");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_A.DOC_ONE.FIELD_3_VALUE"))
            .isEqualTo("false");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_A.DOC_ONE.FIELD_4_TITLE"))
            .isEqualTo("Issuing Authority");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_A.DOC_ONE.FIELD_4_VALUE"))
            .isEqualTo("U.S. Department of State");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_A.DOC_ONE.FIELD_5_TITLE"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_A.DOC_ONE.FIELD_5_VALUE"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_A.DOC_ONE.FIELD_6_TITLE"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_A.DOC_ONE.FIELD_6_VALUE"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_A.DOC_ONE.FIELD_7_TITLE"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_A.DOC_ONE.FIELD_7_VALUE"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_A.DOC_ONE.FIELD_8_TITLE"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_A.DOC_ONE.FIELD_8_VALUE"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_B.DOC_ONE.TITLE")).isEqualTo("card");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_B.DOC_ONE.FIELD_1_TITLE"))
            .isEqualTo("Document Number");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_B.DOC_ONE.FIELD_1_VALUE"))
            .isEqualTo("34263545");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_B.DOC_ONE.FIELD_2_TITLE"))
            .isEqualTo("Expiration Date");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_B.DOC_ONE.FIELD_2_VALUE"))
            .isEqualTo("2030-09-09");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_B.DOC_ONE.FIELD_3_TITLE"))
            .isEqualTo("Is Receipt");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_B.DOC_ONE.FIELD_3_VALUE"))
            .isEqualTo("false");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_B.DOC_ONE.FIELD_4_TITLE"))
            .isEqualTo("Issuing Authority");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_B.DOC_ONE.FIELD_4_VALUE"))
            .isEqualTo("U.S. Department of State");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_B.DOC_ONE.FIELD_5_TITLE"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_B.DOC_ONE.FIELD_5_VALUE"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_B.DOC_ONE.FIELD_6_TITLE"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_B.DOC_ONE.FIELD_6_VALUE"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_B.DOC_ONE.FIELD_7_TITLE"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_B.DOC_ONE.FIELD_7_VALUE"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_B.DOC_ONE.FIELD_8_TITLE"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_B.DOC_ONE.FIELD_8_VALUE"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_C.DOC_ONE.TITLE"))
            .isEqualTo("residence card");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_C.DOC_ONE.FIELD_1_TITLE"))
            .isEqualTo("Document Number");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_C.DOC_ONE.FIELD_1_VALUE"))
            .isEqualTo("242341234");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_C.DOC_ONE.FIELD_2_TITLE"))
            .isEqualTo("Expiration Date");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_C.DOC_ONE.FIELD_2_VALUE"))
            .isEqualTo("2028-09-09");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_C.DOC_ONE.FIELD_3_TITLE"))
            .isEqualTo("Is Receipt");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_C.DOC_ONE.FIELD_3_VALUE"))
            .isEqualTo("false");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_C.DOC_ONE.FIELD_4_TITLE"))
            .isEqualTo("Issuing Authority");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_C.DOC_ONE.FIELD_4_VALUE"))
            .isEqualTo("U.S. Department of State");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_C.DOC_ONE.FIELD_5_TITLE"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_C.DOC_ONE.FIELD_5_VALUE"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_C.DOC_ONE.FIELD_6_TITLE"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_C.DOC_ONE.FIELD_6_VALUE"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_C.DOC_ONE.FIELD_7_TITLE"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_C.DOC_ONE.FIELD_7_VALUE"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_C.DOC_ONE.FIELD_8_TITLE"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_TWO.LIST_C.DOC_ONE.FIELD_8_VALUE"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_TWO.HIRE_DATE")).isEqualTo("2020-04-23");
        assertThat(convertedI9Form.get("SECTION_TWO.TWN_HIRE_DATE")).isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_TWO.TERMINATION_DATE")).isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_TWO.EXPECTED_PURGE_DATE")).isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_TWO.ACTIVE_I9")).isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_TWO.EMPLOYER_ID")).isEqualTo("07a8edf4-bbdb-4c75-a3cd-fe66e1277702");
        assertThat(convertedI9Form.get("SECTION_TWO.EMPLOYER_REPRESENTATIVE.EMPLOYER_NAME"))
            .isEqualTo("Joe Black");
        assertThat(convertedI9Form.get("SECTION_TWO.EMPLOYER_REPRESENTATIVE.EMPLOYER_TITLE"))
            .isEqualTo("string");
        assertThat(convertedI9Form.get("SECTION_TWO.ORGANIZATION.EMPLOYER_BUSINESS_NAME"))
            .isEqualTo("Traffic Balance");
        assertThat(convertedI9Form.get("SECTION_TWO.ORGANIZATION.EMPLOYER_ADDRESS_1"))
            .isEqualTo("Krakow Opolska 114");
        assertThat(convertedI9Form.get("SECTION_TWO.ORGANIZATION.EMPLOYER_ADDRESS_2"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_TWO.ORGANIZATION.EMPLOYER_CITY")).isEqualTo("Krakow");
        assertThat(convertedI9Form.get("SECTION_TWO.ORGANIZATION.EMPLOYER_STATE")).isEqualTo("CA");
        assertThat(convertedI9Form.get("SECTION_TWO.ORGANIZATION.EMPLOYER_ZIP")).isEqualTo("12345");
        assertThat(convertedI9Form.get("SECTION_TWO.EMPLOYER_SIGNATURE_DATE")).isEqualTo("2020-04-23");
        assertThat(convertedI9Form.get("SECTION_TWO.EMPLOYER_SIGNATURE_METHOD")).isEqualTo("E-signature");
        assertThat(convertedI9Form.get("SECTION_TWO.ORGANIZATION.AGENT")).isEqualTo("Traffic Balance");
        assertThat(convertedI9Form.get("SECTION_THREE.REVERIFICATION_DUE_DATE")).isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_THREE.REV_DUE_DATE_REASON")).isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_THREE.RECEIPT_DUE_DATE")).isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_THREE.RECEIPT_DUE_REASON")).isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_THREE.REVERIFICATION_SSN")).isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_THREE.REVERIFICATION_FIRST_NAME")).isEqualTo("John");
        assertThat(convertedI9Form.get("SECTION_THREE.REVERIFICATION_LAST_NAME")).isEqualTo("Doe");
        assertThat(convertedI9Form.get("SECTION_THREE.REVERIFICATION_MI")).isEqualTo("M");
        assertThat(convertedI9Form.get("SECTION_THREE.REVERIFICATION_REHIRE_DATE")).isEqualTo("2020-05-03");
        assertThat(convertedI9Form.get("SECTION_THREE.EMPLOYER_SIGNATURE.REVERIFICATION_SIGNATURE_NAME"))
            .isEqualTo("John Q Doe");
        assertThat(convertedI9Form.get("SECTION_THREE.EMPLOYER_SIGNATURE.REVERIFICATION_SIGNATURE_DATE"))
            .isEqualTo("2019-12-31");
        assertThat(convertedI9Form.get("SECTION_THREE.EMPLOYER_SIGNATURE.REVERIFICATION_SIGNATURE_METHOD"))
            .isEqualTo("E-signature");
        assertThat(convertedI9Form.get("SECTION_THREE.REVERIFICATION_DOC.TITLE"))
            .isEqualTo("Passport");
        assertThat(convertedI9Form.get("SECTION_THREE.REVERIFICATION_DOC.FIELD_1_TITLE"))
            .isEqualTo("Document Number");
        assertThat(convertedI9Form.get("SECTION_THREE.REVERIFICATION_DOC.FIELD_1_VALUE"))
            .isEqualTo("6526354");
        assertThat(convertedI9Form.get("SECTION_THREE.REVERIFICATION_DOC.FIELD_2_TITLE"))
            .isEqualTo("Expiration Date");
        assertThat(convertedI9Form.get("SECTION_THREE.REVERIFICATION_DOC.FIELD_2_VALUE"))
            .isEqualTo("2025-09-08");
        assertThat(convertedI9Form.get("SECTION_THREE.REVERIFICATION_DOC.FIELD_3_TITLE"))
            .isEqualTo("Is Receipt");
        assertThat(convertedI9Form.get("SECTION_THREE.REVERIFICATION_DOC.FIELD_3_VALUE"))
            .isEqualTo("false");
        assertThat(convertedI9Form.get("SECTION_THREE.REVERIFICATION_DOC.FIELD_4_TITLE"))
            .isEqualTo("Issuing Authority");
        assertThat(convertedI9Form.get("SECTION_THREE.REVERIFICATION_DOC.FIELD_4_VALUE"))
            .isEqualTo("U.S. Department of State");
        assertThat(convertedI9Form.get("SECTION_THREE.REVERIFICATION_DOC.FIELD_5_TITLE"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_THREE.REVERIFICATION_DOC.FIELD_5_VALUE"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_THREE.REVERIFICATION_DOC.FIELD_6_TITLE"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_THREE.REVERIFICATION_DOC.FIELD_6_VALUE"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_THREE.REVERIFICATION_DOC.FIELD_7_TITLE"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_THREE.REVERIFICATION_DOC.FIELD_7_VALUE"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_THREE.REVERIFICATION_DOC.FIELD_8_TITLE"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("SECTION_THREE.REVERIFICATION_DOC.FIELD_8_VALUE"))
            .isEqualTo("");
        assertThat(convertedI9Form.get("MEDIA_SOURCE")).isEqualTo("WEB");
        assertThat(convertedI9Form.get("ENTRY_TYPE")).isEqualTo("electronic");
        assertThat(convertedI9Form.get("LOAD_DATE")).isEqualTo("");
        assertThat(convertedI9Form.get("I_9_TYPE")).isEqualTo("");
        assertThat(convertedI9Form.get("EDIT_DATA_DATE")).isNotBlank();
        assertThat(convertedI9Form.get("EDIT_DATA_USER")).isEqualTo("user1");
        assertThat(convertedI9Form.get("EDIT_DATA_DESCRIPTION")).isEqualTo(SECTION_2_AMENDED.getEventKey());
        assertThat(convertedI9Form.get("CONVERSION_ERROR_FIELD")).isEqualTo("");
        assertThat(convertedI9Form.get("HIRE_CODE")).isEqualTo("");
        assertThat(convertedI9Form.get("VISA_TYPE")).isEqualTo("");
        assertThat(convertedI9Form.get("EMPLOYEE_ID")).isEqualTo("");
        assertThat(convertedI9Form.get("FICA_EXEMPT")).isEqualTo("");
        assertThat(convertedI9Form.get("IPADDRESS")).isEqualTo("90.0.1.1.201");
        assertThat(convertedI9Form.get("TERMINATE_DATE_SOURCE")).isBlank();
        assertThat(convertedI9Form.get("SECTION_ONE.EMPLOYEE_INFO.LAST_NAME")).isEqualTo("Black");
        assertThat(convertedI9Form.get("MODIFICATION_TS")).isBlank();
        assertThat(convertedI9Form.get("I9_EMPLOYER_ID")).isEqualTo("c4");
    }
}
