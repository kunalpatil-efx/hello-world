package com.efx.ews.es.everifydatasourcing.integration;

import static com.efx.ews.es.i9datasourcing.util.TestConstants.INTEGRATION_TEST;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.clearInvocations;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.skyscreamer.jsonassert.JSONAssert.assertEquals;
import static org.skyscreamer.jsonassert.JSONCompareMode.NON_EXTENSIBLE;

import com.efx.ews.es.dto.LocationDto;
import com.efx.ews.es.eev.barricade.common.model.BarricadeKeyStore;
import com.efx.ews.es.eev.barricade.common.model.PubSubEncryptedData;
import com.efx.ews.es.eev.barricade.common.service.CryptographyService;
import com.efx.ews.es.eev.barricade.common.service.PubSubEncryptionService;
import com.efx.ews.es.everifydatasourcing.EVerifyCaseConverter;
import com.efx.ews.es.everifydatasourcing.model.TestCase;
import com.efx.ews.es.i9datasourcing.config.TestConfig;
import com.efx.ews.es.i9datasourcing.provider.LocationDataProvider;
import com.efx.ews.es.i9datasourcing.util.JsonReaderUtil;
import com.efx.ews.es.i9datasourcing.util.ReaderUtil;
import com.efx.ews.es.i9datasourcing.util.WriterUtil;
import com.efx.ews.es.i9integration.i9portaleventshandler.I9PortalEventsHandlerApplication;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.pubsub.PubSubEvent;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.GooglePublisherService;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.json.JSONObject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.MethodSource;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.mock.mockito.SpyBean;
import reactor.core.publisher.Mono;

@SpringBootTest(classes = {I9PortalEventsHandlerApplication.class, TestConfig.class})
@Slf4j
@Tag(INTEGRATION_TEST)
class EVerifyCaseConverterIntegrationTest {

    @Autowired
    private EVerifyCaseConverter eVerifyCaseConverter;

    @SpyBean
    private GooglePublisherService googlePublisherService;

    @MockBean
    private LocationDataProvider locationDataProvider;

    @MockBean
    List<BarricadeKeyStore> barricadeKeyStores;

    @MockBean
    CryptographyService cryptographyService;

    @MockBean
    PubSubEncryptionService encryptionService;

    @Captor
    ArgumentCaptor<PubSubEvent> pubSubEventCaptor;

    private static final int JSON_INDENT_SPACES = 2;

    @BeforeEach
    void beforeEach() {
        when(locationDataProvider.getLocation(any(UUID.class), any(UUID.class)))
            .thenReturn(Mono.just(new LocationDto().setLocationName("Manteo Office")));

        when(encryptionService.encrypt(any()))
            .thenAnswer(invocation -> {
                byte[] payload = invocation.getArgument(0);
                return new PubSubEncryptedData(new String(payload), "encryptionMetadata", "gcsBucketPath");
            });
    }

    @SneakyThrows
    @ParameterizedTest
    @MethodSource
    void itShouldProcessEVerifyCases(TestCase testCase) {
        //GIVEN
        log.info("Test Case: {}", testCase);

        // EXECUTE
        eVerifyCaseConverter.convert(testCase.getEverifyCase(), testCase.getChangeContext());

        //ASSERT
        verify(googlePublisherService, atLeastOnce()).sendEvent(pubSubEventCaptor.capture());
        List<JSONObject> depEventPayloads = pubSubEventCaptor.getAllValues().stream()
            .map(PubSubEvent::getEventPayload)
            .map(JsonReaderUtil::parseJSONObject)
            .collect(Collectors.toList());

        //WRITE RESULT TO FILE
        var eVerifyEvent = depEventPayloads.get(0).toString(JSON_INDENT_SPACES);
        WriterUtil.writeActualEVerifyEvent(testCase.getName(), eVerifyEvent);

        clearInvocations(googlePublisherService);

        assertThat(depEventPayloads).hasSize(1);
        assertEquals(testCase.getExpectedEvent(), depEventPayloads.get(0), NON_EXTENSIBLE);
    }

    private static Stream<TestCase> itShouldProcessEVerifyCases() {
        return ReaderUtil.listEVerifyTestCases()
            .map(TestCase::create);
    }
}
