package com.efx.ews.es.i9integration.i9portaleventshandler;

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse;
import static com.github.tomakehurst.wiremock.client.WireMock.anyUrl;
import static com.github.tomakehurst.wiremock.client.WireMock.get;
import static com.github.tomakehurst.wiremock.client.WireMock.post;
import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.options;

import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.AbstractRemoteServiceProperties;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.DocumentApiProperties;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.EmployerConfigApiProperties;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.EmployerPersonApiProperties;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.I9FormApiProperties;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.I9PartnerApiProperties;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.PacketApiProperties;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.PdfGeneratorProperties;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.ReferenceApiProperties;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.TaskApiProperties;
import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.client.MappingBuilder;
import com.github.tomakehurst.wiremock.common.Slf4jNotifier;
import com.github.tomakehurst.wiremock.matching.RequestPattern;
import com.github.tomakehurst.wiremock.matching.RequestPatternBuilder;
import java.time.Duration;
import java.util.HashSet;
import java.util.Set;

import lombok.EqualsAndHashCode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

@Component
@Scope("prototype")
public class ServiceCalls implements AutoCloseable {
    public RestEndpoint i9api;
    private RestEndpoint portalApi;
    public RestEndpoint pdfGenerator;
    public RestEndpoint documentApi;
    public RestEndpoint taskApi;
    public RestEndpoint employerConfigApi;
    public RestEndpoint employerPersonApi;
    public RestEndpoint referenceApi;
    public RestEndpoint partnerApi;

    @Autowired
    private I9FormApiProperties i9FormApiProperties;

    @Autowired
    private I9PartnerApiProperties i9PartnerApiProperties;

    public ServiceCalls(
            I9FormApiProperties i9FormApiProperties,
            PacketApiProperties packetApiProperties,
            PdfGeneratorProperties pdfGeneratorProperties,
            DocumentApiProperties documentApiProperties,
            TaskApiProperties taskApiProperties,
            EmployerConfigApiProperties employerConfigApiProperties,
            EmployerPersonApiProperties employerPersonApiProperties,
            ReferenceApiProperties referenceApiProperties,
            I9PartnerApiProperties i9PartnerApiProperties,
            @Value("${requestsTrace.verbose:false}") boolean verboseNotifications) {
        taskApi = new RestEndpoint(taskApiProperties,
                verboseNotifications,
                taskApiProperties.postGenerate(),
                get(anyUrl()).willReturn(aResponse().withStatus(200)));
        i9api = new RestEndpoint(i9FormApiProperties,
                verboseNotifications,
                i9FormApiProperties.getFormDataUrlBuilder(),
                get(anyUrl()).willReturn(aResponse().withStatus(200)));
        portalApi = new RestEndpoint(
                packetApiProperties,
                verboseNotifications,
                packetApiProperties.getPacketUrlBuilder(),
                post(anyUrl()).willReturn(aResponse().withStatus(201)));
        pdfGenerator = new RestEndpoint(
                pdfGeneratorProperties,
                verboseNotifications,
                pdfGeneratorProperties.postGenerate(),
                get(anyUrl()).willReturn(aResponse().withStatus(200)));
        documentApi = new RestEndpoint(
                documentApiProperties,
                verboseNotifications,
                documentApiProperties.postUploadDocument(),
                post(anyUrl()).willReturn(aResponse().withStatus(201)));
        employerConfigApi = new RestEndpoint(
                employerConfigApiProperties,
                verboseNotifications,
                employerConfigApiProperties.getEmployerConfigBuilder(),
                get(anyUrl()).willReturn(aResponse().withStatus(200)));
        employerPersonApi = new RestEndpoint(
                employerPersonApiProperties,
                verboseNotifications,
                employerPersonApiProperties.postGenerate(),
                post(anyUrl()).willReturn(aResponse().withStatus(201)));
        referenceApi = new RestEndpoint(
                referenceApiProperties,
                verboseNotifications,
                getUriBuilder(referenceApiProperties, referenceApiProperties.getCountries(), null),
                get(anyUrl()).willReturn(aResponse().withStatus(200)
                    .withHeader("Content-Type", "application/json")
                    .withBodyFile("countriesResponse.json")));
        partnerApi = new RestEndpoint(
                i9PartnerApiProperties,
                verboseNotifications,
                i9PartnerApiProperties.getAppointmentStatusUrlBuilder(),
                get(anyUrl()).willReturn(aResponse().withStatus(200))
        );
    }

    @Override
    public void close() {
        i9api.close();
        portalApi.close();
        pdfGenerator.close();
        documentApi.close();
        taskApi.close();
        employerConfigApi.close();
        referenceApi.close();
    }

    @EqualsAndHashCode
    private static class RequestInfo {
        private String method;
        private String url;

        public RequestInfo(String method, String url) {
            this.method = method;
            this.url = url;
        }

        @SuppressWarnings("unused")
        public String getMethod() {
            return method.toUpperCase();
        }

        @SuppressWarnings("unused")
        public String getUrl() {
            return url.toLowerCase();
        }
    }

    public static class RestEndpoint implements AutoCloseable {
        private static final Duration timeout = Duration.ofSeconds(15);
        private final WireMockServer server;
        private final Set<RequestInfo> receivedRequestsUrls = new HashSet<>();
        private final UriComponentsBuilder expectedUrlBuilder;

        public RestEndpoint(AbstractRemoteServiceProperties remoteServiceProperties, boolean verboseNotifications,
                            UriComponentsBuilder expectedUrlBuilder, MappingBuilder stubbedMapping) {
            this.expectedUrlBuilder = expectedUrlBuilder;
            server = new WireMockServer(
                    options().dynamicPort()
                            .notifier(new Slf4jNotifier(verboseNotifications)));
            server.stubFor(stubbedMapping);
            server.addMockServiceRequestListener((request, response) -> {
                final String url = skipQueryParameters(request.getUrl());
                final String method = request.getMethod().getName();
                receivedRequestsUrls.add(new RequestInfo(method, url));
            });
            server.start();
            remoteServiceProperties.setPort(server.port());
        }

        private String skipQueryParameters(String url) {
            final UriComponents requestUrl = UriComponentsBuilder.fromUriString(url).build();
            return UriComponentsBuilder.newInstance()
                    .scheme(requestUrl.getScheme())
                    .host(requestUrl.getHost())
                    .path(requestUrl.getPath())
                    .build()
                    .toUriString();
        }

        public void stubFor(MappingBuilder mappingBuilder) {
            server.stubFor(mappingBuilder);
        }

        public void assertCall(RequestPatternBuilder requestPatternBuilder, Object... parameters) throws InterruptedException {
            RequestInfo expectedRequest = getExpectedRequestToReceive(requestPatternBuilder, parameters);
            waitForRequest(expectedRequest);
            server.verify(requestPatternBuilder);
        }

        public void assertNotCalled(RequestPatternBuilder requestPatternBuilder) {
            server.verify(0, requestPatternBuilder);
        }

        private RequestInfo getExpectedRequestToReceive(RequestPatternBuilder requestPatternBuilder, Object[] parameters) {
            final RequestPattern requestPattern = requestPatternBuilder.build();
            String expectedUrl;
            String method = requestPattern.getMethod().getName();
            expectedUrl = requestPattern.getUrl() != null
                    ? requestPattern.getUrl()
                    : expectedUrlBuilder.buildAndExpand(parameters).toUri().getPath();
            return new RequestInfo(method, expectedUrl);
        }

        private void waitForRequest(RequestInfo expectedRequest) throws InterruptedException {
            final int timeSlice = 100;
            for (int i = 0; i < timeSlice; i++) {
                if (receivedRequestsUrls.contains(expectedRequest)) {
                    break;
                }
                Thread.sleep(timeout.toMillis() / timeSlice);
            }
        }

        @Override
        public void close() {
            server.shutdownServer();
        }
    }

    private UriComponentsBuilder getUriBuilder(AbstractRemoteServiceProperties properties,
        AbstractRemoteServiceProperties.RemoteResource resource, String id) {
        return UriComponentsBuilder.newInstance()
            .scheme(properties.getScheme())
            .host(properties.getHost())
            .port(properties.getPort())
            .path(properties.getPath())
            .pathSegment(resource.getPath());
    }

}
