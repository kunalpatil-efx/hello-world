package com.efx.ews.es.i9datasourcing.processor;

import com.efx.ews.es.i9datasourcing.constant.DepEventName;
import com.efx.ews.es.i9datasourcing.dep.api.DepEventPayloadSender;
import com.efx.ews.es.i9datasourcing.dep.model.DepEventPayload;
import com.efx.ews.es.i9datasourcing.dep.model.DepEventPayloadField;
import com.efx.ews.es.i9datasourcing.formatter.TemporalFormatter;
import com.efx.ews.es.i9datasourcing.model.ChangeContext;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.BooleanUtils;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class AuditSummarySingleI9FormHistoryProcessor implements SingleI9FormHistoryProcessor {

    private static final String MODIFICATION_TS = "MODIFICATION_TS";
    private static final String I9_ID = "I9_ID";

    private static final Set<String> booleanFieldsPaths = Set.of(
        "FICA_EXEMPT",
        "SECTION_ONE.EMPLOYEE_INFO.SSN_APPLIED_FOR",
        "SECTION_ONE.EMPLOYEE_INFO.SSN_NOT_SUPPLIED"
    );

    private final DepEventPayloadSender depPubSubSender;
    private final TemporalFormatter temporalFormatter;

    @Override
    public void process(Map<String, String> convertedI9FormBefore, Map<String, String> convertedI9FormAfter,
        ChangeContext changeContext) {
        DepEventPayload depEventPayload = createDepEventPayload(convertedI9FormAfter, changeContext);
        depPubSubSender.publish(depEventPayload, changeContext, DepEventName.AUDIT_SUMMARY_I9);
    }

    private DepEventPayload createDepEventPayload(Map<String, String> convertedI9formAfter,
        ChangeContext changeContext) {
        List<DepEventPayloadField> fields = convertedI9formAfter
            .entrySet()
            .stream()
            .map(fieldEntry -> new DepEventPayloadField(fieldEntry.getKey(),
                convertToObject(fieldEntry.getKey(), fieldEntry.getValue())))
            .collect(Collectors.toList());

        fields.add(new DepEventPayloadField(I9_ID, changeContext.getI9FormId()));

        fields.add(new DepEventPayloadField(MODIFICATION_TS,
            temporalFormatter.formatDateTime(changeContext.getSourceEventDateTime())));
        return new DepEventPayload(fields);
    }

    private Object convertToObject(String fieldName, String fieldValue) {
        if (isBoolean(fieldName)) {
            return BooleanUtils.toBooleanObject(fieldValue);
        }
        return fieldValue;
    }

    private boolean isBoolean(String fieldName) {
        return booleanFieldsPaths.contains(fieldName);
    }
}
