package com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.pubsub.PubSubEvent;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.GooglePublisherService;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.configuration.PubSubProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.cloud.pubsub.v1.Publisher;
import com.google.protobuf.ByteString;
import com.google.pubsub.v1.PubsubMessage;
import com.google.pubsub.v1.TopicName;
import java.io.IOException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.gcp.pubsub.core.publisher.PubSubPublisherTemplate;
import org.springframework.cloud.gcp.pubsub.support.DefaultPublisherFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.concurrent.ListenableFuture;
import org.springframework.util.concurrent.ListenableFutureCallback;
import reactor.core.publisher.Mono;

import java.util.concurrent.ExecutionException;

@Service
@Slf4j
public class GooglePublisherServiceImpl implements GooglePublisherService {

    private final PubSubProperties pubSubProperties;
    private final PubSubPublisherTemplate pubSubTemplate;
    private final ObjectMapper mapper = new ObjectMapper();

    public GooglePublisherServiceImpl(PubSubProperties pubSubProperties) {
        this.pubSubProperties = pubSubProperties;
        this.pubSubTemplate = new PubSubPublisherTemplate(new DefaultPublisherFactory(pubSubProperties::getProjectId));
    }

    @Override
    public void sendEvent(PubSubEvent event) throws ExecutionException, InterruptedException, JsonProcessingException {
        pubSubTemplate.publish(pubSubProperties.getEventTopicId(), mapper.writeValueAsString(event)).get();
    }

    @Override
    public Mono<String> sendEventAsync(PubSubEvent pubSubEvent) {
        final ListenableFuture<String> publishFuture =
                pubSubTemplate.publish(pubSubProperties.getEventTopicId(), serializePubSubEvent(pubSubEvent));
        return Mono.create(
                voidMonoSink -> publishFuture.addCallback(new ListenableFutureCallback<>() {
                    @Override
                    public void onFailure(Throwable throwable) {
                        voidMonoSink.error(throwable);
                    }

                    @Override
                    public void onSuccess(String messageId) {
                        voidMonoSink.success(messageId);
                    }
                }));
    }
    @Override
    public <T> void sendDataPurgeEvent(PubSubEvent pubSubEvent) {
        sendMessage(pubSubProperties.getDataPurge().getEventTopicId(), serializePubSubEvent(pubSubEvent),
            pubSubProperties.getDataPurge().getProjectId());
    }

    private void sendMessage(String topicId,String message, String projectId) {
        Publisher publisher = null;
        log.info("Sending DataPurge message to project");
        TopicName topicName = TopicName.of(projectId, topicId);
        try {
            log.info("Building Publisher for topic name {}", topicName);
            publisher = Publisher.newBuilder(topicName).build();
        } catch (IOException e) {
            log.error("An Exception occurred while building publisher", e);
        }
        PubsubMessage pubsubMessage = PubsubMessage.newBuilder().setData(ByteString.copyFromUtf8(message)).build();
        if (pubsubMessage != null) {
            log.info("Now publishing DataPurge message to topic {}", topicId);
            publisher.publish(pubsubMessage);
        }
    }

    private String serializePubSubEvent(PubSubEvent event) {
        try {
            return mapper.writeValueAsString(event);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }
}
