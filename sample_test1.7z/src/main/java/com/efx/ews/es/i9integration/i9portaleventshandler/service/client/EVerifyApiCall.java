package com.efx.ews.es.i9integration.i9portaleventshandler.service.client;

import com.efx.ews.es.everifydatasourcing.model.EVerifyCase;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.logger.MdcReactorLogger;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.webclient.HttpCallClient;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.EVerifyApiProperties;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.net.URI;

import static java.lang.String.format;

@Component
@RequiredArgsConstructor
@Slf4j
public class EVerifyApiCall {

    private final EVerifyApiProperties eVerifyApiProperties;
    private final HttpCallClient httpCallClient;

    public Mono<EVerifyCase> getCase(String id) {
        URI uri = eVerifyApiProperties.getCaseDataBuilder().buildAndExpand(id).toUri();
        return httpCallClient.doCall(webClient ->
            webClient
                .get()
                .uri(uri)
                .retrieve()
                .bodyToMono(EVerifyCase.class)
                .doOnEach(MdcReactorLogger.logOnNext(evCase -> log.info("EVerifyCase retrieved successfully caseId: {}, {}", id, evCase)))
                .doOnEach(MdcReactorLogger.logOnError(ex -> log.error(format("Failed retrieving EVerifyCase, caseId: %s", id), ex)))
        );
    }
}
