package com.efx.ews.es.i9integration.i9portaleventshandler.model.i9;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.hateoas.RepresentationModel;

import java.util.Base64;
import java.util.Optional;

@Data
@EqualsAndHashCode(callSuper = true)
public class SignatureData extends RepresentationModel<SignatureData> {

    private Method method;
    private String name;
    private String date;
    private String imageType;
    private String value;
    private String signatureRef;
    private String owner;
    private String offset;
    @JsonIgnore
    private byte[] imageData;

    public enum Method {
        IMAGE, TEXT, LINK
    }

    @JsonIgnore
    public Optional<String> getEncodedSignature() {
        return Optional.ofNullable(getImageData()).map(data -> Base64.getEncoder().encodeToString(data));
    }

    @JsonIgnore
    public Optional<String> getSignatureAsText() {
        if (getMethod() == SignatureData.Method.TEXT) {
            return Optional.ofNullable(getValue());
        }
        return Optional.empty();
    }
}
