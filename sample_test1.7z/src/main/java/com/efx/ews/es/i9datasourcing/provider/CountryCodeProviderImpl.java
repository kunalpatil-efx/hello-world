package com.efx.ews.es.i9datasourcing.provider;

import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Profile("!mocked")
@Component
@RequiredArgsConstructor
public class CountryCodeProviderImpl implements CountryCodeProvider {

    private final CachedCountryProvider cachedCountryProvider;

    @Override
    public String getCountryCode(String countryName) {
        return cachedCountryProvider.getCountryByName(countryName).getCode();
    }
}
