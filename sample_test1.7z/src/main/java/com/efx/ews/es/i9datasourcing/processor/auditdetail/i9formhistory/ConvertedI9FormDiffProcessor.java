package com.efx.ews.es.i9datasourcing.processor.auditdetail.i9formhistory;

import com.google.common.collect.MapDifference;
import com.google.common.collect.MapDifference.ValueDifference;
import com.google.common.collect.Maps;
import java.util.Map;
import java.util.Objects;
import org.springframework.stereotype.Component;

@Component
class ConvertedI9FormDiffProcessor {

    public static final String EMPTY_FIELD_VALUE = "";

    public void process(Map<String, String> convertedI9FormBefore, Map<String, String> convertedI9FormAfter,
        I9FormSingleChangeProcessor i9FormSingleChangeProcessor) {
        if (Objects.nonNull(convertedI9FormBefore)) {
            processDiffBetweenBeforeAfter(convertedI9FormBefore, convertedI9FormAfter, i9FormSingleChangeProcessor);
        } else {
            processAllAfterFieldsAsNew(convertedI9FormAfter, i9FormSingleChangeProcessor);
        }
    }

    private void processDiffBetweenBeforeAfter(Map<String, String> convertedI9FormBefore,
        Map<String, String> convertedI9FormAfter,
        I9FormSingleChangeProcessor i9FormSingleChangeProcessor) {
        MapDifference<String, String> mapDifference = Maps.difference(
            convertedI9FormBefore, convertedI9FormAfter);

        Map<String, ValueDifference<String>> differentValues = mapDifference.entriesDiffering();
        differentValues.forEach((fieldName, valueDifference) ->
            processDiff(i9FormSingleChangeProcessor,
                fieldName, valueDifference.leftValue(), valueDifference.rightValue()));

        Map<String, String> onlyNewValues = mapDifference.entriesOnlyOnRight();
        onlyNewValues.forEach((fieldName, valueDifference) ->
            processDiff(i9FormSingleChangeProcessor,
                fieldName, EMPTY_FIELD_VALUE, valueDifference));

        Map<String, String> onlyOldValues = mapDifference.entriesOnlyOnLeft();
        onlyOldValues.forEach((fieldName, valueDifference) ->
            processDiff(i9FormSingleChangeProcessor,
                fieldName, valueDifference, EMPTY_FIELD_VALUE));
    }

    private void processAllAfterFieldsAsNew(Map<String, String> convertedI9FormAfter,
        I9FormSingleChangeProcessor i9FormSingleChangeProcessor) {
        convertedI9FormAfter.forEach((fieldName, fieldValue) ->
            processDiff(i9FormSingleChangeProcessor,
                fieldName, EMPTY_FIELD_VALUE, fieldValue));
    }

    private void processDiff(I9FormSingleChangeProcessor i9FormSingleChangeProcessor,
        String fieldName, String valueBefore, String valueAfter) {
        FieldDiff fieldDiff = new FieldDiff(ReportField.getTargetLabel(fieldName), valueBefore, valueAfter);
        i9FormSingleChangeProcessor.publishDepEventForFieldChange(fieldDiff);
    }
}
