package com.efx.ews.es.i9datasourcing.dep.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class DepEventPayloadField {

    private String name;
    private Object value;
}
