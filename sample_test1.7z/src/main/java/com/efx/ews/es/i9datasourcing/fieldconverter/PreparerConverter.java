package com.efx.ews.es.i9datasourcing.fieldconverter;

import com.efx.ews.es.i9datasourcing.fieldconverter.Utils.Constants;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;

class PreparerConverter extends IndexedFieldNameConverter {

    protected PreparerConverter(String fieldNameWithoutIndex, int preparerIndex) {
        super(fieldNameWithoutIndex, "preparers", preparerIndex);
    }

    @Override
    public String convert(Map<String, String> flattenedI9Form) {
        String indexedFieldName = super.convert(flattenedI9Form);

        return StringUtils.isNotBlank(indexedFieldName)
            ? flattenedI9Form.get(indexedFieldName) : Constants.DEFAULT_EMPTY_VALUE;
    }

    protected String getIndexedFieldName(Map<String, String> flattenedI9Form) {
        return super.convert(flattenedI9Form);
    }
}