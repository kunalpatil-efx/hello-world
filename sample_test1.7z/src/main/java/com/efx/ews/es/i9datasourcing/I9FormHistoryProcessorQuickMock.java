package com.efx.ews.es.i9datasourcing;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.I9Form;
import java.io.IOException;

public interface I9FormHistoryProcessorQuickMock {

    I9Form simulateReceivedSection1Creation() throws IOException;

    I9Form simulateReceivedSection2Creation() throws IOException;
}
