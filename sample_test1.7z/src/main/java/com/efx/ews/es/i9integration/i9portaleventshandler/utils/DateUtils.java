package com.efx.ews.es.i9integration.i9portaleventshandler.utils;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import static java.util.Objects.nonNull;

@Slf4j
@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class DateUtils {
    private static final String DATE_FORMAT = "MM/dd/yyyy";
    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private static final DateTimeFormatter US_DATE_FORMAT = DateTimeFormatter.ofPattern(DATE_FORMAT);

    public static String formatToOffsetDate(String date, String offset) {
        try {
            LocalDate ld = LocalDate.parse(date, DATE_TIME_FORMATTER);
            LocalDateTime localDateTime = ld.atStartOfDay();
            OffsetDateTime offsetDateTime = localDateTime.atOffset(ZoneOffset.UTC);
            OffsetDateTime offsetTime = offsetDateTime.withOffsetSameInstant(ZoneOffset.of(offset));
            return offsetTime.toLocalDateTime().format(US_DATE_FORMAT);
        } catch (Exception ex) {
            log.warn("error thrown while formatting date to offset", ex);
            return parseIsoToUsDate(date);
        }
    }

    public static String formatDateTimeWithOffset(String date, String offset) {
        try {
            LocalDateTime localDateTime = LocalDateTime.parse(date, DateTimeFormatter.ISO_DATE_TIME);
            OffsetDateTime offsetDateTime = localDateTime.atOffset(ZoneOffset.UTC);

            OffsetDateTime offsetTime;
            if (nonNull(offset)) {
                offsetTime = offsetDateTime.withOffsetSameInstant(ZoneOffset.of(offset));
            } else {
                log.warn("The offset value is null then using ZoneOffset.UTC");
                offsetTime = offsetDateTime.withOffsetSameInstant(ZoneOffset.UTC);
            }

            return offsetTime.toLocalDateTime().format(US_DATE_FORMAT);
        } catch (Exception ex) {
            log.warn("error thrown while formatting date to offset", ex);
            return parseIsoToUsDate(date);
        }
    }

    public static String parseIsoToUsDate(String date) {
        Date dateObject;
        SimpleDateFormat originalDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String formattedDate = null;
        try {
            if (date != null) {
                dateObject = originalDateFormat.parse(date);
                SimpleDateFormat formatter = new SimpleDateFormat(DATE_FORMAT);
                formattedDate = formatter.format(dateObject);
            }
        } catch (ParseException e) {
            log.debug("Returning the original date since the " +
                    "conversion using ISO-format date: {} to MM/dd/yyy format has failed", date);
            return date;
        }
        return formattedDate;
    }

}
