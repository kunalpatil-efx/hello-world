package com.efx.ews.es.i9integration.i9portaleventshandler.model.billing;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class BillingEvent {
    private String transactionId;
    private String transactionStartDateTime;
    private String transactionEndDateTime;
    private String fulfillmentId;
    private String fulfillmentSystemName;
    private BillingEventProduct product;
    private BillingEventEmployee employee;
    private BillingEventEmployer employer;
    private BillingEventMetadata metadata;
    private String packetId;
    private String i9Id;
}
