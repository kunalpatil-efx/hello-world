package com.efx.ews.es.i9datasourcing.fieldconverter;

import java.util.Map;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
final class Utils {

    static boolean containsKeyWithNotBlankValue(Map<String, String> flattenedI9Form, String key) {
        String value = flattenedI9Form.get(key);
        return !StringUtils.isBlank(value);
    }

    static boolean containsKeyWithTrueValue(Map<String, String> flattenedI9Form, String key) {
        String value = flattenedI9Form.get(key);
        return Boolean.parseBoolean(value);
    }

    @NoArgsConstructor(access = AccessLevel.PRIVATE)
    static class Constants {

        static final String DEFAULT_EMPTY_VALUE = StringUtils.EMPTY;
    }
}
