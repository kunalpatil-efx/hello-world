package com.efx.ews.es.i9datasourcing.fieldconverter;

import com.efx.ews.es.i9datasourcing.model.ChangeContext;
import java.util.Map;

public interface FormConverter {

    Map<String, String> convertForm(Map<String, String> flattenedForm, ChangeContext changeContext);
}
