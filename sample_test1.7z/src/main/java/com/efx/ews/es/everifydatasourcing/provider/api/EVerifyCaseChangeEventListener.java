package com.efx.ews.es.everifydatasourcing.provider.api;

import com.efx.ews.es.everifydatasourcing.model.pubsub.EventMessage;

public interface EVerifyCaseChangeEventListener {

    void onEventReceived(EventMessage eVerifyEventMessage);
}
