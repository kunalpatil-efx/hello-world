package com.efx.ews.es.i9integration.i9portaleventshandler.service.properties;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;

@Data
@Component
@ConfigurationProperties(prefix = "employer-config-api")
@EqualsAndHashCode(callSuper = true)
public class EmployerConfigApiProperties extends AbstractRemoteServiceProperties {

    RemoteResource employer;
    RemoteResource location;

    public UriComponentsBuilder getEmployerConfigBuilder() {
        return getBaseUriComponentsBuilder()
                .pathSegment(getEmployer().getPath())
                .pathSegment("{employerId}");
    }

    public UriComponentsBuilder getLocationUrlBuilder() {
        return getEmployerConfigBuilder()
                .pathSegment(getLocation().getPath())
                .pathSegment("{locationId}");
    }
}
