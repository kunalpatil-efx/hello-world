package com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.event.I9EventPayload;
import reactor.core.publisher.Mono;

import java.util.Map;

public interface AuditPubSubPublisherService {
    Mono<String> sendAuditMessage(Map<String, String> headers, I9EventPayload payload);
}
