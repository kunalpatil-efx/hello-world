package com.efx.ews.es.i9datasourcing.fieldconverter;

import java.util.Map;

@FunctionalInterface
public interface FieldDataConverter {

    String convert(Map<String, String> flattenedI9Form);
}
