package com.efx.ews.es.everifydatasourcing.model.pubsub;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
public class EventMessage {

    @JsonIgnore
    @Setter
    private String messageId;
    private String i9FormId;
    private String everifyCaseId;
    private String specVersion;
    private String sessionId;
    private String transactionId;
    private String applicationId;
    private String applicationName;
    private String groupId;
    private String subGroupId;
    private String sourceId;
    private String sourceName;
    private String eventTime;
    private String componentName;
    private String contributor;
    private CaseAction action;
    private String dataType;
    private String eventType;
    private EventData eventData;

}
