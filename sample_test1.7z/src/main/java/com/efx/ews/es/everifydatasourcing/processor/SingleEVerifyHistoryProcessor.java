package com.efx.ews.es.everifydatasourcing.processor;

import com.efx.ews.es.i9datasourcing.model.ChangeContext;
import java.util.Map;

public interface SingleEVerifyHistoryProcessor {

    void process(Map<String, String> convertedEVerifyCase, ChangeContext changeContext);
}
