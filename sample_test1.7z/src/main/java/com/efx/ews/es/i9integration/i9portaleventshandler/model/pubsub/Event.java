package com.efx.ews.es.i9integration.i9portaleventshandler.model.pubsub;

import com.google.cloud.firestore.annotation.PropertyName;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;

@Data
@NoArgsConstructor
public class Event {
    private String eventModelVersion;
    private String sourceSystemName;
    private String sourceSystemReferenceId;
    private String createCaseUTC;
    private String topicId;
    private String status;
    private String envelopeType;
    private String envelopeTypeModelVersion;
    private String documentId;

    private ArrayList<PubSubEvent> pubsubEvents = new ArrayList<>();

    @PropertyName("event_model_version")
    public String getEventModelVersion() {
        return eventModelVersion;
    }

    @PropertyName("event_model_version")
    public void setEventModelVersion(String eventModelVersion) {
        this.eventModelVersion = eventModelVersion;
    }

    @PropertyName("source_system_name")
    public String getSourceSystemName() {
        return sourceSystemName;
    }

    @PropertyName("source_system_name")
    public void setSourceSystemName(String sourceSystemName) {
        this.sourceSystemName = sourceSystemName;
    }

    @PropertyName("source_system_reference_id")
    public String getSourceSystemReferenceId() {
        return sourceSystemReferenceId;
    }

    @PropertyName("source_system_reference_id")
    public void setSourceSystemReferenceId(String sourceSystemReferenceId) {
        this.sourceSystemReferenceId = sourceSystemReferenceId;
    }

    @PropertyName("create_date_utc")
    public String getCreateCaseUTC() {
        return createCaseUTC;
    }

    @PropertyName("create_date_utc")
    public void setCreateCaseUTC(String createCaseUTC) {
        this.createCaseUTC = createCaseUTC;
    }

    @PropertyName("topic_id")
    public String getTopicId() {
        return topicId;
    }

    @PropertyName("topic_id")
    public void setTopicId(String topicId) {
        this.topicId = topicId;
    }

    @PropertyName("status")
    public String getStatus() {
        return status;
    }

    @PropertyName("status")
    public void setStatus(String status) {
        this.status = status;
    }


    @PropertyName("envelope_type")
    public String getEnvelopeType() {
        return envelopeType;
    }

    @PropertyName("envelope_type")
    public void setEnvelopeType(String envelopeType) {
        this.envelopeType = envelopeType;
    }

    @PropertyName("envelope_type_model_version")
    public String getEnvelopeTypeModelVersion() {
        return envelopeTypeModelVersion;
    }

    @PropertyName("envelope_type_model_version")
    public void setEnvelopeTypeModelVersion(String envelopeTypeModelVersion) {
        this.envelopeTypeModelVersion = envelopeTypeModelVersion;
    }

    @PropertyName("document_id")
    public String getDocumentId() {
        return documentId;
    }

    @PropertyName("document_id")
    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }

    public ArrayList<PubSubEvent> getPubsubEvents() {
        return pubsubEvents;
    }

    public void setPubsubEvents(ArrayList<PubSubEvent> pubsubEvents) {
        this.pubsubEvents = pubsubEvents;
    }
}
