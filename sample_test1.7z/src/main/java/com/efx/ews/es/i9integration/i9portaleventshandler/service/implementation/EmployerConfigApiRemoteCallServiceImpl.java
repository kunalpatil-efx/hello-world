package com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.employer.config.EmployerConfigResponse;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.EmployerConfigApiRemoteCallService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Slf4j
@Service
public class EmployerConfigApiRemoteCallServiceImpl implements EmployerConfigApiRemoteCallService {

    private EmployerConfigApiConnector employerConfigApiConnector;

    public EmployerConfigApiRemoteCallServiceImpl(EmployerConfigApiConnector employerConfigApiConnector) {
        this.employerConfigApiConnector = employerConfigApiConnector;
    }

    public Mono<EmployerConfigResponse> getEmployerInfo(String employerId) {
        log.info("Getting Employer info by employer id: {}",employerId);
        return this.employerConfigApiConnector.getEmployerInfo(employerId);
    }
}
