package com.efx.ews.es.everifydatasourcing.provider.infrastructure;

import com.efx.ews.es.everifydatasourcing.model.EVerifyCase;
import com.efx.ews.es.everifydatasourcing.model.pubsub.EventMessage;
import com.efx.ews.es.everifydatasourcing.provider.api.EVerifyCaseChangeEventListener;
import com.efx.ews.es.everifydatasourcing.provider.api.EVerifyCaseChangeProvider;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.EVerifyApiCall;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.I9HeaderBuilder;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.pubsub.v1.PubsubMessage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gcp.pubsub.core.subscriber.PubSubSubscriberTemplate;
import org.springframework.cloud.gcp.pubsub.support.BasicAcknowledgeablePubsubMessage;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;
import reactor.util.context.Context;

import java.util.Map;
import java.util.Objects;
import java.util.UUID;

import static com.efx.ews.es.common.filter.CorrelationFilter.TRANSACTION_ID_HEADER_NAME;
import static java.lang.String.format;

@Slf4j
@Service
@RequiredArgsConstructor
@Profile("!mocked")
public class EVerifyCaseChangeProviderAdapter implements EVerifyCaseChangeProvider {

    private final EVerifyApiCall eVerifyApiCall;

    private final ObjectMapper objectMapper;

    private final PubSubSubscriberTemplate pubSubSubscriberTemplate;

    @Value("${subscription.everify}")
    private String subscription;

    private Map<String, String> headers;

    @Override
    public void registerEventListener(EVerifyCaseChangeEventListener eventListener) {
        if (Objects.isNull(eventListener)) {
            return;
        }
        pubSubSubscriberTemplate.subscribe(subscription,
            basicAcknowledgeablePubsubMessage -> handleEVerifyCaseMessage(eventListener,
                basicAcknowledgeablePubsubMessage));
    }

    private void handleEVerifyCaseMessage(EVerifyCaseChangeEventListener eventListener,
        BasicAcknowledgeablePubsubMessage basicAcknowledgeablePubsubMessage) {

        PubsubMessage pubsubMessage = basicAcknowledgeablePubsubMessage.getPubsubMessage();
        String messageDataString = pubsubMessage.getData().toStringUtf8();

        String correlationId = UUID.randomUUID().toString();
        MDC.put(TRANSACTION_ID_HEADER_NAME, correlationId);

        log.info("EVerify message received id: {} headers: {} payload: {} correlationId: {}",
            pubsubMessage.getMessageId(), pubsubMessage.getAttributesMap(), messageDataString,
            correlationId);

        headers = I9HeaderBuilder.build(pubsubMessage);

        try {
            EventMessage eventMessage = objectMapper
                .readValue(messageDataString, EventMessage.class);
            eventMessage.setMessageId(pubsubMessage.getMessageId());
            eventListener.onEventReceived(eventMessage);
            basicAcknowledgeablePubsubMessage.ack();
        } catch (JsonProcessingException e) {
            log.error(format("Message data can't be parsed. Message Id: %s, Message Attributes: %s, Message Data: %s",
                pubsubMessage.getMessageId(), pubsubMessage.getAttributesMap(), messageDataString), e);
            basicAcknowledgeablePubsubMessage.nack();
        } catch (Exception e) {
            log.error(
                format("Error occurred during processing. Message Id: %s, Message Attributes: %s, Message Data: %s",
                    pubsubMessage.getMessageId(), pubsubMessage.getAttributesMap(), messageDataString), e);
            basicAcknowledgeablePubsubMessage.nack();
        } finally {
            MDC.remove(TRANSACTION_ID_HEADER_NAME);
        }
    }

    @Override
    public EVerifyCase getCaseById(String caseId) {
        return eVerifyApiCall.getCase(caseId)
                .subscriberContext(Context.of(headers))
                .block();
    }
}
