package com.efx.ews.es.i9integration.i9portaleventshandler.service.client.webclient;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.Map;

import static com.efx.ews.es.common.filter.CorrelationFilter.SESSION_ID_HEADER_NAME;
import static com.efx.ews.es.common.filter.CorrelationFilter.TRANSACTION_ID_HEADER_NAME;
import static java.util.Objects.requireNonNull;
import static net.logstash.logback.encoder.org.apache.commons.lang3.StringUtils.EMPTY;

@Slf4j
@Component
public class WebClientProvider {
    public Mono<WebClient> get() {
        return Mono.just(WebClient.builder())
                .flatMap(
                        builder ->
                                Mono.subscriberContext()
                                        .map(ctx -> Map.of(
                                                TRANSACTION_ID_HEADER_NAME, requireNonNull(ctx.getOrDefault(TRANSACTION_ID_HEADER_NAME, EMPTY)),
                                                SESSION_ID_HEADER_NAME, requireNonNull(ctx.getOrDefault(SESSION_ID_HEADER_NAME, EMPTY))))
                                        .doOnSuccess(headers -> log.info("WebClientProvider: Headers: {}", headers))
                                        .map(headers -> builder.defaultHeaders(httpHeaders -> headers.forEach(httpHeaders::set)))
                                        .map(o -> builder))
                .map(WebClient.Builder::build);
    }
}
