package com.efx.ews.es.everifydatasourcing.processor;

import com.efx.ews.es.i9datasourcing.constant.DepEventName;
import com.efx.ews.es.i9datasourcing.dep.api.DepEventPayloadSender;
import com.efx.ews.es.i9datasourcing.dep.model.DepEventPayload;
import com.efx.ews.es.i9datasourcing.dep.model.DepEventPayloadField;
import com.efx.ews.es.i9datasourcing.formatter.TemporalFormatter;
import com.efx.ews.es.i9datasourcing.model.ChangeContext;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class AuditSummaryEVerifyProcessor implements SingleEVerifyHistoryProcessor {

    public static final String MODIFICATION_TS = "MODIFICATION_TS";
    public static final String I9_ID = "I9_ID";

    private final DepEventPayloadSender depPubSubSender;
    private final TemporalFormatter temporalFormatter;

    @Override
    public void process(Map<String, String> convertedEVerifyCase, ChangeContext changeContext) {

        DepEventPayload depEventPayload = createDepEventPayload(convertedEVerifyCase, changeContext);
        depPubSubSender.publish(depEventPayload, changeContext, DepEventName.AUDIT_SUMMARY_EVERIFY);
    }

    private DepEventPayload createDepEventPayload(Map<String, String> flattenedEVerifyCase,
        ChangeContext changeContext) {
        List<DepEventPayloadField> fields = new ArrayList<>(flattenedEVerifyCase.size());
        DepEventPayload payload = new DepEventPayload(fields);
        flattenedEVerifyCase.forEach((name, value) -> fields.add(new DepEventPayloadField(name, value)));

        fields.add(new DepEventPayloadField(I9_ID, changeContext.getI9FormId()));

        fields.add(new DepEventPayloadField(MODIFICATION_TS,
            temporalFormatter.formatDateTime(changeContext.getSourceEventDateTime())));
        return payload;
    }
}
