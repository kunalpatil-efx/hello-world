package com.efx.ews.es.i9datasourcing;

import static java.util.Collections.emptyMap;

import com.efx.ews.es.i9datasourcing.fieldconverter.FormConverterImpl;
import com.efx.ews.es.i9datasourcing.flattener.Flattener;
import com.efx.ews.es.i9datasourcing.model.ChangeContext;
import com.efx.ews.es.i9datasourcing.processor.AuditSummarySingleI9FormHistoryProcessor;
import com.efx.ews.es.i9datasourcing.processor.auditdetail.i9formhistory.AuditDetailI9FormHistoryProcessor;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.I9Form;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class I9FormHistoryConverter {

    private final Flattener flattener;
    private final FormConverterImpl formConverter;
    private final AuditSummarySingleI9FormHistoryProcessor auditSummarySingleI9FormHistoryProcessor;
    private final AuditDetailI9FormHistoryProcessor auditDetailI9FormHistoryProcessor;

    public void convert(I9Form i9before, I9Form i9after, ChangeContext changeContext) {

        Map<String, String> flattenedI9formBefore = i9before != null ? flattener.process(i9before) : emptyMap();
        Map<String, String> flattenedI9formAfter = flattener.process(i9after);

        Map<String, String> convertedI9formBefore = formConverter.convertForm(flattenedI9formBefore, changeContext);
        Map<String, String> convertedI9formAfter = formConverter.convertForm(flattenedI9formAfter, changeContext);

        auditSummarySingleI9FormHistoryProcessor.process(convertedI9formBefore, convertedI9formAfter, changeContext);
        auditDetailI9FormHistoryProcessor.process(convertedI9formBefore, convertedI9formAfter, changeContext);
    }
}
