package com.efx.ews.es.i9datasourcing.fieldconverter;

import com.efx.ews.es.i9datasourcing.fieldconverter.Utils.Constants;
import com.efx.ews.es.i9datasourcing.formatter.Formatters;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.temporal.TemporalAccessor;
import java.util.Map;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;

@RequiredArgsConstructor(access = AccessLevel.PACKAGE)
@AllArgsConstructor(access = AccessLevel.PACKAGE)
class TemporalConverter implements FieldDataConverter {

    private final String dateTimeFieldName;
    private final DateTimeFormatter sourceFormatter;
    private DateTimeFormatter alternativeSourceFormatter;
    private final DateTimeFormatter targetFormatter;

    @Override
    public String convert(Map<String, String> flattenedI9Form) {
        String dateTimeField = flattenedI9Form.get(dateTimeFieldName);

        if (StringUtils.isBlank(dateTimeField)) {
            return Constants.DEFAULT_EMPTY_VALUE;
        }

        TemporalAccessor dateTime;
        try {
            dateTime = sourceFormatter.parse(dateTimeField);
        } catch (DateTimeParseException e) {
            dateTime = parseWithAlternativeFormatters(dateTimeField, e);
        }
        return targetFormatter.format(dateTime);
    }

    private TemporalAccessor parseWithAlternativeFormatters(String dateTimeField, DateTimeParseException e) {
        TemporalAccessor dateTime;
        try {
            if (alternativeSourceFormatter != null) {
                // in case of parse exception attempting to try with alternative formatter
                dateTime = alternativeSourceFormatter.parse(dateTimeField);
            } else {
                throw e;
            }
        } catch (DateTimeParseException ex) {
            dateTime = Formatters.DATE_TIME_OFFSET_FORMATTER.parse(dateTimeField);
        }

        return dateTime;
    }
}
