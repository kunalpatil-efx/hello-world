package com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation;

import com.efx.ews.es.eev.barricade.common.model.PubSubEncryptedData;
import com.efx.ews.es.eev.barricade.common.service.PubSubEncryptionService;
import com.efx.ews.es.i9datasourcing.dep.model.DepEventDataHolder;
import com.efx.ews.es.i9datasourcing.dep.util.PubSubEventBuilder;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.pubsub.Event;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.pubsub.PubSubEvent;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.DataEngineeringTopicService;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.GooglePublisherService;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.configuration.PubSubProperties;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.ArrayList;
import java.util.function.BiFunction;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Slf4j
@RequiredArgsConstructor
@Service
public class DataEngineeringTopicServiceImpl implements DataEngineeringTopicService {

    private final PubSubEncryptionService encryptionService;
    private final PubSubProperties pubSubProperties;
    private final GooglePublisherService pubSubService;
    private final PubSubEventBuilder pubSubEventBuilder;

    @Override
    public Event sendEvent(DepEventDataHolder eventDataHolder,
                           BiFunction<DepEventDataHolder, PubSubEncryptedData, PubSubEvent> pubSubEventFactory) throws IOException {
        String i9FormId = eventDataHolder.getChangeContext().getI9FormId();
        try {
            log.debug("Sending event for {}", i9FormId);
            PubSubEvent pubSubEvent = getPubSubEvent(eventDataHolder, pubSubEventFactory);
            pubSubService.sendEvent(pubSubEvent);
            log.debug("Event {} published for I9FormId: {}", eventDataHolder.getEventName(), i9FormId);
            return generateEvent(i9FormId, pubSubEvent);
        } catch (Exception e) {
            log.error(String.format("Error while sending event for document: %s", i9FormId), e);
            throw new IOException(e.getMessage(), e);
        }
    }

    @Override
    public Mono<Event> sendEventAsync(DepEventDataHolder eventDataHolder,
                                      BiFunction<DepEventDataHolder, PubSubEncryptedData, PubSubEvent> pubSubEventFactory) {
        String i9FormId = eventDataHolder.getChangeContext().getI9FormId();
        PubSubEvent pubSubEvent;
        try {
            pubSubEvent = getPubSubEvent(eventDataHolder, pubSubEventFactory);
        } catch (Exception e) {
            log.error(String.format("Error while sending event for document: %s", i9FormId), e);
            return Mono.error(e);
        }
        return pubSubService.sendEventAsync(pubSubEvent)
                .doOnSuccess(messageId -> log.info("Event {} published for I9FormId: {}", eventDataHolder.getEventName(), i9FormId))
                .doOnError(e -> log.error(String.format("Error while sending event for document: %s", i9FormId), e))
                .map(messageId -> generateEvent(i9FormId, pubSubEvent));
    }

   @Override
    public Event sendDataPurgeEvent(DepEventDataHolder eventDataHolder, String employeeId) {
       String i9FormId = eventDataHolder.getChangeContext().getI9FormId();
       log.info("Populating PubSubEvent for i9Id :{}", i9FormId);
       PubSubEvent pubSubEvent = getPubSubEvent(eventDataHolder, employeeId);
       pubSubService.sendDataPurgeEvent(pubSubEvent);
       Event event = generateEvent(i9FormId, pubSubEvent);
       event.setTopicId(pubSubProperties.getDataPurge().getEventTopicId());
       return event;
   }

    private PubSubEvent getPubSubEvent(DepEventDataHolder eventDataHolder, BiFunction<DepEventDataHolder, PubSubEncryptedData, PubSubEvent> pubSubEventFactory) {
        String payloadJson = eventDataHolder.getPayloadJson();
        PubSubEncryptedData pubSubEncryptedData = encryptData(payloadJson);
        return pubSubEventFactory.apply(eventDataHolder, pubSubEncryptedData);
    }

    private Event generateEvent(String id, PubSubEvent pubSubEvent) {
        Event event = new Event();
        ArrayList<PubSubEvent> pubSubEvents = new ArrayList<>();
        event.setEnvelopeTypeModelVersion("v01");
        event.setTopicId(pubSubProperties.getEventTopicId());
        event.setCreateCaseUTC(Instant.now().toString());
        event.setEventModelVersion("v01");
        event.setDocumentId(id);
        pubSubEvents.add(pubSubEvent);
        event.setPubsubEvents(pubSubEvents);
        return event;
    }

    private PubSubEncryptedData encryptData(String payloadJson) {
        PubSubEncryptedData pubSubEncryptedData = encryptionService
                .encrypt(payloadJson.getBytes(StandardCharsets.UTF_8));
        log.debug("Event encrypted");
        return pubSubEncryptedData;
    }
    private PubSubEvent getPubSubEvent(DepEventDataHolder eventDataHolder, String employeeId) {
        PubSubEncryptedData pubSubEncryptedData = encryptData(eventDataHolder.getPayloadJson());
        return pubSubEventBuilder.buildDataPurgeBillingEvent(pubSubEncryptedData, employeeId);
    }
}
