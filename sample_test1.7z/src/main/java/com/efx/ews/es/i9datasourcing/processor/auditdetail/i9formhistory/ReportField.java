package com.efx.ews.es.i9datasourcing.processor.auditdetail.i9formhistory;

import java.util.Arrays;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.AllArgsConstructor;

@AllArgsConstructor
enum ReportField {

    I9_ID(null, "I9_ID"),
    I9_EMPLOYER_ID(null, "I9_EMPLOYER_ID"),
    CREATE_TS(null, "EVENT_CREATE_TS"),
    SSN("SECTION_ONE.EMPLOYEE_INFO.SSN", "EMPLOYEE.SSN"),
    LAST_NAME("SECTION_ONE.EMPLOYEE_INFO.LAST_NAME", "EMPLOYEE.LAST_NAME"),
    FIRST_NAME("SECTION_ONE.EMPLOYEE_INFO.FIRST_NAME", "EMPLOYEE.FIRST_NAME"),
    MIDDLE_INITIAL("SECTION_ONE.EMPLOYEE_INFO.MI", "EMPLOYEE.MIDDLE_INITIAL"),
    DATE_OF_BIRTH("SECTION_ONE.EMPLOYEE_INFO.DATE_OF_BIRTH", "EMPLOYEE.DATE_OF_BIRTH"),
    SIGNATURE_METHOD(null, "SIGNATURE_METHOD"),
    LOCATION_CODE("LOCATION_CODE", "LOCATION_CODE"),
    FIELD_UPDATED(null, "UPDATE_DTLS.FIELD_NAME"),
    BEFORE(null, "UPDATE_DTLS.VALUE_BEFORE"),
    AFTER(null, "UPDATE_DTLS.VALUE_AFTER"),
    DESCRIPTION(null, "EVENT.DESCRIPTION"),
    IP_ADDRESS(null, "IP_ADDRESS"),
    EVENT_CREATE_TS(null, "EVENT.CREATE_TS"),
    EVENT_NAME(null, "EVENT.NAME"),
    EVENT_SOURCE(null, "EVENT.SOURCE");

    public final String sourceLabel;
    public final String targetLabel;

    private static final Map<String, String> SOURCE_TO_TARGET = Arrays.stream(ReportField.values())
        .filter(field -> field.sourceLabel != null)
        .collect(Collectors.toUnmodifiableMap(field -> field.sourceLabel, field -> field.targetLabel));

    public static String getTargetLabel(String sourceLabel) {
        return SOURCE_TO_TARGET.getOrDefault(sourceLabel, sourceLabel);
    }
}
