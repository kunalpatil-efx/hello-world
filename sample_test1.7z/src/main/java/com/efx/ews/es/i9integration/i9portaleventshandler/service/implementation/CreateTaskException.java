package com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation;

public class CreateTaskException extends RuntimeException {
    public CreateTaskException(Throwable cause) {
        super(cause);
    }
}
