package com.efx.ews.es.i9integration.i9portaleventshandler;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = {
    "com.efx.ews.es.config",
    "com.efx.ews.es.i9integration.i9portaleventshandler",
    "com.efx.ews.es.i9datasourcing",
    "com.efx.ews.es.everifydatasourcing",
    "com.efx.ews.es.historyprovider",
    "com.efx.ews.es.eev.barricade.common.utilities",
    "com.efx.ews.es.eev.barricade.common.service.implementation",
    "com.efx.ews.es.common.user",
    "com.efx.ews.es.common.feature",
    "com.efx.ews.es.common.config",
    "com.efx.ews.es.common.sss",
})
public class I9PortalEventsHandlerApplication {

    public static void main(String[] args) {
        SpringApplication.run(I9PortalEventsHandlerApplication.class, args);
    }
}
