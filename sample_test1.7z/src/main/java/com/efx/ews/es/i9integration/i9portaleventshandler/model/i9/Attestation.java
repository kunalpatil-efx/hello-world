package com.efx.ews.es.i9integration.i9portaleventshandler.model.i9;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class Attestation {
    @JsonProperty("isAlienAuthorizedToWork")
    private Boolean isAlienAuthorizedToWork;
    @JsonProperty("isLawfulPermanentResident")
    private Boolean isLawfulPermanentResident;
    @JsonProperty("isNonCitizenNational")
    private Boolean isNonCitizenNational;
    @JsonProperty("isUnitedStatesCitizen")
    private Boolean isUnitedStatesCitizen;
    @JsonProperty("lawfulPermanentResidentInfo")
    private LawfulPermanentResidentInfo lawfulPermanentResidentInfo;
    private AlienAuthorizedToWork alienAuthorizedToWorkData;
}
