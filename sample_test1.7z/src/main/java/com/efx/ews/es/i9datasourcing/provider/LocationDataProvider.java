package com.efx.ews.es.i9datasourcing.provider;

import com.efx.ews.es.dto.LocationDto;
import java.util.UUID;
import reactor.core.publisher.Mono;

public interface LocationDataProvider {

    Mono<LocationDto> getLocation(UUID employerId, UUID locationId);
}
