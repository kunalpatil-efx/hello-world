package com.efx.ews.es.i9integration.i9portaleventshandler;

import com.efx.ews.es.common.user.User;
import com.efx.ews.es.common.user.UserSdk;
import com.efx.ews.es.eev.barricade.common.model.BarricadeEncryptedData;
import com.efx.ews.es.eev.barricade.common.service.CryptographyService;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.PacketMailSentEvent;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.I9ApiCall;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.I9HeaderBuilder;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.logger.MdcSetting;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.AuditPubSubPublisherService;
import com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageConfirmation;
import com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageReader;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gcp.pubsub.core.PubSubTemplate;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.dsl.RouterSpec;
import org.springframework.integration.router.MethodInvokingRouter;
import org.springframework.messaging.Message;
import reactor.core.publisher.Mono;
import reactor.util.context.Context;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import static com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageConfirmation.manualAckMessageChannel;

@Configuration
@Slf4j
public class EmailSubscriberConfig {

    private final I9ApiCall i9ApiCall;
    private final MessageConfirmation messageConfirmation;
    private final AuditPubSubPublisherService publisherService;
    private final int FIRST_INDEX = 0;
    private CryptographyService cryptographyService;
    private final SubscriberErrorHandling errorHandling;
    private UserSdk userSdk;


    public EmailSubscriberConfig(MessageConfirmation messageConfirmation,
                                 I9ApiCall i9ApiCall,
                                 AuditPubSubPublisherService publisherService,
                                 CryptographyService cryptographyService,
                                 UserSdk userSdk) {
        this.messageConfirmation = messageConfirmation;
        this.i9ApiCall = i9ApiCall;
        this.publisherService = publisherService;
        this.cryptographyService = cryptographyService;
        this.userSdk = userSdk;
        this.errorHandling = new SubscriberErrorHandling(log);
    }

    @Bean("EmailSubscriberConfig")
    IntegrationFlow subscriberFlow(PubSubTemplate pubSubTemplate,
                                   @Value("${subscription.email}") String subscription) {
        return IntegrationFlows
                .from(manualAckMessageChannel(pubSubTemplate, subscription))
                .route(Message.class, this::hasPacketId, this::routeMessage)
                .get();
    }

    private void routeMessage(RouterSpec<Boolean, MethodInvokingRouter> mapping) {
        mapping.subFlowMapping(Boolean.TRUE, sf -> sf.handle(msg -> MdcSetting.wrapWithHeaders(msg, this::handleMessage)))
                .subFlowMapping(Boolean.FALSE, sf -> sf.handle(msg -> MdcSetting.wrapWithHeaders(msg, this::handleNoPacket)));
    }

    private boolean hasPacketId(Message<?> message) {
        try {
            PacketMailSentEvent payload = MessageReader.readPayloadSync(message, PacketMailSentEvent.class);
            return Optional.ofNullable(payload).map(PacketMailSentEvent::getPacketId).isPresent();
        } catch (Exception e) {
            log.error("Got exception during read payload {}, {}", e, message);
            return false;
        }
    }

    private void handleNoPacket(Message<?> message) {
        log.warn("Received a message without payload {}", message);
        messageConfirmation.acknowledge(message);
    }

    void handleMessage(Message<?> message) {
        log.info("Received a message for email event {}", message);
        BarricadeEncryptedData encryptedUser = findUserAndEncrypt(message);
        MessageReader.readPayload(message, PacketMailSentEvent.class)
                .flatMap(payload -> i9ApiCall.queryDocumentsByPacketId(payload.getPacketId())
                        .map(ids -> new EmailContext().payload(payload).docId(ids.isEmpty() ? null : ids.get(FIRST_INDEX))))
                .map(context -> context.encryptedUser(encryptedUser))
                .map(context -> context.headers(mapToHeaders(context.getDocId(), context.getPayload())))
                .flatMap(context -> publisherService.sendAuditMessage(context.getHeaders(), context.getPayload().mapToPayload(context.getEncryptedUser()))
                        .map(messageId -> context))
                .doOnSuccess(context -> {
                    log.info("Message successfully sent to Audit topic with mail type {}", context.getPayload().getMailType());
                    messageConfirmation.acknowledge(message);
                })
                .onErrorResume(errorHandling::processingCompleted, t -> {
                    log.error("Unable to process the message", t);
                    messageConfirmation.acknowledge(message);
                    return Mono.empty();
                })
                .onErrorResume(errorHandling::processingFailed, t -> {
                    log.error("Processing failed. Will re-try", t);
                    messageConfirmation.nAcknowledge(message);
                    return Mono.empty();
                })
                .subscriberContext(Context.of(I9HeaderBuilder.build(message)))
                .block();
    }

    private BarricadeEncryptedData findUserAndEncrypt(Message<?> message) {
        PacketMailSentEvent payload = MessageReader.readPayloadSync(message, PacketMailSentEvent.class);
        if(payload.getSenderId() == null) {
            return null;
        }
        try {
            UUID senderUuid= UUID.fromString(payload.getSenderId());
            Optional<User> user = userSdk.getUser(senderUuid);
            String firstAndLastName = user.isPresent() ? user.get().getFirstName() + " " + user.get().getLastName() : null;
            if(firstAndLastName == null) {
                return null;
            }
            return cryptographyService.encrypt(firstAndLastName);
        } catch (Exception e) {
            log.error("Got exception during encryption senderId: {}, {}", message, e);
            return null;
        }
    }

    private Map<String, String> mapToHeaders(String documentId, PacketMailSentEvent payload) {
        Map<String, String> headers = new HashMap<>();
        if(documentId !=null) {
            headers.put("documentId", documentId);
        }
        headers.put("sourceId", "packet_ui");
        headers.put("sourceRefId", payload.getPacketId());
        headers.put("status", "Email_Sent");
        headers.put("system", "ESP");
        return headers;
    }

    @NoArgsConstructor
    @Getter
    private static class EmailContext {
        private PacketMailSentEvent payload;
        private String docId;
        private BarricadeEncryptedData encryptedUser;
        private Map<String, String> headers;

        public EmailContext payload(PacketMailSentEvent payload) {
            this.payload = payload;
            return this;
        }

        public EmailContext docId(String docId) {
            this.docId = docId;
            return this;
        }

        public EmailContext encryptedUser(BarricadeEncryptedData encryptedUser) {
            this.encryptedUser = encryptedUser;
            return this;
        }

        public EmailContext headers(Map<String, String> headers) {
            this.headers = headers;
            return this;
        }
    }
}
