package com.efx.ews.es.historyprovider.api;

import com.efx.ews.es.historyprovider.model.I9AuditModel;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.I9Form;
import java.util.List;

public interface I9FormHistoryProvider {

    void registerEventListener(HistoryEventListener historyEventListener);

    List<I9AuditModel> getAudits(String documentId);

    I9Form getRevision(String documentId, long revision);
}
