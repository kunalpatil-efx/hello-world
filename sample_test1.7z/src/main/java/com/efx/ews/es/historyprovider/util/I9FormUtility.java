package com.efx.ews.es.historyprovider.util;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.Document;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.ListA;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.ListB;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.ListC;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.SectionTwo;
import java.util.Optional;
import java.util.function.Function;

public class I9FormUtility {

    public static boolean hasReceipt(SectionTwo sectionTwo) {
        return isTrue(sectionTwo.getListA(), Document::getIsReceipt) ||
            isTrue(sectionTwo.getListB(), Document::getIsReceipt) ||
            isTrue(sectionTwo.getListC(), Document::getIsReceipt);
    }

    public static boolean isTrue(Document doc, final Function<Document, Boolean> booleanFunction) {
        return doc != null && booleanFunction.apply(doc);
    }

    public static boolean isTrue(ListA listA, final Function<Document, Boolean> booleanFunction) {
        return listA != null &&
            (Optional.ofNullable(listA.getDocumentOne())
                .map(booleanFunction)
                .orElse(false) ||
                Optional.ofNullable(listA.getDocumentTwo())
                    .map(booleanFunction)
                    .orElse(false) ||
                Optional.ofNullable(listA.getDocumentThree())
                    .map(booleanFunction)
                    .orElse(false));
    }

    public static boolean isTrue(ListB listB, final Function<Document, Boolean> booleanFunction) {
        return listB != null &&
            (Optional.ofNullable(listB.getDocumentOne()).map(booleanFunction).orElse(false));
    }

    public static boolean isTrue(ListC listC, final Function<Document, Boolean> booleanFunction) {
        return listC != null &&
            (Optional.ofNullable(listC.getDocumentOne()).map(booleanFunction).orElse(false));
    }


}
