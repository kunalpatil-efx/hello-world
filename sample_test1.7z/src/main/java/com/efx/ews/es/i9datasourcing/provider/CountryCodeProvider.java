package com.efx.ews.es.i9datasourcing.provider;

public interface CountryCodeProvider {

    String getCountryCode(String countryName);
}
