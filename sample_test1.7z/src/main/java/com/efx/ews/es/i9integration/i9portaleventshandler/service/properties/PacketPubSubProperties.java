package com.efx.ews.es.i9integration.i9portaleventshandler.service.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "pubsub-packet")
public class PacketPubSubProperties extends AbstractPubSubProperties {
}
