package com.efx.ews.es.i9datasourcing.processor.auditdetail.i9formhistory;

import static java.util.Objects.isNull;

import com.efx.ews.es.i9datasourcing.model.ChangeContext;
import java.util.Map;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class SignatureMethodProvider {

    private static final String SIGNATURE = "E-signature";
    private static final String BLANK = "";
    public static final String SECTION_1_SIGNATURE_DATE = "SECTION_ONE.EMPLOYEE_INFO.SIGNATURE.SIGNATURE_DATE";
    public static final String SECTION_2_SIGNATURE_DATE = "SECTION_TWO.EMPLOYER_SIGNATURE_DATE";
    public static final String SECTION_3_REVERIFICATION_SIGNATURE_DATE = "SECTION_THREE.EMPLOYER_SIGNATURE.REVERIFICATION_SIGNATURE_DATE";
    public static final String EMPLOYEE_SIGNATURE_DATE = "SECTION_ONE.EMPLOYEE_INFO.SIGNATURE.SIGNATURE_DATE";
    public static final String EMPLOYER_SIGNATURE_DATE = "SECTION_TWO.EMPLOYER_SIGNATURE_DATE";

    String getSignatureMethod(Map<String, String> convertedI9FormAfter, ChangeContext changeContext) {
        final String signatureMethod;
        switch (changeContext.getI9Event()) {
            case FORM_CREATED:
            case SECTION_1_COMPLETE:
                signatureMethod = getSignatureOrBlank(convertedI9FormAfter, SECTION_1_SIGNATURE_DATE);
                break;
            case SECTION_2_COMPLETE:
                signatureMethod = getSignatureOrBlank(convertedI9FormAfter, SECTION_2_SIGNATURE_DATE);
                break;
            case SECTION_3_COMPLETE:
                signatureMethod = getSignatureOrBlank(convertedI9FormAfter, SECTION_3_REVERIFICATION_SIGNATURE_DATE);
                break;
            case SECTION_1_AMENDED:
                signatureMethod = getSignatureOrBlank(convertedI9FormAfter, EMPLOYEE_SIGNATURE_DATE);
                break;
            case SECTION_2_AMENDED:
                signatureMethod = getSignatureOrBlank(convertedI9FormAfter, EMPLOYER_SIGNATURE_DATE);
                break;
            default:
                String msg = "There is no signature date for: " + changeContext.getI9Event().name();
                log.debug(msg);
                throw new IllegalArgumentException(msg);
        }
        if (isNull(signatureMethod)) {
            throw new IllegalStateException(
                "Something went wrong in the switch statement for I9Event = " + changeContext.getI9Event());
        }
        return signatureMethod;
    }

    private String getSignatureOrBlank(Map<String, String> convertedI9FormAfter, String key) {
        return isFieldNotEmpty(convertedI9FormAfter, key) ? SIGNATURE : BLANK;
    }

    private boolean isFieldNotEmpty(Map<String, String> convertedI9FormAfter, String key) {
        if (!convertedI9FormAfter.containsKey(key)) {
            return false;
        }
        return StringUtils.isNotEmpty(convertedI9FormAfter.get(key));
    }
}
