package com.efx.ews.es.i9integration.i9portaleventshandler.service.configuration;

import lombok.Data;
import org.springframework.stereotype.Component;

@Component
@Data
public class DataPurgeProperties {
    private boolean enabled;
    private String eventTopicId;
    private String appId;
    private String eventType;
    private String eventName;
    private String eventTime;
    private String projectId;
}
