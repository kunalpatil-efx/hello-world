package com.efx.ews.es.i9integration.i9portaleventshandler.service.client;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.EmployeeDataPurgeResponse;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.ingest.IngestEmployeeFact;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.logger.MdcReactorLogger;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.webclient.HttpCallClient;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.EmployerPersonApiProperties;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.net.URI;

import static java.lang.String.format;

@Component
@Slf4j
@RequiredArgsConstructor
public class EmployerPersonApiCall {

    private final EmployerPersonApiProperties employerPersonApiProperties;
    private final HttpCallClient httpCallClient;

    public Mono<ResponseEntity<Void>> postIngestEmployeeFact(IngestEmployeeFact ingestEmployeeFact) {
        URI uri = employerPersonApiProperties.postGenerate().build().toUri();
        return httpCallClient.doCall(webClient ->
            webClient.post()
                .uri(uri)
                .bodyValue(ingestEmployeeFact)
                .retrieve()
                .toBodilessEntity()
                .doOnEach(MdcReactorLogger.logOnNext(response -> log
                    .info("Success postIngestEmployeeFact, employerId: {}", ingestEmployeeFact.getEmployerId())))
                .doOnEach(MdcReactorLogger.logOnError(ex -> log
                    .error(format("Failed postIngestEmployeeFact, employerId: %s", ingestEmployeeFact.getEmployerId()),
                        ex)))
        );
    }

    public Mono<EmployeeDataPurgeResponse> getEmployeeByEmployeeId(String employeeId) {
        URI uri = employerPersonApiProperties.getByEmployeeId().buildAndExpand(employeeId).toUri();
        return httpCallClient.doCall(webClient ->
            webClient.get()
                .uri(uri.toString(), employeeId)
                .retrieve()
                .bodyToMono(EmployeeDataPurgeResponse.class)
                .doOnEach(MdcReactorLogger.logOnNext(response -> log
                    .info("Successfully  retrieved employee details for employee id: {}", employeeId)))
                .doOnEach(MdcReactorLogger.logOnError(ex -> log
                    .error(format("Employee Info Retrieval failed for employeeId: %s", employeeId),
                        ex))));
    }
}
