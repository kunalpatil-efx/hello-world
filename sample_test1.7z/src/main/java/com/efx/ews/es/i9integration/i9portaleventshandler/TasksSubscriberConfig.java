package com.efx.ews.es.i9integration.i9portaleventshandler;

import com.efx.ews.es.i9integration.i9portaleventshandler.exception.OutOfSubcriberScopeException;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.I9EventStatus;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.PacketSourceId;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.UserIdAndTaskResponse;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.Document;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.FormData;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.I9Form;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.SectionThree;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.Task;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.UpdateMetadataRequest;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.event.I9EventPayload;
import com.efx.ews.es.i9integration.i9portaleventshandler.pubsub.ReactiveSubscriber;
import com.efx.ews.es.i9integration.i9portaleventshandler.pubsub.ReactiveSubscription;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.EmployerPersonCall;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.I9ApiCall;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.I9HeaderBuilder;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.logger.MdcReactorLogger;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.logger.MdcSetting;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.PacketPubSubPublisherService;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.TaskApiRemoteCallService;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.TaskApiProperties;
import com.efx.ews.es.i9integration.i9portaleventshandler.utils.ContextLogging;
import com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageConfirmation;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.cloud.gcp.pubsub.support.AcknowledgeablePubsubMessage;
import org.springframework.cloud.gcp.pubsub.support.converter.JacksonPubSubMessageConverter;
import org.springframework.cloud.gcp.pubsub.support.converter.PubSubMessageConverter;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.util.context.Context;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Predicate;

@Component
@SuppressWarnings("unused")
@Slf4j
public class TasksSubscriberConfig implements ApplicationListener<ApplicationReadyEvent>, ReactiveSubscription {

    @Value("${subscription.tasks}")
    private String subscriptionName;
    private final static Set<String> FETCH_I9_EVENTS = Set.of(I9EventStatus.SECTION2_COMPLETE.getValue(),
        I9EventStatus.SECTION3_COMPLETE.getValue(), I9EventStatus.SECTION2_AMENDED.getValue());
    private static final String TASKSTATUS_NEW = "NEW";
    private static final String TASKSTATUS_COMPLETED = "COMPLETED";
    private static final String TASK_CODE_SSN_APPLIED = "I9:SSNApplied";
    private static final String TASK_CODE_EVERIFY = "Everify:UnconfirmedDataSection1WaitingOnEmployee";
    private static final String TASK_CODE_SECTION2_UPLOAD = "I9:Section2UploadLater";
    private static final String TASK_CODE_S3 = "I9:Section3";
    private static final String SECTION2_STATUS = "Section2_Complete";
    private static final String SECTION1_STATUS = "section1_complete";
    private static final String TASK_CODE_RECEIPT_UPDATE = "I9:ReceiptUpdate";
    private static final String RECEIPT_UPDATE_FEATURE = "receiptUpdate";

    private final I9ApiCall i9ApiCall;
    private final TaskApiRemoteCallService taskApiRemoteCallService;
    private final MessageConfirmation messageConfirmation;
    private final PacketPubSubPublisherService publisherService;
    private final TaskApiProperties properties;
    private final SubscriberErrorHandling errorHandling;
    private final EmployerPersonCall employerPersonCall;
    private final ObjectMapper converter = new ObjectMapper();
    private final PubSubMessageConverter pubSubMessageConverter;
    private final ReactiveSubscriber reactiveSubscriber;

    public TasksSubscriberConfig(I9ApiCall i9ApiCall,
                                 TaskApiRemoteCallService taskApiRemoteCallService,
                                 PacketPubSubPublisherService publisherService,
                                 ObjectProvider<MessageConfirmation> messageConfirmationForFlow,
                                 TaskApiProperties properties,
                                 EmployerPersonCall employerPersonCall,
                                 ReactiveSubscriber reactiveSubscriber) {
        this.i9ApiCall = i9ApiCall;
        this.taskApiRemoteCallService = taskApiRemoteCallService;
        this.messageConfirmation = messageConfirmationForFlow.getObject(getClass());
        this.publisherService = publisherService;
        this.properties = properties;
        this.employerPersonCall = employerPersonCall;
        errorHandling = new SubscriberErrorHandling(log);
        this.reactiveSubscriber = reactiveSubscriber;
        this.pubSubMessageConverter = new JacksonPubSubMessageConverter(
                new ObjectMapper()
                        .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
                        .findAndRegisterModules());
    }

    @Override
    public void onApplicationEvent(@SuppressWarnings("NullableProblems") ApplicationReadyEvent applicationReadyEvent) {
        reactiveSubscriber.subscribe(this, subscriptionName);
    }

    @Override
    public Flux<?> processing(Flux<AcknowledgeablePubsubMessage> flux) {
        return flux.flatMap(message ->
                Mono
                        .just(message)
                        .doOnNext(MdcSetting::setFromMessage)
                        .doOnEach(MdcReactorLogger.logOnNext(m -> log.info("Message captured in {}", getClass().getSimpleName())))
                        .flatMap(this::routeOnSourceId)
                        .doOnEach(MdcReactorLogger.logOnNext(m -> log.info("Message processing completed in {}", getClass().getSimpleName())))
                        .doOnEach(signal -> MdcSetting.remove())
                        .subscriberContext(createContext(message))
        );
    }

    private Context createContext(AcknowledgeablePubsubMessage message) {
        final Map<String, String> contextProperties = I9HeaderBuilder.build(message.getPubsubMessage());
        contextProperties.put(ContextLogging.CONTEXT_PROPERTY, getClass().getSimpleName());
        return Context.of(contextProperties);
    }

    private Mono<?> routeOnSourceId(AcknowledgeablePubsubMessage message) {
        final PacketSourceId packetSourceId = resolveContext(message);
        if (PacketSourceId.PACKET_UI == packetSourceId) {
            return withTaskCreatedMessage(message);
        } else if (PacketSourceId.I9ANYWHERE == packetSourceId) {
            return i9AnywhereMessage(message);
        } else if (PacketSourceId.OTHER == packetSourceId) {
            return noTaskCreatedMessage(message);
        }
        return Mono.empty();
    }

    private Mono<?> i9AnywhereMessage(AcknowledgeablePubsubMessage message) {
        final TaskContext taskContext = TaskContext.fromMessage(message.getPubsubMessage().getAttributesMap());
        log.info("TasksSubscriberConfig I9Anywhere for task flow for document {}", taskContext.getDocumentId());
        final Mono<I9EventPayload> i9EventPayload = Mono.defer(() -> Mono.just(pubSubMessageConverter.fromPubSubMessage(message.getPubsubMessage(), I9EventPayload.class)));
        return setupErrorHandling(
                Mono.zip(i9EventPayload, i9ApiCall.getTasks(taskContext.getDocumentId()), TaskHandlerObject::new)
                        .doOnEach(MdcReactorLogger.logOnNext(taskHandlerObjectSignal -> log.debug("Passing {}", taskHandlerObjectSignal)))
                        .flatMap(taskHandlerObject -> completeTasks(taskContext.getStatus(), taskContext.getDocumentId(), taskHandlerObject)),
                message,
                taskContext.getDocumentId());
    }

    private Mono<?> noTaskCreatedMessage(AcknowledgeablePubsubMessage message) {
        final TaskContext taskContext = TaskContext.fromMessage(message.getPubsubMessage().getAttributesMap());
        log.info("TasksSubscriberConfig no valid source for task creation for document {}, message {}", taskContext.getDocumentId(), message);

        return setupErrorHandling(
                updateEmployeeIdForFactId(taskContext),
                message,
                taskContext.getDocumentId());
    }

    Mono<?> withTaskCreatedMessage(AcknowledgeablePubsubMessage message) {
        log.info("TasksSubscriberConfig received message with task create: {}", message);
        final TaskContext taskContext = TaskContext.fromMessage(message.getPubsubMessage().getAttributesMap());
        final Mono<I9EventPayload> i9EventPayload = Mono.defer(() -> Mono.just(pubSubMessageConverter.fromPubSubMessage(message.getPubsubMessage(), I9EventPayload.class)));
        return setupErrorHandling(Mono.zip(i9EventPayload, i9ApiCall.getTasks(taskContext.getDocumentId()), TaskHandlerObject::new)
                        .flatMap(taskHandlerObject -> fetchI9Form(taskContext, taskHandlerObject))
                        .flatMap(taskHandlerObject -> createSection2Task(taskContext.getDocumentId(), taskContext.getStatus(), taskHandlerObject))
                        .flatMap(taskHandlerObject -> createSection2DocumentUpload(taskContext.getDocumentId(), taskContext.getStatus(), taskHandlerObject))
                        .doOnEach(MdcReactorLogger.logOnNext(taskHandlerObjectSignal -> log.debug("Passing {}", taskHandlerObjectSignal)))
                        .flatMap(taskHandlerObject -> createReceiptUpdateTask(taskContext.getDocumentId(), taskContext.getStatus(), taskHandlerObject))
                        .flatMap(taskHandlerObject -> createSsnAppliedTask(taskContext.getDocumentId(), taskContext.getStatus(), taskHandlerObject))
                        .flatMap(taskHandlerObject -> completeTasks(taskContext.getStatus(), taskContext.getDocumentId(), taskHandlerObject))
                        .flatMap(ignore -> updateEmployeeIdForFactId(taskContext)),
                message, taskContext.getDocumentId());
    }

    private Mono<TaskHandlerObject> fetchI9Form(TaskContext taskContext, TaskHandlerObject taskHandlerObject) {
        if (FETCH_I9_EVENTS.contains(taskContext.status)) {
            String version = String.valueOf(taskHandlerObject.getI9form().getDocument().getRecordVersion());
            return i9ApiCall.getFormByRevision(taskContext.documentId, version)
                    .map(i9FormResponse -> {
                        taskHandlerObject.addI9FormResponse(i9FormResponse);
                        return taskHandlerObject;
                    })
                    .doOnEach(MdcReactorLogger.logOnNext(ignore -> log.info("Fetched I9 for task")));
        } else {
            return Mono.just(taskHandlerObject)
                    .doOnEach(MdcReactorLogger.logOnNext(ignore -> log.info("Skipping Fetch I9")));
        }
    }

    private <T> Mono<T> setupErrorHandling(Mono<T> publisher, AcknowledgeablePubsubMessage message, String documentId) {
        return publisher.doOnSuccess(ignore -> messageConfirmation.acknowledge(message))
                .doOnEach(MdcReactorLogger.logOnError(t -> log.error("Exception", t)))
                .onErrorResume(errorHandling::processingCompleted, t -> {
                    messageConfirmation.acknowledge(message);
                    errorHandling.logClientErrorException(documentId, t);
                    return Mono.empty();
                })
                .onErrorResume(errorHandling::processingFailed, t -> {
                    messageConfirmation.nAcknowledge(message);
                    log.error("error in processing for documentId {}", documentId, t);
                    return Mono.empty();
                });
    }

    private Mono<?> updateEmployeeIdForFactId(TaskContext taskContext) {
        if (taskContext.isNotSectionOneCompleteOrSectionTwoComplete()) {
            log.info("Skipped employee-id update for document {} expected status is section1_complete or section2_complete, actual status {}",
                    taskContext.getDocumentId(), taskContext.getStatus());
            return Mono.empty();
        }
        if (StringUtils.isNotBlank(taskContext.getEmployeeId())) {
            log.info("EmployeeId {} is present on document {}. No employer-config-api call is needed",
                    taskContext.getEmployeeId(), taskContext.getDocumentId());
            return Mono.empty();
        }
        if (StringUtils.isBlank(taskContext.getEmployeeFactId())) {
            log.error("No employee fact id for document {}, skipping employee id update", taskContext.getDocumentId());
            return Mono.empty();
        }
        log.info("document {} requesting employee id for fact id {}", taskContext.getDocumentId(), taskContext.getEmployeeFactId());
        return employerPersonCall.getEmployeeByFactId(taskContext.getEmployeeFactId())
                .flatMap(employeeForFactId -> {
                    log.info("Updating employeeId for i9: {}", taskContext.getDocumentId());
                    UpdateMetadataRequest updateMetadataRequest = new UpdateMetadataRequest();
                    updateMetadataRequest.setEmployeeId(employeeForFactId.getEmployeeId());
                    updateMetadataRequest.setFactIdToEmployeeIdSyncDate(employeeForFactId.getLastOperationDate());
                    return i9ApiCall.patchMetadata(taskContext.getDocumentId(), updateMetadataRequest);
                });
    }

    private Mono<TaskHandlerObject> createSsnAppliedTask(String documentId, String status, TaskHandlerObject i9form) {
        log.debug("createSsnAppliedTask {} {}", status, i9form);
        if ((SECTION2_STATUS.equalsIgnoreCase(status) || SECTION1_STATUS.equalsIgnoreCase(status))
                && BooleanUtils.isTrue(i9form.getI9form().getForm().getSsnApplied())
                && !i9form.hasAnyActive(properties.getSsnApplied().getCode())) {
            return taskApiRemoteCallService.createSsnAppliedTask(documentId, i9form.getI9form())
                    .doOnSuccess(task -> {
                        log.info("Created SSN Applied Task for id {}", documentId);
                        i9form.addTask(task);
                    })
                    .flatMap(task -> publisherService.restartPacketForSSN(
                            i9form.getI9form().getDocument().getSourceRefId(), task.getTaskId()))
                    .doOnEach(MdcReactorLogger.logOnNext(id -> log.info("Sent Pub/Sub event {} for i9 {}", id, documentId)))
                    .flatMap(task -> Mono.just(i9form));
        }
        return Mono.just(i9form);
    }

    private Mono<TaskHandlerObject> createSection2DocumentUpload(String documentId, String status,
                                                                 TaskHandlerObject i9form) {
        log.debug("createSection2DocumentUpload Task {} {}", status, i9form);
        if ((SECTION2_STATUS.equalsIgnoreCase(status))
                && (isUploadLaterCheckedListA(i9form)
                || isUploadLaterCheckedListBandC(i9form))
                && !i9form.hasAnyActive(properties.getSection2UploadLater().getCode())) {
            return taskApiRemoteCallService.createSection2DocumentUpload(documentId, i9form.getI9form())
                    .doOnEach(MdcReactorLogger.logOnNext(ignore -> log.info("Created Section2DocumentUpload Task for id {}", documentId)))
                    .flatMap(task -> Mono.just(i9form.addTask(task)));
        }
        return Mono.just(i9form)
                .doOnEach(MdcReactorLogger.logOnNext(ignore -> log.info("Skipping createSection2DocumentUpload for {}", documentId)));
    }


    private boolean isUploadLaterCheckedListA(TaskHandlerObject taskHandlerObject) {
        log.debug("Checking flag for List A documents for document Upload later task");
        return taskHandlerObject.getI9FormResponse() != null && taskHandlerObject.getI9FormResponse().getFormData().getSectionTwo() != null &&
                taskHandlerObject.getI9FormResponse().getFormData().getSectionTwo().getListA() != null &&
                (Optional.ofNullable(taskHandlerObject.getI9FormResponse().getFormData().getSectionTwo().getListA().getDocumentOne())
                        .map(Document::getUploadLater)
                        .orElse(Boolean.FALSE) ||
                        Optional.ofNullable(taskHandlerObject.getI9FormResponse().getFormData().getSectionTwo().getListA().getDocumentTwo())
                                .map(Document::getUploadLater)
                                .orElse(Boolean.FALSE) ||
                        Optional.ofNullable(taskHandlerObject.getI9FormResponse().getFormData().getSectionTwo().getListA().getDocumentThree())
                                .map(Document::getUploadLater)
                                .orElse(Boolean.FALSE));
    }

    private boolean isUploadLaterCheckedListBandC(TaskHandlerObject taskHandlerObject) {
        log.debug("Checking flag for List B & C documents for document Upload later task");
        return taskHandlerObject.getI9FormResponse().getFormData() != null &&
                ((taskHandlerObject.getI9FormResponse().getFormData().getSectionTwo().getListB() != null &&
                        Optional.ofNullable(taskHandlerObject.getI9FormResponse().getFormData().getSectionTwo().getListB().getDocumentOne())
                                .map(Document::getUploadLater)
                                .orElse(Boolean.FALSE)) ||
                        (taskHandlerObject.getI9FormResponse().getFormData().getSectionTwo().getListC() != null &&
                                Optional.ofNullable(taskHandlerObject.getI9FormResponse().getFormData().getSectionTwo()
                                        .getListC().getDocumentOne())
                                        .map(Document::getUploadLater)
                                        .orElse(Boolean.FALSE)));
    }

    private Mono<TaskHandlerObject> createSection2Task(String documentId, String status, TaskHandlerObject i9form) {
        if (SECTION1_STATUS.equalsIgnoreCase(status) && !i9form.hasAnyActive(properties.getSection2type().getCode())) {
            return taskApiRemoteCallService.createSection2Task(documentId, i9form.getI9form())
                    .doOnEach(MdcReactorLogger.logOnNext(ignore -> log.info("Created Section 2 Task for id {}", documentId)))
                    .flatMap(task -> Mono.just(i9form.addTask(task)));
        }
        return Mono.just(i9form)
                .doOnEach(MdcReactorLogger.logOnNext(ignore -> log.info("Skipping createSection2Task for {}", documentId)));
    }

    protected Mono<TaskHandlerObject> createReceiptUpdateTaskAfterClose(Task task, String documentId, String status,
        TaskHandlerObject i9form) {
        if(TASK_CODE_RECEIPT_UPDATE.equalsIgnoreCase(task.getTaskType())
            && TASKSTATUS_COMPLETED.equalsIgnoreCase(task.getTaskStatus())) {
            return createReceiptUpdateTask(documentId, status, i9form);
        } else {
            return Mono.just(i9form);
        }
    }

    protected Mono<TaskHandlerObject> createReceiptUpdateTask(String documentId, String status,
        TaskHandlerObject i9form) {
        if ( (SECTION2_STATUS.equalsIgnoreCase(status) ||
            I9EventStatus.SECTION2_AMENDED.getValue().equalsIgnoreCase(status))
            && (isReceiptCheckedListA(i9form) || isReceiptCheckedListBandC(i9form))
            && !i9form.hasAnyActive(properties.getReceiptUpdateSectionTwo().getCode())) {
            return i9ApiCall.getFeature(RECEIPT_UPDATE_FEATURE)
                .flatMap(enabled -> {
                    if (Boolean.TRUE.equals(enabled)) {
                        return taskApiRemoteCallService.createReceiptUpdateTask(documentId, i9form.getI9FormResponse())
                            .doOnEach(MdcReactorLogger.logOnNext(
                                ignore -> log.info("Created Section2 Receipt Update Task for id {}", documentId)))
                            .flatMap(task -> Mono.just(i9form.addTask(task)));
                    } else {
                        log.info("Receipt update feature disabled. Skipping createSection2 Receipt Update Task for {}",
                            documentId);
                    }
                    return Mono.just(i9form);
                });
        }

        return Mono.just(i9form)
            .doOnEach(MdcReactorLogger.logOnNext(
                ignore -> log.info("Skipping createSection2 Receipt Update Task for {}, Form status {}",
                    documentId, status)));
    }

    private boolean isReceiptCheckedListA(TaskHandlerObject taskHandlerObject) {
        log.debug("Checking flag for List A documents for document Receipt task");
        return taskHandlerObject.getI9FormResponse() != null && taskHandlerObject.getI9FormResponse().getFormData().getSectionTwo() != null &&
                taskHandlerObject.getI9FormResponse().getFormData().getSectionTwo().getListA() != null &&
                isListADocument(taskHandlerObject);
    }

    private boolean isListADocument(TaskHandlerObject taskHandlerObject) {
        return (isListDocument(taskHandlerObject.getI9FormResponse().getFormData().getSectionTwo().getListA().getDocumentOne()) ||
                isListDocument(taskHandlerObject.getI9FormResponse().getFormData().getSectionTwo().getListA().getDocumentTwo()) ||
                isListDocument(taskHandlerObject.getI9FormResponse().getFormData().getSectionTwo().getListA().getDocumentThree()));
    }

    private Boolean isListDocument(Document document) {
        return Optional.ofNullable(document)
                .map(Document::getIsReceipt)
                .orElse(Boolean.FALSE);
    }

    private boolean isReceiptCheckedListBandC(TaskHandlerObject taskHandlerObject) {
        log.debug("Checking flag for List B & C documents for document Receipt task");
        return taskHandlerObject.getI9FormResponse().getFormData().getSectionTwo() != null &&
                ((taskHandlerObject.getI9FormResponse().getFormData().getSectionTwo().getListB() != null &&
                        isListDocument(taskHandlerObject.getI9FormResponse().getFormData().getSectionTwo().getListB().getDocumentOne())) ||
                        isListCDocument(taskHandlerObject));
    }

    private boolean isListCDocument(TaskHandlerObject taskHandlerObject) {
        return taskHandlerObject.getI9FormResponse().getFormData().getSectionTwo().getListC() != null
                && isListDocument(taskHandlerObject.getI9FormResponse().getFormData().getSectionTwo().getListC().getDocumentOne());
    }

    private static final Set<String> COMPLETE_TASK_EVENTS = Set.of(I9EventStatus.SECTION1_AMENDED.getValue(),
            I9EventStatus.SECTION2_AMENDED.getValue(),
            I9EventStatus.SECTION2_COMPLETE.getValue(),
            I9EventStatus.SECTION3_COMPLETE.getValue(),
            I9EventStatus.DATA_CONFIRMED.getValue(),
            I9EventStatus.SECTION2_DOCUMENT_UPLOADED.getValue());

    private Mono<TaskHandlerObject> completeTasks(String status, String documentId, TaskHandlerObject i9form) {
        if (COMPLETE_TASK_EVENTS.contains(status)) {
            return Mono.just(i9form.getTasks())
                    .doOnEach(MdcReactorLogger.logOnNext(tasks -> log.info("Retrieved tasks size {} i9 document with id {}", tasks.size(), documentId)))
                    .flatMap(tasks -> filterTasksForClosure(documentId, status, tasks))
                    .flatMap(task -> closePacket(i9form.getI9form().getDocument().getSourceRefId(), status, task))
                    .flatMap(task -> i9ApiCall.getAudit(documentId, i9form.getI9form().getDocument().getRecordVersion())
                            .flatMap(a -> Mono.just(new UserIdAndTaskResponse(a.getSourceKey(), task))))
                    .doOnEach(MdcReactorLogger.logOnNext(ignore -> log.info("Retrieved Audit Entry for i9 with id {}", documentId)))
                    .filter(response -> filterForS3Task(response.getTask(), i9form))
                    .flatMap(response -> taskApiRemoteCallService.completeTask(documentId, response.getTask(), response.getUserId()))
                    .flatMap(task -> createReceiptUpdateTaskAfterClose(task, documentId, status, i9form))
                    .doOnEach(MdcReactorLogger.logOnNext(ignore -> log.info("Completed tasks for i9 with id {}, status {}", documentId, status)))
                    .flatMap(ignore -> Mono.just(i9form))
                    .doOnEach(MdcReactorLogger.logOnError(e -> log.warn("Exception occured in Task completion", e)))
                    .onErrorResume(OutOfSubcriberScopeException.class, e -> {
                        log.warn("Ignoring Task completion for {} in status {}", documentId, status);
                        return Mono.just(i9form);
                    });
        }
        return Mono.just(i9form)
                .doOnEach(MdcReactorLogger.logOnNext(ignore -> log.info("skipping complete task for document id {}, status {}", documentId, status)));
    }

    public boolean filterForS3Task(Task task, TaskHandlerObject taskHandlerObject) {
        if(TASK_CODE_S3.equals(task.getTaskType())) {
            return Optional.ofNullable(taskHandlerObject)
                    .map(TaskHandlerObject::getI9FormResponse)
                    .map(I9Form::getFormData)
                    .map(FormData::getSectionThreeList)
                    .orElse(Collections.emptyList())
                    .stream()
                    .max(Comparator.comparing(SectionThree::getTimestamp))
                    .map(SectionThree::getIsReverification)
                    .orElse(false);
        }
        return true;
    }

    private Mono<Task> closePacket(String packetId, String status, Task task) {
        if (I9EventStatus.SECTION1_AMENDED.equals(status) && TASK_CODE_SSN_APPLIED.equals(task.getTaskType())
                && TASKSTATUS_NEW.equals(task.getTaskStatus())) {
            return publisherService.closePacketForSSN(packetId)
                    .doOnEach(MdcReactorLogger.logOnNext(s -> log.info("Packet closed for taskId: {} , packet id: {}, type: {}", task.getTaskId(), packetId, task.getTaskType())))
                    .map(s -> task);
        } else if ((I9EventStatus.SECTION1_AMENDED.equals(status) || I9EventStatus.DATA_CONFIRMED.equals(status))
                && TASK_CODE_EVERIFY.equals(task.getTaskType())
                && TASKSTATUS_NEW.equals(task.getTaskStatus())) {
            return publisherService.closePacketForUnconfirmedData(packetId)
                    .doOnEach(MdcReactorLogger.logOnNext(s -> log.info("Packet closed for taskId: {} , packet id: {}, type: {}", task.getTaskId(), packetId, task.getTaskType())))
                    .map(s -> task);
        }
        return Mono.just(task);
    }

    private final static Set<String> SECTION1_AMENDED_TASK_TYPES = Set.of(TASK_CODE_SSN_APPLIED, TASK_CODE_EVERIFY);
    private final static Set<String> SECTION2_AMENDED_TASK_TYPES = Set.of(TASK_CODE_RECEIPT_UPDATE);

    public Mono<Task> filterTasksForClosure(String documentId, String status, List<Task> tasksList) {
        Predicate<Task> typeFilter;
        if (I9EventStatus.SECTION1_AMENDED.equals(status)) {
            typeFilter = task -> SECTION1_AMENDED_TASK_TYPES.contains(task.getTaskType());
        } else if (I9EventStatus.DATA_CONFIRMED.equals(status)) {
            typeFilter = task -> TASK_CODE_EVERIFY.equals(task.getTaskType());
        } else if (I9EventStatus.SECTION2_COMPLETE.equals(status)) {
            typeFilter = task -> "I9:Section2".equals(task.getTaskType());
        } else if (I9EventStatus.SECTION2_DOCUMENT_UPLOADED.equals(status)) {
            typeFilter = task -> TASK_CODE_SECTION2_UPLOAD.equals(task.getTaskType());
        } else if(I9EventStatus.SECTION3_COMPLETE.equals(status)) {
            typeFilter = task -> TASK_CODE_S3.equals(task.getTaskType());
        } else if(I9EventStatus.SECTION2_AMENDED.equals(status)) {
            typeFilter = task -> SECTION2_AMENDED_TASK_TYPES.contains(task.getTaskType());
        } else {
            //shouldn't really be here
            return Mono.error(new OutOfSubcriberScopeException());
        }
        return tasksList.stream()
                .filter(typeFilter)
                .filter(task -> TASKSTATUS_NEW.equals(task.getTaskStatus()))
                .findFirst()
                .map(Mono::just)
                .orElse(
                        Mono.error(
                                new IllegalArgumentException(
                                        "Unable to find task for to close, document "
                                                + documentId + ", status " + status)));
    }

    private PacketSourceId resolveContext(AcknowledgeablePubsubMessage message) {
        String source = message.getPubsubMessage().getAttributesMap().get("sourceId");
        return taskApiRemoteCallService.isValidContext(source) ? PacketSourceId.PACKET_UI : PacketSourceId.OTHER;
    }

    protected static class TaskHandlerObject {
        private final I9EventPayload i9form;
        private final List<Task> tasks;
        private I9Form i9FormResponse;

        TaskHandlerObject(I9EventPayload i9form, List<Task> tasks) {
            this.i9form = i9form;
            this.tasks = tasks;
        }

        boolean hasAnyActive(String type) {
            return tasks.stream().filter(task -> type.equals(task.getTaskType()))
                    .anyMatch(task -> TASKSTATUS_NEW.equals(task.getTaskStatus()));
        }

        I9EventPayload getI9form() {
            return i9form;
        }

        TaskHandlerObject addTask(Task task) {
            tasks.add(task);
            return this;
        }

        public TaskHandlerObject addI9FormResponse(I9Form i9FormResponse) {
            this.i9FormResponse = i9FormResponse;
            return this;
        }

        public I9Form getI9FormResponse() {
            return i9FormResponse;
        }

        List<Task> getTasks() {
            return tasks;
        }

        void completeTask(String taskId) {

        }
    }

    @Getter
    private static class TaskContext {
        private String documentId;
        private String employeeFactId;
        private String employeeId;
        private String status;

        private TaskContext(String documentId, String employeeFactId, String employeeId, String status) {
            this.documentId = documentId;
            this.employeeFactId = employeeFactId;
            this.employeeId = employeeId;
            this.status = status;
        }

        public static TaskContext fromMessage(Map<String, String> attributes) {
            String documentId = attributes.get("documentId");
            String employeeFactId = attributes.get("employeeFactId");
            String employeeId = attributes.get("employeeId");
            String status = attributes.get("status");
            return new TaskContext(documentId, employeeFactId, employeeId, status);
        }

        public boolean isNotSectionOneCompleteOrSectionTwoComplete() {
            return !SECTION1_STATUS.equalsIgnoreCase(status) && !SECTION2_STATUS.equalsIgnoreCase(status);
        }
    }
}
