package com.efx.ews.es.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.security.config.annotation.SecurityBuilder;
import org.springframework.security.config.annotation.web.WebSecurityConfigurer;
import org.springframework.security.config.annotation.web.builders.WebSecurity;

@Configuration
@Profile("local")
public class LocalWebSecurityConfig implements WebSecurityConfigurer {

    @Override
    public void init(SecurityBuilder securityBuilder) {
        WebSecurity webSecurity = (WebSecurity) securityBuilder;
        webSecurity.ignoring().anyRequest();
    }

    @Override
    public void configure(SecurityBuilder securityBuilder) {
        //Nothing to initialize
    }
}
