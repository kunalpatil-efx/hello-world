package com.efx.ews.es.i9datasourcing.fieldconverter;

import com.efx.ews.es.i9datasourcing.fieldconverter.Utils.Constants;
import java.util.Map;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor(access = AccessLevel.PACKAGE)
public class I9TypeConverter implements FieldDataConverter {

    private static final String SSN_MESSAGE = "SSN Applied For";
    private final String flattenedI9FormFieldNameToCheck;

    @Override
    public String convert(Map<String, String> flattenedI9Form) {
        return Utils.containsKeyWithTrueValue(flattenedI9Form, (flattenedI9FormFieldNameToCheck)) ? SSN_MESSAGE
            : Constants.DEFAULT_EMPTY_VALUE;
    }
}
