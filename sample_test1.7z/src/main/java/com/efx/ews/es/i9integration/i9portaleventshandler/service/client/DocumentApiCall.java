package com.efx.ews.es.i9integration.i9portaleventshandler.service.client;

import com.efx.ews.es.common.filter.CorrelationFilter;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.document.DocumentApiRequest;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.document.DocumentDownloadResponse;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.document.DocumentUploadResponse;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.logger.MdcReactorLogger;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.webclient.HttpCallClient;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.AbstractRemoteServiceProperties;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.DocumentApiProperties;
import com.google.common.primitives.Bytes;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FilenameUtils;
import org.apache.http.client.utils.URIBuilder;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.reactive.function.BodyExtractors;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.ByteBuffer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Collection;
import java.util.Optional;
import java.util.UUID;

import static java.lang.String.format;

@Slf4j
@Component
@RequiredArgsConstructor
public class DocumentApiCall {

    private final DocumentApiProperties documentApiProperties;
    private final HttpCallClient httpCallClient;

    public Mono<DocumentUploadResponse> uploadDocument(DocumentApiRequest documentApiRequest) {
        log.debug("Uploading the image {} to the document API", documentApiRequest.getDocumentName());
        final URI uri = documentApiProperties.postUploadDocument()
                .queryParam("documentType", documentApiRequest.getDocumentType())
                .queryParam("securityModel", documentApiRequest.getSecurityModel())
                .queryParam("retentionPolicy", documentApiRequest.getRetentionPolicy())
                .queryParam("dataClassification", documentApiRequest.getDataClassification().toString())
                .queryParam("ownerId", documentApiRequest.getOwnerId())
                .queryParam("ownerReferenceId", documentApiRequest.getOwnerReferenceId())
                .queryParam("ownerReferenceVersion", documentApiRequest.getOwnerReferenceVersion())
                .queryParam("documentName", documentApiRequest.getDocumentName())
                .build()
                .toUri();

        MultiValueMap<String, Object> documentToUpload = new LinkedMultiValueMap<>();
        Resource resource = getFile(documentApiRequest.getMultipartFile(),
            documentApiRequest.getMultipartFile().getOriginalFilename());
        documentToUpload.add("file", resource);

        return httpCallClient.doCall(webClient ->
            webClient
                .post()
                .uri(uri)
                .contentType(MediaType.MULTIPART_FORM_DATA)
                .body(BodyInserters.fromMultipartData(documentToUpload))
                .retrieve()
                .bodyToMono(DocumentUploadResponse.class)
                .doOnEach(MdcReactorLogger.logOnNext(clientResponse -> log.info("Document {} created successfully", documentApiRequest.getDocumentName())))
                .doOnEach(clientResponseSignal -> removeTempFile(resource)));
    }

    private Resource getFile(MultipartFile file, String fileName) {
        try {
            Path tempFile = Files.createTempFile(FilenameUtils.getBaseName(fileName), FilenameUtils.getExtension(fileName));
            Files.write(tempFile, file.getBytes());
            return new FileSystemResource(tempFile.toFile());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    private void removeTempFile(Resource resource) {
        try {
            if (resource.getFile().exists()) {
                resource.getFile().delete();
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public Flux<DocumentDownloadResponse> getDocuments(String i9FormId, Collection<String> ids) {
        return Flux.fromIterable(ids).flatMap(id->getDocument( i9FormId, id));
    }

    public Mono<DocumentDownloadResponse> getDocument(String i9FormId, String documentId) {
        final URI uri;
        try {
            final AbstractRemoteServiceProperties.RemoteResource resource = documentApiProperties.getDocument();
            final String id = documentId;
            final DocumentApiProperties properties = documentApiProperties;
            String resourcePath = "";
            if (Optional.ofNullable(id).isPresent()) {
                resourcePath = resource.getPath()
                    + Optional.ofNullable(resource.getOperation()).map(op -> "/" + id + "/" + op).orElse("/" + id);
            } else {
                resourcePath = resource.getPath();
            }
            uri = new URIBuilder()
                .setScheme(properties.getScheme())
                .setHost(properties.getHost())
                .setPort(properties.getPort())
                .setPath(properties.getPath() + "/" + resourcePath)
                .build();
        } catch (URISyntaxException e) {
            throw new IllegalArgumentException(e);
        }
        return Mono.just(uri)
            .doOnEach(MdcReactorLogger.logOnNext(
                uri1 -> log
                    .info("Retrieving document from document-api i9FormId: {} documentId : {}", i9FormId, documentId)))
            .flatMap(uri1 ->
                httpCallClient.doCall(webClient ->
                    webClient
                        .get()
                        .uri(uri)
                        .header(CorrelationFilter.TRANSACTION_ID_HEADER_NAME,
                            CorrelationFilter.getTransactionId().orElse(UUID.randomUUID().toString()))
                        .header(CorrelationFilter.SESSION_ID_HEADER_NAME,
                            CorrelationFilter.getSessionId().orElse(UUID.randomUUID().toString()))
                        .exchange()
                        .doOnEach(MdcReactorLogger.logOnNext(response -> log.debug("Parsing document response from document-api")))
                        .flatMap(this::responseToBytes)
                        .map(documentBytes ->
                            new DocumentDownloadResponse(documentBytes, MediaType.APPLICATION_OCTET_STREAM, documentId))
                        .doOnEach(MdcReactorLogger.logOnError(e -> {
                                WebClientResponseException ex;
                                if (e instanceof WebClientResponseException) {
                                    ex = (WebClientResponseException) e;
                                    String errorMsg = String
                                        .format("Failed to connect to document-api: %s, i9FormId: %s, documentId: %s",
                                            ex.getStatusCode(), i9FormId, documentId);
                                    log.error(errorMsg);
                                } else {
                                    log.error(
                                        format("Failed document-api, i9FormId: %s, documentId: %s", i9FormId, documentId),
                                        e);
                                }
                            })
                        )
                        .doOnEach(MdcReactorLogger.logOnNext(
                            response -> log.info("Success getDocument from document-api, i9FormId: {}, documentId: {}",
                                i9FormId, documentId)))
                ));
    }

    private Mono<byte[]> responseToBytes(ClientResponse response) {
        return response
                .body(BodyExtractors.toDataBuffers())
                .map(dataBuffer -> {
                    ByteBuffer byteBuffer = dataBuffer.asByteBuffer();
                    byte[] byteArray = new byte[byteBuffer.remaining()];
                    byteBuffer.get(byteArray);
                    return byteArray;
                })
                .reduce(Bytes::concat);
    }
}
