package com.efx.ews.es.i9datasourcing.fieldconverter;

import com.efx.ews.es.dto.LocationDto;
import com.efx.ews.es.i9datasourcing.provider.LocationDataProvider;
import reactor.core.publisher.Mono;

public class LocationNameConverter extends AbstractLocationFieldConverter {

    public LocationNameConverter(String employerIdName, String employerLocationIdName,
        LocationDataProvider locationDataProvider) {
        super(employerIdName, employerLocationIdName, locationDataProvider);
    }

    @Override
    protected String getField(Mono<LocationDto> locationMono) {
        return locationMono.map(LocationDto::getLocationName).block();
    }
}
