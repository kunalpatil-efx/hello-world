package com.efx.ews.es.i9datasourcing.fieldconverter;

import static com.efx.ews.es.i9datasourcing.fieldconverter.Utils.Constants.DEFAULT_EMPTY_VALUE;
import static org.apache.commons.lang3.StringUtils.isNotBlank;

import java.util.Map;

class ReverificationFieldConverter extends ReverificationFieldNameConverter {

    ReverificationFieldConverter(String fieldName) {
        super(fieldName);
    }

    @Override
    public String convert(Map<String, String> flattenedI9Form) {
        String fieldName = super.convert(flattenedI9Form);
        if (isNotBlank(fieldName) && isNotBlank(flattenedI9Form.get(fieldName))) {
            return flattenedI9Form.get(fieldName);
        } else {
            return DEFAULT_EMPTY_VALUE;
        }
    }
}