package com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.pubsub.Event;
import reactor.core.publisher.Mono;

public interface I9FormDao {
    Mono<String> updateEvent(String documentId, Event event);
}
