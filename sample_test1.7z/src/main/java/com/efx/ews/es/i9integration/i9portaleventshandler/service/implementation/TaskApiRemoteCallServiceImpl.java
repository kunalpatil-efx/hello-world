package com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation;


import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.Document;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.I9Form;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.I9FormResponse;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.Task;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.event.I9EventPayload;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.pdfGenerator.I9History;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.task.ExtraInformation;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.task.TaskCreateRequest;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.task.TaskResponse;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.I9ApiCall;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.TaskApiProperties.TaskType;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.logger.MdcReactorLogger;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.TaskApiProperties;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import javax.annotation.PostConstruct;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.*;

@Service
@Slf4j
public class TaskApiRemoteCallServiceImpl implements TaskApiRemoteCallService {
    private TaskApiConnector taskApiConnector;
    private final I9ApiCall i9ApiCall;
    private TaskApiProperties taskApiProperties;
    private static final String FORMAT_DATE = "yyyy-MM-dd";
    private static final String DATE_FORMAT_US = "MM/dd/yyyy";

    public TaskApiRemoteCallServiceImpl(TaskApiConnector taskApiConnector, I9ApiCall i9ApiCall,
        TaskApiProperties taskApiProperties) {
        this.taskApiConnector = taskApiConnector;
        this.i9ApiCall = i9ApiCall;
        this.taskApiProperties = taskApiProperties;
    }

    @SneakyThrows
    @PostConstruct
    public void trySetup() {
        int retries = 0;
        Throwable t;
        do {
            t = null;
            try {
                taskApiConnector.checkAndRegisterTaskType();
            } catch (Exception e) {
                log.error("Unable to set-up environment. Retry {}, exception {}", retries++, e);
                t = e;
                final int retryInMilliseconds = 5000;
                Thread.sleep(retryInMilliseconds);
            }
        } while (t != null);
    }

    @Override
    public Mono<Task> createSection2Task(String documentId, I9EventPayload i9FormResponse) {
        log.info("Creating Section 2 Task for {}", documentId);
        TaskCreateRequest tcr = new TaskCreateRequest();
        tcr.setAssociatedEmployerId(UUID.fromString(i9FormResponse.getDocument().getEmployerId()));
        tcr.setDueOnDate(LocalDate.parse(i9FormResponse.getDocument().getProjectedStartDate()).plusDays(2).toString()); // at latest on 3rd day of employment
        tcr.setEmployerPersonFactId(UUID.fromString(i9FormResponse.getDocument().getEmployeeFactId()));
        tcr.setAssociatedLocationId(UUID.fromString(i9FormResponse.getDocument().getEmployerLocationId()));
        tcr.setAssociatedSourceSystemId(documentId);
        return taskApiConnector.createSection2Task(tcr)
                .doOnEach(MdcReactorLogger.logOnNext(task -> log.info("Created Section 2 task: {} for document: {}", task.getTaskId(), documentId)))
                .flatMap(task -> i9ApiCall.createTaskAssociation(documentId, task))
                .doOnEach(MdcReactorLogger.logOnError(e -> log.error("Unable to create Section 2 Task", e)));
    }

    @Override
    public Mono<Task> createSsnAppliedTask(String documentId, I9EventPayload i9FormResponse) {
        log.info("Creating Ssn Applied Task for {}", documentId);
        TaskCreateRequest tcr = new TaskCreateRequest();
        tcr.setAssociatedEmployerId(UUID.fromString(i9FormResponse.getDocument().getEmployerId()));
        tcr.setDueOnDate(LocalDate.parse(i9FormResponse.getDocument().getProjectedStartDate()).plusDays(14).toString()); // 2 weeks from employment
        tcr.setEmployerPersonFactId(UUID.fromString(i9FormResponse.getDocument().getEmployeeFactId()));
        tcr.setAssociatedLocationId(UUID.fromString(i9FormResponse.getDocument().getEmployerLocationId()));
        tcr.setAssociatedSourceSystemId(documentId);
        return taskApiConnector.createSsnAppliedTask(tcr)
                .doOnEach(MdcReactorLogger.logOnNext(task -> log.info("Created SSN Applied task: {} for document: {}", task.getTaskId(), documentId)))
                .flatMap(task -> i9ApiCall.createTaskAssociation(documentId, task))
                .doOnEach(MdcReactorLogger.logOnError(e -> log.error("Unable to create SSN Applied Task", e)));
    }

    @Override
    public boolean isValidContext(String sourceId) {
        return taskApiConnector.isValidContext(sourceId);
    }

    @Override
    public Mono<Task> createSection2DocumentUpload(String documentId, I9EventPayload i9FormResponse) {
        log.info("Creating Section 2 Document Upload Task for {}", documentId);
        TaskCreateRequest tcr = new TaskCreateRequest();
        tcr.setAssociatedEmployerId(UUID.fromString(i9FormResponse.getDocument().getEmployerId()));
        tcr.setDueOnDate(LocalDate.parse(i9FormResponse.getDocument().getProjectedStartDate()).plusDays(365).toString()); // 1 year from employment
        tcr.setEmployerPersonFactId(UUID.fromString(i9FormResponse.getDocument().getEmployeeFactId()));
        tcr.setAssociatedLocationId(UUID.fromString(i9FormResponse.getDocument().getEmployerLocationId()));
        tcr.setAssociatedSourceSystemId(documentId);
        return taskApiConnector.createSection2DocumentUploadTask(tcr)
                .doOnEach(MdcReactorLogger.logOnNext(task -> log.info("Created Section 2 Document Upload Task : {} for document: {}", task.getTaskId(), documentId)))
                .flatMap(task -> i9ApiCall.createTaskAssociation(documentId, task))
                .doOnEach(MdcReactorLogger.logOnError(e -> log.error("Unable to create Section 2 Document Upload Task", e)));
    }

    @Override
    public Mono<Task> createTask(TaskType taskType, String documentId, I9FormResponse i9FormResponse) {
        log.info("Creating task for {}", documentId);
        TaskCreateRequest tcr = new TaskCreateRequest();
        tcr.setAssociatedEmployerId(UUID.fromString(i9FormResponse.getEmployerId()));
        tcr.setDueOnDate(LocalDate.parse(i9FormResponse.getProjectedStartDate()).plusDays(2).toString()); // at latest on 3rd day of employment
        tcr.setEmployerPersonFactId(UUID.fromString(i9FormResponse.getEmployeeFactId()));
        tcr.setAssociatedLocationId(UUID.fromString(i9FormResponse.getEmployerLocationId()));
        tcr.setAssociatedSourceSystemId(documentId);
        return taskApiConnector.createTask(taskType, tcr)
            .doOnSuccess(task -> log.info("Created task: {} for document: {}", task.getTaskId(), documentId))
            .flatMap(task -> i9ApiCall.createTaskAssociation(documentId, task))
            .doOnError(e -> log.error("Unable to create task", e));
    }

    @Override
    public Mono<Task> completeTask(String documentId, Task task, String userId) {
        String s2receiptUpdateType = taskApiProperties.getReceiptUpdateSectionTwo().getCode();
        return Mono.just(task)
            .flatMap(t -> {
                if(s2receiptUpdateType.equalsIgnoreCase(t.getTaskType())) {
                    return i9ApiCall.getHistory(documentId)
                        .filter(Objects::nonNull)
                        .map(i9FormResponses -> {
                            I9History i9History = new I9History(i9FormResponses, null);
                            return i9History.hasReceiptChange();
                        }).defaultIfEmpty(Boolean.FALSE);
                }
                return Mono.just(Boolean.TRUE);
            })
            .flatMap(aBoolean -> {
                return aBoolean ? taskApiConnector.completeTask(task, userId)
                    .flatMap(result -> i9ApiCall.markTaskAsCompleted(documentId, result.getTaskId()))
                    .doOnEach(MdcReactorLogger.logOnNext(
                        ignore -> log.info("Completed tasks {} for i9 with id {}", task.getTaskId(), documentId)))
                    .map(ignore -> task) : Mono.just(task);
            });
    }

    @Override
    public Mono<Task> deleteTask(String documentId, Task task) {
        return taskApiConnector.deleteTask(task.getTaskId())
                .flatMap(result -> i9ApiCall.deleteTask(documentId, result.toString()))
                .doOnEach(MdcReactorLogger.logOnNext(ignore -> log.info("Deleted tasks {} for i9 with id {}", task.getTaskId(), documentId)))
                .map(ignore -> task);
    }

    @Override
    public Mono<TaskResponse> getTask(String taskId) {
        return taskApiConnector.getTask(taskId); }

    @Override
    public Mono<Task> createReceiptUpdateTask(String documentId, I9Form i9FormResponse) {
        log.info("Creating Section 2 Receipt Update Task for {}", documentId);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(FORMAT_DATE);
        TaskCreateRequest tcr = new TaskCreateRequest();
        tcr.setAssociatedEmployerId(UUID.fromString(i9FormResponse.getEmployerId()));
        List<ExtraInformation> extraInformationList = new ArrayList<>();
        Date minimalDate = getExpirationDate(i9FormResponse, extraInformationList);
        tcr.setDueOnDate(minimalDate != null ? simpleDateFormat.format(minimalDate) : "");
        tcr.setEmployerPersonFactId(UUID.fromString(i9FormResponse.getEmployeeFactId()));
        tcr.setAssociatedLocationId(UUID.fromString(i9FormResponse.getEmployerLocationId()));
        tcr.setAssociatedSourceSystemId(documentId);
        tcr.setExtraInformation(extraInformationList);
        return taskApiConnector.createReceiptUpdateTask(tcr)
            .doOnEach(MdcReactorLogger.logOnNext(task -> log.info("Created Section 2 Receipt Update task: {} for document: {}",
                task.getTaskId(),
                documentId)))
            .flatMap(task -> i9ApiCall.createTaskAssociation(documentId, task))
            .doOnEach(MdcReactorLogger.logOnError(e -> log.error("Unable to create Section 2 Receipt Update Task", e)));
    }

    private Date getExpirationDate(I9Form i9FormResponse, List<ExtraInformation> extraInformationList) {
        Date minimumDate = null;
        if (i9FormResponse.getFormData().getSectionTwo() != null) {
                minimumDate = listAMinimumDate(i9FormResponse, minimumDate, extraInformationList);
                minimumDate = listBMinimumDate(i9FormResponse, minimumDate, extraInformationList);
                minimumDate = listCMinimumDate(i9FormResponse, minimumDate, extraInformationList);
            }
        return minimumDate;
    }

    private Date listAMinimumDate(I9Form i9FormResponse, Date minimumDate,
        List<ExtraInformation> extraInformationList){
        if (i9FormResponse.getFormData().getSectionTwo().getListA() != null) {
            minimumDate = checkListADocumentOne(i9FormResponse, minimumDate, extraInformationList);
            minimumDate = checkListADocumentTwo(i9FormResponse, minimumDate, extraInformationList);
            minimumDate = checkListADocumentThree(i9FormResponse, minimumDate, extraInformationList);
        }
        return minimumDate;
    }

    private Date checkListADocumentOne(I9Form i9FormResponse, Date minimumDate,
        List<ExtraInformation> extraInformationList) {
        if (i9FormResponse.getFormData().getSectionTwo().getListA().getDocumentOne() != null
            && i9FormResponse.getFormData().getSectionTwo().getListA().getDocumentOne().getIsReceipt()
            && i9FormResponse.getFormData().getSectionTwo().getListA()
            .getDocumentOne().getExpirationDate() != null) {
            log.info("Expiration date on list A DocumentOne"+ i9FormResponse.getFormData().getSectionTwo().getListA()
                .getDocumentOne().getExpirationDate());
            ExtraInformation extraInformation = getExtraInformationForDocument(i9FormResponse.getFormData()
                .getSectionTwo().getListA().getDocumentOne());
            extraInformationList.add(extraInformation);
            if (minimumDate == null) {
                minimumDate = getExpirationDate(i9FormResponse.getFormData()
                    .getSectionTwo().getListA().getDocumentOne(), null);
            }
        }
        return minimumDate;
    }

    private Date checkListADocumentTwo(I9Form i9FormResponse, Date minimumDate,
        List<ExtraInformation> extraInformationList) {
        if (i9FormResponse.getFormData().getSectionTwo().getListA().getDocumentTwo() != null
            && i9FormResponse.getFormData().getSectionTwo().getListA().getDocumentTwo().getIsReceipt()
            && i9FormResponse.getFormData().getSectionTwo().getListA().getDocumentTwo().getExpirationDate() != null) {
            log.info("Expiration date on list A DocumentTwo");
            minimumDate = getExpirationDate(
                i9FormResponse.getFormData().getSectionTwo().getListA().getDocumentTwo(),
                minimumDate);
            ExtraInformation extraInformation = getExtraInformationForDocument(
                i9FormResponse.getFormData().getSectionTwo().getListA().getDocumentTwo());
            extraInformationList.add(extraInformation);
        }
        return minimumDate;
    }

    private Date checkListADocumentThree(I9Form i9FormResponse, Date minimumDate,
        List<ExtraInformation> extraInformationList) {
        if (i9FormResponse.getFormData().getSectionTwo().getListA().getDocumentThree() != null
            && i9FormResponse.getFormData().getSectionTwo().getListA().getDocumentThree().getIsReceipt()
            && i9FormResponse.getFormData().getSectionTwo().getListA().getDocumentThree().getExpirationDate() != null) {
            log.info("Expiration date on list A DocumentThree");
            minimumDate = getExpirationDate(
                i9FormResponse.getFormData().getSectionTwo().getListA().getDocumentThree(),
                minimumDate);
            ExtraInformation extraInformation = getExtraInformationForDocument(
                i9FormResponse.getFormData().getSectionTwo().getListA().getDocumentThree());
            extraInformationList.add(extraInformation);
        }
        return minimumDate;
    }

    private ExtraInformation getExtraInformationForDocument(Document document) {
        ExtraInformation extraInformation = new ExtraInformation();
        extraInformation.setKey("documentTitle");
        extraInformation.setValue(document.getDocumentTitle());
        return extraInformation;
    }

    private Date listCMinimumDate(I9Form i9FormResponse, Date minimumDate,
        List<ExtraInformation> extraInformationList) {
        if (i9FormResponse.getFormData().getSectionTwo().getListC() != null
            && i9FormResponse.getFormData().getSectionTwo().getListC().getDocumentOne() != null
            && i9FormResponse.getFormData().getSectionTwo().getListC().getDocumentOne().getIsReceipt()
            && i9FormResponse.getFormData().getSectionTwo().getListC().getDocumentOne().getExpirationDate() != null) {
            log.info("Expiration date on list C DocumentOne");
            minimumDate = getExpirationDate(
                i9FormResponse.getFormData().getSectionTwo().getListC().getDocumentOne()
                , minimumDate);
            ExtraInformation extraInformation = getExtraInformationForDocument(
                i9FormResponse.getFormData().getSectionTwo().getListC().getDocumentOne());
            extraInformationList.add(extraInformation);
        }
        return minimumDate;
    }

    private Date listBMinimumDate(I9Form i9FormResponse,
        Date minimumDate,
        List<ExtraInformation> extraInformationList) {
        if (i9FormResponse.getFormData().getSectionTwo().getListB() != null
            && i9FormResponse.getFormData().getSectionTwo().getListB().getDocumentOne() != null
            && i9FormResponse.getFormData().getSectionTwo().getListB().getDocumentOne().getIsReceipt()
            && i9FormResponse.getFormData().getSectionTwo().getListB().getDocumentOne().getExpirationDate() != null) {
            log.info("Expiration date Check on list B DocumentOne");
            minimumDate = getExpirationDate(
                i9FormResponse.getFormData().getSectionTwo().getListB().getDocumentOne(),
                minimumDate);
            ExtraInformation extraInformation = getExtraInformationForDocument(
                i9FormResponse.getFormData().getSectionTwo().getListB().getDocumentOne());
            extraInformationList.add(extraInformation);
        }
        return minimumDate;
    }

    private Date getExpirationDate(Document document,
        Date minimumDate) {
        String documentExpirationDate = document.getExpirationDate();
        if (minimumDate != null) {
            Date calculatedDate = formatConversion(documentExpirationDate);
            if (minimumDate.after(calculatedDate)) {
                minimumDate = calculatedDate;
            }
        } else {
            minimumDate = formatConversion(documentExpirationDate);
        }
        return minimumDate;
    }

    private Date formatConversion(String date) {
        try {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(DATE_FORMAT_US);
            Date formatDate = simpleDateFormat.parse(date);
            SimpleDateFormat dateFormat = new SimpleDateFormat(FORMAT_DATE);
            log.info("Formatting the value in dateFormat");
            return dateConversion(dateFormat.format(formatDate));
        } catch (ParseException ex) {
            return dateConversion(date);
        }
    }

    private Date dateConversion(String date) {
        try {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(FORMAT_DATE);
            Date formatDate = simpleDateFormat.parse(date);
            log.info("Formatting the value in dateConversion value");
            return formatDate;
        } catch (Exception ex) {
            log.error("Error when formatting date for expiration date for receipt document" + ex);
            return null;
        }
    }
}
