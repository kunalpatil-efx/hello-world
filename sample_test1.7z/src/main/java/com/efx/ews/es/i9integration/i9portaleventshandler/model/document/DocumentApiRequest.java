package com.efx.ews.es.i9integration.i9portaleventshandler.model.document;

import lombok.Builder;
import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

@Builder
@Data
public class DocumentApiRequest {
    private String documentType;
    private String securityModel;
    private String retentionPolicy;
    private String ownerId;
    private String ownerReferenceId;
    private String ownerReferenceVersion;
    private String documentName;
    private Integer dataClassification;
    private MultipartFile multipartFile;
}
