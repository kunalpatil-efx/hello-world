package com.efx.ews.es.i9integration.i9portaleventshandler.service.properties;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "reference-api")
@Data
@EqualsAndHashCode(callSuper = true)
public class ReferenceApiProperties extends AbstractRemoteServiceProperties {

    private String i9Version;
    private String evVersion;

    RemoteResource states;
    RemoteResource countries;
    RemoteResource provinces;
    RemoteResource documents;

}
