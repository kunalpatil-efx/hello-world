package com.efx.ews.es.i9datasourcing.processor.auditdetail.i9formhistory;

import static java.lang.String.format;

import com.efx.ews.es.i9datasourcing.model.ChangeContext;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
class SectionDescriptionProvider {

    public static final String SECTION_1_INITIATED_MESSAGE = "Section 1 initiated";
    public static final String SECTION_COMPLETED_MESSAGE = "Section %s Data Entered \"%s\"-\"%s\"";
    public static final String SECTION_AMENDED_MESSAGE = "Section %s Data Updated \"%s\" - from \"%s\" to \"%s\"";

    public String createDescription(FieldDiff fieldDiff, ChangeContext changeContext) {
        final String description;
        switch (changeContext.getI9Event()) {
            case FORM_CREATED:
                description = SECTION_1_INITIATED_MESSAGE;
                break;
            case SECTION_1_COMPLETE:
                description = format(SECTION_COMPLETED_MESSAGE, 1, fieldDiff.getFieldName(), fieldDiff.getValueAfter());
                break;
            case SECTION_1_AMENDED:
                description = format(SECTION_AMENDED_MESSAGE, 1, fieldDiff.getFieldName(), fieldDiff.getValueBefore(),
                    fieldDiff.getValueAfter());
                break;
            case SECTION_2_COMPLETE:
                description = format(SECTION_COMPLETED_MESSAGE, 2, fieldDiff.getFieldName(), fieldDiff.getValueAfter());
                break;
            case SECTION_2_AMENDED:
                description = format(SECTION_AMENDED_MESSAGE, 2, fieldDiff.getFieldName(), fieldDiff.getValueBefore(),
                    fieldDiff.getValueAfter());
                break;
            case SECTION_3_COMPLETE:
                description = format(SECTION_COMPLETED_MESSAGE, 3, fieldDiff.getFieldName(), fieldDiff.getValueAfter());
                break;
            default:
                throw new IllegalArgumentException(changeContext.getI9Event().name());
        }
        return description;
    }
}
