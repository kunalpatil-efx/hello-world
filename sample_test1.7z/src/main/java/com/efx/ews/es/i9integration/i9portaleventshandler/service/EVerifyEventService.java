package com.efx.ews.es.i9integration.i9portaleventshandler.service;

import org.springframework.messaging.Message;

public interface EVerifyEventService {
    void handleMessage(Message<?> message);
}
