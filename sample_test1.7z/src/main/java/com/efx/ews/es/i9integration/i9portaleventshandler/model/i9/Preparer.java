package com.efx.ews.es.i9integration.i9portaleventshandler.model.i9;

import lombok.Data;

@Data
public class Preparer {
    private String firstName;
    private String lastName;
    private String address;
    private String city;
    private String state;
    private String zipCode;
    private SignatureData signature;
    private Long recordVersion;
}

