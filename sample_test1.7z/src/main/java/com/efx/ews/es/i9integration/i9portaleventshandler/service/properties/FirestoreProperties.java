package com.efx.ews.es.i9integration.i9portaleventshandler.service.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "firestore")
@Data
public class FirestoreProperties {

    private String projectId;

    private Collections collections;

    @Data
    public static class Collections {
        private String i9forms;
        private String audits;
        private String events;
    }
}
