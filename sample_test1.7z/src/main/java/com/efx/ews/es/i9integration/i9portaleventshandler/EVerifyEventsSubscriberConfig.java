package com.efx.ews.es.i9integration.i9portaleventshandler;

import com.efx.ews.es.i9integration.i9portaleventshandler.service.EVerifyEventService;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.logger.MdcSetting;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gcp.pubsub.core.PubSubTemplate;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;

import static com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageConfirmation.manualAckMessageChannel;

@Configuration
@Slf4j
public class EVerifyEventsSubscriberConfig {

    private final EVerifyEventService eventService;

    public EVerifyEventsSubscriberConfig(EVerifyEventService eventService) {
        this.eventService = eventService;
    }

    @Bean("EVerifyEventsSubscriber")
    IntegrationFlow subscriberFlow(PubSubTemplate pubSubTemplate,
                                   @Value("${subscription.eVerifyEvent}") String subscription) {
        return IntegrationFlows
                .from(manualAckMessageChannel(pubSubTemplate, subscription))
                .handle(msg -> MdcSetting.wrapWithHeaders(msg, eventService::handleMessage))
                .get();
    }
}
