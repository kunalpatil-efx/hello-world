package com.efx.ews.es.i9datasourcing.provider;

import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;

@Profile("mocked")
@Component
public class CountryCodeProviderMock implements CountryCodeProvider {

    @Override
    public String getCountryCode(String countryName) {
        return "POL";
    }
}
