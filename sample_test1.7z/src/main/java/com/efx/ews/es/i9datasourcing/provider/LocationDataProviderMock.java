package com.efx.ews.es.i9datasourcing.provider;

import com.efx.ews.es.dto.LocationDto;
import java.util.UUID;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

@Profile("mocked")
@Component
public class LocationDataProviderMock implements LocationDataProvider {

    @Override
    public Mono<LocationDto> getLocation(UUID employerId, UUID locationId) {
        return Mono.just(new LocationDto()
            .setLocationId(locationId)
            .setLocationCode("NC27954")
            .setLocationName("Manteo Office")
            .setAddressLine1("15-12 Hammock Dr")
            .setCity("Manteo, NC")
            .setStateCode("NC")
            .setPostalCode("27954")
            .setPrimary(true)
            .setActive(true)
            .setEverifyEnabled(true));
    }
}
