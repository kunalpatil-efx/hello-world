package com.efx.ews.es.i9integration.i9portaleventshandler.service.client;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.employer.person.EmployeeForFactId;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.logger.MdcReactorLogger;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.webclient.HttpCallClient;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.EmployerPersonApiProperties;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.net.URI;

import static java.lang.String.format;

@Slf4j
@Component
@RequiredArgsConstructor
public class EmployerPersonCall {

    private final HttpCallClient httpCallClient;
    private final EmployerPersonApiProperties employerPersonApiProperties;

    public Mono<EmployeeForFactId> getEmployeeByFactId(String factId) {
        final URI uri = employerPersonApiProperties.getByFactId().buildAndExpand(factId).toUri();
        return httpCallClient.doCall(webClient ->
            webClient
                .get()
                .uri(uri)
                .retrieve()
                .bodyToMono(EmployeeForFactId.class)
                .doOnEach(MdcReactorLogger.logOnNext(employeeForFactId -> log.info("Retrieved employee id {} for fact id {}",
                    employeeForFactId == null ? null : employeeForFactId.getEmployeeId(),
                    factId))
                )
                .doOnEach(MdcReactorLogger.logOnError(ex -> log.error(format("Failed getEmployeeByFactId factId: %s", factId), ex)))
        );
    }
}
