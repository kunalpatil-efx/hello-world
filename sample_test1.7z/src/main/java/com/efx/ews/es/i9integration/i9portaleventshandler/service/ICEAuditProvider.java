package com.efx.ews.es.i9integration.i9portaleventshandler.service;

import com.efx.ews.es.eev.barricade.common.exceptions.EncryptionException;
import com.efx.ews.es.eev.barricade.common.service.CryptographyService;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.audit.AuditMessage;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.audit.IceAuditEntry;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.event.I9EventAuditData;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.event.I9EventPayload;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.I9ApiCall;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.logger.MdcReactorLogger;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.util.Base64;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.function.Predicate;

@Component
@AllArgsConstructor
@Slf4j
public class ICEAuditProvider {

    private static final Set<String> MATCHING_EVENTS = Set.of(
            "PDF_Generated",
            "Data_Accessed_Employee",
            "Data_Confirmed",
            "welcome_email");

    private final CryptographyService crypto;
    private final I9ApiCall i9ApiCall;
    private final AuditDataFeed auditFeed;

    private final ObjectMapper converter = new ObjectMapper();

    public Mono<List<IceAuditEntry>> getIceEntries(String documentId, String sourceRefId) {
        return Flux.concat(
                    i9ApiCall.getIceEntries(documentId).flatMapMany(Flux::fromIterable),
                    getFromAuditData(sourceRefId))
                .sort(Comparator.comparing(IceAuditEntry::getDate).thenComparing(IceAuditEntry::getAction))
                .collectList();
    }

    private Flux<IceAuditEntry> getFromAuditData(String sourceRefId) {
        return auditFeed.fetchAuditData(sourceRefId)
                .flatMapMany(Flux::fromIterable)
                .filter(Objects::nonNull)
                .map(AuditMessage::getData)
                .map(Base64.getDecoder()::decode)
                .flatMap(bytes -> {
                    try {
                        return Mono.just(converter.readValue(bytes, I9EventPayload.class));
                    } catch (IOException e) {
                        return Mono.error(e);
                    }
                })
                .map(I9EventPayload::getAudit)
                .filter(interestingEventsFilter())
                .flatMap(this::mapAuditMessage);
    }

    private Predicate<I9EventAuditData> interestingEventsFilter() {
        return auditData -> MATCHING_EVENTS.contains(auditData.getEventKey());
    }

    private Mono<IceAuditEntry> mapAuditMessage(I9EventAuditData auditData) {
        try {
            IceAuditEntry entry = new IceAuditEntry();
            entry.setAction(auditData.getEventDescription());
            entry.setDate(auditData.getDate());
            entry.setSourceIp(crypto.decrypt(auditData.getSourceIp()));
            if (entry.getSourceIp() == null) entry.setSourceIp("N/A");
            entry.setUser(crypto.decrypt(auditData.getSource()));
            if (entry.getUser() == null) entry.setUser("N/A");
            return Mono.just(entry);
        } catch (EncryptionException e) {
            return Mono.error(e);
        }
    }
}
