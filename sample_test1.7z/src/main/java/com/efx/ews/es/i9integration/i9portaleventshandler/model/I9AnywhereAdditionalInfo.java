package com.efx.ews.es.i9integration.i9portaleventshandler.model;

import com.fasterxml.jackson.annotation.JsonValue;

public enum I9AnywhereAdditionalInfo {
    PACKET_CANCELED("PacketCanceled"),
    FLIP_TO_ONSITE("FlipToOnsite"),
    FLIP_TO_REMOTE("FlipToRemote"),
    NONE("None");

    private final String value;

    I9AnywhereAdditionalInfo(String value) {
        this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
        return String.valueOf(value);
    }

    public boolean equals(String status) {
        return this.value.equals(status);
    }

    public boolean equalsIgnoreCase(String value) {
        return this.value.equalsIgnoreCase(value);
    }

    public static I9AnywhereAdditionalInfo convertFromName(String value) {
        for (I9AnywhereAdditionalInfo additionalInfo : I9AnywhereAdditionalInfo.values()) {
            if (additionalInfo.equalsIgnoreCase(value)) {
                return additionalInfo;
            }
        }
        return I9AnywhereAdditionalInfo.NONE;
    }
}
