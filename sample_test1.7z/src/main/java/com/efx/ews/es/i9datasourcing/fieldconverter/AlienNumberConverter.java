package com.efx.ews.es.i9datasourcing.fieldconverter;

import com.efx.ews.es.i9datasourcing.fieldconverter.Utils.Constants;
import java.util.Map;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
class AlienNumberConverter implements FieldDataConverter {

    static final AlienNumberConverter INSTANCE = new AlienNumberConverter();

    @Override
    public String convert(Map<String, String> flattenedI9Form) {
        if (Utils
            .containsKeyWithTrueValue(flattenedI9Form, "formData.sectionOne.attestation.isAlienAuthorizedToWork")) {
            return flattenedI9Form
                .getOrDefault("formData.sectionOne.attestation.alienAuthorizedToWorkData.alienRegistrationNumber",
                    Constants.DEFAULT_EMPTY_VALUE);
        } else if (Utils
            .containsKeyWithTrueValue(flattenedI9Form, "formData.sectionOne.attestation.isLawfulPermanentResident")) {
            return flattenedI9Form
                .getOrDefault("formData.sectionOne.attestation.lawfulPermanentResidentInfo.alienRegistrationNumber",
                    Constants.DEFAULT_EMPTY_VALUE);
        }

        return Constants.DEFAULT_EMPTY_VALUE;
    }
}