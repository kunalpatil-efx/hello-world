package com.efx.ews.es.i9datasourcing.fieldconverter;

import java.util.Map;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor(access = AccessLevel.PACKAGE)
class StaticFieldNameConverter implements FieldDataConverter {

    private final String flattenedI9FormFieldName;

    @Override
    public String convert(Map<String, String> flattenedI9Form) {
        return flattenedI9FormFieldName;
    }
}
