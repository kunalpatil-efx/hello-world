package com.efx.ews.es.i9integration.i9portaleventshandler.service.client.logger;

import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.I9HeaderBuilder;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.slf4j.MDC;
import org.springframework.cloud.gcp.pubsub.support.AcknowledgeablePubsubMessage;
import org.springframework.messaging.Message;

import java.util.Map;
import java.util.Set;
import java.util.function.Consumer;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class MdcSetting {
    public static void setFromMessage(AcknowledgeablePubsubMessage message) {
        Map<String, String> headers = I9HeaderBuilder.build(message.getPubsubMessage());
        addHeaders(headers);
    }

    public static void remove() {
        removeHeaders(I9HeaderBuilder.HEADERS_NAME);
    }

    public static void wrapWithHeaders(Message<?> message, Consumer<Message<?>> statement) {
        Map<String, String> headers = I9HeaderBuilder.build(message);
        addHeaders(headers);
        statement.accept(message);
        removeHeaders(headers);
    }

    public static void wrapWithHeaders(Message<?> message, Runnable statement) {
        Map<String, String> headers = I9HeaderBuilder.build(message);
        addHeaders(headers);
        statement.run();
        removeHeaders(headers);
    }

    private static void addHeaders(Map<String, String> headers) {
        headers.forEach(MDC::put);
    }

    private static void removeHeaders(Map<String, String> headers) {
        removeHeaders(headers.keySet());
    }

    private static void removeHeaders(Set<String> headers) {
        headers.forEach(MDC::remove);
    }
}
