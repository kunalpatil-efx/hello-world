package com.efx.ews.es.i9integration.i9portaleventshandler;

import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.I9ApiCall;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.I9HeaderBuilder;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.logger.MdcSetting;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.configuration.PubSubProperties;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.BillingService;
import com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageConfirmation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gcp.pubsub.core.PubSubTemplate;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.dsl.RouterSpec;
import org.springframework.integration.router.MethodInvokingRouter;
import org.springframework.messaging.Message;
import reactor.core.publisher.Mono;
import reactor.util.context.Context;

import static com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageConfirmation.manualAckMessageChannel;

@Configuration
@Slf4j
public class BillingSubscriberConfig {

    private final I9ApiCall i9ApiCall;
    private final MessageConfirmation messageConfirmation;
    private final BillingService service;
    private final PubSubProperties pubSubProperties;

    public BillingSubscriberConfig(BillingService service,
                                   MessageConfirmation messageConfirmation,
                                   I9ApiCall i9ApiCall,
                                   PubSubProperties pubSubProperties) {
        this.service = service;
        this.messageConfirmation = messageConfirmation;
        this.i9ApiCall = i9ApiCall;
        this.pubSubProperties = pubSubProperties;
    }

    @Bean("BillingSubscriberConfig")
    IntegrationFlow subscriberFlow(
            PubSubTemplate pubSubTemplate,
            @Value("${subscription.billing}") String subscription) {
        return IntegrationFlows
                .from(manualAckMessageChannel(pubSubTemplate, subscription))
                .route(Message.class, this::shouldExecute, this::routeMessage)
                .get();
    }

    private void routeMessage(RouterSpec<Boolean, MethodInvokingRouter> mapping) {
        mapping.subFlowMapping(Boolean.TRUE, sf -> sf.handle(msg -> MdcSetting.wrapWithHeaders(msg, this::handleMessage)))
            .subFlowMapping(Boolean.FALSE, sf -> sf.handle(msg -> MdcSetting.wrapWithHeaders(msg, this::noBillingForThisMessage)));
    }

    void noBillingForThisMessage(Message<?> message) {
        log.info("BillingSubscriberConfig filtered out {}", message.getHeaders().get("documentId", String.class));
        messageConfirmation.acknowledge(message);
    }

    void handleMessage(Message<?> message) {
        log.info("received message: {}", message);
        String i9Id = message.getHeaders().get("documentId", String.class);

        Mono.just(i9Id)
                .flatMap(i9ApiCall::getForm)
                .flatMap(service::createBillableEvent)
                .doOnSuccess(ignore -> {
                    log.info("Successfully billed for document {}.", i9Id);
                    messageConfirmation.acknowledge(message);
                })
                .onErrorResume(e -> {
                    log.error("Unable to process billing message for {} due to error: {}", i9Id, e.getMessage(), e);
                    messageConfirmation.nAcknowledge(message);
                    return Mono.empty();
                })
                .subscriberContext(Context.of(I9HeaderBuilder.build(message)))
                .block();
    }

    boolean shouldExecute(Message<?> message) {
        return pubSubProperties.isEnabled()
                && "Section2_Complete".equalsIgnoreCase(message.getHeaders().get("status", String.class))
                && !("packet-ui-I9ANYWHERE".equalsIgnoreCase(message.getHeaders().get("sourceId", String.class)));
    }
}
