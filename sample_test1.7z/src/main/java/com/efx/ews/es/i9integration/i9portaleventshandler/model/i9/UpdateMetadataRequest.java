package com.efx.ews.es.i9integration.i9portaleventshandler.model.i9;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class UpdateMetadataRequest {
    private String employeeId;
    private String factIdToEmployeeIdSyncDate;
    private String documentApiDocumentId;
    private String documentApiAuditId;
    private String documentApiRevisionId; // TODO: Change this to a list / array so we can send multiple at once.
}
