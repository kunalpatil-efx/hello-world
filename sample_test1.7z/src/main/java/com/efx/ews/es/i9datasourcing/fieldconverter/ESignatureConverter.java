package com.efx.ews.es.i9datasourcing.fieldconverter;

import com.efx.ews.es.i9datasourcing.fieldconverter.Utils.Constants;
import java.util.Map;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor(access = AccessLevel.PACKAGE)
class ESignatureConverter implements FieldDataConverter {

    private static final String E_SIGNATURE_MESSAGE = "E-signature";
    private final String flattenedI9FormFieldNameToCheck;

    @Override
    public String convert(Map<String, String> flattenedI9Form) {
        if (Utils.containsKeyWithNotBlankValue(flattenedI9Form, flattenedI9FormFieldNameToCheck)) {
            return E_SIGNATURE_MESSAGE;
        } else {
            return Constants.DEFAULT_EMPTY_VALUE;
        }
    }
}