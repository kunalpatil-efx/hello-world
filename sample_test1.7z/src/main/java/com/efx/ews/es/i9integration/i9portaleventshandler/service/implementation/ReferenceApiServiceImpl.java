package com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.Document;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.referenceapi.IssuingAuthorityLookup;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiFunction;
import javax.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Slf4j
@Service
public class ReferenceApiServiceImpl implements ReferenceApiService {

    private final ReferenceApiConnector connector;
    private final Map<String, BiFunction<Document, String, Mono<Document>>> codeResolvers = new HashMap<>();

    @Autowired
    public ReferenceApiServiceImpl(ReferenceApiConnector connector) {
        this.connector = connector;
    }

    @PostConstruct
    public void initialize() {
        codeResolvers.put("states", this::updateStateName);
        codeResolvers.put("provinces", this::updateProvinceName);
        codeResolvers.put("countries", this::updateCountryName);
    }

    @Override
    public Mono<List<Document>> updateIssuingAuthorityByTitle(Map<String, IssuingAuthorityLookup>lookupMap,
        List<Document> documents, String i9Version) {
        return Flux.fromStream(documents.stream())
            .flatMap(document -> {
                String title = document.getDocumentTitle();
                IssuingAuthorityLookup lookup =  lookupMap.get(title);
                if (lookup != null && codeResolvers.containsKey(lookup.getIssuingAuthorityType())) {
                    return codeResolvers.get(lookup.getIssuingAuthorityType()).apply(document, i9Version);
                } else {
                    return Mono.just(document);
                }
            }).collectList();
    }

    @Override
    public Mono<Map<String, IssuingAuthorityLookup>> getIssuingAuthorityMapByTitle(String i9Version) {
        return connector.getIssuingAuthorityMap(i9Version);
    }

    private Mono<Document> updateStateName(final Document document, final String i9Version) {
        final String code = document.getIssuingAuthority();
        return getStateName(code, i9Version)
            .map(name -> update(document, code, name, "state"));
    }

    private Mono<Document> updateCountryName(final Document document, final String i9Version) {
        final String code = document.getIssuingAuthority();
        return getCountryName(code, i9Version)
            .map(name -> update(document, code, name, "country"));
    }

    private Mono<Document> updateProvinceName(final Document document, final String i9Version) {
        final String code = document.getIssuingAuthority();
        return getProvinceName(code, i9Version)
            .map(name -> update(document, code, name, "province"));
    }

    @Override
    public Mono<String> getStateName(String stateCode, String i9Version) {
        return connector.getStateCodeMap(i9Version)
            .map(stateCodeMap -> stateCodeMap != null && stateCodeMap.get(stateCode) != null ?
                stateCodeMap.get(stateCode).getName() : "");
    }

    @Override
    public Mono<String> getCountryName(String countryCode, String i9Version) {
        return connector.getCountryCodeMap(i9Version)
            .map(countryCodeMap -> countryCodeMap != null && countryCodeMap.get(countryCode) != null ?
                countryCodeMap.get(countryCode).getName() : "");
    }

    @Override
    public Mono<String> getProvinceName(String provinceCode, String i9Version) {
        return connector.getProvinceCodeMap(i9Version)
            .map(provinceCodeMap -> provinceCodeMap != null && provinceCodeMap.get(provinceCode) != null ?
                provinceCodeMap.get(provinceCode).getName() : "");
    }

    private Document update(Document document, String code, String name, String type) {
        if(StringUtils.isNotBlank(name)) {
            log.info("Updated {} code {} to {}", type, code, name);
            document.setIssuingAuthority(String.format("%s - %s", name, code));
        } else {
            log.info("Unable to find name for {} code {}", type, code);
        }
        return document;
    }
}
