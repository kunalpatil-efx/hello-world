package com.efx.ews.es.i9datasourcing.fieldconverter;

import static java.util.Arrays.asList;

import com.efx.ews.es.i9datasourcing.formatter.Formatters;
import com.efx.ews.es.i9datasourcing.formatter.TemporalFormatter;
import com.efx.ews.es.i9datasourcing.model.ChangeContext;
import com.efx.ews.es.i9datasourcing.provider.CountryCodeProvider;
import com.efx.ews.es.i9datasourcing.provider.LocationDataProvider;
import com.google.common.collect.ImmutableMap;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
class I9FormFieldConverterConfigProviderImpl implements I9FormFieldConverterConfigProvider {

    private static final String DOCUMENT_NUMBER = "Document Number";
    private static final String EXPIRATION_DATE = "Expiration Date";
    private static final String ISSUING_AUTHORITY = "Issuing Authority";
    private static final String IS_RECEIPT = "Is Receipt";

    private final LocationDataProvider locationDataProvider;
    private final CountryCodeProvider countryCodeProvider;
    private final TemporalFormatter temporalFormatter;

    @Override
    public Map<String, FieldDataConverter> provideConfig(ChangeContext changeContext) {
        return ImmutableMap.<String, FieldDataConverter>builder()
            .put("GROUP_CODE", BlankConverter.INSTANCE)
            .put("LOCATION_CODE", new NoChangeConverter("employerLocationId"))
            .put("I9_EMPLOYER_ID", new StaticFieldNameConverter(changeContext.getEmployerId()))
            .put("LOCATION_NAME", new LocationNameConverter("employerId", "employerLocationId", locationDataProvider))
            .put("SECTION_ONE.EMPLOYEE_INFO.SSN",
                new NoChangeConverter("formData.sectionOne.employeeInfo.socialSecurityNumber"))
            .put("SECTION_ONE.EMPLOYEE_INFO.FIRST_NAME",
                new NoChangeConverter("formData.sectionOne.employeeInfo.firstName"))
            .put("SECTION_ONE.EMPLOYEE_INFO.LAST_NAME",
                new NoChangeConverter("formData.sectionOne.employeeInfo.lastName"))
            .put("SECTION_ONE.EMPLOYEE_INFO.MI",
                new NoChangeConverter("formData.sectionOne.employeeInfo.middleInitial"))
            .put("SECTION_ONE.EMPLOYEE_INFO.OTHER_NAMES_USED",
                new NoChangeConverter("formData.sectionOne.employeeInfo.otherLastName"))
            .put("SECTION_ONE.EMPLOYEE_INFO.DATE_OF_BIRTH",
                new DateConverter("formData.sectionOne.employeeInfo.dateOfBirth"))
            .put("SECTION_ONE.EMPLOYEE_INFO.E_MAIL_ADDRESS",
                new NoChangeConverter("formData.sectionOne.employeeInfo.email"))
            .put("SECTION_ONE.EMPLOYEE_INFO.TELEPHONE_NUMBER",
                new NoChangeConverter("formData.sectionOne.employeeInfo.telephoneNumber"))
            .put("SECTION_ONE.ATTESTATION.IMMIGRATION_STATUS", ImmigrationStatusConverter.INSTANCE)
            .put("SECTION_ONE.ATTESTATION.ALIEN_NUMBER", AlienNumberConverter.INSTANCE)
            .put("SECTION_ONE.ATTESTATION.WORK_EXPIRATION_DATE",
                new DateConverter("formData.sectionOne.attestation.alienAuthorizedToWorkData.expirationDate"))
            .put("SECTION_ONE.ATTESTATION.I94_NUMBER",
                new NoChangeConverter(
                    "formData.sectionOne.attestation.alienAuthorizedToWorkData.formI94AdmissionNumber"))
            .put("SECTION_ONE.ATTESTATION.SECTION_1_FOREIGN_PASSPORT_NUMBER",
                new NoChangeConverter(
                    "formData.sectionOne.attestation.alienAuthorizedToWorkData.foreignPassportObject.number"))
            .put("SECTION_ONE.ATTESTATION.SECTION_1_FOREIGN_PASSPORT_COUNTRY", new NoChangeConverter(
                "formData.sectionOne.attestation.alienAuthorizedToWorkData.foreignPassportObject.countryOfIssuance"))
            .put("SECTION_ONE.ATTESTATION.SECTION_1_FOREIGN_PASSPORT_COUNTRY_CODE",
                new CountryCodeConverter(countryCodeProvider,
                    "formData.sectionOne.attestation.alienAuthorizedToWorkData.foreignPassportObject.countryOfIssuance"))
            .put("SECTION_ONE.EMPLOYEE_INFO.SSN_APPLIED_FOR", new NoChangeConverter("formData.ssnApplied"))
            .put("SECTION_ONE.EMPLOYEE_INFO.SSN_NOT_SUPPLIED", SsnNotSuppliedConverter.INSTANCE)
            .put("SECTION_ONE.EMPLOYEE_INFO.ADDRESS_LINE_1",
                new NoChangeConverter("formData.sectionOne.employeeInfo.address"))
            .put("SECTION_ONE.EMPLOYEE_INFO.ADDRESS_LINE_2", BlankConverter.INSTANCE)
            .put("SECTION_ONE.EMPLOYEE_INFO.APARTMENT_NUMBER",
                new NoChangeConverter("formData.sectionOne.employeeInfo.apartmentNumber"))
            .put("SECTION_ONE.EMPLOYEE_INFO.CITY", new NoChangeConverter("formData.sectionOne.employeeInfo.city"))
            .put("SECTION_ONE.EMPLOYEE_INFO.STATE_PROVINCE",
                new NoChangeConverter("formData.sectionOne.employeeInfo.state"))
            .put("SECTION_ONE.EMPLOYEE_INFO.ZIP_POSTAL_CODE",
                new NoChangeConverter("formData.sectionOne.employeeInfo.zipCode"))
            .put("SECTION_ONE.EMPLOYEE_INFO.I9_ENTRY_DATE", new DateTimeConverter("formData.sectionOne.date"))
            .put("SECTION_ONE.EMPLOYEE_INFO.SIGNATURE.SIGNATURE_DATE",
                new DateTimeToDateConverter("formData.sectionOne.signature.date"))
            .put("SECTION_ONE.EMPLOYEE_INFO.SIGNATURE.SIGNATURE_METHOD",
                new ESignatureConverter("formData.sectionOne.signature.date"))
            .put("SECTION_ONE.PREPARERS.PREPARER_ONE.NAME",
                new MergingPreparerConverter(
                    asList("formData.sectionOne.preparers.firstName", "formData.sectionOne.preparers.lastName"), 0))
            .put("SECTION_ONE.PREPARERS.PREPARER_ONE.ADDRESS_1",
                new PreparerConverter("formData.sectionOne.preparers.address", 0))
            .put("SECTION_ONE.PREPARERS.PREPARER_ONE.ADDRESS_2", BlankConverter.INSTANCE)
            .put("SECTION_ONE.PREPARERS.PREPARER_ONE.CITY",
                new PreparerConverter("formData.sectionOne.preparers.city", 0))
            .put("SECTION_ONE.PREPARERS.PREPARER_ONE.STATE_PROVINCE",
                new PreparerConverter("formData.sectionOne.preparers.state", 0))
            .put("SECTION_ONE.PREPARERS.PREPARER_ONE.ZIP_POSTAL_CODE",
                new PreparerConverter("formData.sectionOne.preparers.zipCode", 0))
            .put("SECTION_ONE.PREPARERS.PREPARER_ONE.SIGNATURE.SIGNATURE_DATE",
                new PreparerDateTimeToDateConverter("formData.sectionOne.preparers.signature.date", 0))
            .put("SECTION_ONE.PREPARERS.PREPARER_ONE.SIGNATURE.SIGNATURE_METHOD",
                new ESignaturePreparerConverter("formData.sectionOne.preparers.signature.date", 0))
            .put("SECTION_ONE.PREPARERS.PREPARER_TWO.NAME",
                new MergingPreparerConverter(
                    asList("formData.sectionOne.preparers.firstName", "formData.sectionOne.preparers.lastName"), 1))
            .put("SECTION_ONE.PREPARERS.PREPARER_TWO.ADDRESS_1",
                new PreparerConverter("formData.sectionOne.preparers.address", 1))
            .put("SECTION_ONE.PREPARERS.PREPARER_TWO.ADDRESS_2", BlankConverter.INSTANCE)
            .put("SECTION_ONE.PREPARERS.PREPARER_TWO.CITY",
                new PreparerConverter("formData.sectionOne.preparers.city", 1))
            .put("SECTION_ONE.PREPARERS.PREPARER_TWO.STATE_PROVINCE",
                new PreparerConverter("formData.sectionOne.preparers.state", 1))
            .put("SECTION_ONE.PREPARERS.PREPARER_TWO.ZIP_POSTAL_CODE",
                new PreparerConverter("formData.sectionOne.preparers.zipCode", 1))
            .put("SECTION_ONE.PREPARERS.PREPARER_TWO.SIGNATURE.SIGNATURE_DATE",
                new PreparerDateTimeToDateConverter("formData.sectionOne.preparers.signature.date", 1))
            .put("SECTION_ONE.PREPARERS.PREPARER_TWO.SIGNATURE.SIGNATURE_METHOD",
                new ESignaturePreparerConverter("formData.sectionOne.preparers.signature.date", 1))
            .put("SECTION_ONE.PREPARERS.PREPARER_THREE.NAME",
                new MergingPreparerConverter(
                    asList("formData.sectionOne.preparers.firstName", "formData.sectionOne.preparers.lastName"), 2))
            .put("SECTION_ONE.PREPARERS.PREPARER_THREE.ADDRESS_1",
                new PreparerConverter("formData.sectionOne.preparers.address", 2))
            .put("SECTION_ONE.PREPARERS.PREPARER_THREE.ADDRESS_2", BlankConverter.INSTANCE)
            .put("SECTION_ONE.PREPARERS.PREPARER_THREE.CITY",
                new PreparerConverter("formData.sectionOne.preparers.city", 2))
            .put("SECTION_ONE.PREPARERS.PREPARER_THREE.STATE_PROVINCE",
                new PreparerConverter("formData.sectionOne.preparers.state", 2))
            .put("SECTION_ONE.PREPARERS.PREPARER_THREE.ZIP_POSTAL_CODE",
                new PreparerConverter("formData.sectionOne.preparers.zipCode", 2))
            .put("SECTION_ONE.PREPARERS.PREPARER_THREE.SIGNATURE.SIGNATURE_DATE",
                new PreparerDateTimeToDateConverter("formData.sectionOne.preparers.signature.date", 2))
            .put("SECTION_ONE.PREPARERS.PREPARER_THREE.SIGNATURE.SIGNATURE_METHOD",
                new ESignaturePreparerConverter("formData.sectionOne.preparers.signature.date", 2))
            .put("SECTION_TWO.RECEIPT_CODE", BlankConverter.INSTANCE)
            .put("SECTION_TWO.EMPLOYEE_TERMED_BEFORE_COMPLETING_I_9", BlankConverter.INSTANCE)
            .put("SECTION_TWO.LIST_A.DOC_ONE.TITLE",
                new NoChangeConverter("formData.sectionTwo.listA.documentOne.documentTitle"))
            .put("SECTION_TWO.LIST_A.DOC_ONE.FIELD_1_TITLE", new StaticFieldNameConverter(DOCUMENT_NUMBER))
            .put("SECTION_TWO.LIST_A.DOC_ONE.FIELD_1_VALUE",
                new NoChangeConverter("formData.sectionTwo.listA.documentOne.documentNumber"))
            .put("SECTION_TWO.LIST_A.DOC_ONE.FIELD_2_TITLE", new StaticFieldNameConverter(EXPIRATION_DATE))
            .put("SECTION_TWO.LIST_A.DOC_ONE.FIELD_2_VALUE",
                new DateConverter("formData.sectionTwo.listA.documentOne.expirationDate"))
            .put("SECTION_TWO.LIST_A.DOC_ONE.FIELD_3_TITLE", new StaticFieldNameConverter(IS_RECEIPT))
            .put("SECTION_TWO.LIST_A.DOC_ONE.FIELD_3_VALUE",
                new NoChangeConverter("formData.sectionTwo.listA.documentOne.isReceipt"))
            .put("SECTION_TWO.LIST_A.DOC_ONE.FIELD_4_TITLE",
                new StaticFieldNameConverter(ISSUING_AUTHORITY))
            .put("SECTION_TWO.LIST_A.DOC_ONE.FIELD_4_VALUE",
                new NoChangeConverter("formData.sectionTwo.listA.documentOne.issuingAuthority"))
            .put("SECTION_TWO.LIST_A.DOC_ONE.FIELD_5_TITLE", BlankConverter.INSTANCE)
            .put("SECTION_TWO.LIST_A.DOC_ONE.FIELD_5_VALUE", BlankConverter.INSTANCE)
            .put("SECTION_TWO.LIST_A.DOC_ONE.FIELD_6_TITLE", BlankConverter.INSTANCE)
            .put("SECTION_TWO.LIST_A.DOC_ONE.FIELD_6_VALUE", BlankConverter.INSTANCE)
            .put("SECTION_TWO.LIST_A.DOC_ONE.FIELD_7_TITLE", BlankConverter.INSTANCE)
            .put("SECTION_TWO.LIST_A.DOC_ONE.FIELD_7_VALUE", BlankConverter.INSTANCE)
            .put("SECTION_TWO.LIST_A.DOC_ONE.FIELD_8_TITLE", BlankConverter.INSTANCE)
            .put("SECTION_TWO.LIST_A.DOC_ONE.FIELD_8_VALUE", BlankConverter.INSTANCE)
            .put("SECTION_TWO.LIST_B.DOC_ONE.TITLE",
                new NoChangeConverter("formData.sectionTwo.listB.documentOne.documentTitle"))
            .put("SECTION_TWO.LIST_B.DOC_ONE.FIELD_1_TITLE", new StaticFieldNameConverter(DOCUMENT_NUMBER))
            .put("SECTION_TWO.LIST_B.DOC_ONE.FIELD_1_VALUE",
                new NoChangeConverter("formData.sectionTwo.listB.documentOne.documentNumber"))
            .put("SECTION_TWO.LIST_B.DOC_ONE.FIELD_2_TITLE", new StaticFieldNameConverter(EXPIRATION_DATE))
            .put("SECTION_TWO.LIST_B.DOC_ONE.FIELD_2_VALUE",
                new DateConverter("formData.sectionTwo.listB.documentOne.expirationDate"))
            .put("SECTION_TWO.LIST_B.DOC_ONE.FIELD_3_TITLE", new StaticFieldNameConverter(IS_RECEIPT))
            .put("SECTION_TWO.LIST_B.DOC_ONE.FIELD_3_VALUE",
                new NoChangeConverter("formData.sectionTwo.listB.documentOne.isReceipt"))
            .put("SECTION_TWO.LIST_B.DOC_ONE.FIELD_4_TITLE",
                new StaticFieldNameConverter(ISSUING_AUTHORITY))
            .put("SECTION_TWO.LIST_B.DOC_ONE.FIELD_4_VALUE",
                new NoChangeConverter("formData.sectionTwo.listB.documentOne.issuingAuthority"))
            .put("SECTION_TWO.LIST_B.DOC_ONE.FIELD_5_TITLE", BlankConverter.INSTANCE)
            .put("SECTION_TWO.LIST_B.DOC_ONE.FIELD_5_VALUE", BlankConverter.INSTANCE)
            .put("SECTION_TWO.LIST_B.DOC_ONE.FIELD_6_TITLE", BlankConverter.INSTANCE)
            .put("SECTION_TWO.LIST_B.DOC_ONE.FIELD_6_VALUE", BlankConverter.INSTANCE)
            .put("SECTION_TWO.LIST_B.DOC_ONE.FIELD_7_TITLE", BlankConverter.INSTANCE)
            .put("SECTION_TWO.LIST_B.DOC_ONE.FIELD_7_VALUE", BlankConverter.INSTANCE)
            .put("SECTION_TWO.LIST_B.DOC_ONE.FIELD_8_TITLE", BlankConverter.INSTANCE)
            .put("SECTION_TWO.LIST_B.DOC_ONE.FIELD_8_VALUE", BlankConverter.INSTANCE)
            .put("SECTION_TWO.LIST_C.DOC_ONE.TITLE",
                new NoChangeConverter("formData.sectionTwo.listC.documentOne.documentTitle"))
            .put("SECTION_TWO.LIST_C.DOC_ONE.FIELD_1_TITLE", new StaticFieldNameConverter(DOCUMENT_NUMBER))
            .put("SECTION_TWO.LIST_C.DOC_ONE.FIELD_1_VALUE",
                new NoChangeConverter("formData.sectionTwo.listC.documentOne.documentNumber"))
            .put("SECTION_TWO.LIST_C.DOC_ONE.FIELD_2_TITLE", new StaticFieldNameConverter(EXPIRATION_DATE))
            .put("SECTION_TWO.LIST_C.DOC_ONE.FIELD_2_VALUE",
                new DateConverter("formData.sectionTwo.listC.documentOne.expirationDate"))
            .put("SECTION_TWO.LIST_C.DOC_ONE.FIELD_3_TITLE", new StaticFieldNameConverter(IS_RECEIPT))
            .put("SECTION_TWO.LIST_C.DOC_ONE.FIELD_3_VALUE",
                new NoChangeConverter("formData.sectionTwo.listC.documentOne.isReceipt"))
            .put("SECTION_TWO.LIST_C.DOC_ONE.FIELD_4_TITLE",
                new StaticFieldNameConverter(ISSUING_AUTHORITY))
            .put("SECTION_TWO.LIST_C.DOC_ONE.FIELD_4_VALUE",
                new NoChangeConverter("formData.sectionTwo.listC.documentOne.issuingAuthority"))
            .put("SECTION_TWO.LIST_C.DOC_ONE.FIELD_5_TITLE", BlankConverter.INSTANCE)
            .put("SECTION_TWO.LIST_C.DOC_ONE.FIELD_5_VALUE", BlankConverter.INSTANCE)
            .put("SECTION_TWO.LIST_C.DOC_ONE.FIELD_6_TITLE", BlankConverter.INSTANCE)
            .put("SECTION_TWO.LIST_C.DOC_ONE.FIELD_6_VALUE", BlankConverter.INSTANCE)
            .put("SECTION_TWO.LIST_C.DOC_ONE.FIELD_7_TITLE", BlankConverter.INSTANCE)
            .put("SECTION_TWO.LIST_C.DOC_ONE.FIELD_7_VALUE", BlankConverter.INSTANCE)
            .put("SECTION_TWO.LIST_C.DOC_ONE.FIELD_8_TITLE", BlankConverter.INSTANCE)
            .put("SECTION_TWO.LIST_C.DOC_ONE.FIELD_8_VALUE", BlankConverter.INSTANCE)
            .put("SECTION_TWO.HIRE_DATE", new NoChangeConverter("formData.sectionTwo.hireDate"))
            .put("SECTION_TWO.TWN_HIRE_DATE", new NoChangeConverter("blank"))
            .put("SECTION_TWO.TERMINATION_DATE", new NoChangeConverter("blank"))
            .put("SECTION_TWO.EXPECTED_PURGE_DATE", new NoChangeConverter("blank"))
            .put("SECTION_TWO.ACTIVE_I9", new NoChangeConverter(""))
            .put("SECTION_TWO.EMPLOYER_ID", new NoChangeConverter("employerId"))
            .put("SECTION_TWO.EMPLOYER_REPRESENTATIVE.EMPLOYER_NAME",
                new MergingConverter("formData.sectionTwo.employerRepresentative.firstName",
                    "formData.sectionTwo.employerRepresentative.lastName"))
            .put("SECTION_TWO.EMPLOYER_REPRESENTATIVE.EMPLOYER_TITLE",
                new NoChangeConverter("formData.sectionTwo.employerRepresentative.title"))
            .put("SECTION_TWO.ORGANIZATION.EMPLOYER_BUSINESS_NAME",
                new NoChangeConverter("formData.sectionTwo.organization.name"))
            .put("SECTION_TWO.ORGANIZATION.EMPLOYER_ADDRESS_1",
                new NoChangeConverter("formData.sectionTwo.organization.address"))
            .put("SECTION_TWO.ORGANIZATION.EMPLOYER_ADDRESS_2", BlankConverter.INSTANCE)
            .put("SECTION_TWO.ORGANIZATION.EMPLOYER_CITY",
                new NoChangeConverter("formData.sectionTwo.organization.city"))
            .put("SECTION_TWO.ORGANIZATION.EMPLOYER_STATE",
                new NoChangeConverter("formData.sectionTwo.organization.state"))
            .put("SECTION_TWO.ORGANIZATION.EMPLOYER_ZIP",
                new NoChangeConverter("formData.sectionTwo.organization.zipCode"))
            .put("SECTION_TWO.EMPLOYER_SIGNATURE_DATE",
                new DateTimeToDateConverter("formData.sectionTwo.signature.date"))
            .put("SECTION_TWO.EMPLOYER_SIGNATURE_METHOD",
                new ESignatureConverter("formData.sectionTwo.signature.date"))
            .put("SECTION_TWO.ORGANIZATION.AGENT", new NoChangeConverter("formData.sectionTwo.organization.name"))
            .put("SECTION_THREE.REVERIFICATION_DUE_DATE", new NoChangeConverter("blank"))
            .put("SECTION_THREE.REV_DUE_DATE_REASON", new NoChangeConverter("blank"))
            .put("SECTION_THREE.RECEIPT_DUE_DATE", new NoChangeConverter("blank"))
            .put("SECTION_THREE.RECEIPT_DUE_REASON", new NoChangeConverter("blank"))
            .put("SECTION_THREE.REVERIFICATION_SSN", new NoChangeConverter("blank"))
            .put("SECTION_THREE.REVERIFICATION_FIRST_NAME",
                new ReverificationFieldConverter("formData.sectionThreeList.firstName"))
            .put("SECTION_THREE.REVERIFICATION_LAST_NAME",
                new ReverificationFieldConverter("formData.sectionThreeList.lastName"))
            .put("SECTION_THREE.REVERIFICATION_MI",
                new ReverificationFieldConverter("formData.sectionThreeList.middleInitial"))
            .put("SECTION_THREE.REVERIFICATION_REHIRE_DATE",
                new ReverificationFieldConverter("formData.sectionThreeList.projectedStartDate"))
            .put("SECTION_THREE.EMPLOYER_SIGNATURE.REVERIFICATION_SIGNATURE_NAME",
                new ReverificationFieldConverter("formData.sectionThreeList.employerSignature.name"))
            .put("SECTION_THREE.EMPLOYER_SIGNATURE.REVERIFICATION_SIGNATURE_DATE",
                new ReverificationDateConverter("formData.sectionThreeList.employerSignature.date",
                    Formatters.DATE_TIME_FORMATTER_WITH_ZONE))
            .put("SECTION_THREE.EMPLOYER_SIGNATURE.REVERIFICATION_SIGNATURE_METHOD",
                new ESignatureReverificationDataConverter("formData.sectionThreeList.employerSignature.date"))
            .put("SECTION_THREE.REVERIFICATION_DOC.TITLE",
                new ReverificationFieldConverter("formData.sectionThreeList.reverificationDocument.documentTitle"))
            .put("SECTION_THREE.REVERIFICATION_DOC.FIELD_1_TITLE",
                new StaticFieldNameConverter(DOCUMENT_NUMBER))
            .put("SECTION_THREE.REVERIFICATION_DOC.FIELD_1_VALUE",
                new ReverificationFieldConverter("formData.sectionThreeList.reverificationDocument.documentNumber"))
            .put("SECTION_THREE.REVERIFICATION_DOC.FIELD_2_TITLE",
                new StaticFieldNameConverter(EXPIRATION_DATE))
            .put("SECTION_THREE.REVERIFICATION_DOC.FIELD_2_VALUE",
                new ReverificationDateConverter("formData.sectionThreeList.reverificationDocument.expirationDate",
                    DateTimeFormatter.ISO_DATE))
            .put("SECTION_THREE.REVERIFICATION_DOC.FIELD_3_TITLE",
                new StaticFieldNameConverter(IS_RECEIPT))
            .put("SECTION_THREE.REVERIFICATION_DOC.FIELD_3_VALUE",
                new ReverificationFieldConverter("formData.sectionThreeList.reverificationDocument.isReceipt"))
            .put("SECTION_THREE.REVERIFICATION_DOC.FIELD_4_TITLE",
                new StaticFieldNameConverter(ISSUING_AUTHORITY))
            .put("SECTION_THREE.REVERIFICATION_DOC.FIELD_4_VALUE",
                new ReverificationFieldConverter(
                    "formData.sectionThreeList.reverificationDocument.issuingAuthority"))
            .put("SECTION_THREE.REVERIFICATION_DOC.FIELD_5_TITLE", BlankConverter.INSTANCE)
            .put("SECTION_THREE.REVERIFICATION_DOC.FIELD_5_VALUE", BlankConverter.INSTANCE)
            .put("SECTION_THREE.REVERIFICATION_DOC.FIELD_6_TITLE", BlankConverter.INSTANCE)
            .put("SECTION_THREE.REVERIFICATION_DOC.FIELD_6_VALUE", BlankConverter.INSTANCE)
            .put("SECTION_THREE.REVERIFICATION_DOC.FIELD_7_TITLE", BlankConverter.INSTANCE)
            .put("SECTION_THREE.REVERIFICATION_DOC.FIELD_7_VALUE", BlankConverter.INSTANCE)
            .put("SECTION_THREE.REVERIFICATION_DOC.FIELD_8_TITLE", BlankConverter.INSTANCE)
            .put("SECTION_THREE.REVERIFICATION_DOC.FIELD_8_VALUE", BlankConverter.INSTANCE)
            .put("MEDIA_SOURCE", new StaticFieldNameConverter("WEB"))
            .put("ENTRY_TYPE", new StaticFieldNameConverter("electronic"))
            .put("LOAD_DATE", BlankConverter.INSTANCE)
            .put("I_9_TYPE", new I9TypeConverter("formData.ssnApplied"))
            .put("EDIT_DATA_DATE",
                new StaticFieldNameConverter(temporalFormatter.formatDateTime(changeContext.getSourceEventDateTime())))
            .put("EDIT_DATA_USER", new StaticFieldNameConverter(changeContext.getSource()))
            .put("EDIT_DATA_DESCRIPTION", new StaticFieldNameConverter(changeContext.getI9Event().getEventKey()))
            .put("CONVERSION_ERROR_FIELD", BlankConverter.INSTANCE)
            .put("HIRE_CODE", BlankConverter.INSTANCE)
            .put("VISA_TYPE", BlankConverter.INSTANCE)
            .put("EMPLOYEE_ID", BlankConverter.INSTANCE)
            .put("FICA_EXEMPT", BlankConverter.INSTANCE)
            .put("IPADDRESS", new StaticFieldNameConverter(changeContext.getIpAddress()))
            .put("TERMINATE_DATE_SOURCE", BlankConverter.INSTANCE)
            .build();
    }
}
