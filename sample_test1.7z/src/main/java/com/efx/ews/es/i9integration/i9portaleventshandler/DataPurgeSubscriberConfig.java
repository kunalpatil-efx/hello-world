package com.efx.ews.es.i9integration.i9portaleventshandler;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.event.I9EventPayload;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.logger.MdcSetting;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.configuration.PubSubProperties;
import static com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageConfirmation.manualAckMessageChannel;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.DataPurgeService;
import com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageConfirmation;
import com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageReader;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gcp.pubsub.core.PubSubTemplate;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.dsl.RouterSpec;
import org.springframework.integration.router.MethodInvokingRouter;
import org.springframework.messaging.Message;

@Configuration
@Slf4j
public class DataPurgeSubscriberConfig {

    private final MessageConfirmation messageConfirmation;
    private final DataPurgeService service;
    private final PubSubProperties pubSubProperties;
    public DataPurgeSubscriberConfig(DataPurgeService service,
                                   MessageConfirmation messageConfirmation,
                                   PubSubProperties pubSubProperties) {
        this.service = service;
        this.messageConfirmation = messageConfirmation;
        this.pubSubProperties = pubSubProperties;
    }

    @Bean("DataPurgeSubscriberConfig")
    IntegrationFlow subscriberFlow(
            PubSubTemplate pubSubTemplate,
            @Value("${subscription.dataPurge}") String subscription) {
        return IntegrationFlows
                .from(manualAckMessageChannel(pubSubTemplate, subscription))
                .route(Message.class, this::shouldExecute, this::routeMessage)
                .get();
    }

    private void routeMessage(RouterSpec<Boolean, MethodInvokingRouter> mapping) {
        mapping.subFlowMapping(Boolean.TRUE, sf -> sf.handle(msg -> MdcSetting.wrapWithHeaders(msg, this::handleMessage)))
            .subFlowMapping(Boolean.FALSE, sf -> sf.handle(msg -> MdcSetting.wrapWithHeaders(msg, this::noDataPurgeEventForThisMessage)));
    }

    void noDataPurgeEventForThisMessage(Message<?> message) {
        log.info("DataPurgeSubscriberConfig filtered out {}", message.getHeaders().get("documentId", String.class));
        messageConfirmation.acknowledge(message);
    }

    void handleMessage(Message<?> message) {
        log.info("Data purge received message: {}", message);
        String i9Id = message.getHeaders().get("documentId", String.class);
        I9EventPayload i9e = MessageReader.readPayloadSync(message, I9EventPayload.class);
        service.createDataPurgeEvent(i9Id, i9e);
        messageConfirmation.acknowledge(message);
    }

    boolean shouldExecute(Message<?> message) {
        return pubSubProperties.getDataPurge().isEnabled()
            && "Deleted".equalsIgnoreCase(message.getHeaders().get("status", String.class));
    }

}
