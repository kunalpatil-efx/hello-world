package com.efx.ews.es.i9integration.i9portaleventshandler.model.i9;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class EmployeeInfo {
    private String lastName;
    private String firstName;
    private String middleInitial;
    private String otherLastName;
    private String address;
    private String apartmentNumber;
    private String city;
    private String state;
    private String zipCode;
    private String dateOfBirth;
    private String socialSecurityNumber;
    private String telephoneNumber;
    private String email;
}
