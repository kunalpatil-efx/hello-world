package com.efx.ews.es.i9integration.i9portaleventshandler.utils;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.Message;
import reactor.core.publisher.Mono;

import java.io.IOException;

@Slf4j
public class MessageReader {

    private final static ObjectMapper converter = new ObjectMapper()
            .configure(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_USING_DEFAULT_VALUE, true)
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

    private MessageReader () {

    }

    public static <T> T readPayloadSync(Message<?> message, Class<T> payloadType) {
        try {
            T payload = converter.readValue((byte[]) message.getPayload(), payloadType);
            return payload;
        } catch (IOException e) {
            log.error("Invalid massage payload. " + e.getMessage());
            return null;
        }
    }

    public static <T> Mono<T> readPayload(Message<?> message, Class<T> payloadType) {
        try {
            T payload = converter.readValue((byte[]) message.getPayload(), payloadType);
            if (payload == null) {
                return Mono.error(new IllegalArgumentException());
            }
            return Mono.just(payload);
        } catch (IOException e) {
            log.error("Invalid massage payload. " + e.getMessage());
            return Mono.error(e);
        }
    }
}
