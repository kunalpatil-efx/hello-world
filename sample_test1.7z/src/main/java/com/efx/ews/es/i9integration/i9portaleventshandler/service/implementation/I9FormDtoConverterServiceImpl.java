package com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.dto.TaskDto;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.Task;
import com.googlecode.jmapper.JMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class I9FormDtoConverterServiceImpl implements I9FormDtoConverterService {

    private JMapper<TaskDto, Task> taskToTaskDtoJMapper;

    @Autowired
    I9FormDtoConverterServiceImpl() {
        this.taskToTaskDtoJMapper = new JMapper<>(TaskDto.class, Task.class);
    }

    @Override
    public TaskDto toDto(Task task) {
        return taskToTaskDtoJMapper.getDestination(task);
    }
}
