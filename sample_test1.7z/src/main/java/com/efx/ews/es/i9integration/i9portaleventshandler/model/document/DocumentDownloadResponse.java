package com.efx.ews.es.i9integration.i9portaleventshandler.model.document;

import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.http.MediaType;

@Data
@AllArgsConstructor
public class DocumentDownloadResponse {
    private byte[] content;
    private MediaType mediaType;
    private String documentId;
}
