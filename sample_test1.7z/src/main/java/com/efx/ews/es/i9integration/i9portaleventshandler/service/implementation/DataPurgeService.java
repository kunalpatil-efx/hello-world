package com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation;

import com.efx.ews.es.i9datasourcing.dep.model.DepEventDataHolder;
import com.efx.ews.es.i9datasourcing.model.ChangeContext;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.billing.BillingServiceException;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.event.I9EventPayload;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.pubsub.Event;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.DataEngineeringTopicService;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class DataPurgeService {

    private final DataEngineeringTopicService dataEngineeringTopicService;
    private final I9FormDao i9FormDao;
    private final ObjectMapper mapper = new ObjectMapper();

    public DataPurgeService(DataEngineeringTopicService dataEngineeringTopicService,
                          I9FormDao i9FormDao) {
        this.dataEngineeringTopicService = dataEngineeringTopicService;
        this.i9FormDao = i9FormDao;
    }

   public void createDataPurgeEvent(String i9Id, I9EventPayload payload) {
       DepEventDataHolder eventHolder = createEventDataHolder(i9Id, serializeEventData(payload));
       Event event = null;
       event = dataEngineeringTopicService
           .sendDataPurgeEvent(eventHolder, payload.getDocument().getEmployeeId());
       log.info("DataPurge event message published successfully for I9Id:{}, Now updating the event in firestore", i9Id);
       i9FormDao.updateEvent(i9Id, event);
   }

    private String serializeEventData(I9EventPayload eventData) {
        try {
            return mapper.writeValueAsString(eventData);
        } catch (Exception e) {
            throw BillingServiceException.of(e);
        }
    }

    private DepEventDataHolder createEventDataHolder(String documentId, String jsonPayload) {
        ChangeContext changeContext = new ChangeContext();
        changeContext.setI9FormId(documentId);

        return DepEventDataHolder.builder()
            .payloadJson(jsonPayload)
            .changeContext(changeContext)
            .build();
    }

}
