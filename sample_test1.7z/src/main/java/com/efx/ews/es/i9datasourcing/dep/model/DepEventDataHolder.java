package com.efx.ews.es.i9datasourcing.dep.model;

import com.efx.ews.es.i9datasourcing.model.ChangeContext;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DepEventDataHolder {

    private final String payloadJson;
    private final ChangeContext changeContext;
    private final String eventName;
}
