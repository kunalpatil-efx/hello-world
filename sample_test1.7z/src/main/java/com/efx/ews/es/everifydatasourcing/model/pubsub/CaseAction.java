package com.efx.ews.es.everifydatasourcing.model.pubsub;

import com.fasterxml.jackson.annotation.JsonProperty;

public enum CaseAction {
    @JsonProperty("CreateCase")
    CREATE_CASE,
    @JsonProperty("UpdateCase")
    UPDATE_CASE,
    @JsonProperty("SubmitCase")
    SUBMIT_CASE,
    @JsonProperty("CloseCase")
    CLOSE_CASE,
    @JsonProperty("AutoCloseCase")
    AUTO_CLOSE_CASE
}
