package com.efx.ews.es.i9integration.i9portaleventshandler.model.i9;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class AlienAuthorizedToWork {
    private String expirationDate;
    private String alienRegistrationNumber;
    private String formI94AdmissionNumber;
    private ForeignPassport foreignPassportObject;
}
