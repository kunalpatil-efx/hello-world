package com.efx.ews.es.i9integration.i9portaleventshandler.utils;

import org.slf4j.MDC;

public class ContextLogging {
    public static final String CONTEXT_PROPERTY = "flow";
    private final Class<?> contextClass;

    public ContextLogging(Class<?> contextClass) {
        this.contextClass = contextClass;
    }

    public void logWithContext(Runnable runnable) {
        if (contextClass == null) {
            runnable.run();
        } else {
            try (MDC.MDCCloseable ignored = MDC.putCloseable(CONTEXT_PROPERTY, contextClass.getSimpleName())) {
                runnable.run();
            }
        }
    }
}
