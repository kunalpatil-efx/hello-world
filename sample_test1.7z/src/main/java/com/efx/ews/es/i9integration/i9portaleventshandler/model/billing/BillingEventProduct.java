package com.efx.ews.es.i9integration.i9portaleventshandler.model.billing;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class BillingEventProduct {
    private String code;
    private String codeDescription;
    private int quantity;
    private String lineOfService;
}
