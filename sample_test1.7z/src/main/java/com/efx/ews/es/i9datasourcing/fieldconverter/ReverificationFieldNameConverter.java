package com.efx.ews.es.i9datasourcing.fieldconverter;

import com.efx.ews.es.i9datasourcing.fieldconverter.Utils.Constants;
import java.time.ZonedDateTime;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;

@RequiredArgsConstructor(access = AccessLevel.PACKAGE)
class ReverificationFieldNameConverter implements FieldDataConverter {

    private final String fieldName;

    @Override
    public String convert(Map<String, String> flattenedI9Form) {
        Map<String, ZonedDateTime> signatureDates = flattenedI9Form.entrySet().stream()
            .filter(entry -> entry.getKey().endsWith("employerSignature.date"))
            .collect(Collectors.toMap(Entry::getKey, entry -> ZonedDateTime.parse(entry.getValue())));

        return signatureDates.entrySet().stream()
            .max(Entry.comparingByValue())
            .map(maxDateEntry -> StringUtils.substringBetween(maxDateEntry.getKey(), "[", "]"))
            .map(index -> fieldName.replace("sectionThreeList", "sectionThreeList[" + index + "]"))
            .orElse(Constants.DEFAULT_EMPTY_VALUE);
    }
}