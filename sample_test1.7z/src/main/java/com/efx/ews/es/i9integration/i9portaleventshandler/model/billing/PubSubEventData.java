package com.efx.ews.es.i9integration.i9portaleventshandler.model.billing;

import lombok.Data;

@Data
public class PubSubEventData {
    private BillingEvent billingEvents;
}
