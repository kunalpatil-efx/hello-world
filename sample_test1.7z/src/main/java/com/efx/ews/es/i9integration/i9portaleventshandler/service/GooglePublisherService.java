package com.efx.ews.es.i9integration.i9portaleventshandler.service;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.pubsub.PubSubEvent;
import com.fasterxml.jackson.core.JsonProcessingException;
import reactor.core.publisher.Mono;

import java.util.concurrent.ExecutionException;

public interface GooglePublisherService {
    void sendEvent(PubSubEvent event) throws ExecutionException, InterruptedException, JsonProcessingException;
    Mono<String> sendEventAsync(PubSubEvent event);
    <T> void sendDataPurgeEvent(PubSubEvent event) ;
}
