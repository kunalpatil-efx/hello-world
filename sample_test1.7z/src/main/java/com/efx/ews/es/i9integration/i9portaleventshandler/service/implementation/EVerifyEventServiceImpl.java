package com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation;

import com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageConfirmation;
import com.efx.ews.es.i9integration.i9portaleventshandler.SubscriberErrorHandling;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.DocumentIdAndTaskResponse;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.PacketEvent;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.PacketEvent.EventType;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.TaskAndPacketResponse;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.Task;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.task.TaskResponse;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.EVerifyEventService;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.I9ApiCall;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.I9HeaderBuilder;
import com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageReader;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;
import reactor.util.context.Context;

import java.util.Optional;
import java.util.UUID;

@Service
@Slf4j
public class EVerifyEventServiceImpl implements EVerifyEventService {
    private final TaskApiRemoteCallService taskApiRemoteCallService;
    private final I9ApiCall i9ApiCall;
    private final MessageConfirmation messageConfirmation;
    private final SubscriberErrorHandling errorHandling;

    public EVerifyEventServiceImpl(MessageConfirmation messageConfirmation,
                                   TaskApiRemoteCallService taskApiRemoteCallService,
                                   I9ApiCall i9ApiCall) {
        this.messageConfirmation = messageConfirmation;
        this.taskApiRemoteCallService = taskApiRemoteCallService;
        this.i9ApiCall = i9ApiCall;
        this.errorHandling = new SubscriberErrorHandling(log);
    }

    public void handleMessage(Message<?> message) {
        log.info("received message: {}", message);
        MessageReader.readPayload(message, PacketEvent.class)
            .filter(packetEvent -> {
                if (EventType.UNCONFIRMED_DATA.equals(packetEvent.getEventType())) {
                    log.info("Message for packetEventType {}", packetEvent.getEventType());
                    return true;
                } else {
                    log.debug("EVerifyEventsSubscriberConfig filtered out {}",
                        message.getHeaders().get("documentId", String.class));
                    messageConfirmation.acknowledge(message);
                    return false;
                }
            })
                .flatMap(packetEvent -> taskApiRemoteCallService.getTask(packetEvent.getMetadata().getTaskId())
                        .flatMap(taskResponse -> TaskAndPacketResponse.of(packetEvent, taskResponse)))
                .doOnSuccess(tapr -> {
                    log.info("Have packetId {} / taskId {}", Optional.ofNullable(tapr).map(TaskAndPacketResponse::getPacket).map(PacketEvent::getPacketId).orElse("null"),
                            Optional.ofNullable(tapr).map(TaskAndPacketResponse::getTask).map(TaskResponse::getId).map(UUID::toString).orElse("null"));
                })
                .flatMap(result-> i9ApiCall.queryDocumentsByPacketId(result.getPacket().getPacketId())
                        .flatMap(ids -> DocumentIdAndTaskResponse.of(ids.get(0), result.getTask())))
                .doOnSuccess(datr -> log.info("Have documentId {} / taskId {}", datr.getDocumentId(), datr.getTask().getId()))
                .filter(result -> filterCode(result.getTask()))
                .doOnSuccess(datr -> log.info("Have documentId {} / taskId {} /taskTypeCode {} after filtering ", datr.getDocumentId(), datr.getTask().getId(), datr.getTask().getTaskType().getCode()))
                .flatMap(result -> i9ApiCall.createTaskAssociation(result.getDocumentId(), map(result.getTask())))
                .doOnSuccess(t -> log.info("Have taskId {} / taskStatus {}", t.getTaskId(), t.getTaskStatus()))
                .doOnSuccess(ignore -> messageConfirmation.acknowledge(message))
                .onErrorResume(errorHandling::processingCompleted, t -> {
                    log.error("Unable for handle message", t);
                    messageConfirmation.acknowledge(message);
                    return Mono.empty();
                })
                .onErrorResume(errorHandling::processingFailed, t -> {
                    log.error("Unable for handle message", t);
                    messageConfirmation.nAcknowledge(message);
                    return Mono.empty();
                })
                .subscriberContext(Context.of(I9HeaderBuilder.build(message)))
                .block();
    }

    private Task map(TaskResponse response) {
        log.info("Mapping response for taskId {} / taskTypeCode {}", response.getId(),response.getTaskType().getCode());
        Task task = new Task();
        task.setTaskId(response.getId().toString());
        task.setTaskType(response.getTaskType().getCode());
        return task;
    }

    private boolean filterCode(TaskResponse response) {
        log.info("Filtered message for taskType {}", response.getTaskType().getCode());
        return Optional.of(response)
                .map(TaskResponse::getTaskType)
                .map(TaskResponse.TaskTypeResponse::getCode)
                .map("Everify:UnconfirmedDataSection1WaitingOnEmployee"::equalsIgnoreCase).orElse(false);
    }
}
