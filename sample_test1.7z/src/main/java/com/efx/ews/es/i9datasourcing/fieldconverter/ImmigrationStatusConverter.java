package com.efx.ews.es.i9datasourcing.fieldconverter;

import com.efx.ews.es.i9datasourcing.fieldconverter.Utils.Constants;
import java.util.Map;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
class ImmigrationStatusConverter implements FieldDataConverter {

    static final ImmigrationStatusConverter INSTANCE = new ImmigrationStatusConverter();

    @Override
    public String convert(Map<String, String> flattenedI9Form) {

        String result = Constants.DEFAULT_EMPTY_VALUE;

        if (Utils
            .containsKeyWithTrueValue(flattenedI9Form, "formData.sectionOne.attestation.isAlienAuthorizedToWork")) {
            result = "An Alien Authorized to Work";
        } else if (Utils
            .containsKeyWithTrueValue(flattenedI9Form, "formData.sectionOne.attestation.isLawfulPermanentResident")) {
            result = "A Lawful Permanent Resident";
        } else if (Utils
            .containsKeyWithTrueValue(flattenedI9Form, "formData.sectionOne.attestation.isNonCitizenNational")) {
            result = "A Non Citizen National of the United States";
        } else if (Utils
            .containsKeyWithTrueValue(flattenedI9Form, "formData.sectionOne.attestation.isUnitedStatesCitizen")) {
            result = "A Citizen of the United States";
        }

        return result;
    }
}
