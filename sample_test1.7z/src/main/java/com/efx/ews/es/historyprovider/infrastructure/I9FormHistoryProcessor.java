package com.efx.ews.es.historyprovider.infrastructure;

import static java.lang.String.format;

import com.efx.ews.es.historyprovider.api.I9FormHistoryProvider;
import com.efx.ews.es.historyprovider.model.EventMessageDocument;
import com.efx.ews.es.historyprovider.model.I9AuditModel;
import com.efx.ews.es.historyprovider.model.I9FormEventMessage;
import com.efx.ews.es.i9datasourcing.I9FormHistoryConverter;
import com.efx.ews.es.i9datasourcing.constant.I9Event;
import com.efx.ews.es.i9datasourcing.model.ChangeContext;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.I9Form;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import javax.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Slf4j
@RequiredArgsConstructor
@Service
public class I9FormHistoryProcessor {

    @Value("${reportingDataSourcingEnabled}")
    private boolean reportingDataSourcingEnabled;

    private final I9FormHistoryProvider formHistoryProvider;
    private final I9FormHistoryConverter formHistoryConverter;

    @PostConstruct
    public void init() {
        if (reportingDataSourcingEnabled) {
            formHistoryProvider.registerEventListener(this::processFormHistory);
        }
    }

    protected void processFormHistory(I9FormEventMessage formEventMessage) {
        final EventMessageDocument document = formEventMessage.getDocument();
        if (document.isNewForm()) {
            log.info("I9Form with id {} was created!", document.getDocumentId());
        } else {
            List<I9AuditModel> audits = formHistoryProvider.getAudits(document.getDocumentId());
            if (formEventMessage.isMigratedForm()) {
                processMigratedI9Form(formEventMessage.getMessageId(), audits, document);
            } else if(isCurrentAuditProcessable(formEventMessage.getStatus())) {
                processAudits(formEventMessage.getMessageId(), audits, document);
            }
        }

    }

    private void processMigratedI9Form(String messageId, List<I9AuditModel> audits, EventMessageDocument document) {

        I9AuditModel migrationAudit = audits
            .stream()
            .filter(this::isMigrationAudit)
            .findFirst()
            .orElseThrow(() ->
                new IllegalStateException(
                    format("There is no audit for migration revision! documentId: %s, revisionVersion %s",
                        document.getDocumentId(), document.getRecordVersion()))
            );

        ChangeContext changeContext = createChangeContext(messageId, migrationAudit, document);

        I9Form migrationRevisionForm = formHistoryProvider
            .getRevision(document.getDocumentId(), migrationAudit.getRecordRevision());
        log.info("Processing Migration history for I9Form with id {}", document.getDocumentId());
        formHistoryConverter.convert(null, migrationRevisionForm, changeContext);
    }

    private void processAudits(String messageId, List<I9AuditModel> audits, EventMessageDocument document) {

        if(!isCurrentAuditProcessable(document.getStatus())){
            log.warn("I9Form with id {} was skipped, status: {}", document.getDocumentId(), document.getStatus());
            return;
        }

        I9AuditModel currentAudit = audits
            .stream()
            .filter(i9AuditModel -> isCurrentAudit(i9AuditModel, document))
            .findFirst()
            .orElseThrow(() ->
                new IllegalStateException(
                    format("There is no audit for current revision version! documentId: %s, revisionVersion %s",
                        document.getDocumentId(), document.getRecordVersion()))
            );

        if (isCurrentAuditProcessable(currentAudit.getEventKey())) {

            int previousAuditRevision = audits
                .stream()
                .filter(i9AuditModel -> isPreviousAudit(i9AuditModel, document))
                .map(I9AuditModel::getRecordRevision)
                .max(Comparator.naturalOrder())
                .orElse(1);

            ChangeContext changeContext = createChangeContext(messageId, currentAudit, document);
            processFormRevisions(document, previousAuditRevision, changeContext);
        }
    }

    private boolean isCurrentAuditProcessable(String eventKey) {
        return I9Event.getByEventKey(eventKey) != I9Event.OTHER;
    }

    private void processFormRevisions(EventMessageDocument document, int previousRevision,
        ChangeContext changeContext) {
        I9Form currentRevisionForm = formHistoryProvider
            .getRevision(document.getDocumentId(), document.getRecordVersion());
        I9Form previousRevisionForm = formHistoryProvider
            .getRevision(document.getDocumentId(), previousRevision);
        formHistoryConverter.convert(previousRevisionForm, currentRevisionForm, changeContext);
    }

    private ChangeContext createChangeContext(String messageId, I9AuditModel currentAudit, EventMessageDocument document) {
        return new ChangeContext(
            document.getDocumentId(),
            currentAudit.getSourceIp(),
            I9Event.getByEventKey(document.getStatus()),
            currentAudit.getSource(),
            document.getSourceRefId(),
            StringUtils.EMPTY,
            LocalDateTime.parse(currentAudit.getDate(), DateTimeFormatter.ISO_DATE_TIME).atZone(ZoneOffset.UTC),
            document.getEmployerId(),
            messageId
        );
    }

    private boolean isMigrationAudit(I9AuditModel i9AuditModel) {
        return i9AuditModel.getEventKey().equals(I9Event.MIGRATED_I9.getEventKey());
    }

    private boolean isCurrentAudit(I9AuditModel i9AuditModel, EventMessageDocument document) {
        if(Objects.isNull(i9AuditModel.getEventKey())){
            return false;
        }
        return i9AuditModel.getEventKey().equalsIgnoreCase(document.getStatus());
    }

    private boolean isPreviousAudit(I9AuditModel i9AuditModel, EventMessageDocument document) {
        return i9AuditModel.getRecordRevision() < document.getRecordVersion();
    }
}
