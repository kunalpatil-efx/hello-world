package com.efx.ews.es.i9integration.i9portaleventshandler.model.billing;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class BillingEventEmployee {
    private String firstName;
    private String lastName;
    private String ssn;
    private String hireCode;
}
