package com.efx.ews.es.i9integration.i9portaleventshandler.utils;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
public class UtilsConfiguration {
    @Bean
    public MessageConfirmation messageConfirmation() {
        return new MessageConfirmation();
    }

    @Bean
    @Scope(BeanDefinition.SCOPE_PROTOTYPE)
    public MessageConfirmation messageConfirmationForFlow(Class<?> contextClass) {
        return new MessageConfirmation(contextClass);
    }
}
