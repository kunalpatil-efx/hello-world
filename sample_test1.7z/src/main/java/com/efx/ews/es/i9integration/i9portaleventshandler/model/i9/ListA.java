package com.efx.ews.es.i9integration.i9portaleventshandler.model.i9;

import lombok.Data;

@Data
public class ListA {
    private Document documentOne;
    private Document documentTwo;
    private Document documentThree;
}
