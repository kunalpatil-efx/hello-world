package com.efx.ews.es.i9integration.i9portaleventshandler.service.properties;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;

@Component
@ConfigurationProperties(prefix = "packet-api")
@Data
@EqualsAndHashCode(callSuper = true)
public class PacketApiProperties extends AbstractRemoteServiceProperties {

    RemoteResource packetdata;

    public UriComponentsBuilder getPacketUrlBuilder() {
        return UriComponentsBuilder.newInstance()
                .scheme(getScheme())
                .host(getHost())
                .port(getPort())
                .path(getPath())
                .pathSegment(getPacketdata().getPath())
                .pathSegment("{documentId}")
                .pathSegment(getPacketdata().getOperation());
    }
}
