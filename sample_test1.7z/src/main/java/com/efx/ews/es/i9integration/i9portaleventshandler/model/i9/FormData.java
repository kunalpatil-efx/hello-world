package com.efx.ews.es.i9integration.i9portaleventshandler.model.i9;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;
import lombok.Data;

@Data
public class FormData {
    private Boolean specialPlacement;
    private Boolean validListBDocs;
    private Boolean ssnApplied;
    private Boolean ssnRefused;
    private Boolean isMinor;
    private SectionOne sectionOne;
    private SectionTwo sectionTwo;
    private List<SectionThree> sectionThreeList;
    private String documentApiDocumentId;

    public Stream<SectionThree> sortedSectionThree() {
        return getSectionThreeList()
            .stream()
            .sorted(Comparator.comparing(SectionThree::getTimestamp));
    }
}
