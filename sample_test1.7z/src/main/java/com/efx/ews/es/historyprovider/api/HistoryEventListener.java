package com.efx.ews.es.historyprovider.api;

import com.efx.ews.es.historyprovider.model.I9FormEventMessage;

@FunctionalInterface
public interface HistoryEventListener {

    void onEventReceived(I9FormEventMessage formEventMessage);
}
