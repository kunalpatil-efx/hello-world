package com.efx.ews.es.i9datasourcing.flattener;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ClassUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

@Component
@NoArgsConstructor
@Slf4j
public class I9FormHistoryFlattener implements Flattener {

    private static final String PATH_FORMAT = "%s.%s";
    private static final String ARRAY_FORMAT = "%s[%d].%s";
    private static final String ARRAY_FORMAT_LAST_KEY = "%s[%d]";
    private static final String NOT_APPLIED = "n/a";

    @Override
    public Map<String, String> process(Object object) {
        validate(object);

        final Map<String, String> flattenedI9Form = new LinkedHashMap<>();

        Field[] declaredFields = object.getClass().getDeclaredFields();
        List<Field> fields = Arrays.stream(declaredFields)
            .filter(field -> !isStaticFinal(field))
            .collect(Collectors.toList());

        for (Field field : fields) {
            try {
                Class<?> fieldType = field.getType();
                field.setAccessible(true);
                if (isPossibleToBeConvertedToString(fieldType)) {
                    flattenedI9Form.putAll(flatValue(object, field));
                } else if (fieldType.isAssignableFrom(List.class)) {
                    flattenedI9Form.putAll(flatList(object, field));
                } else {
                    flattenedI9Form.putAll(flatObject(object, field));
                }
            } catch (IllegalAccessException e) {
                log.debug(String.format("Field '%s' could not be accessed.", field.getName()), e);
            }
        }
        return flattenedI9Form;
    }

    private boolean isStaticFinal(Field field) {
        int modifiers = field.getModifiers();
        return (Modifier.isStatic(modifiers) && Modifier.isFinal(modifiers));
    }

    private void validate(Object object) {
        if (object == null) {
            throw new IllegalArgumentException();
        }
    }

    private Map<String, String> flatObject(Object object, Field field) throws IllegalAccessException {
        Map<String, String> flattenedObject = new LinkedHashMap<>();
        Object objectToFlat = field.get(object);
        if (objectToFlat != null) {
            process(objectToFlat)
                .forEach(
                    (key, value) -> flattenedObject.put(String.format(PATH_FORMAT, field.getName(), key), value));
        } else {
            flattenedObject.put(field.getName(), null);
        }
        return flattenedObject;
    }

    private Map<String, String> flatValue(Object object, Field field) throws IllegalAccessException {
        String value;
        if (Objects.isNull(field.get(object)) || field.get(object).toString().equalsIgnoreCase(NOT_APPLIED)) {
            value = StringUtils.EMPTY;
        } else {
            value = field.get(object).toString();
        }
        return Map.of(field.getName(), value);
    }

    private Map<String, String> flatList(Object object, Field field) throws IllegalAccessException {
        Map<String, String> flattenedList = new LinkedHashMap<>();
        List<?> list = (List<?>) field.get(object);
        if (list != null) {
            for (int i = 0; i < list.size(); i++) {
                int finalI = i;
                Object objectToFlat = list.get(i);
                if (isPossibleToBeConvertedToString(objectToFlat.getClass())) {
                    flattenedList.put(String.format(ARRAY_FORMAT_LAST_KEY, field.getName(), finalI),
                        objectToFlat.toString());
                } else {
                    process(objectToFlat).forEach(
                        (key, value) -> flattenedList
                            .put(String.format(ARRAY_FORMAT, field.getName(), finalI, key), value));
                }
            }
        }
        return flattenedList;
    }

    private boolean isPossibleToBeConvertedToString(Class<?> classToCheck) {
        return classToCheck.equals(String.class) || classToCheck.isEnum()
            || ClassUtils.isPrimitiveOrWrapper(classToCheck);
    }
}
