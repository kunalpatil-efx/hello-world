package com.efx.ews.es.everifydatasourcing.provider.infrastructure;

import static java.time.format.DateTimeFormatter.ISO_ZONED_DATE_TIME;

import com.efx.ews.es.everifydatasourcing.EVerifyCaseConverter;
import com.efx.ews.es.everifydatasourcing.model.EVerifyCase;
import com.efx.ews.es.everifydatasourcing.model.pubsub.EventMessage;
import com.efx.ews.es.everifydatasourcing.provider.api.EVerifyCaseChangeProvider;
import com.efx.ews.es.i9datasourcing.model.ChangeContext;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import javax.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class EVerifyCaseChangeProcessor {

    @Value("${reportingDataSourcingEnabled}")
    private boolean reportingDataSourcingEnabled;

    private final EVerifyCaseChangeProvider eVerifyCaseChangeProvider;
    private final EVerifyCaseConverter eVerifyCaseConverter;

    @PostConstruct
    public void init() {
        if (reportingDataSourcingEnabled) {
            eVerifyCaseChangeProvider.registerEventListener(this::processEVerifyCase);
        }
    }

    protected void processEVerifyCase(EventMessage eventMessage) {
        EVerifyCase eVerifyCase = eVerifyCaseChangeProvider.getCaseById(eventMessage.getEverifyCaseId());
        ChangeContext changeContext = createChangeContext(eventMessage);
        eVerifyCaseConverter.convert(eVerifyCase, changeContext);
    }

    protected ChangeContext createChangeContext(EventMessage eventMessage) {
        return new ChangeContext(
            eventMessage.getI9FormId(),
            StringUtils.EMPTY,
            null,
            eventMessage.getSourceName(),
            eventMessage.getSourceId(),
            StringUtils.EMPTY,
            LocalDateTime.parse(eventMessage.getEventTime(), ISO_ZONED_DATE_TIME)
                .atZone(ZoneOffset.UTC),
            null,
            eventMessage.getMessageId()
        );
    }
}
