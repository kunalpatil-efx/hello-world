package com.efx.ews.es.i9integration.i9portaleventshandler.service.client.webclient;

import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.function.Function;

@Component
public class HttpCallClient {
    private final Mono<WebClient> webClientMono;

    public HttpCallClient(WebClientProvider webClientProvider) {
        webClientMono = webClientProvider.get();
    }

    public <T> Mono<T> doCall(Function<WebClient, Mono<T>> statement) {
        return webClientMono.flatMap(statement);
    }
}
