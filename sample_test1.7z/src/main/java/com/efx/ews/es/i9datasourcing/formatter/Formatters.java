package com.efx.ews.es.i9datasourcing.formatter;

import java.time.format.DateTimeFormatter;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class Formatters {

    public static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ISO_LOCAL_DATE;
    public static final DateTimeFormatter DATE_FORMATTER_US = DateTimeFormatter.ofPattern("MM/dd/yyyy");
    public static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");
    public static final DateTimeFormatter DATE_TIME_FORMATTER_WITH_ZONE = DateTimeFormatter
        .ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSS[X][XXX]");
    public static final DateTimeFormatter DATE_TIME_MICROSECONDS_FORMATTER_WITH_ZONE = DateTimeFormatter
        .ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSSSS'Z'");
    public static final DateTimeFormatter DATE_TIME_OFFSET_FORMATTER = DateTimeFormatter.ISO_OFFSET_DATE_TIME;
}
