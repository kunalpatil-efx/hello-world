package com.efx.ews.es.historyprovider.infrastructure;

import com.efx.ews.es.historyprovider.api.HistoryEventListener;
import com.efx.ews.es.historyprovider.api.I9FormHistoryProvider;
import com.efx.ews.es.historyprovider.model.I9AuditModel;
import com.efx.ews.es.historyprovider.model.I9FormEventMessage;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.I9Form;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.I9ApiCall;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.I9HeaderBuilder;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.pubsub.v1.PubsubMessage;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gcp.pubsub.core.subscriber.PubSubSubscriberTemplate;
import org.springframework.cloud.gcp.pubsub.support.BasicAcknowledgeablePubsubMessage;
import org.springframework.context.annotation.Profile;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.concurrent.ListenableFutureCallback;
import reactor.util.context.Context;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

import static com.efx.ews.es.common.filter.CorrelationFilter.TRANSACTION_ID_HEADER_NAME;
import static java.lang.String.format;

@Slf4j(topic = "I9FormHistoryProviderAdapter")
@RequiredArgsConstructor
@Service
@Profile("!mocked")
public class I9FormHistoryProviderAdapter implements I9FormHistoryProvider {

    private static final String DOCUMENT_ID_KEY = "documentId";
    private static final String STATUS_KEY = "status";

    private final I9ApiCall i9ApiCall;

    private final ObjectMapper objectMapper;

    private final PubSubSubscriberTemplate pubSubSubscriberTemplate;

    private Map<String, String> headers;

    @Value("${subscription.i9datasourcing}")
    private String subscription;

    @Override
    public void registerEventListener(HistoryEventListener historyEventListener) {
        if (Objects.isNull(historyEventListener)) {
            return;
        }
        pubSubSubscriberTemplate.subscribe(subscription,
            basicAcknowledgeablePubsubMessage -> handleI9Message(historyEventListener,
                basicAcknowledgeablePubsubMessage));
    }

    private void handleI9Message(HistoryEventListener historyEventListener,
        BasicAcknowledgeablePubsubMessage basicAcknowledgeablePubsubMessage) {

        PubsubMessage pubsubMessage = basicAcknowledgeablePubsubMessage.getPubsubMessage();
        String messageDataString = pubsubMessage.getData().toStringUtf8();

        String transactionId = pubsubMessage.getAttributesMap().get(TRANSACTION_ID_HEADER_NAME);
        String correlationId = StringUtils.isBlank(transactionId) ? UUID.randomUUID().toString(): transactionId;

        MDC.put(TRANSACTION_ID_HEADER_NAME, correlationId);

        log.info("I9 message received id: {} headers: {} payload: {} correlationId: {}",
            pubsubMessage.getMessageId(), pubsubMessage.getAttributesMap(), messageDataString,
            correlationId);

        headers = I9HeaderBuilder.build(pubsubMessage);

        try {
            I9FormEventMessage eventMessage = objectMapper
                .readValue(messageDataString, I9FormEventMessage.class);

            final String messageId = pubsubMessage.getMessageId();
            eventMessage.setMessageId(messageId);

            final String documentId = pubsubMessage.getAttributesMap().get(DOCUMENT_ID_KEY);
            eventMessage.getDocument().setDocumentId(documentId);

            final String status = pubsubMessage.getAttributesMap().get(STATUS_KEY);
            eventMessage.setStatus(status);

            historyEventListener.onEventReceived(eventMessage);
            basicAcknowledgeablePubsubMessage.ack().addCallback(new ListenableFutureCallback<>() {
                @Override
                public void onFailure(Throwable ex) {
                    log.error(format("Message ack failed. Message Id: %s, Message Attributes: %s, Message Data: %s",
                        pubsubMessage.getMessageId(), pubsubMessage.getAttributesMap(), messageDataString), ex);
                }

                @Override
                public void onSuccess(Void result) {
                    log.debug("Message with Id {} acked", pubsubMessage.getMessageId());
                }
            });
        } catch (JsonProcessingException e) {
            log.error(format("Message data can't be parsed. Message Id: %s, Message Attributes: %s, Message Data: %s",
                pubsubMessage.getMessageId(), pubsubMessage.getAttributesMap(), messageDataString), e);
            basicAcknowledgeablePubsubMessage.nack();
        } catch (Exception e) {
            log.error(
                format("Error occurred during processing. Message Id: %s, Message Attributes: %s, Message Data: %s",
                    pubsubMessage.getMessageId(), pubsubMessage.getAttributesMap(), messageDataString), e);
            basicAcknowledgeablePubsubMessage.nack();
        } finally {
            MDC.remove(TRANSACTION_ID_HEADER_NAME);
        }
    }

    /**
     * Fetches all I9 form audits from API.
     * This will get only audits with "dataUpdate" set to "true".
     * That means audit with eventKey = "new" won't be included in result list (it's not a data-update audit)
     */
    @Override
    public List<I9AuditModel> getAudits(String documentId) {
        ResponseEntity<List<I9AuditModel>> responseEntity = i9ApiCall.getFormDataAudits(documentId)
                .subscriberContext(Context.of(headers))
                .block();

        if (responseEntity != null && responseEntity.getBody() != null) {
            return responseEntity.getBody();
        } else {
            return Collections.emptyList();
        }
    }

    @Override
    public I9Form getRevision(String documentId, long revision) {
        return i9ApiCall.getFormByRevision(documentId, String.valueOf(revision))
                .subscriberContext(Context.of(headers))
                .block();
    }
}
