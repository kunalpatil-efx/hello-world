package com.efx.ews.es.i9integration.i9portaleventshandler.utils;

import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.gcp.pubsub.core.subscriber.PubSubSubscriberOperations;
import org.springframework.cloud.gcp.pubsub.integration.AckMode;
import org.springframework.cloud.gcp.pubsub.integration.inbound.PubSubInboundChannelAdapter;
import org.springframework.cloud.gcp.pubsub.support.AcknowledgeablePubsubMessage;
import org.springframework.cloud.gcp.pubsub.support.BasicAcknowledgeablePubsubMessage;
import org.springframework.cloud.gcp.pubsub.support.GcpPubSubHeaders;
import org.springframework.messaging.Message;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

@Slf4j
public class MessageConfirmation {
    private static final int timeoutValue = 30;
    private static final TimeUnit timeoutUnit = TimeUnit.SECONDS;
    private final ContextLogging contextLogging;

    public MessageConfirmation() {
        this(null);
    }

    public MessageConfirmation(Class<?> contextClass) {
        this.contextLogging = new ContextLogging(contextClass);
    }

    public static PubSubInboundChannelAdapter manualAckMessageChannel(PubSubSubscriberOperations pubSubSubscriberOperations, String subscription) {
        PubSubInboundChannelAdapter adapter = new PubSubInboundChannelAdapter(pubSubSubscriberOperations, subscription);
        adapter.setAckMode(AckMode.MANUAL);
        return adapter;
    }

    public void acknowledge(AcknowledgeablePubsubMessage message) {
        try {
            message.ack().get(timeoutValue, timeoutUnit);
            contextLogging.logWithContext(() -> log.debug("Acknowledging message: {}", message));
        } catch (InterruptedException | ExecutionException | TimeoutException e) {
            contextLogging.logWithContext(() -> log.warn("error while message ack", e));
        }
    }

    public void acknowledge(Message<?> message) {
        BasicAcknowledgeablePubsubMessage acknowledgeablePubSubMessage = message.getHeaders()
                .get(GcpPubSubHeaders.ORIGINAL_MESSAGE, BasicAcknowledgeablePubsubMessage.class);
        if (acknowledgeablePubSubMessage == null) {
            log.error("Could not get ORIGINAL_MESSAGE header. Failed to acknowledge message");
            return;
        }
        try {
            acknowledgeablePubSubMessage.ack().get(timeoutValue, timeoutUnit);
            log.debug("Acknowledging message: {}", message);
        } catch (InterruptedException | ExecutionException | TimeoutException e) {
            log.warn("error while message ack", e);
        }
    }

    public void nAcknowledge(AcknowledgeablePubsubMessage message) {
        try {
            message.nack().get(timeoutValue, timeoutUnit);
            contextLogging.logWithContext(() -> log.debug("NAcknowledging message: {}", message));
        } catch (InterruptedException | ExecutionException | TimeoutException e) {
            contextLogging.logWithContext(() -> log.warn("error while message nack", e));
        }
    }

    public void nAcknowledge(Message<?> message) {
        BasicAcknowledgeablePubsubMessage acknowledgeablePubSubMessage = message.getHeaders()
                .get(GcpPubSubHeaders.ORIGINAL_MESSAGE, BasicAcknowledgeablePubsubMessage.class);
        if (acknowledgeablePubSubMessage == null) {
            log.error("Could not get ORIGINAL_MESSAGE header. Failed to acknowledge message");
            return;
        }
        try {
            acknowledgeablePubSubMessage.nack().get(timeoutValue, timeoutUnit);
            log.debug("NAcknowledging message: {}", message);
        } catch (InterruptedException | ExecutionException | TimeoutException e) {
            log.warn("error while message nack", e);
        }
    }
}
