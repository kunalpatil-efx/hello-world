package com.efx.ews.es.i9datasourcing.dep.api;

import com.efx.ews.es.i9datasourcing.constant.DepEventName;
import com.efx.ews.es.i9datasourcing.dep.model.DepEventPayload;
import com.efx.ews.es.i9datasourcing.model.ChangeContext;

public interface DepEventPayloadSender {

    void publish(DepEventPayload eventPayload, ChangeContext changeContext, DepEventName eventName);
}
