package com.efx.ews.es.i9datasourcing.fieldconverter;

import com.efx.ews.es.i9datasourcing.formatter.Formatters;
import java.time.format.DateTimeFormatter;

class DateConverter extends TemporalConverter {

    private static final DateTimeFormatter SOURCE_FORMATTER = DateTimeFormatter.ISO_DATE;
    private static final DateTimeFormatter TARGET_FORMATTER = Formatters.DATE_FORMATTER;
    private static final DateTimeFormatter ALTERNATIVE_SOURCE_FORMATTER = Formatters.DATE_FORMATTER_US;

    DateConverter(String dateFieldName) {
        super(dateFieldName, SOURCE_FORMATTER, ALTERNATIVE_SOURCE_FORMATTER, TARGET_FORMATTER);
    }

    DateConverter(String dateFieldName, DateTimeFormatter sourceFormatter) {
        super(dateFieldName, sourceFormatter, ALTERNATIVE_SOURCE_FORMATTER, TARGET_FORMATTER);
    }
}
