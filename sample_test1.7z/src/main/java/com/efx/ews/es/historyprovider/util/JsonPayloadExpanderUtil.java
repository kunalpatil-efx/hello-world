package com.efx.ews.es.historyprovider.util;

import com.efx.ews.es.i9datasourcing.dep.model.DepEventPayload;
import java.util.Objects;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.apache.commons.lang.StringUtils;
import org.json.simple.JSONObject;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class JsonPayloadExpanderUtil {

    private static final String DOT_SEPARATOR = ".";
    private static final int BEGIN_INDEX = 0;
    private static final int ONE = 1;

    public static String expand(DepEventPayload eventPayload) {
        JSONObject returningJson = new JSONObject();
        eventPayload.getFields().stream()
            .filter(Objects::nonNull)
            .forEach(field -> processElement(returningJson, field.getName(), field.getValue()));
        return returningJson.toJSONString();
    }

    private static void processElement(JSONObject returningJson, String key, final Object value) {
        JSONObject workingJson = returningJson;
        boolean lastItem = false;
        final Object valueToPut = StringUtils.EMPTY.equals(value) ? null : value;

        while (key.contains(DOT_SEPARATOR)) {
            String primaryKey = key.substring(BEGIN_INDEX, key.indexOf(DOT_SEPARATOR));
            if (workingJson.containsKey(primaryKey) && !(workingJson.get(primaryKey) instanceof String)) {
                workingJson = (JSONObject) workingJson.get(primaryKey);
                key = key.substring(key.indexOf(DOT_SEPARATOR) + ONE);
            } else {
                workingJson.put(primaryKey, generateJson(key.substring(key.indexOf(DOT_SEPARATOR) + ONE), valueToPut));
                lastItem = true;
                break;
            }
        }
        if (!lastItem) {
            workingJson.put(key, valueToPut);
        }
    }

    private static JSONObject generateJson(String key, Object value) {
        JSONObject json = new JSONObject();
        if (key.contains(DOT_SEPARATOR)) {
            json.put(key.substring(0, key.indexOf(DOT_SEPARATOR)),
                generateJson(key.substring(key.indexOf(DOT_SEPARATOR) + ONE), value));
        } else {
            json.put(key, value);
        }
        return json;
    }
}
