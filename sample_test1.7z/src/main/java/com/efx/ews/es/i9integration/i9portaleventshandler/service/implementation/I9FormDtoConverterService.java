package com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.dto.TaskDto;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.Task;

public interface I9FormDtoConverterService {
    TaskDto toDto(Task task);
}
