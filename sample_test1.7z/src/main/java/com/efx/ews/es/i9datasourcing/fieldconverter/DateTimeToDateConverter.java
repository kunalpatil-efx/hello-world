package com.efx.ews.es.i9datasourcing.fieldconverter;

import com.efx.ews.es.i9datasourcing.formatter.Formatters;
import java.time.format.DateTimeFormatter;

class DateTimeToDateConverter extends TemporalConverter {

    private static final DateTimeFormatter SOURCE_FORMATTER = DateTimeFormatter.ISO_DATE_TIME;
    private static final DateTimeFormatter ALTERNATIVE_SOURCE_FORMATTER = Formatters.DATE_FORMATTER;
    private static final DateTimeFormatter TARGET_FORMATTER = Formatters.DATE_FORMATTER;

    DateTimeToDateConverter(String dateTimeFieldName) {
        super(dateTimeFieldName, SOURCE_FORMATTER, ALTERNATIVE_SOURCE_FORMATTER, TARGET_FORMATTER);
    }
}
