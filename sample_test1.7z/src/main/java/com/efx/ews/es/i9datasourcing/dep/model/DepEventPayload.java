package com.efx.ews.es.i9datasourcing.dep.model;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class DepEventPayload {

    private List<DepEventPayloadField> fields;
}
