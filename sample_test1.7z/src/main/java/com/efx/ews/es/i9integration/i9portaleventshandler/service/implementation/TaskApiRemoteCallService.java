package com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.I9Form;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.I9FormResponse;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.Task;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.event.I9EventPayload;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.task.TaskResponse;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.TaskApiProperties.TaskType;
import reactor.core.publisher.Mono;

public interface TaskApiRemoteCallService {
    Mono<Task> createSection2Task(String documentId, I9EventPayload i9FormResponse);
    Mono<Task> createSsnAppliedTask(String documentId, I9EventPayload i9FormResponse);
    Mono<Task> completeTask(String documentId, Task task, String userId);
    Mono<Task> deleteTask(String documentId, Task task);
    Mono<TaskResponse> getTask(String taskId);
    boolean isValidContext(String sourceId);
    Mono<Task> createSection2DocumentUpload(String documentId, I9EventPayload i9FormResponse);
    Mono<Task> createTask(TaskType taskType, String documentId, I9FormResponse i9FormResponse);
    Mono<Task> createReceiptUpdateTask(String documentId, I9Form i9FormResponse);
}
