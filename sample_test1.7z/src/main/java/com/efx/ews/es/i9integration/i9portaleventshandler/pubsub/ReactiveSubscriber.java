package com.efx.ews.es.i9integration.i9portaleventshandler.pubsub;


import org.springframework.cloud.gcp.pubsub.reactive.PubSubReactiveFactory;
import org.springframework.cloud.gcp.pubsub.support.AcknowledgeablePubsubMessage;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import reactor.core.Disposable;
import reactor.core.publisher.Flux;

@Scope("prototype")
@Component
public class ReactiveSubscriber implements Disposable {
    private PubSubReactiveFactory reactiveFactory;
    private Disposable subscription;

    public ReactiveSubscriber(PubSubReactiveFactory reactiveFactory) {
        this.reactiveFactory = reactiveFactory;
    }

    public void subscribe(ReactiveSubscription reactiveSubscription, String subscriptionName) {
        final Flux<AcknowledgeablePubsubMessage> flux = reactiveFactory.poll(subscriptionName, 100);
        subscription = reactiveSubscription.processing(flux).subscribe();
    }

    @Override
    public void dispose() {
        subscription.dispose();
    }
}
