package com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.referenceapi.Country;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.referenceapi.DocumentDefinition;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.referenceapi.DocumentField;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.referenceapi.IssuingAuthorityLookup;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.referenceapi.Province;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.referenceapi.State;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.referenceapi.response.CountriesResponse;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.referenceapi.response.ProvincesResponse;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.referenceapi.response.StatesResponse;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.AbstractRemoteServiceProperties.RemoteResource;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.ReferenceApiProperties;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.stream.Collectors;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.message.BasicNameValuePair;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;
import reactor.core.publisher.Mono;

@Slf4j
@Component
public class ReferenceApiConnector {

    private static final String ISSUING_AUTHORITY = "issuingAuthority";

    private WebClientConnector<ReferenceApiProperties> connector;
    private final ReferenceApiProperties properties;

    private final ConcurrentHashMap<String, Map<String, State>> statesCodeMapCache = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, Map<String, Country>> countriesCodeMapCache = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, List<Country>> countriesCache = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, Map<String, Province>> provincesCodeMapCache = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, Map<String, IssuingAuthorityLookup>> issAuthorityMapCache
        = new ConcurrentHashMap<>();


    @Autowired
    public ReferenceApiConnector(ReferenceApiProperties props,
        @Value("${webclient.codec.maxinmemorybytes}") int webClientCodecMaxInMemory) {
        properties = props;
        connector = new WebClientConnector<>(properties, webClientCodecMaxInMemory);
    }

    public Mono<Map<String, State>> getStateCodeMap(String i9Version) {
        if(statesCodeMapCache.containsKey(i9Version)) {
            return Mono.just(statesCodeMapCache.get(i9Version));
        } else {
            return getStates(i9Version)
                .map(stateList -> {
                    Map<String, State> stateMap =
                        stateList.stream().collect(Collectors.toMap(State::getCode, Function.identity()));
                    statesCodeMapCache.put(i9Version, stateMap);
                    return stateMap;
                });
        }
    }

    public Mono<List<State>> getStates(String i9Version) {
        log.info("Fetching states from references api {}", toUrlFormat(properties.getStates(), i9Version));
        return getData("states", properties.getStates(), i9Version,
            new ParameterizedTypeReference<StatesResponse>() {})
            .map(statesResponse -> {
                List<State> states = statesResponse.getStates();
                log.info("States count from Reference API: {}", states != null ? states.size() : 0);
                return states;
            })
            .doOnError(t -> log.error("Error in retrieving states from Reference API: {}", t.getMessage()));
    }

    public Mono<Map<String, Country>> getCountryCodeMap(String i9Version) {
        if(countriesCodeMapCache.containsKey(i9Version)) {
            return Mono.just(countriesCodeMapCache.get(i9Version));
        } else {
            return getCountries(i9Version)
                .map(countryList -> {
                    Map<String, Country> countryMap =
                        countryList.stream().collect(Collectors.toMap(Country::getCode, Function.identity()));
                    countriesCodeMapCache.put(i9Version, countryMap);
                    return countryMap;
                });
        }
    }

    public Mono<List<Country>> getCountries(String i9Version) {
        if(countriesCache.containsKey(i9Version)) {
            return Mono.just(countriesCache.get(i9Version));
        } else {
            log.info("Fetching countries from references api {}", toUrlFormat(properties.getCountries(), i9Version));
            return getData("countries", properties.getCountries(), i9Version,
                new ParameterizedTypeReference<CountriesResponse>() {})
                .map(countriesResponse -> {
                    List<Country> countries = countriesResponse.getCountries();
                    if(countries != null) {
                        countriesCache.put(i9Version, countries);
                    }
                    log.info("Countries count from Reference API: {}", countries != null ? countries.size() : 0);
                    return countries;
                });
        }
    }

    public Mono<Map<String, Province>> getProvinceCodeMap(String i9Version) {
        if(provincesCodeMapCache.containsKey(i9Version)) {
            return Mono.just(provincesCodeMapCache.get(i9Version));
        } else {
            return getProvinces(i9Version)
                .map(provinceList -> {
                    Map<String, Province> provinceMap = provinceList.stream()
                        .collect(Collectors.toMap(Province::getCode, Function.identity()));
                    provincesCodeMapCache.put(i9Version, provinceMap);
                    return provinceMap;
                });
        }
    }

    public Mono<List<Province>> getProvinces(String i9Version) {
        log.info("Fetching provinces from references api {}", toUrlFormat(properties.getProvinces(), i9Version));
        return getData("provinces", properties.getProvinces(), i9Version,
                new ParameterizedTypeReference<ProvincesResponse>() {})
            .map(provincesResponse -> {
                List<Province> provinces = provincesResponse.getProvinces();
                log.info("Provinces count from Reference API: {}", provinces != null ? provinces.size() : 0);
                return provinces;
            });
    }

    public Mono<Map<String, IssuingAuthorityLookup>> getIssuingAuthorityMap(String i9Version) {
        if(issAuthorityMapCache.containsKey(i9Version)) {
            return Mono.just(issAuthorityMapCache.get(i9Version));
        } else {
            return getDocumentDefinitions(i9Version)
                .map(docDefList -> {
                    Map<String, IssuingAuthorityLookup> map = docDefList.stream().filter(dd ->
                            dd.getFields().stream().anyMatch(field -> ISSUING_AUTHORITY.equals(field.getName()))
                        ).map(dd -> {
                            IssuingAuthorityLookup lookup = null;
                            Optional<DocumentField> field = dd.getFields().stream()
                                .filter(f -> ISSUING_AUTHORITY.equals(f.getName())
                                    && StringUtils.isNotEmpty(f.getIssuingAuthorityType())).findFirst();
                            if (field.isPresent()) {
                                lookup = new IssuingAuthorityLookup(dd.getDisplayName(),
                                    field.get().getIssuingAuthorityType());
                            }
                            return lookup;
                        }).filter(l -> l != null)
                            .collect(Collectors.toMap(IssuingAuthorityLookup::getDocumentTitle, Function.identity()));
                    issAuthorityMapCache.put(i9Version, map);
                    return map;
                })
                .doOnError(t -> log.error("Connector: Error in getting document definitions"));
        }
    }

    public Mono<List<DocumentDefinition>> getDocumentDefinitions(String i9Version) {
        log.info("Fetching document definition from references api {}", toUrlFormat(properties.getDocuments(), i9Version));
        return getData("document definitions", properties.getDocuments(), i9Version,
                new ParameterizedTypeReference<List<DocumentDefinition>>() {});
    }

    private <T> Mono<T> getData(final String dataDescription, final RemoteResource resource,
        final String i9Version, final ParameterizedTypeReference<T> p) {
        log.debug("Retrieving list of " + dataDescription);
        return connector.getToApi(resource, null, Arrays.asList(new BasicNameValuePair("i9Version", i9Version)))
            .flatMap(response -> {
                if (response.statusCode().is2xxSuccessful()){
                    return response.bodyToMono(p);
                }
                String errorMsg = String.format("Failed to get data from reference-api %s : %s",
                    resource.getPath(), response.statusCode());
                log.error(errorMsg);
                return Mono.empty();
            })
            .doOnError(t -> log.error("Error retrieving data for {} : {} ", dataDescription, t.getMessage()));
    }

    private String toUrlFormat(RemoteResource resource, String i9Version) {
        return UriComponentsBuilder.newInstance()
            .scheme(properties.getScheme())
            .host(properties.getHost())
            .port(properties.getPort())
            .path(properties.getPath())
            .pathSegment(resource.getPath())
            .queryParam("i9Version", Collections.singletonList(i9Version))
            .toUriString();
    }

}
