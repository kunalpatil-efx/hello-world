package com.efx.ews.es.historyprovider.model;

import static com.efx.ews.es.i9datasourcing.constant.I9Event.FORM_CREATED;
import static com.efx.ews.es.i9datasourcing.constant.I9Event.MIGRATED_I9;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class EventMessageDocument {

    private String documentId;
    private String employerId;
    private String sourceId;
    private String status;
    private Integer recordVersion;
    private String modelVersion;
    private String employerLocationId;
    private String employeeFactId;
    private String employeeId;
    private String projectedStartDate;
    private String sourceRefId;
    private String everifyVersion;
    private String formRevDate;
    private String stateChangeDate;
    private String handlerTriggerDate;

    public boolean isNewForm() {
        return FORM_CREATED.getEventKey().equalsIgnoreCase(status);
    }
}
