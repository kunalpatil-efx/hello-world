package com.efx.ews.es.i9integration.i9portaleventshandler.service.properties;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;

@Component
@ConfigurationProperties(prefix = "partner-api")
@Data
@EqualsAndHashCode(callSuper = true)
public class I9PartnerApiProperties extends AbstractRemoteServiceProperties {

    RemoteResource status;

    private String businessPath;
    private Boolean useInternalEndpoint = Boolean.TRUE;

    public UriComponentsBuilder getAppointmentStatusUrlBuilder() {
        return getBaseUriComponentsBuilder()
            .pathSegment(getStatus().getPath())
            .pathSegment("{appointmentId}")
            .pathSegment(getStatus().getOperation());
    }

    @Override
    UriComponentsBuilder getBaseUriComponentsBuilder() {
        return UriComponentsBuilder.newInstance()
            .scheme(getScheme())
            .host(getHost())
            .port(getPort())
            .path(useInternalEndpoint ? getPath() : getBusinessPath());
    }
}
