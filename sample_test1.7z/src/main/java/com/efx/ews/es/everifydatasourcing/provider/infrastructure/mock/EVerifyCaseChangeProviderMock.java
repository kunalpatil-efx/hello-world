package com.efx.ews.es.everifydatasourcing.provider.infrastructure.mock;

import static com.efx.ews.es.common.filter.CorrelationFilter.TRANSACTION_ID_HEADER_NAME;
import static org.springframework.util.ResourceUtils.getFile;

import com.efx.ews.es.everifydatasourcing.model.EVerifyCase;
import com.efx.ews.es.everifydatasourcing.model.pubsub.EventMessage;
import com.efx.ews.es.everifydatasourcing.provider.api.EVerifyCaseChangeEventListener;
import com.efx.ews.es.everifydatasourcing.provider.api.EVerifyCaseChangeProvider;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Service
@Profile("mocked")
@Slf4j
@RequiredArgsConstructor
@RestController
@RequestMapping("/mock/change-case")
public class EVerifyCaseChangeProviderMock implements EVerifyCaseChangeProvider {

    private static final String PATH_TO_EVERIFY_FILES = "classpath:everifycase/";
    private EVerifyCaseChangeEventListener eventListener;
    private final ObjectMapper objectMapper;

    @Override
    public void registerEventListener(EVerifyCaseChangeEventListener eventListener) {
        this.eventListener = eventListener;
    }

    @GetMapping
    @SneakyThrows
    public void changeCaseMessage() {

        String correlationId = UUID.randomUUID().toString();
        MDC.put(TRANSACTION_ID_HEADER_NAME, correlationId);

        try {
            File everifyChangeCaseMessageFile = getFile(PATH_TO_EVERIFY_FILES + "everify-change-case-message.json");
            EventMessage eventMessage = objectMapper.readValue(everifyChangeCaseMessageFile, EventMessage.class);
            eventListener.onEventReceived(eventMessage);
        } finally {
            MDC.remove(TRANSACTION_ID_HEADER_NAME);
        }
    }

    @Override
    @SneakyThrows
    public EVerifyCase getCaseById(String caseId) {
        File formFile = getFile(PATH_TO_EVERIFY_FILES + "everify-case-mock.json");
        return objectMapper.readValue(formFile, EVerifyCase.class);
    }
}
