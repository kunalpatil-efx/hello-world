package com.efx.ews.es.i9datasourcing.fieldconverter;

import com.efx.ews.es.i9datasourcing.fieldconverter.Utils.Constants;
import java.util.Map;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class BlankConverter implements FieldDataConverter {

    public static final BlankConverter INSTANCE = new BlankConverter();

    @Override
    public String convert(Map<String, String> ignored) {
        return Constants.DEFAULT_EMPTY_VALUE;
    }
}
