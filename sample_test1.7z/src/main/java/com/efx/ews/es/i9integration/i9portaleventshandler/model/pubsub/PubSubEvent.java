package com.efx.ews.es.i9integration.i9portaleventshandler.model.pubsub;

import lombok.Data;

@Data
public class PubSubEvent {
    private String specVersion;
    private String businessUnit;
    private String tribeName;
    private String domain;
    private String subDomain;
    private String appId;
    private String appName;
    private String appTraceId;
    private String clientTransactionId;
    private String correlationId;
    private String eventType;
    private String eventSource;
    private String eventGenerator;
    private String eventTrigger;
    private String eventName;
    private String eventTime;
    private String encryptionMetadata;
    private String dekKeyPath;
    private String eventPayload;
    private String publisherId;
    private Boolean encryptionIndicator;
    private String employeeId;
}
