package com.efx.ews.es.historyprovider.infrastructure.mock;

import static com.efx.ews.es.common.filter.CorrelationFilter.TRANSACTION_ID_HEADER_NAME;

import com.efx.ews.es.historyprovider.api.HistoryEventListener;
import com.efx.ews.es.historyprovider.api.I9FormHistoryProvider;
import com.efx.ews.es.historyprovider.model.I9AuditModel;
import com.efx.ews.es.historyprovider.model.I9FormEventMessage;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.I9Form;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import javax.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.MDC;
import org.springframework.context.annotation.Profile;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Profile("mocked")
@Slf4j
@RequiredArgsConstructor
@RestController
@RequestMapping("/mock/update-form")
public class MockI9FormHistoryProviderAdapter implements I9FormHistoryProvider {

    private static final Map<String, List<I9AuditModel>> AUDITS = new HashMap<>();
    private static final Map<Pair<String, Long>, I9Form> FORMS = new HashMap<>();
    private static final List<String> LIST_OF_I9_FORM_FILE = List.of("i9form-1-mock.json", "i9form-2-mock.json");
    private static final String FORM_EVENT_MESSAGES_FILE = "i9form-event-message-1-mock.json";

    private static final String DOCUMENT_ID = "00eoPiBdzg9TFY0sUmIs";

    private HistoryEventListener historyEventListener;

    private final ObjectMapper objectMapper;

    @PostConstruct
    public void init() {
        initData();
    }

    @SneakyThrows
    @GetMapping
    public void updateFormMessage() {

        String correlationId = UUID.randomUUID().toString();
        MDC.put(TRANSACTION_ID_HEADER_NAME, correlationId);

        try {
            ClassLoader classLoader = MockI9FormHistoryProviderAdapter.class.getClassLoader();
            File formEventMessageFile = new File(
                Objects.requireNonNull(classLoader.getResource("i9forms/" + FORM_EVENT_MESSAGES_FILE)).toURI());
            I9FormEventMessage formEventMessage = objectMapper
                .readValue(formEventMessageFile, I9FormEventMessage.class);
            formEventMessage.getDocument().setDocumentId(DOCUMENT_ID);
            historyEventListener.onEventReceived(formEventMessage);
        } finally {
            MDC.remove(TRANSACTION_ID_HEADER_NAME);
        }
    }

    @Override
    public void registerEventListener(HistoryEventListener historyEventListener) {
        this.historyEventListener = historyEventListener;
    }

    @Override
    public List<I9AuditModel> getAudits(String documentId) {
        return AUDITS.get(documentId);
    }

    @Override
    public I9Form getRevision(String documentId, long revision) {
        return FORMS.get(Pair.of(documentId, revision));
    }

    private void initData() {
        ClassLoader classLoader = MockI9FormHistoryProviderAdapter.class
            .getClassLoader();

        initForms(classLoader);
        initAudits(classLoader);
    }

    private void initAudits(ClassLoader classLoader) {
        try {
            File auditsFile = new File(
                Objects.requireNonNull(classLoader.getResource("i9forms/i9audits-list-mock.json")).toURI());
            List<I9AuditModel> audits = objectMapper.readValue(auditsFile,
                objectMapper.getTypeFactory().constructCollectionType(List.class, I9AuditModel.class));
            AUDITS.put(DOCUMENT_ID, audits);
        } catch (URISyntaxException | IOException e) {
            log.error("initData() failed to load auditsFile", e);
        }
    }

    private void initForms(ClassLoader classLoader) {
        LIST_OF_I9_FORM_FILE
            .forEach(fileName -> {
                try {
                    File formFile = new File(
                        Objects.requireNonNull(classLoader.getResource("i9forms/" + fileName)).toURI());
                    I9Form form = objectMapper.readValue(formFile, I9Form.class);
                    FORMS.put(Pair.of(DOCUMENT_ID, form.getRecordVersion()), form);
                } catch (IOException | URISyntaxException e) {
                    log.error(String.format("initData() failed to load formFile from %s", fileName), e);
                }
            });
    }
}
