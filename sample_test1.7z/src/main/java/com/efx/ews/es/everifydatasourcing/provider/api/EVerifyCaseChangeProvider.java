package com.efx.ews.es.everifydatasourcing.provider.api;

import com.efx.ews.es.everifydatasourcing.model.EVerifyCase;

public interface EVerifyCaseChangeProvider {

    void registerEventListener(EVerifyCaseChangeEventListener eventListener);

    EVerifyCase getCaseById(String caseId);
}
