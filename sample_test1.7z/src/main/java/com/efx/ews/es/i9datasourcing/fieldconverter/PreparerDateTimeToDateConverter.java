package com.efx.ews.es.i9datasourcing.fieldconverter;

import java.util.Map;

public class PreparerDateTimeToDateConverter extends IndexedFieldNameConverter {

    public PreparerDateTimeToDateConverter(String fieldNameWithoutIndex, int index) {
        super(fieldNameWithoutIndex, "preparers", index);
    }

    @Override
    public String convert(Map<String, String> flattenedI9Form) {
        String fieldName = super.convert(flattenedI9Form);
        return new DateTimeToDateConverter(fieldName).convert(flattenedI9Form);
    }
}
