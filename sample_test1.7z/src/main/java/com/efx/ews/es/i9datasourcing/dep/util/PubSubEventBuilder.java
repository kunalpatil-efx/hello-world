package com.efx.ews.es.i9datasourcing.dep.util;

import com.efx.ews.es.common.filter.CorrelationFilter;
import com.efx.ews.es.eev.barricade.common.model.PubSubEncryptedData;
import com.efx.ews.es.i9datasourcing.dep.model.DepEventDataHolder;
import com.efx.ews.es.i9datasourcing.formatter.TemporalFormatter;
import com.efx.ews.es.i9datasourcing.model.ChangeContext;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.pubsub.PubSubEvent;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.configuration.PubSubProperties;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.UUID;

@Slf4j
@RequiredArgsConstructor
@Component
public class PubSubEventBuilder {

    private final TemporalFormatter temporalFormatter;
    private final PubSubProperties pubSubProperties;

    private static final String TRANSACTIONAL_EVENT = "TRANSACTIONAL_EVENT";

    private PubSubEvent buildCommonEvent(PubSubEncryptedData pubSubEncryptedData) {

        PubSubEvent pubSubEvent = new PubSubEvent();

        pubSubEvent.setSpecVersion(pubSubProperties.getSpecVersion());
        pubSubEvent.setBusinessUnit(pubSubProperties.getBusinessUnit());
        pubSubEvent.setTribeName(pubSubProperties.getTribeName());
        pubSubEvent.setDomain(pubSubProperties.getDomain());
        pubSubEvent.setSubDomain(pubSubProperties.getSubDomain());
        pubSubEvent.setAppId(pubSubProperties.getAppId());
        pubSubEvent.setAppName(pubSubProperties.getAppName());
        pubSubEvent.setClientTransactionId(pubSubProperties.getClientTransactionId());
        pubSubEvent.setEventSource(pubSubProperties.getEventSource());
        pubSubEvent.setEventGenerator(pubSubProperties.getEventGenerator());
        pubSubEvent.setEventTrigger(pubSubProperties.getEventTrigger());
        String uuid = UUID.randomUUID().toString();
        pubSubEvent.setAppTraceId(uuid);
        log.info("AppTraceId {}", uuid);
        pubSubEvent.setEncryptionIndicator(true);
        pubSubEvent.setEventPayload(pubSubEncryptedData.getEncryptedEventPayload());
        pubSubEvent.setEncryptionMetadata(pubSubEncryptedData.getEncryptionMetadata());
        pubSubEvent.setDekKeyPath(pubSubEncryptedData.getGcsBucketPath());

        return pubSubEvent;
    }

    public PubSubEvent buildAuditEvent(DepEventDataHolder depEventDataHolder, PubSubEncryptedData pubSubEncryptedData) {

        ChangeContext changeContext = depEventDataHolder.getChangeContext();

        PubSubEvent pubSubEvent = buildCommonEvent(pubSubEncryptedData);
        pubSubEvent.setCorrelationId(changeContext.getCorrelationId());
        pubSubEvent.setPublisherId(changeContext.getDeduplicationId());
        pubSubEvent.setEventType(TRANSACTIONAL_EVENT);
        pubSubEvent.setEventName(depEventDataHolder.getEventName());
        pubSubEvent.setEventTime(temporalFormatter.formatInstant(changeContext.getSourceEventDateTime()));
        pubSubEvent.setPublisherId(changeContext.getDeduplicationId());
        return pubSubEvent;
    }

    public PubSubEvent buildBillingEvent(DepEventDataHolder depEventDataHolder,
        PubSubEncryptedData pubSubEncryptedData) {

        PubSubEvent pubSubEvent = buildCommonEvent(pubSubEncryptedData);
        String uuid = UUID.randomUUID().toString();
        pubSubEvent.setCorrelationId(CorrelationFilter.getTransactionId().orElse(uuid));
        pubSubEvent.setPublisherId(uuid);
        log.info("PublisherId {}", uuid);
        pubSubEvent.setEventType(pubSubProperties.getEventType());
        pubSubEvent.setEventName(pubSubProperties.getEventName());
        pubSubEvent.setEventTime(Instant.now().toString());

        return pubSubEvent;
    }

    public PubSubEvent buildDataPurgeBillingEvent(PubSubEncryptedData pubSubEncryptedData, String employeeId) {
        PubSubEvent pubSubEvent = buildCommonEvent(pubSubEncryptedData);
        String uuid = UUID.randomUUID().toString();
        pubSubEvent.setCorrelationId(CorrelationFilter.getTransactionId().orElse(uuid));
        pubSubEvent.setPublisherId(uuid);
        log.info("PublisherId {}", uuid);
        pubSubEvent.setAppId(pubSubProperties.getDataPurge().getAppId());
        pubSubEvent.setEventType(pubSubProperties.getDataPurge().getEventType());
        pubSubEvent.setEventName(pubSubProperties.getDataPurge().getEventName());
        pubSubEvent.setEventTime(Instant.now().toString());
        pubSubEvent.setEmployeeId(employeeId);
        return pubSubEvent;
    }
}
