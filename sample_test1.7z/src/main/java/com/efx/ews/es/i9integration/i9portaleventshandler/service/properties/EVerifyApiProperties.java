package com.efx.ews.es.i9integration.i9portaleventshandler.service.properties;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;

@Data
@Component
@ConfigurationProperties(prefix = "ev-api")
@EqualsAndHashCode(callSuper = true)
public class EVerifyApiProperties extends AbstractRemoteServiceProperties {

    RemoteResource casedata;

    public UriComponentsBuilder getCaseDataBuilder() {
        return getBaseUriComponentsBuilder()
            .pathSegment(casedata.getPath())
            .pathSegment("{caseId}");
    }
}
