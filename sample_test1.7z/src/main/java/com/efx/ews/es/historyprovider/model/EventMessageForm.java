package com.efx.ews.es.historyprovider.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class EventMessageForm {

    private Boolean specialPlacement;
    private Boolean validListBDocs;
    private Boolean ssnApplied;
    private Boolean ssnRefused;
    private Boolean isMinor;
}
