package com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.audit.AuditDbEntity;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.audit.AuditMessage;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.AuditDataFeed;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.FirestoreProperties;
import com.google.api.core.ApiFuture;
import com.google.api.core.ApiFutureCallback;
import com.google.api.core.ApiFutures;
import com.google.cloud.firestore.CollectionReference;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.QuerySnapshot;
import com.google.common.util.concurrent.MoreExecutors;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;
import reactor.core.publisher.MonoSink;

import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.stream.Collectors;

@Component
@Slf4j
@AllArgsConstructor
public class DataBaseAuditDataFeed implements AuditDataFeed {

    private static final String PACKETID_PATH = "message.attributes.sourceRefId";

    private Firestore firestore;
    private FirestoreProperties properties;

    @Override
    public Mono<List<AuditMessage>> fetchAuditData(String packetId) {
        CollectionReference collection = firestore.collection(properties.getCollections().getAudits());
        ApiFuture<QuerySnapshot> byPacketQuery = collection.whereEqualTo(PACKETID_PATH, packetId).get();
        return Mono.create(constructConsumer(byPacketQuery));
    }

    private Consumer<MonoSink<List<AuditMessage>>> constructConsumer(ApiFuture<QuerySnapshot> queryFuture) {
        return sink -> ApiFutures.addCallback(queryFuture, new ApiFutureCallback<>() {
            @Override
            public void onFailure(Throwable throwable) {
                sink.error(throwable);
            }
            @Override
            public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                sink.success(queryDocumentSnapshots.getDocuments()
                        .stream()
                        .map(doc -> doc.toObject((AuditDbEntity.class)))
                        .map(AuditDbEntity::getMessage)
                        .filter(Objects::nonNull)
                        .peek(message -> log.debug("Found matching message: {}", message.getMessageId()))
                        .collect(Collectors.toList())
                );
            }
        }, MoreExecutors.directExecutor());
    }
}
