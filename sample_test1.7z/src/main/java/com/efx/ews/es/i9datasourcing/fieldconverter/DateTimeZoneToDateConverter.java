package com.efx.ews.es.i9datasourcing.fieldconverter;

import com.efx.ews.es.i9datasourcing.formatter.Formatters;
import java.time.format.DateTimeFormatter;

public class DateTimeZoneToDateConverter extends TemporalConverter {

    private static final DateTimeFormatter SOURCE_FORMATTER = Formatters.DATE_TIME_FORMATTER_WITH_ZONE;
    private static final DateTimeFormatter ALTERNATIVE_SOURCE_FORMATTER = Formatters.DATE_FORMATTER;
    private static final DateTimeFormatter TARGET_FORMATTER = Formatters.DATE_FORMATTER;

    public DateTimeZoneToDateConverter(String dateTimeFieldName) {
        super(dateTimeFieldName, SOURCE_FORMATTER, ALTERNATIVE_SOURCE_FORMATTER, TARGET_FORMATTER);
    }
}
