package com.efx.ews.es.i9integration.i9portaleventshandler.service;

import com.efx.ews.es.eev.barricade.common.model.PubSubEncryptedData;
import com.efx.ews.es.i9datasourcing.dep.model.DepEventDataHolder;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.pubsub.Event;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.pubsub.PubSubEvent;
import reactor.core.publisher.Mono;

import java.io.IOException;
import java.util.function.BiFunction;

public interface DataEngineeringTopicService {

    Event sendEvent(DepEventDataHolder depEventDataHolder,
        BiFunction<DepEventDataHolder, PubSubEncryptedData, PubSubEvent> pubSubEventFactory) throws IOException;
    Mono<Event> sendEventAsync(DepEventDataHolder eventDataHolder,
                               BiFunction<DepEventDataHolder, PubSubEncryptedData, PubSubEvent> pubSubEventFactory);
    Event sendDataPurgeEvent(DepEventDataHolder eventDataHolder,String employeeId);
}
