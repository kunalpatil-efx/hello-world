package com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.Document;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.referenceapi.IssuingAuthorityLookup;
import java.util.List;
import java.util.Map;
import reactor.core.publisher.Mono;

public interface ReferenceApiService {

    Mono<List<Document>> updateIssuingAuthorityByTitle(Map<String, IssuingAuthorityLookup> lookup,
        List<Document> document, String i9Version);
    Mono<Map<String, IssuingAuthorityLookup>> getIssuingAuthorityMapByTitle(String i9Version);
    Mono<String> getStateName(String stateCode, String i9Version);
    Mono<String> getCountryName(String countryCode, String i9Version);
    Mono<String> getProvinceName(String provinceCode, String i9Version);

}
