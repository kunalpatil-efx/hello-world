package com.efx.ews.es.i9integration.i9portaleventshandler;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.I9EventStatus;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.EmployeeInfo;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.FormData;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.I9Form;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.SectionOne;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.SectionThree;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.ingest.IngestEmployeeFact;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.pdfGenerator.SectionsComparator;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.EmployerPersonApiCall;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.I9ApiCall;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.I9HeaderBuilder;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.logger.MdcReactorLogger;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.logger.MdcSetting;
import com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageConfirmation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gcp.pubsub.core.PubSubTemplate;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.dsl.RouterSpec;
import org.springframework.integration.router.MethodInvokingRouter;
import org.springframework.messaging.Message;
import reactor.core.publisher.Mono;
import reactor.util.context.Context;

import java.time.Instant;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import static com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageConfirmation.manualAckMessageChannel;

@Configuration
@Slf4j
public class IngestEmployeeSubscriberConfig {

    private final I9ApiCall i9ApiCall;
    private final MessageConfirmation messageConfirmation;
    private final EmployerPersonApiCall personApiCall;
    private final SubscriberErrorHandling errorHandling;

    public IngestEmployeeSubscriberConfig(
        I9ApiCall i9ApiCall,
        MessageConfirmation messageConfirmation,
        EmployerPersonApiCall personApiCall) {
        this.i9ApiCall = i9ApiCall;
        this.messageConfirmation = messageConfirmation;
        this.personApiCall = personApiCall;
        errorHandling = new SubscriberErrorHandling(log);
    }

    @Bean("SectionThreeSubscriberConfig")
    IntegrationFlow subscriberFlow(
        PubSubTemplate pubSubTemplate,
        @Value("${subscription.sectionThree}") String subscription
    ) {
        return IntegrationFlows
            .from(manualAckMessageChannel(pubSubTemplate, subscription))
            .route(Message.class, this::isSection3Completed, this::routeMessage)
            .get();
    }

    private void routeMessage(RouterSpec<Boolean, MethodInvokingRouter> mapping) {
        mapping.subFlowMapping(Boolean.TRUE, sf -> sf.handle(msg -> MdcSetting.wrapWithHeaders(msg, this::handleMessage)))
               .subFlowMapping(Boolean.FALSE, sf -> sf.handle(this::noIngestEmployeeFactForThisMessage));
    }

    void noIngestEmployeeFactForThisMessage(Message<?> message) {
        MdcSetting.wrapWithHeaders(message, () -> {
            log.info("SectionThreeSubscriberConfig filtered out {}", message.getHeaders().get("documentId", String.class));
            messageConfirmation.acknowledge(message);
        });
    }

    void handleMessage(Message message) {
        log.info("received message: {}", message);
        String documentId = message.getHeaders().get("documentId", String.class);
        String recordVersion = message.getHeaders().get("recordVersion", String.class);
        String status = message.getHeaders().get("status", String.class);

        i9ApiCall.getFormByRevision(documentId, recordVersion)
            .doOnEach(MdcReactorLogger.logOnNext(i9Form -> log.info("getFormByRevision successfully completed, documentId: {}", i9Form.getDocumentId())))
            .flatMap(currI9 -> {
              if(I9EventStatus.SECTION3_COMPLETE.getValue().equalsIgnoreCase(status)) {
                  return Mono.just(new CurrentAndPreviousI9FormResponse(currI9, null));
              }
              return i9ApiCall.getFormByRevision(documentId, findPrevRecordVersion(recordVersion))
                        .map(prevI9 -> new CurrentAndPreviousI9FormResponse(currI9, prevI9));
            })
            .map(response -> map(response.getCurrentI9Form(), response.getPreviousI9Form(), status))
            .filter(ingestEmployeeFact -> ingestEmployeeFact.isActive())
            .flatMap(ingestEmployeeFact -> personApiCall.postIngestEmployeeFact(ingestEmployeeFact))
            .doOnSuccess(i9Form -> messageConfirmation.acknowledge(message))
            .doOnEach(MdcReactorLogger.logOnNext(e -> log.info("Ingest Employee Fact successfully completed, documentId: {}", documentId)))
            .doOnEach(MdcReactorLogger.logOnError(t -> {
                if(errorHandling.processingCompleted(t)) {
                    errorHandling.logClientErrorException(documentId, t);
                }
            }))
            .onErrorResume(errorHandling::processingCompleted, t -> {
                messageConfirmation.acknowledge(message);
                return Mono.empty();
            })
            .doOnEach(MdcReactorLogger.logOnError(t -> {
                if(errorHandling.processingFailed(t)){
                    log.error("error in processing for documentId {}", documentId, t);
                }
            }))
            .onErrorResume(errorHandling::processingFailed, t -> {
                messageConfirmation.nAcknowledge(message);
                return Mono.empty();
            })
            .subscriberContext(Context.of(I9HeaderBuilder.build(message)))
            .block();
    }

    private String findPrevRecordVersion(String recordVersion) {
        if(recordVersion == null) {
            return null;
        }
        int version = Integer.parseInt(recordVersion);
        return String.valueOf(version - 1);
    }

    private IngestEmployeeFact map(I9Form i9Form, I9Form prevI9Form, String status) {
        IngestEmployeeFact ingestEmployeeFact = new IngestEmployeeFact();
        ingestEmployeeFact.setFactId(UUID.randomUUID().toString());
        ingestEmployeeFact.setFactTruthDate(Instant.now().toString());
        ingestEmployeeFact.setEmployerId(i9Form.getEmployerId());
        ingestEmployeeFact.setRootFactId(i9Form.getEmployeeFactId());
        if(I9EventStatus.SECTION1_AMENDED.getValue().equalsIgnoreCase(status)) {
            mapSectionOne(i9Form, prevI9Form, ingestEmployeeFact);
        } else if (I9EventStatus.SECTION3_COMPLETE.getValue().equalsIgnoreCase(status)) {
            mapSectionThree(i9Form, ingestEmployeeFact);
        }
        return ingestEmployeeFact;
    }

    private final static List<String> IGNORED_FIELDS = List.of("metadata",
            "attestation",
            "preparers",
            "signature",
            "signatureDate",
            "signatureText",
            "version");

    private void mapSectionOne(I9Form currI9Form, I9Form prevI9Form, IngestEmployeeFact ingestEmployeeFact) {
        ingestEmployeeFact.setFactTypeCode("SECTION1_GENERIC_FACT");
        SectionsComparator sectionsComparator = new SectionsComparator(IGNORED_FIELDS);
        SectionOne currS1 = currI9Form.getFormData().getSectionOne();
        SectionOne prevS1 = prevI9Form.getFormData().getSectionOne();
        sectionsComparator.eraseUnchanged(prevS1, currS1);

        EmployeeInfo employeeInfo = currS1.getEmployeeInfo();
        ingestEmployeeFact.setFirstName(employeeInfo.getFirstName());
        ingestEmployeeFact.setLastName(employeeInfo.getLastName());
        ingestEmployeeFact.setMiddleName(employeeInfo.getMiddleInitial());
        ingestEmployeeFact.setSsn(employeeInfo.getSocialSecurityNumber());
        ingestEmployeeFact.setCity(employeeInfo.getCity());
        ingestEmployeeFact.setAddressLine1(employeeInfo.getAddress());
        ingestEmployeeFact.setState(employeeInfo.getState());
        ingestEmployeeFact.setZipCode(employeeInfo.getZipCode());
        ingestEmployeeFact.setEmail(employeeInfo.getEmail());
        ingestEmployeeFact.setPhone(employeeInfo.getTelephoneNumber());
        ingestEmployeeFact.setDateOfBirth(employeeInfo.getDateOfBirth());
        ingestEmployeeFact.setActive(true);
    }

    private void mapSectionThree(I9Form i9Form, IngestEmployeeFact ingestEmployeeFact) {
        ingestEmployeeFact.setFactTypeCode("SECTION3_CHANGES_FACT");
        SectionThree sectionThree = Optional.of(i9Form)
            .map(I9Form::getFormData)
            .map(FormData::getSectionThreeList)
            .get()
            .stream()
            .max(Comparator.comparing(SectionThree::getTimestamp))
            .get();

        if (sectionThree.getIsNameChange()) {
            ingestEmployeeFact.setFirstName(sectionThree.getFirstName());
            ingestEmployeeFact.setLastName(sectionThree.getLastName());
            ingestEmployeeFact.setMiddleName(sectionThree.getMiddleInitial());
            ingestEmployeeFact.setActive(true);
        }
        if (sectionThree.getIsRehire()) {
            ingestEmployeeFact.setStartDate(sectionThree.getProjectedStartDate());
            ingestEmployeeFact.setActive(true);
        }
    }

    private static final Set<String> STATUSES = Set.of(I9EventStatus.SECTION1_AMENDED.getValue(),
            I9EventStatus.SECTION3_COMPLETE.getValue());
    private boolean isSection3Completed(Message<?> message) {
        String status = message.getHeaders().get("status", String.class);
        return STATUSES.contains(status);
    }


    private static class CurrentAndPreviousI9FormResponse {
        private final I9Form currentI9Form, previousI9Form;

        CurrentAndPreviousI9FormResponse(I9Form currentI9Form, I9Form previousI9Form) {
            this.currentI9Form = currentI9Form;
            this.previousI9Form = previousI9Form;
        }

        public I9Form getCurrentI9Form() {
            return currentI9Form;
        }

        public I9Form getPreviousI9Form() {
            return previousI9Form;
        }
    }
}
