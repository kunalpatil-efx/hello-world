package com.efx.ews.es.i9datasourcing.constant;

public enum DepEventName {
    I9_AUDIT_DETAIL,
    AUDIT_SUMMARY_I9,
    AUDIT_SUMMARY_EVERIFY,
}
