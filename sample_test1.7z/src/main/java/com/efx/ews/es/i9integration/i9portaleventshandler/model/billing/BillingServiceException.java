package com.efx.ews.es.i9integration.i9portaleventshandler.model.billing;

public class BillingServiceException extends RuntimeException {

    private BillingServiceException(String message, Throwable cause) {
        super(message, cause);
    }

    public static BillingServiceException of(Throwable t) {
        return new BillingServiceException(t.getMessage(), t.getCause());
    }
}
