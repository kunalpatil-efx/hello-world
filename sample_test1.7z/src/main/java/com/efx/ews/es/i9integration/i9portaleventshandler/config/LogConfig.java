package com.efx.ews.es.i9integration.i9portaleventshandler.config;

import com.efx.ews.es.common.logging.logback.masker.DefaultJsonFieldValueMasker;
import com.efx.ews.es.common.logging.logback.masker.JsonFieldValueMasker;
import com.efx.ews.es.common.logging.logback.masker.ValueMasker;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import java.util.List;

@Configuration
public class LogConfig {
    private static final List<String> FIELDS_TO_MASK = List.of(
            "firstName",
            "lastName",
            "dateOfBirth",
            "middleInitial",
            "otherLastName",
            "socialSecurityNumber",
            "telephoneNumber",
            "address",
            "documentNumber",
            "expirationDate",
            "documentTitle",
            "name",
            "city",
            "email",
            "zipCode",
            "apartmentNumber",
            "state",
            "imageData",
            "value"
    );

    @Bean
    @Primary
    public ValueMasker[] valueMaskers() {
        return new ValueMasker[]{
                new DefaultJsonFieldValueMasker(),
                new JsonFieldValueMasker(FIELDS_TO_MASK)
        };
    }
}
