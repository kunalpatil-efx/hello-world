package com.efx.ews.es.i9datasourcing.fieldconverter;

import static org.apache.commons.lang3.StringUtils.SPACE;
import static org.apache.commons.lang3.StringUtils.isBlank;

import com.efx.ews.es.i9datasourcing.fieldconverter.Utils.Constants;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.apache.commons.lang3.StringUtils;

public class MergingConverter implements FieldDataConverter {

    private final List<String> fieldNamesToMerge;

    public MergingConverter(String... fieldNamesToMerge) {
        if (fieldNamesToMerge == null || fieldNamesToMerge.length <= 1) {
            throw new IllegalArgumentException("Merging converter should have at least 2 arguments");
        }

        this.fieldNamesToMerge = List.of(fieldNamesToMerge);
    }

    @Override
    public String convert(Map<String, String> flattenedI9Form) {
        if (areAllValuesNullOrBlank(flattenedI9Form)) {
            return Constants.DEFAULT_EMPTY_VALUE;
        }
        return fieldNamesToMerge.stream()
            .map(flattenedI9Form::get)
            .filter(StringUtils::isNotEmpty)
            .collect(Collectors.joining(SPACE));
    }

    private boolean areAllValuesNullOrBlank(Map<String, String> flattenedI9Form) {
        return fieldNamesToMerge.stream()
            .allMatch(fieldName -> isBlank(flattenedI9Form.get(fieldName)));
    }
}