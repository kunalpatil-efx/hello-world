package com.efx.ews.es.i9integration.i9portaleventshandler.service.properties;

import lombok.Data;

@Data
public class AbstractPubSubProperties {
    private String projectId;
    private String topic;
}
