package com.efx.ews.es.i9integration.i9portaleventshandler.model;

import com.fasterxml.jackson.annotation.JsonValue;

public enum I9AnywhereEventType {
    SCHEDULED("Scheduled"),
    CANCELLED("Cancelled"),
    RESCHEDULED("Rescheduled"),
    DATA_RECEIVED("DataReceived"),
    OTHER("Other");

    private final String value;

    I9AnywhereEventType(String value) {
        this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
        return String.valueOf(value);
    }

    public boolean equals(String status) {
        return this.value.equals(status);
    }

    public boolean equalsIgnoreCase(String value) {
        return this.value.equalsIgnoreCase(value);
    }

    public static I9AnywhereEventType convertFromName(String value) {
        for (I9AnywhereEventType i9AnywhereEventType : I9AnywhereEventType.values()) {
            if (i9AnywhereEventType.equalsIgnoreCase(value)) {
                return i9AnywhereEventType;
            }
        }
        return I9AnywhereEventType.OTHER;
    }
}
