package com.efx.ews.es.everifydatasourcing;

import com.efx.ews.es.everifydatasourcing.fieldconverter.EVerifyConverterImpl;
import com.efx.ews.es.everifydatasourcing.model.EVerifyCase;
import com.efx.ews.es.everifydatasourcing.processor.AuditSummaryEVerifyProcessor;
import com.efx.ews.es.i9datasourcing.flattener.Flattener;
import com.efx.ews.es.i9datasourcing.model.ChangeContext;
import java.util.Map;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class EVerifyCaseConverter {

    private final Flattener flattener;
    private final EVerifyConverterImpl eVerifyFormConverter;
    private final AuditSummaryEVerifyProcessor auditSummaryEVerifyProcessor;

    public void convert(EVerifyCase eVerifyCase, ChangeContext changeContext) {

        Map<String, String> flattenedEVerifyCase = flattener.process(Objects.requireNonNull(eVerifyCase));

        Map<String, String> convertedEVerifyCase = eVerifyFormConverter
            .convertForm(flattenedEVerifyCase, changeContext);

        auditSummaryEVerifyProcessor.process(convertedEVerifyCase, changeContext);
    }
}
