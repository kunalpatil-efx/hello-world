package com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation;

import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.logger.MdcReactorLogger;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.AbstractPubSubProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.gcp.pubsub.core.publisher.PubSubPublisherTemplate;
import org.springframework.cloud.gcp.pubsub.support.DefaultPublisherFactory;
import reactor.core.publisher.Mono;

import java.util.Map;

@Slf4j
public abstract class PubSubPublisherServiceImpl {

    private PubSubPublisherTemplate publisher;
    private AbstractPubSubProperties properties;
    private ObjectMapper mapper = new ObjectMapper();

    PubSubPublisherServiceImpl(AbstractPubSubProperties properties) {
        this.properties = properties;
        publisher = new PubSubPublisherTemplate(new DefaultPublisherFactory(properties::getProjectId));
    }

    Mono<String> sendMessage(Object object) {
        log.debug("message published when sending message to topic {}", properties.getTopic());
        try {
            return Mono.fromFuture(publisher.publish(properties.getTopic(), mapper.writeValueAsString(object)).completable())
                    .doOnEach(MdcReactorLogger.logOnNext(id -> log.info("message {} published to topic {}", id, properties.getTopic())));
        } catch (JsonProcessingException e) {
            return Mono.error(e);
        }
    }

    Mono<String> sendMessage(Object object, Map<String, String> headers) {
        log.debug("message published when sending message to topic {}", properties.getTopic());
        try {
            return Mono.fromFuture(publisher.publish(properties.getTopic(), mapper.writeValueAsString(object), headers).completable())
                    .doOnEach(MdcReactorLogger.logOnNext(id -> log.info("message {} published to topic {}", id, properties.getTopic())));
        } catch (JsonProcessingException e) {
            return Mono.error(e);
        }
    }
}
