package com.efx.ews.es.config;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

@Service
@Slf4j
public class GitVersioning {
    private String gitProperties;

    @PostConstruct
    private void logGitInfo() {
        if (gitProperties == null) {
            initializeGitProperties();
        }
        log.info(gitProperties);
    }

    private void initializeGitProperties() {
        final InputStream gitPropertiesStream = getClass().getClassLoader().getResourceAsStream("git.properties");
        if (gitPropertiesStream == null) {
            log.info("Could not find git.properties resource (is git-commit-id-plugin build plugin configured?)");
            return;
        }
        try {
            gitProperties = readFromResource(gitPropertiesStream);
        } catch (IOException e) {
            log.info("could not read git.properties");
        }
    }

    private String readFromResource(InputStream gitPropertiesStream) throws IOException {
        StringBuilder stringBuilder = new StringBuilder();
        try (BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(gitPropertiesStream))) {
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                stringBuilder.append(line);
                stringBuilder.append(System.lineSeparator());
            }
        }
        return stringBuilder.toString();
    }
}
