package com.efx.ews.es.i9datasourcing.constant;

import java.util.Arrays;
import lombok.Getter;

public enum I9Event {

    FORM_CREATED("new"),
    SECTION_1_COMPLETE("Section1_Complete"),
    SECTION_1_AMENDED("Section1_Amended"),
    SECTION_2_COMPLETE("Section2_Complete"),
    SECTION_2_AMENDED("Section2_Amended"),
    SECTION_3_COMPLETE("Section3_Complete"),
    CANCELED("Canceled"),
    DELETED("Deleted"),
    MIGRATED_I9("Migrated_I9"),
    DATA_CONFIRMED("Data_Confirmed"),
    METADATA("metadata"),

    OTHER("Other");

    @Getter
    private final String eventKey;

    I9Event(String eventKey) {
        this.eventKey = eventKey;
    }

    public static I9Event getByEventKey(String eventKey) {
        return Arrays.stream(I9Event.values())
            .filter(i9EventName -> i9EventName.eventKey.equalsIgnoreCase(eventKey))
            .findFirst()
            .orElse(OTHER);
    }
}
