package com.efx.ews.es.i9integration.i9portaleventshandler.model.i9;

import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.messaging.Message;

import java.util.Arrays;

@AllArgsConstructor
public enum I9CompletionStatus {

    NEW("New"),
    SECTION1_AMENDED("Section1_Amended"),
    SECTION1_COMPLETE("Section1_Complete"),
    SECTION2_AMENDED("Section2_Amended"),
    SECTION2_COMPLETE("Section2_Complete"),
    SECTION2_DOCUMENTS_UPLOADED("Section2_Documents_Uploaded"),
    SECTION3_AMENDED("Section3_Amended"),
    SECTION3_COMPLETE("Section3_Complete"),
    MIGRATED_I9("Migrated_I9"),
    TERMINATED("Terminated"),
    CANCELED("Canceled"),
    NO_CHANGES("No_Changes"),
    AUDIT("Audit");

    @Getter private final String value;

    public static I9CompletionStatus getStatus(Message<?> message) {
        String status = message.getHeaders().get("status", String.class);
        return I9CompletionStatus.getEnum(status);
    }

    public static I9CompletionStatus getEnum (String value) {
        return Arrays.stream(I9CompletionStatus.values())
                .filter(status -> status.getValue().equalsIgnoreCase(value))
                .findAny()
                .orElse(null);
    }
}
