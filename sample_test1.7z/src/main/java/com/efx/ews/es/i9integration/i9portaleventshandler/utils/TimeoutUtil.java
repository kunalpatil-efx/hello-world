package com.efx.ews.es.i9integration.i9portaleventshandler.utils;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class TimeoutUtil {
    private final long waitTime;

    private final Map<String, Long> timeoutsMap = new HashMap<>();

    private final ReentrantReadWriteLock LOCK = new ReentrantReadWriteLock();
    private final Lock READ = LOCK.readLock();
    private final Lock WRITE = LOCK.writeLock();

    public TimeoutUtil(long waitTime) {
        this.waitTime = waitTime;
    }

    public boolean isWithinTimeout(String id) {
        Long timeout = Optional.ofNullable(getTimeout(id)).orElse(createTimeout(id));
        if (timeout.longValue() > System.currentTimeMillis()) {
            return true;
        }
        removeTimeout(id);
        return false;
    }

    private Long getTimeout(String id) {
        READ.lock();
        try {
            return timeoutsMap.get(id);
        } finally {
            READ.unlock();
        }
    }

    private Long createTimeout(String id) {
        Long value = Long.valueOf(System.currentTimeMillis() + waitTime);
        WRITE.lock();
        try {
            timeoutsMap.put(id, value);
            return value;
        } finally {
            WRITE.unlock();
        }
    }

    private void removeTimeout(String id) {
        WRITE.lock();
        try {
            timeoutsMap.remove(id);
        } finally {
            WRITE.unlock();
        }
    }
}
