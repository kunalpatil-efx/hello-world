package com.efx.ews.es.i9integration.i9portaleventshandler.model.document;

import com.fasterxml.jackson.annotation.JsonIgnoreType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;

@Slf4j
@JsonIgnoreType
public class CustomMultipartFile implements MultipartFile {
    private final byte[] fileContent;
    private String fileName;
    private File file;

    public CustomMultipartFile(byte[] fileData, String name) {
        log.info("Creating MultipartFile from byte[]");
        String destPath = System.getProperty("java.io.tmpdir");
        this.fileContent = fileData;
        this.fileName = name;
        file = new File(destPath + fileName);
    }

    @Override
    public void transferTo(File dest) throws IllegalStateException {
        //Nothing to do here
    }

    @Override
    public String getName() {
        return this.fileName;
    }

    @Override
    public String getOriginalFilename() {
        return this.fileName;
    }

    @Override
    public String getContentType() {
        try {
            return Files.probeContentType(file.toPath());
        } catch (IOException e) {
            return null;
        }
    }

    @Override
    public boolean isEmpty() {
        return this.file.length() <= 0;
    }

    @Override
    public long getSize() {
        return this.file.getTotalSpace();
    }

    @Override
    public byte[] getBytes() {
        return fileContent;
    }

    @Override
    public InputStream getInputStream() {
        return new ByteArrayInputStream(fileContent);
    }

}
