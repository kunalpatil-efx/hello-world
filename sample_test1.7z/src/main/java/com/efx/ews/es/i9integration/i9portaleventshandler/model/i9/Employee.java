package com.efx.ews.es.i9integration.i9portaleventshandler.model.i9;

import lombok.Data;

import java.io.Serializable;
import java.util.Map;

@Data
public class Employee implements Serializable {
    private static final Map<String, String> S2_CITIZEN_STATUS = Map.of("US_CITIZEN", "1"
            ,"NONCITIZEN", "2"
            ,"LAWFUL_PERMANENT_RESIDENT", "3"
            ,"ALIEN_AUTHORIZED_TO_WORK", "4");

    private String firstName;
    private String lastName;
    private String middleInitial;
    private String citizenshipImmigrationStatus;

    public void setCitizenShipImmigrationAsDigit() {
        if (citizenshipImmigrationStatus == null) {
            return;
        }

        if(citizenshipImmigrationStatus.matches("[1-4]+")) {
            return;
        }

        citizenshipImmigrationStatus = S2_CITIZEN_STATUS.get(citizenshipImmigrationStatus);
    }
}