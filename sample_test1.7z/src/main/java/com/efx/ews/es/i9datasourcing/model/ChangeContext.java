package com.efx.ews.es.i9datasourcing.model;

import com.efx.ews.es.i9datasourcing.constant.I9Event;
import java.time.ZonedDateTime;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ChangeContext {

    String i9FormId;
    String ipAddress;
    I9Event i9Event;
    String source;
    String correlationId;
    String clientTransactionId;
    ZonedDateTime sourceEventDateTime;
    String employerId;
    String deduplicationId;

}
