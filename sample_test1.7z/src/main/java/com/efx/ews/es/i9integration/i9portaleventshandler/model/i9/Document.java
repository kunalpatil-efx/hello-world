package com.efx.ews.es.i9integration.i9portaleventshandler.model.i9;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.io.Serializable;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class Document implements Serializable {
    private String documentId;
    private String documentNumber;
    private String documentTitle;
    private String expirationDate;
    private String issuingAuthority;
    private Boolean isReceipt;
    private Boolean uploadLater;
}
