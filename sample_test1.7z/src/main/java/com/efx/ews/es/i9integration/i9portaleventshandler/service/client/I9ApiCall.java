package com.efx.ews.es.i9integration.i9portaleventshandler.service.client;

import com.efx.ews.es.historyprovider.model.I9AuditModel;
import com.efx.ews.es.i9integration.i9portaleventshandler.EmployeeChangeSubscriberConfig.TerminationDetailBody;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.audit.IceAuditEntry;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.Audit;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.I9Form;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.I9FormResponse;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.Task;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.UpdateMetadataRequest;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.logger.MdcReactorLogger;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.webclient.HttpCallClient;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.I9FormApiProperties;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.net.URI;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static java.lang.String.format;

@Component
@Slf4j
@RequiredArgsConstructor
public class I9ApiCall {

    private static final String SOURCE_REF_ID = "sourceRefId";
    private static final String EMPLOYEE_FACT_ID = "employeeFactId";

    private final I9FormApiProperties i9FormApiProperties;
    private final HttpCallClient httpCallClient;

    public Mono<I9FormResponse> getForm(String id) {
        return Mono.just(i9FormApiProperties.getFormDataUrlBuilder().buildAndExpand(id).toUri())
            .doOnEach(MdcReactorLogger.logOnNext(uri -> log.info("Getting Form documentId: {}", id)))
            .flatMap(uri -> httpCallClient.doCall(webClient ->
                webClient
                    .get()
                    .uri(uri)
                    .retrieve()
                    .bodyToMono(I9FormResponse.class)
                    .doOnEach(MdcReactorLogger.logOnNext(response -> log.info("Success getForm documentId: {}", id)))
                    .doOnEach(
                        MdcReactorLogger
                            .logOnError(ex -> log.error(format("Failed getForm documentId: %s", id), ex)))));
    }

    public Mono<I9Form> getFormByRevision(String documentId, String revisionId) {
        return Mono.just(i9FormApiProperties.getFormDataByRevisionUrlBuilder()
            .buildAndExpand(documentId, revisionId).toUri())
            .doOnEach(MdcReactorLogger.logOnNext(
                uri -> log.info("Getting FormByRevision documentId: {}, revisionsId: {}", documentId, revisionId)))
            .flatMap(uri ->
                httpCallClient.doCall(webClient ->
                    webClient
                        .get()
                        .uri(uri)
                        .retrieve()
                        .bodyToMono(I9Form.class)
                        .doOnEach(MdcReactorLogger.logOnNext(response -> log
                            .info("Success getFormByRevision documentId: {}, revisionId: {}", documentId, revisionId)))
                        .doOnEach(MdcReactorLogger.logOnError(ex -> log.error(
                            format("Failed getFormByRevision documentId: %s, revisionId: %s", documentId, revisionId),
                            ex)))
                ));
    }

    public Mono<ResponseEntity<List<I9AuditModel>>> getFormDataAudits(String documentId) {
        return Mono.just(i9FormApiProperties.getAuditDataUrlBuilder()
            .queryParam("i9Id", documentId)
            .queryParam("type", "data")
            .build().toUri())
            .doOnEach(MdcReactorLogger.logOnNext(
                uri -> log.info("Getting FormDataAudits documentId: {}", documentId)))
            .flatMap(uri -> httpCallClient.doCall(webClient ->
                webClient
                    .get()
                    .uri(uri)
                    .retrieve().toEntityList(I9AuditModel.class)
                    .doOnEach(MdcReactorLogger
                        .logOnNext(response -> log.info("Success getFormDataAudits documentId: {}", documentId)))
                    .doOnEach(MdcReactorLogger
                        .logOnError(ex -> log.error(format("Failed getFormDataAudits documentId: %s", documentId), ex)))
            ));
    }

    public Mono<List<Task>> getTasks(String documentId) {
        return Mono.just(i9FormApiProperties.getBasicTaskAccessUrlBuilder().buildAndExpand(documentId).toUri())
            .doOnEach(MdcReactorLogger.logOnNext(
                uri -> log.info("Getting Tasks documentId: {}", documentId)))
            .flatMap(uri -> httpCallClient.doCall(webClient ->
                webClient
                    .get()
                    .uri(uri)
                    .retrieve()
                    .bodyToMono(new ParameterizedTypeReference<List<Task>>() {
                    })
                    .onErrorReturn(e ->
                            ((e instanceof WebClientResponseException) &&
                                ((WebClientResponseException) e).getStatusCode().equals(HttpStatus.NOT_FOUND))
                        , new ArrayList<>())
                    .doOnEach(
                        MdcReactorLogger.logOnNext(response -> log.info("Success getTasks documentId: {}", documentId)))
                    .doOnEach(MdcReactorLogger
                        .logOnError(ex -> log.error(format("Failed getTasks documentId: %s", documentId), ex)))
            ));
    }

    public Mono<Boolean> getFeature(String feature) {
        return Mono.just(i9FormApiProperties.getFeatureUrlBuilder().buildAndExpand(feature).toUri())
            .doOnEach(MdcReactorLogger.logOnNext(
                uri -> log.info("Getting feature: {} at uri {}", feature, uri)))
            .flatMap(uri -> httpCallClient.doCall(webClient ->
                webClient
                    .get()
                    .uri(uri)
                    .retrieve()
                    .bodyToMono(new ParameterizedTypeReference<Boolean>() {
                    })
                    .onErrorReturn(e -> {
                            log.error("Error in feature api call {}", e.getMessage(), e);
                            return ((e instanceof WebClientResponseException) &&
                                ((WebClientResponseException) e).getStatusCode() == HttpStatus.NOT_FOUND);
                        }
                        , Boolean.FALSE)
                    .doOnEach(
                        MdcReactorLogger.logOnNext(response -> log.info("Success getFeature: {}", feature)))
                    .doOnEach(MdcReactorLogger
                        .logOnError(ex -> log.error(format("Failed feature: %s", feature), ex)))
            ));
    }

    public Mono<Audit> getAudit(String documentId, Long recordVersion) {
        return Mono.just(i9FormApiProperties.getAuditUrlBuilder().buildAndExpand(documentId, recordVersion).toUri())
            .doOnEach(MdcReactorLogger.logOnNext(
                uri -> log.info("Getting Audit documentId: {}, recordVersion: {}", documentId, recordVersion)))
            .flatMap(uri -> httpCallClient.doCall(webClient ->
                webClient
                    .get()
                    .uri(uri)
                    .retrieve()
                    .bodyToMono(Audit.class)
                    .doOnEach(MdcReactorLogger.logOnNext(response -> log
                        .info("Success getAudit documentId: {}, recordVersion: {}", documentId, recordVersion)))
                    .doOnEach(MdcReactorLogger.logOnError(ex -> log
                        .error(format("Failed getAudit documentId: %s, recordVersion: %s", documentId, recordVersion),
                            ex)))
            ));
    }

    public Mono<List<IceAuditEntry>> getIceEntries(String documentId) {
        return Mono.just(i9FormApiProperties.getIceAuditUrlBuilder().buildAndExpand(documentId).toUri())
            .doOnEach(MdcReactorLogger.logOnNext(
                uri -> log.info("Getting IceEntries documentId: {}", documentId)))
            .flatMap(uri -> httpCallClient.doCall(webClient ->
                webClient
                    .get()
                    .uri(uri)
                    .retrieve()
                    .bodyToMono(new ParameterizedTypeReference<List<IceAuditEntry>>() {
                    })
                    .doOnEach(MdcReactorLogger.logOnNext(
                        response -> log.info("Fetched {} audit entries documentId: {}", response.size(), documentId)))
                    .doOnEach(MdcReactorLogger
                        .logOnError(ex -> log.error(format("Failed getIceEntries documentId: %s", documentId), ex)))
            ));
    }

    public Mono<List<String>> queryDocumentsByPacketId(String packetId) {
        return query(SOURCE_REF_ID, packetId);
    }

    private Mono<List<String>> query(String field, String value) {
        return Mono.just(i9FormApiProperties.getQueryUrlBuilder()
            .queryParam(field, value)
            .build()
            .toUri())
            .doOnEach(MdcReactorLogger.logOnNext(uri -> log.info("Querying by {}:{}", field, value)))
            .flatMap(uri -> httpCallClient.doCall(webClient ->
                webClient
                    .get()
                    .uri(uri)
                    .retrieve()
                    .bodyToMono(new ParameterizedTypeReference<List<String>>() {
                    })
                    .doOnEach(MdcReactorLogger
                        .logOnNext(
                            response -> log.info("Fetched {} i9 entries, by {}:{}", response.size(), field, value)))
                    .doOnEach(MdcReactorLogger
                        .logOnError(ex -> log.error(format("Failed querying i9 entries by %s:%s", field, value), ex)))
            ));
    }

    public Mono<List<String>> queryByFactId(String factId) {
        return query(EMPLOYEE_FACT_ID, factId);
    }

    public Mono<I9FormResponse> patchMetadata(String id, UpdateMetadataRequest updates) {
        URI uri = i9FormApiProperties.getPatchMetadataUrlBuilder().buildAndExpand(id).toUri();
        return httpCallClient.doCall(webClient ->
            webClient
                .patch()
                .uri(uri)
                .bodyValue(updates)
                .retrieve()
                .bodyToMono(I9FormResponse.class)
                .doOnEach(
                    MdcReactorLogger.logOnNext(response -> log.info("patch document {} with update {}", id, updates)))
                .doOnEach(MdcReactorLogger.logOnError(ex -> log.error(format("Failed patch document %s ", id), ex)))
        );
    }

    public Mono<List<I9FormResponse>> getHistory(String id) {
        return Mono.just(i9FormApiProperties.getHistoryUrlBuilder().buildAndExpand(id).toUri())
            .doOnEach(MdcReactorLogger.logOnNext(uri -> log.info("Getting History documentId: {}", id)))
            .flatMap(uri -> httpCallClient.doCall(webClient ->
                webClient
                    .get()
                    .uri(uri)
                    .retrieve()
                    .bodyToMono(I9FormResponse[].class)
                    .map(Arrays::asList)
                    .doOnEach(MdcReactorLogger.logOnNext(response ->
                        log.info("Success getHistory documentId: {}, number of revisions: {}", id, response.size())))
                    .doOnEach(
                        MdcReactorLogger
                            .logOnError(ex -> log.error(format("Failed getHistory documentId: %s", id), ex)))
            ));
    }

    public Mono<Task> createTaskAssociation(String id, Task task) {
        URI uri = i9FormApiProperties.getBasicTaskAccessUrlBuilder().buildAndExpand(id).toUri();
        return httpCallClient.doCall(webClient ->
            webClient
                .post()
                .uri(uri)
                .bodyValue(task)
                .retrieve()
                .toBodilessEntity()
                .flatMap(ignore -> Mono.just(task))
                .doOnEach(MdcReactorLogger
                    .logOnNext(response -> log.info("Success createTaskAssociation documentId: {}", id)))
                .doOnEach(MdcReactorLogger.logOnError(
                    ex -> log.error(format("Failed createTaskAssociation documentId: %s, Task:%s", id, task), ex)))
        );
    }

    public Mono<ResponseEntity<Void>> markTaskAsCompleted(String id, String taskId) {
        URI uri = i9FormApiProperties.getSpecifcTaskAccessUrlBuilder().buildAndExpand(id, taskId).toUri();
        return httpCallClient.doCall(webClient ->
            webClient
                .patch()
                .uri(uri)
                .retrieve()
                .toBodilessEntity()
                .doOnEach(MdcReactorLogger.logOnNext(
                    response -> log.info("Success markTaskAsCompleted documentId: {}, taskId: {}", id, taskId)))
                .doOnEach(MdcReactorLogger.logOnError(
                    ex -> log.error(format("Failed markTaskAsCompleted documentId: %s, taskId: %s", id, taskId), ex)))
        );
    }

    public Mono<ResponseEntity<Void>> deleteTask(String id, String taskId) {
        URI uri = i9FormApiProperties.getSpecifcTaskAccessUrlBuilder().buildAndExpand(id, taskId).toUri();
        return httpCallClient.doCall(webClient ->
            webClient
                .delete()
                .uri(uri)
                .retrieve()
                .toBodilessEntity()
                .doOnEach(MdcReactorLogger
                    .logOnNext(response -> log.info("Success deleteTask documentId: {}, taskId: {}", id, taskId)))
                .doOnEach(MdcReactorLogger.logOnError(
                    ex -> log.error(format("Failed deleteTask documentId: %s, taskId: %s", id, taskId), ex)))
        );
    }

    public Mono<ClientResponse> submitTerminationDetails(String employeeId,
        TerminationDetailBody terminationDetailBody) {
        URI uri = i9FormApiProperties.getTerminationDetailUrlBuilder().buildAndExpand(employeeId).toUri();
        return httpCallClient.doCall(webClient ->
            webClient.post()
                .uri(uri)
                .bodyValue(terminationDetailBody)
                .exchange())
            .doOnEach(MdcReactorLogger
                .logOnNext(
                    response -> log.info("Successfully submitted termination details for employee : {}", employeeId)))
            .doOnEach(MdcReactorLogger.logOnError(
                ex -> log.error(format("Failed submitting termination details for employee: {}", employeeId), ex)));
    }
}
