package com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation;

import com.efx.ews.es.i9datasourcing.dep.model.DepEventDataHolder;
import com.efx.ews.es.i9datasourcing.dep.util.PubSubEventBuilder;
import com.efx.ews.es.i9datasourcing.model.ChangeContext;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.billing.*;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.employer.config.EmployerConfigResponse;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.I9FormResponse;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.DataEngineeringTopicService;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.EmployerConfigApiRemoteCallService;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.configuration.PubSubProperties;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

@Service
@Slf4j
public class BillingService {

    private final PubSubProperties pubSubProperties;
    private final EmployerConfigApiRemoteCallService employerConfigApiRemoteCallService;
    private final DataEngineeringTopicService dataEngineeringTopicService;
    private final I9FormDao i9FormDao;
    private final ObjectMapper mapper = new ObjectMapper();
    private final PubSubEventBuilder pubSubEventBuilder;

    public BillingService(PubSubProperties pubSubProperties,
                          EmployerConfigApiRemoteCallService employerConfigApiRemoteCallService,
                          DataEngineeringTopicService dataEngineeringTopicService,
                          I9FormDao i9FormDao, PubSubEventBuilder pubSubEventBuilder) {
        this.pubSubProperties = pubSubProperties;
        this.employerConfigApiRemoteCallService = employerConfigApiRemoteCallService;
        this.dataEngineeringTopicService = dataEngineeringTopicService;
        this.i9FormDao = i9FormDao;
        this.pubSubEventBuilder = pubSubEventBuilder;
    }

    public Mono<Void> createBillableEvent(I9FormResponse i9Form) {
        log.info("Billing for {}", i9Form.getDocumentId());
        return employerConfigApiRemoteCallService.getEmployerInfo(i9Form.getEmployerId())
                .doOnSuccess(employerConfig -> log.info("Fetched EmployerConfigResponse {} for {}", employerConfig.getEmployerId(), i9Form.getDocumentId()))
                .map(employerConfig -> generateEventPayload(i9Form, employerConfig))
                .map(eventData -> createEventDataHolder(i9Form.getDocumentId(), serializeEventData(eventData)))
                .flatMap(eventDataHolder -> dataEngineeringTopicService.sendEventAsync(eventDataHolder, pubSubEventBuilder::buildBillingEvent))
                .doOnSuccess(event -> log.info("Billing event send for {}. Updating storage", i9Form.getDocumentId()))
                .flatMap(event -> i9FormDao.updateEvent(i9Form.getDocumentId(), event))
                .doOnSuccess(o -> log.info("{} event saved in the database", i9Form.getDocumentId()))
                .doOnError(e -> log.error("Unable to send billing event for {}", i9Form.getDocumentId(), e))
                .onErrorMap(Exception.class, BillingServiceException::of)
                .then();
    }

    private String serializeEventData(PubSubEventData eventData) {
        try {
            return mapper.writeValueAsString(eventData);
        } catch (Exception e) {
            throw BillingServiceException.of(e);
        }
    }

    private DepEventDataHolder createEventDataHolder(String documentId, String jsonPayload) {
        ChangeContext changeContext = new ChangeContext();
        changeContext.setI9FormId(documentId);

        return DepEventDataHolder.builder()
            .payloadJson(jsonPayload)
            .changeContext(changeContext)
            .build();
    }

    private PubSubEventData generateEventPayload(I9FormResponse i9Form, EmployerConfigResponse employerConfigResponse) {
        String transactionDate = dateFormatter("yyyyMMddHHmmss");
        String transactionId = dateFormatter("yyyyMMddHHmmssSSSSSS");

        BillingEventProduct billingEventProduct = new BillingEventProduct();
        billingEventProduct.setCode(pubSubProperties.getProductCode());
        billingEventProduct.setCodeDescription(pubSubProperties.getProductCodeDescription());
        billingEventProduct.setQuantity(pubSubProperties.getQuantity());
        billingEventProduct.setLineOfService(pubSubProperties.getLineOfService());

        BillingEventEmployee billingEventEmployee = new BillingEventEmployee();
        billingEventEmployee.setFirstName(i9Form.getFormData().getSectionOne().getEmployeeInfo().getFirstName());
        billingEventEmployee.setLastName(i9Form.getFormData().getSectionOne().getEmployeeInfo().getLastName());
        billingEventEmployee.setSsn(i9Form.getFormData().getSectionOne().getEmployeeInfo().getSocialSecurityNumber());
        billingEventEmployee.setHireCode("");

        BillingEventEmployer billingEventEmployer = new BillingEventEmployer();
        billingEventEmployer.setName(employerConfigResponse.getEmployerName());
        billingEventEmployer.setId(employerConfigResponse.getEmployerCode());
        billingEventEmployer.setEfxId(employerConfigResponse.getEmployerEfxId());
        billingEventEmployer.setRelationship("");
        billingEventEmployer.setType("");

        BillingEventMetadata billingEventMetadata = new BillingEventMetadata();
        billingEventMetadata.setSchemaVersion(pubSubProperties.getMetadataSchemaVersion());
        billingEventMetadata.setSchemaPath(pubSubProperties.getMetadataSchemaPath());

        BillingEvent billingEvent = new BillingEvent();
        billingEvent.setEmployee(billingEventEmployee);
        billingEvent.setEmployer(billingEventEmployer);
        billingEvent.setMetadata(billingEventMetadata);
        billingEvent.setProduct(billingEventProduct);

        billingEvent.setTransactionStartDateTime(transactionDate);
        billingEvent.setTransactionEndDateTime(transactionDate);
        billingEvent.setTransactionId(transactionId);
        billingEvent.setFulfillmentSystemName(pubSubProperties.getAppName());
        billingEvent.setFulfillmentId(employerConfigResponse.getEmployerCode());
        billingEvent.setI9Id(i9Form.getDocumentId());
        billingEvent.setPacketId(i9Form.getSourceRefId());

        PubSubEventData pubSubEventData = new PubSubEventData();
        pubSubEventData.setBillingEvents(billingEvent);
        return pubSubEventData;
    }

    private String dateFormatter(String format){
        SimpleDateFormat dateFormatter = new SimpleDateFormat(format);
        dateFormatter.setTimeZone(TimeZone.getTimeZone("UTC"));
        return dateFormatter.format(new Date());
    }
}
