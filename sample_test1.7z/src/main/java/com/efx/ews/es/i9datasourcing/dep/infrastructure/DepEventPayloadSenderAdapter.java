package com.efx.ews.es.i9datasourcing.dep.infrastructure;

import static java.lang.String.format;

import com.efx.ews.es.historyprovider.util.JsonPayloadExpanderUtil;
import com.efx.ews.es.i9datasourcing.constant.DepEventName;
import com.efx.ews.es.i9datasourcing.dep.api.DepEventPayloadSender;
import com.efx.ews.es.i9datasourcing.dep.exception.PubSubSendingException;
import com.efx.ews.es.i9datasourcing.dep.model.DepEventDataHolder;
import com.efx.ews.es.i9datasourcing.dep.model.DepEventPayload;
import com.efx.ews.es.i9datasourcing.dep.util.PubSubEventBuilder;
import com.efx.ews.es.i9datasourcing.model.ChangeContext;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.DataEngineeringTopicService;
import java.io.IOException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class DepEventPayloadSenderAdapter implements DepEventPayloadSender {

    private static final String PUB_SUB_EVENT_MESSAGE_ERROR = "PubSub event message %s was not sent";

    private final DataEngineeringTopicService dataEngineeringTopicService;
    private final PubSubEventBuilder pubSubEventBuilder;

    @Override
    public void publish(DepEventPayload eventPayload, ChangeContext changeContext, DepEventName eventName) {

        String expandedPayload = JsonPayloadExpanderUtil.expand(eventPayload);

        DepEventDataHolder eventDataHolder = DepEventDataHolder.builder()
            .payloadJson(expandedPayload)
            .changeContext(changeContext)
            .eventName(eventName.name())
            .build();

        try {
            dataEngineeringTopicService.sendEvent(eventDataHolder, pubSubEventBuilder::buildAuditEvent);
        } catch (IOException e) {
            log.error(format(PUB_SUB_EVENT_MESSAGE_ERROR, eventName), e);
            throw new PubSubSendingException(format(PUB_SUB_EVENT_MESSAGE_ERROR, eventName), e);
        }
    }
}
