package com.efx.ews.es.i9datasourcing.fieldconverter.config

class FieldConverterConfigGenerator {

    final static String TABLE_DATA_FILE_NAME = "C:\\Users\\axd462\\Documents\\field-converter-data2.csv"

    // for example, the ones with logic instead of JSON path
    final static Map<Integer, String> ROWS_MARKED_AS_NEED_MANUAL_WORK =
            [
                    13 : "ImmigrationStatusConverter.INSTANCE",
                    14 : "AlienNumberConverter.INSTANCE",
                    21 : "SsnNotSuppliedConverter.INSTANCE",

                    30 : "new ESignatureConverter(\"sectionOne.signature.date\")",
                    31 : "new MergingConverter(\"sectionOne.preparers[0].firstName\", \"sectionOne.preparers[0].lastName\")",
                    38 : "null", //E-signature
                    39 : "new MergingConverter(\"sectionOne.preparers[1].firstName\", \"sectionOne.preparers[1].lastName\")",
                    46 : "null", //E-signature
                    47 : "new MergingConverter(\"sectionOne.preparers[2].firstName\", \"sectionOne.preparers[2].lastName\")",
                    54 : "null", //E-signature

                    // title-value pattern
                    58 : "null",
                    60 : "null",
                    62 : "null",
                    64 : "null",
                    75 : "null",
                    77 : "null",
                    79 : "null",
                    81 : "null",
                    92 : "null",
                    94 : "null",
                    96 : "null",
                    98 : "null",

                    114: "new MergingConverter(\"sectionTwo.employerRepresentative.firstName\", \"sectionTwo.employerRepresentative.lastName\")", // MERGE
                    123: "new ESignatureConverter(\"sectionTwo.signature.date\")",
                    136: "null", //E-signature

                    // title-value pattern
                    138: "null",
                    140: "null",
                    142: "null",
                    144: "null",

                    // static ones? 
                    176: "null /* static? */",
                    177: "null /* static? */",
                    179: "null",
                    180: "null /* static? */",
                    181: "null /* static? */",
                    182: "null /* static? */",
                    189: "null /* static? */",
            ]

    public static void main(String[] args) {

        def ROW_INDEX_COLUMN_NO = 0
        def REPORT_FIELD_NAME_COLUMN_NO = 1
        def I9_EVENT_FIELD_NAME_COLUMN_NO = 3

        File inputFile = new File(TABLE_DATA_FILE_NAME)
        String[] lines = inputFile.text.split('\n')
        List<String[]> rows = lines.collect { it.split(',') }
        rows.remove(0); // skip headers

        StringBuilder output = new StringBuilder();
        rows.each { row ->

            // dirty hack - if the column is empty, then parsing to Integer fails. Read more: "Groovy truth"
            Integer rowNumber = row[ROW_INDEX_COLUMN_NO] ? row[ROW_INDEX_COLUMN_NO] as Integer : -1
            String ourReportName = row[REPORT_FIELD_NAME_COLUMN_NO]

            String converter
            String i9eventFieldName = parseI9Field(row[I9_EVENT_FIELD_NAME_COLUMN_NO])
            if (ROWS_MARKED_AS_NEED_MANUAL_WORK.containsKey(rowNumber)) {
                converter = ROWS_MARKED_AS_NEED_MANUAL_WORK.get(rowNumber)
            } else if ("n/a".equals(i9eventFieldName)) {
                converter = "BlankConverter.INSTANCE"
            } else {
                converter = "new NoChangeConverter(\"${i9eventFieldName}\")"
            }

            output.append(".put(\"${ourReportName}\", ${converter})${converter.contains("null") ? " // TODO " : ''}\n")
        }

        println output.toString()
    }

/**
 * A little helper method to get rid of the quotes in the input
 */
    // TODO what should we do with "n/a" values?
    static String parseI9Field(String jsonString) {
        return jsonString
                .replaceAll('"', '')
                .replace(": { ", ".")
                .replace(": [ { ", ".")
    }

}
