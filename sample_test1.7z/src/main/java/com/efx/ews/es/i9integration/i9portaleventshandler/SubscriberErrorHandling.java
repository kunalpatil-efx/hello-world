package com.efx.ews.es.i9integration.i9portaleventshandler;

import com.google.api.gax.rpc.PermissionDeniedException;
import org.slf4j.Logger;
import org.springframework.http.HttpRequest;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import java.net.URI;
import java.util.List;
import java.util.Optional;

public class SubscriberErrorHandling {

    private static final List<Class<?>> breakingExceptions = List.of(
            NullPointerException.class,
            IllegalStateException.class,
            IllegalArgumentException.class,
            PermissionDeniedException.class
    );

    private final Logger log;

    public SubscriberErrorHandling(Logger log) {
        this.log = log;
    }

    public boolean processingFailed(Throwable throwable) {
        return !processingCompleted(throwable);
    }

    public boolean processingCompleted(Throwable throwable) {
        return isWebExceptionInRangeOf400(throwable) || isBreakingException(throwable);
    }

    private boolean isWebExceptionInRangeOf400(Throwable throwable) {
        return (throwable instanceof WebClientResponseException)
                && ((WebClientResponseException) throwable).getStatusCode().is4xxClientError();
    }

    void logClientErrorException(String documentId, Throwable throwable) {
        if (throwable instanceof WebClientResponseException) {
            logWebException400((WebClientResponseException) throwable);
        } else {
            log.error("Error in client request for documentId {}", documentId, throwable);
        }
    }

    private void logWebException400(WebClientResponseException e) {
        Optional<HttpRequest> request = Optional.ofNullable(e.getRequest());
        log.error("error response received while processing dataReceived, request: {} {} response code: {} response body: {}",
                request.map(HttpRequest::getMethodValue).orElse(""),
                request.map(HttpRequest::getURI).map(URI::toString).orElse(""),
                e.getStatusCode().value(),
                e.getResponseBodyAsString());
    }

    private boolean isBreakingException(Throwable throwable) {
        if (breakingExceptions.contains(throwable.getClass())) {
            return true;
        }
        return Optional.ofNullable(throwable.getCause()).map(cause -> isBreakingException(cause)).orElse(Boolean.FALSE);
    }
}
