package com.efx.ews.es.i9integration.i9portaleventshandler.service.client;

import com.google.pubsub.v1.PubsubMessage;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.springframework.cloud.gcp.pubsub.support.AcknowledgeablePubsubMessage;
import org.springframework.messaging.Message;

import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.function.UnaryOperator;
import java.util.stream.Collectors;

import static com.efx.ews.es.common.filter.CorrelationFilter.SESSION_ID_HEADER_NAME;
import static com.efx.ews.es.common.filter.CorrelationFilter.TRANSACTION_ID_HEADER_NAME;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class I9HeaderBuilder {
    public static final String MESSAGE_ID = "messageId";
    public static final String DOCUMENT_ID = "documentId";
    private static final Set<String> DEFAULT_PROPERTIES = Set.of(TRANSACTION_ID_HEADER_NAME, SESSION_ID_HEADER_NAME);
    public static final Set<String> HEADERS_NAME = Set.of(TRANSACTION_ID_HEADER_NAME, SESSION_ID_HEADER_NAME, MESSAGE_ID, DOCUMENT_ID);

    public static Map<String, String> build(Message<?> message) {
        return buildHeaders(headerName ->
            (String) message.getHeaders().getOrDefault(headerName, UUID.randomUUID().toString())
        );
    }

    public static Map<String, String> build(PubsubMessage pubsubMessage) {
        return addCommonProperties(pubsubMessage, buildHeaders(headerName ->
            pubsubMessage.getAttributesMap().getOrDefault(headerName, UUID.randomUUID().toString())
        ));
    }

    private static Map<String, String> addCommonProperties(PubsubMessage message, Map<String, String> attributes) {
        final String documentId = message.getAttributesMap().getOrDefault(DOCUMENT_ID, "");
        final String messageId = message.getMessageId();
        attributes.put(DOCUMENT_ID, documentId);
        attributes.put(MESSAGE_ID, messageId);
        return attributes;
    }

    private static Map<String, String> buildHeaders(UnaryOperator<String> createValueStatement) {
        return DEFAULT_PROPERTIES.stream()
            .map(headerName ->
                Map.entry(headerName, createValueStatement.apply(headerName)))
            .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue));
    }
}
