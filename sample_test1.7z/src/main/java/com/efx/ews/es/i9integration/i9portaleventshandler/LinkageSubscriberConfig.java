package com.efx.ews.es.i9integration.i9portaleventshandler;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.I9FormResponse;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.UpdateMetadataRequest;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.I9ApiCall;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.I9HeaderBuilder;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.logger.MdcSetting;
import com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageConfirmation;
import com.efx.ews.es.i9integration.i9portaleventshandler.utils.TimeoutUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gcp.pubsub.core.PubSubTemplate;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.messaging.Message;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.util.context.Context;

import java.io.IOException;
import java.io.Serializable;
import java.text.MessageFormat;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageConfirmation.manualAckMessageChannel;

@Configuration
@Slf4j
public class LinkageSubscriberConfig {
    private final I9ApiCall i9ApiCall;
    private final ObjectMapper converter = new ObjectMapper();
    private final TimeoutUtil timeouter;
    private final MessageConfirmation messageConfirmation;


    public LinkageSubscriberConfig(I9ApiCall i9ApiCall,
                                   MessageConfirmation messageConfirmation,
                                   @Value("${linkage.timeout}") long timeout) {
        this.i9ApiCall = i9ApiCall;
        this.messageConfirmation = messageConfirmation;
        timeouter = new TimeoutUtil(timeout);
    }

    @Bean(name = "LinkageSubscriberConfig")
    IntegrationFlow subscriberFlow(
            PubSubTemplate pubSubTemplate,
            @Value("${subscription.linkage}") String subscription) {

        return IntegrationFlows
                .from(manualAckMessageChannel(pubSubTemplate, subscription))
                .handle(msg -> MdcSetting.wrapWithHeaders(msg, this::handleMessage))
                .get();
    }

    void handleMessage(Message<?> message) {
        log.info("received message: {}", message);
        Optional<LinkageMessageBody> payload = readPayload(message);

        payload.ifPresent(body ->
                Mono.just(body.getFact_id())
                        .flatMap(i9ApiCall::queryByFactId)
                        .map(i9Ids -> validatePresence(i9Ids, body.getFact_id()))
                        .flatMap(i9Id -> updateI9Metadata(i9Id, body.getEmployee_id(), body.getAs_of()))
                        .doOnSuccess(i9s -> {
                            String updatedDocuments = i9s.stream()
                                    .reduce("",
                                            (acc, i9) -> i9ToEmployeeIdMessage(i9) + ", " + acc,
                                            (s1, s2) -> s1 + ", " + s2);
                            log.info("Updated employee ids for: {}", updatedDocuments);
                            messageConfirmation.acknowledge(message);
                        })
                        .onErrorResume(e -> {
                            if (e instanceof LinkageException) {
                                if (((LinkageException)e).shouldBreakFlow()) {
                                    // passed the timeout - message not intended for I9
                                    log.warn(e.getMessage());
                                    messageConfirmation.acknowledge(message);
                                } else {
                                    // temporarily not able to process - retry
                                    // this can happen for example if the linkage occurs before i9 document was created
                                    log.info(e.getMessage());
                                    messageConfirmation.nAcknowledge(message);
                                }
                            } else {
                                // something is not right at all - skip the message
                                log.error(e.getMessage());
                                messageConfirmation.acknowledge(message);
                            }
                            return Mono.empty();
                        })
                        .subscriberContext(Context.of(I9HeaderBuilder.build(message)))
                        .block()
        );
    }

    private Optional<LinkageMessageBody> readPayload(Message<?> message) {
        try {
            return Optional.of(converter.readValue((byte[]) message.getPayload(), LinkageMessageBody.class));
        } catch (IOException e) {
            log.error("Invalid massage payload. " + e.getMessage());
            messageConfirmation.acknowledge(message);
            return Optional.empty();
        }
    }

    private List<String> validatePresence(List<String> i9Ids, String factId) {
        if (i9Ids.isEmpty()) {
            if (timeouter.isWithinTimeout(factId)) {
                throw new LinkageException(String.format("No I9 document found for factId: %s", factId), false);
            } else {
                throw new LinkageException(String.format("Invalid message for factId: %s", factId), true);
            }
        }
        log.info("Received i9 ids {} for employee fact id {}", i9Ids, factId);
        return i9Ids;
    }

    private Mono<List<I9FormResponse>> updateI9Metadata(List<String> i9Ids, String employeeId, String linkageDate) {
        return Flux.merge(
                i9Ids
                        .stream()
                        .map(i9Id -> updateI9Metadata(i9Id, employeeId, linkageDate))
                        .collect(Collectors.toList()))
                .collectList();
    }

    private Mono<I9FormResponse> updateI9Metadata(String i9Id, String employeeId, String linkageDate) {
        log.info("Updating linkage for i9: {} with employeeId: {}", i9Id, employeeId);
        UpdateMetadataRequest request = new UpdateMetadataRequest();
        request.setEmployeeId(employeeId);
        request.setFactIdToEmployeeIdSyncDate(linkageDate);
        return i9ApiCall.patchMetadata(i9Id, request);
    }

    private String i9ToEmployeeIdMessage(I9FormResponse i9) {
        return MessageFormat.format(
                "(Document id: {0}, employee fact id: {1}, employee id: {2})",
                i9.getDocumentId(),
                i9.getEmployeeFactId(),
                i9.getEmployeeId());
    }

    @Data
    static class LinkageMessageBody implements Serializable {
        private String fact_id, employee_id, as_of;
    }

    static class LinkageException extends RuntimeException {

        private final boolean shouldBreakFlow;

        LinkageException(String message, boolean shouldBreakFlow) {
            super(message);
            this.shouldBreakFlow = shouldBreakFlow;
        }

        boolean shouldBreakFlow() {
            return shouldBreakFlow;
        }
    }
}
