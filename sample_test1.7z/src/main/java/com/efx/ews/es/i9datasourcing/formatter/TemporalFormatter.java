package com.efx.ews.es.i9datasourcing.formatter;

import java.time.temporal.TemporalAccessor;

public interface TemporalFormatter {

    String formatDate(TemporalAccessor temporal);

    String formatDateTime(TemporalAccessor temporal);

    String formatInstant(TemporalAccessor temporal);
}
