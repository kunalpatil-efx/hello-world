package com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.PacketEvent;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.logger.MdcReactorLogger;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.PacketPubSubProperties;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service
@Slf4j
public class PacketPubSubPublisherServiceImpl extends PubSubPublisherServiceImpl implements PacketPubSubPublisherService {

    @Value("${event.metadata.url}")
    private String url;

    public PacketPubSubPublisherServiceImpl(PacketPubSubProperties properties) {
        super(properties);
    }

    @Override
    public Mono<String> restartPacketForSSN(String packetId, String taskId) {
        PacketEvent restartEvent = PacketEvent.createRestartEvent(packetId, taskId, url);
        return sendMessage(restartEvent)
                .doOnEach(
                        MdcReactorLogger.logOnNext(
                                id -> log.info("Restart packet for SSN message {} sent, packet id {}", id, packetId)));
    }

    @Override
    public Mono<String> closePacketForSSN(String packetId) {
        PacketEvent closePacketEvent = PacketEvent.closePacketEventForSSN(packetId);
        return sendMessage(closePacketEvent)
                .doOnEach(
                        MdcReactorLogger.logOnNext(
                                id -> log.info("Close packet for SSN message {} sent, packet id {}", id, packetId)));
    }

    @Override
    public Mono<String> closePacketForUnconfirmedData(String packetId) {
        PacketEvent closePacketEvent = PacketEvent.closePacketEventForUnconfirmedDate(packetId);
        return sendMessage(closePacketEvent)
                .doOnEach(
                        MdcReactorLogger.logOnNext(
                                id -> log.info("Close packet for Unconfirmed Data message {} sent, packet id {}", id, packetId)));
    }


}
