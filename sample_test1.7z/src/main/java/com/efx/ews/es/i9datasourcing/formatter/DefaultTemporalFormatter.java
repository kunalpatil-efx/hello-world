package com.efx.ews.es.i9datasourcing.formatter;

import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
import org.springframework.stereotype.Component;

@Component
public class DefaultTemporalFormatter implements TemporalFormatter {

    @Override
    public String formatDate(TemporalAccessor temporal) {
        return Formatters.DATE_FORMATTER.format(temporal);
    }

    @Override
    public String formatDateTime(TemporalAccessor temporal) {
        return Formatters.DATE_TIME_FORMATTER.format(temporal);
    }

    @Override
    public String formatInstant(TemporalAccessor temporal) {
        return DateTimeFormatter.ISO_INSTANT.format(temporal);
    }
}
