package com.efx.ews.es.i9integration.i9portaleventshandler.model;

import com.efx.ews.es.eev.barricade.common.model.BarricadeEncryptedData;
import com.efx.ews.es.i9datasourcing.constant.I9Event;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.event.I9EventAuditData;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.event.I9EventPayload;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

@Data
@NoArgsConstructor
public class PacketMailSentEvent {
    @JsonProperty("date")
    private String date;

    @JsonProperty("packet_id")
    private String packetId;

    @JsonProperty("receiver_id")
    private String receiverId;

    @JsonProperty("sender_id")
    private String senderId;

    @JsonProperty("mail")
    private String mailType;

    public I9EventPayload mapToPayload(BarricadeEncryptedData encryptedData) {
        I9EventAuditData auditData = new I9EventAuditData();
        auditData.setDate(getFormattedDate());
        auditData.setEventKey(this.getMailType()+"_email");
        auditData.setEventDescription(
                "'" + StringUtils.capitalize(this.getMailType()).replace('_', ' ') + "' email sent");
        auditData.setSourceKey(this.getSenderId());
        auditData.setSource(encryptedData);
        auditData.setSourceIp(null);
        auditData.setDataUpdate(false);
        auditData.setDataRevision(null);

        I9EventPayload payload = new I9EventPayload();
        payload.setAudit(auditData);
        return payload;
    }

    private String getFormattedDate() {
        return ZonedDateTime.parse(this.getDate(), DateTimeFormatter.ISO_OFFSET_DATE_TIME)
                .truncatedTo(ChronoUnit.MILLIS)
                .toString();
    }
}

