package com.efx.ews.es.i9integration.i9portaleventshandler.model.i9;

import lombok.Data;

@Data
public class Task {
    private String taskId;
    private String taskType;
    private String taskStatus;
}
