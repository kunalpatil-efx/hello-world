package com.efx.ews.es.i9integration.i9portaleventshandler.service.properties;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;

@Component
@ConfigurationProperties(prefix = "i9form-api")
@Data
@EqualsAndHashCode(callSuper = true)
public class I9FormApiProperties extends AbstractRemoteServiceProperties {

    RemoteResource formdata;
    RemoteResource audit;
    RemoteResource tasks;
    RemoteResource feature;
    RemoteResource dataMaintenance;

    RemoteResource auditdata;

    public UriComponentsBuilder getFormDataUrlBuilder() {
        return getBaseUriComponentsBuilder()
            .pathSegment(getFormdata().getPath())
            .pathSegment("{documentId}");
    }

    public UriComponentsBuilder getQueryUrlBuilder() {
        return getBaseUriComponentsBuilder()
            .pathSegment(getFormdata().getPath())
            .pathSegment("query");
    }

    public UriComponentsBuilder getPatchMetadataUrlBuilder() {
        return getFormDataUrlBuilder()
            .pathSegment("metadata");
    }

    public UriComponentsBuilder getFormDataByRevisionUrlBuilder() {
        return getBaseUriComponentsBuilder()
            .pathSegment(getFormdata().getPath())
            .pathSegment("{documentId}")
            .pathSegment(getFormdata().getOperation())
            .pathSegment("{revisionId}");
    }

    public UriComponentsBuilder getAuditDataUrlBuilder() {
        return getBaseUriComponentsBuilder()
            .pathSegment(getAuditdata().getPath());
    }

    public UriComponentsBuilder getHistoryUrlBuilder() {
        return getBaseUriComponentsBuilder()
                .pathSegment(getFormdata().getPath())
                .pathSegment("{documentId}")
                .pathSegment("history");
    }

    public UriComponentsBuilder getAuditUrlBuilder() {
        return getBaseUriComponentsBuilder()
                .pathSegment(getAudit().getPath())
                .pathSegment("{documentId}")
                .pathSegment("revision")
                .pathSegment("{recordVersion}");
    }

    public UriComponentsBuilder getIceAuditUrlBuilder() {
        return getBaseUriComponentsBuilder()
                .pathSegment(getAudit().getPath())
                .pathSegment("{documentId}")
                .pathSegment("ice");
    }

    public UriComponentsBuilder getBasicTaskAccessUrlBuilder() {
        return getBaseUriComponentsBuilder()
                .pathSegment(getTasks().getPath())
                .pathSegment("{i9Id}");
    }

    public UriComponentsBuilder getSpecifcTaskAccessUrlBuilder() {
        return getBaseUriComponentsBuilder()
                .pathSegment(getTasks().getPath())
                .pathSegment("{i9Id}")
                .pathSegment("{taskId}");
    }

    public UriComponentsBuilder getTerminationDetailUrlBuilder() {
        return getBaseUriComponentsBuilder()
            .pathSegment(getDataMaintenance().getPath())
            .pathSegment("{employeeId}")
            .pathSegment(getDataMaintenance().getOperation());
    }

    public UriComponentsBuilder getFeatureUrlBuilder() {
        return getBaseUriComponentsBuilder()
            .pathSegment(getFeature().getPath())
            .pathSegment("{feature}");
    }
}
