package com.efx.ews.es.i9integration.i9portaleventshandler.model;

import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

public enum I9EventStatus {
    NEW("new"),
    SECTION1_COMPLETE("Section1_Complete"),
    SECTION1_AMENDED("Section1_Amended"),
    SECTION2_COMPLETE("Section2_Complete"),
    SECTION2_AMENDED("Section2_Amended"),
    SECTION3_COMPLETE("Section3_Complete"),
    TERMINATED("Terminated"),
    CANCELED("Canceled"),
    DELETED("Deleted"),
    MIGRATED_I9("Migrated_I9"),
    DATA_CONFIRMED("Data_Confirmed"),
    SECTION2_DOCUMENT_UPLOADED("Section2_Documents_Uploaded");


    @Getter
    private final String value;

    I9EventStatus(String value) {
        this.value = value;
    }

    @Override
    @JsonValue
    public String toString() {
        return String.valueOf(value);
    }

    public boolean equals(String status) {
        return this.value.equalsIgnoreCase(status);
    }
}
