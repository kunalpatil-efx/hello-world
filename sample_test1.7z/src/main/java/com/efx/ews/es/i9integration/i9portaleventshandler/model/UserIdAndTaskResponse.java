package com.efx.ews.es.i9integration.i9portaleventshandler.model;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.Task;
import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class UserIdAndTaskResponse {
    private String userId;
    private Task task;
}
