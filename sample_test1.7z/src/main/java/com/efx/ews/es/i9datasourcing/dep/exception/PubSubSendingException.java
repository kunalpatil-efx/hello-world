package com.efx.ews.es.i9datasourcing.dep.exception;

public class PubSubSendingException extends RuntimeException {

    public PubSubSendingException(String message, Throwable exception) {
        super(message, exception);
    }

    @Override
    public synchronized Throwable fillInStackTrace() {
        return this;
    }
}
