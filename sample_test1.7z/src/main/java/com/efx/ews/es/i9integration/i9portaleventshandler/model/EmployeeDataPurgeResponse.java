package com.efx.ews.es.i9integration.i9portaleventshandler.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import javax.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class EmployeeDataPurgeResponse {
    @JsonProperty("separation_date")
    private String separationDate;
    @JsonProperty("paid")
    private Boolean paid;
}
