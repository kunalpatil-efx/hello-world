package com.efx.ews.es.i9datasourcing.processor.auditdetail.i9formhistory;

import lombok.Value;

@Value
class FieldDiff {

    String fieldName;
    String valueBefore;
    String valueAfter;
}
