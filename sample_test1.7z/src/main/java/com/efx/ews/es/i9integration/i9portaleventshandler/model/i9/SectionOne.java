package com.efx.ews.es.i9integration.i9portaleventshandler.model.i9;

import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
public class SectionOne implements Serializable {
    private EmployeeInfo employeeInfo;
    private Attestation attestation;
    private List<Preparer> preparers;
    private SignatureData signature;
    private String date;
    private String offset;
}