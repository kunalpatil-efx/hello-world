package com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.Task;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.task.*;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.logger.MdcReactorLogger;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.TaskApiProperties;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.TaskApiProperties.TaskType;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

@Slf4j
@Component
public class TaskApiConnector {

    private static final Pattern UUID_PATTERN = Pattern.compile("[0-9A-Za-z]{8}-[0-9A-Za-z]{4}-[0-9A-Za-z]{4}-[0-9A-Za-z]{4}-[0-9A-Za-z]{12}");
    private static boolean initialized = false;
    private static final String TASK_COMPLETED = "COMPLETED";

    private final WebClientConnector<TaskApiProperties> connector;
    private final TaskApiProperties properties;

    public TaskApiConnector(TaskApiProperties props) {
        connector = new WebClientConnector<>(props);
        properties = props;
    }

    protected synchronized void checkAndRegisterTaskType() throws IOException {
        try {
            if (!initialized) {
                log.debug("Initialing Task API data.");
                UUID groupId = createTaskFamilyEntity()
                        .flatMap(familyId -> createTaskGroupEntity(familyId))
                        .block();
                createTaskTypeEntity(groupId, properties.getSection2type())
                        .doOnSuccess(uuid ->  log.info("Section 2 task-type id: {}", uuid))
                        .block();
                createTaskTypeEntity(groupId, properties.getSsnApplied())
                        .doOnSuccess(uuid ->  log.info("SSN Applied task-type id: {}", uuid))
                        .block();
                createTaskTypeEntity(groupId, properties.getSection2UploadLater())
                        .doOnSuccess(uuid ->  log.info("Section 2 Upload later Applied task-type id: {}", uuid))
                        .block();
                createTaskTypeEntity(groupId, properties.getReceiptUpdateSectionTwo())
                        .doOnSuccess(uuid ->  log.info("Section 2 Receipt Applied task-type id: {}", uuid))
                        .block();
                createTaskTypeEntity(groupId, properties.getSchedulerDateUpdated())
                        .doOnSuccess(uuid ->  log.info("Scheduler Date Updated task-type id: {}", uuid))
                        .block();

                if (properties.getSection2CovidFollowUp().getEnabled()) {
                    createTaskTypeEntity(groupId, properties.getSection2CovidFollowUp())
                        .doOnSuccess(uuid -> log.info("Section 2 Covid-19 Follow-up task-type id: {}", uuid))
                        .block();
                }

                if (properties.getSection2CovidDocumentInspection().getEnabled()) {
                    createTaskTypeEntity(groupId, properties.getSection2CovidDocumentInspection())
                        .doOnSuccess(uuid -> log.info("Section 2 Covid-19 Document Inspection task-type id: {}", uuid))
                        .block();
                }

                if (properties.getSection2Anywhere().getEnabled()) {
                    createTaskTypeEntity(groupId, properties.getSection2Anywhere())
                        .doOnSuccess(uuid -> log.info("Section 2 Remote task-type id: {}", uuid))
                        .block();
                }

                log.info("Successful initialization of TaskApiConnector");
                initialized = true;
            }
        } catch (Exception t) {
            throw new IOException("Unable to set-up Task API. ", t);
        }
    }
    boolean isValidContext(String sourceId) {
        log.debug("Checking valid context for source: {}", sourceId);
        return connector.isValidContext(sourceId);
    }

    Mono<Task> createSection2Task(TaskCreateRequest taskCreateRequest) {
        log.debug("Creating Section 2 Task for {}", taskCreateRequest.getAssociatedSourceSystemId());
        taskCreateRequest.setTaskTypeCode(properties.getSection2type().getCode());
        return connector.postToApi(properties.getTask(), null, taskCreateRequest)
                .flatMap(this::parseClientResponse)
                .doOnSuccess(id -> log.debug("Task for {} created with Id: {}",
                        taskCreateRequest.getAssociatedSourceSystemId(),
                        id.toString())).flatMap(id -> {
                    Task task = new Task();
                    task.setTaskId(id.toString());
                    task.setTaskType(properties.getSection2type().getCode());
                    return Mono.just(task);
                });
    }

    Mono<Task> createSsnAppliedTask(TaskCreateRequest taskCreateRequest) {
        log.debug("Creating SSN Applied Task for {}", taskCreateRequest.getAssociatedSourceSystemId());
        taskCreateRequest.setTaskTypeCode(properties.getSsnApplied().getCode());
        return connector.postToApi(properties.getTask(), null, taskCreateRequest)
                .flatMap(this::parseClientResponse)
                .doOnSuccess(id -> log.debug("Task for {} created with Id: {}",
                        taskCreateRequest.getAssociatedSourceSystemId(),
                        id.toString())).flatMap(id -> {
                    Task task = new Task();
                    task.setTaskId(id.toString());
                    task.setTaskType(properties.getSsnApplied().getCode());
                    return Mono.just(task);
                });
    }

    Mono<Task> createSection2DocumentUploadTask(TaskCreateRequest taskCreateRequest) {
        log.debug("Creating Section 2 Document Upload Task  for {}", taskCreateRequest.getAssociatedSourceSystemId());
        taskCreateRequest.setTaskTypeCode(properties.getSection2UploadLater().getCode());
        return connector.postToApi(properties.getTask(), null, taskCreateRequest)
                .flatMap(this::parseClientResponse)
                .doOnSuccess(id -> log.debug("Document Upload Task for {} created with Id: {}",
                        taskCreateRequest.getAssociatedSourceSystemId(),
                        id.toString())).flatMap(id -> {
                    Task task = new Task();
                    task.setTaskId(id.toString());
                    task.setTaskType(properties.getSection2UploadLater().getCode());
                    return Mono.just(task);
                });
    }

    Mono<Task> createTask(TaskType taskType, TaskCreateRequest taskCreateRequest) {
        log.debug("Creating Section 2 Anywhere Task for {}", taskCreateRequest.getAssociatedSourceSystemId());
        taskCreateRequest.setTaskTypeCode(taskType.getCode());
        return connector.postToApi(properties.getTask(), null, taskCreateRequest)
            .flatMap(this::parseClientResponse)
            .doOnSuccess(id -> log.debug("Task for {} created with Id: {}",
                taskCreateRequest.getAssociatedSourceSystemId(),
                id.toString())).flatMap(id -> {
                Task task = new Task();
                task.setTaskId(id.toString());
                task.setTaskType(taskType.getCode());
                return Mono.just(task);
            });
    }
  
    Mono<Task> createReceiptUpdateTask(TaskCreateRequest taskCreateRequest) {
        log.debug("Creating Section 2 Document Receipt Task for {}", taskCreateRequest.getAssociatedSourceSystemId());
        taskCreateRequest.setTaskTypeCode(properties.getReceiptUpdateSectionTwo().getCode());
        return connector.postToApi(properties.getTask(), null, taskCreateRequest)
                .flatMap(this::parseClientResponse)
                .doOnEach(MdcReactorLogger.logOnNext(id -> log.info("Receipt Task for {} created with Id: {}",
                        taskCreateRequest.getAssociatedSourceSystemId(),
                        id.toString())))
                .flatMap(id -> {
                    Task task = new Task();
                    task.setTaskId(id.toString());
                    task.setTaskType(properties.getReceiptUpdateSectionTwo().getCode());
                    return Mono.just(task);
                });
    }

    Mono<Task> completeTask(Task task, String userId) {
        TaskCompleteRequest tc = new TaskCompleteRequest();
        if(StringUtils.isNotEmpty(userId)) {
            tc.setEsportalUserId(UUID.fromString(userId));
        }
        tc.setEffortCode(properties.getSection2type().getEffortCode());
        return connector.patchToApi(properties.getTask(), task.getTaskId(), tc)
                .flatMap(response -> {
                    if (response.statusCode().is2xxSuccessful()){
                        task.setTaskStatus(TASK_COMPLETED);
                        return Mono.just(task);
                    }
                    return Mono.error(new WebClientResponseException(response.statusCode().getReasonPhrase(),
                            response.statusCode().value(),
                            response.statusCode().getReasonPhrase(),
                            response.headers().asHttpHeaders(),
                            null,
                            StandardCharsets.UTF_8
                    ));
                })
                .doOnSuccess(response -> {
                    log.debug("Completed task with Id: {} and type: {} ", task.getTaskId(), task.getTaskType());
                });
    }

    Mono<UUID> deleteTask(String taskId) {
        return connector.deleteToApi(properties.getTask(), taskId)
            .map(response -> UUID.fromString(taskId))
            .doOnSuccess(response -> log.debug("Deleted task with Id: {}", taskId));
    }

    Mono<UUID> createTaskFamilyEntity() {
        return connector.getToApi(properties.getFamily(), properties.getFamily().getName(), Collections.emptyList())
            .flatMap(this::parseGetResponse)
            .onErrorResume(IllegalArgumentException.class, e -> {
                log.info("Registering family: {}", properties.getFamily().getName());
                TaskFamilyCreateRequest taskFamilyCreateRequest = new TaskFamilyCreateRequest();
                taskFamilyCreateRequest.setName(properties.getFamily().getName());
                return connector.postToApi(properties.getFamily(), null, taskFamilyCreateRequest)
                    .flatMap(this::parseClientResponse)
                    .doOnSuccess(id -> log.debug("Successfully created family with id {}", id.toString()));
            });
    }

    Mono<UUID> createTaskGroupEntity(UUID familyUuid) {
        return connector.getToApi(properties.getGroup(), properties.getGroup().getName(), Collections.emptyList())
            .flatMap(this::parseGetResponse)
            .onErrorResume(IllegalArgumentException.class, e -> {
                log.info("Registering group: {} for family {}", properties.getFamily().getName(), familyUuid);
                TaskGroupCreateRequest taskGroupCreateRequest = new TaskGroupCreateRequest();
                taskGroupCreateRequest.setName(properties.getGroup().getName());
                taskGroupCreateRequest.setTaskFamilyId(familyUuid);
                return connector.postToApi(properties.getGroup(), null, taskGroupCreateRequest)
                    .flatMap(this::parseClientResponse)
                    .doOnSuccess(id -> log.debug("Successfully created group with id {}", id.toString()));
            });
    }

    Mono<UUID> createTaskTypeEntity(UUID groupUuid, TaskApiProperties.TaskType taskType) {
        return connector.getToApi(taskType, taskType.getCode(), Collections.emptyList())
            .flatMap(this::parseGetResponse)
            .onErrorResume(IllegalArgumentException.class, e -> {
                UUID uuid_group = parseForUuid(groupUuid.toString());
                log.info("Registering task type ({}/{}) for group {}", taskType.getName(), taskType.getCode(), uuid_group.toString());
                TaskTypeCreateRequest taskTypeCreateRequest = new TaskTypeCreateRequest();
                taskTypeCreateRequest.setTaskGroupId(groupUuid);
                taskTypeCreateRequest.setCode(taskType.getCode());
                taskTypeCreateRequest.setName(taskType.getName());
                taskTypeCreateRequest.setTaskProcessorUrlTemplate(taskType.getProcessorUrlTemplate());
                taskTypeCreateRequest.setWorkerSecurityFunction(taskType.getWorkerSecurityFunction());
                return connector.postToApi(taskType, null, taskTypeCreateRequest)
                    .flatMap(this::parseClientResponse)
                    .doOnSuccess(id -> log.debug("Successfully created group with id {}", id.toString()));
            });
    }

    private Mono<UUID> parseGetResponse(ClientResponse response) {
        if (response.statusCode().is2xxSuccessful()) {
            return response.bodyToMono(ResponseWithId.class).map(ResponseWithId::getId);
        }
        return response.statusCode() == HttpStatus.NOT_FOUND
            ? Mono.error(new IllegalArgumentException())
            : Mono.error(new IllegalStateException("Invalid response from Task API: " + response.statusCode().toString()));
    }

    private Mono<UUID> parseClientResponse(ClientResponse response) {
        log.debug("Parsing response: " + response);
        if (response.statusCode().is2xxSuccessful()){
            return response.bodyToMono(ResponseWithId.class).map(ResponseWithId::getId);
        } else if (response.statusCode() == HttpStatus.BAD_REQUEST) {
            return response.bodyToMono(String.class).flatMap(this::reactiveParseForUuid);
        } else if (response.statusCode() == HttpStatus.NOT_FOUND) {
            return Mono.error(new IllegalArgumentException());
        } else if (response.statusCode().is5xxServerError()) {
            return response.createException().flatMap(Mono::error);
        }
        return Mono.error(new IllegalStateException("Invalid response from Task API: " + response.statusCode().toString()));
    }

    private Mono<UUID> reactiveParseForUuid(String str) {
        try {
            return Mono.just(parseForUuid(str));
        } catch (IllegalArgumentException iae) {
            return Mono.error(iae);
        }
    }

    private static UUID parseForUuid(String str) {
        Matcher matcher = UUID_PATTERN.matcher(str);
        if (matcher.find()) {
            return UUID.fromString(matcher.group());
        }
        throw new IllegalArgumentException("Unable to retrieve UUID from string: " + str);
    }

    Mono<TaskResponse> getTask(String taskId) {
        return connector.getToApi(properties.getTask(), taskId, null)
                .flatMap(response -> {
                    log.debug("Parsing response: " + response);
                    if (response.statusCode().is2xxSuccessful()){
                        return response.bodyToMono(TaskResponse.class);
                    }

                    return Mono.error(new WebClientResponseException(response.statusCode().getReasonPhrase(),
                            response.statusCode().value(),
                            response.statusCode().getReasonPhrase(),
                            response.headers().asHttpHeaders(),
                            null,
                            StandardCharsets.UTF_8
                    ));
                })
                .doOnSuccess(id -> log.debug("Successfully task returned"));
    }
}
