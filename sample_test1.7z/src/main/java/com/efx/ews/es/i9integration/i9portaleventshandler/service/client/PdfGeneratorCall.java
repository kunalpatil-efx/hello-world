package com.efx.ews.es.i9integration.i9portaleventshandler.service.client;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.pdfGenerator.PdfMergeResponse;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.pdfGenerator.PdfServiceMergeRequest;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.pdfGenerator.PdfServiceRequest;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.logger.MdcReactorLogger;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.webclient.HttpCallClient;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.PdfGeneratorProperties;
import com.google.common.primitives.Bytes;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.BodyExtractors;
import org.springframework.web.reactive.function.client.ClientResponse;
import reactor.core.publisher.Mono;
import reactor.util.retry.Retry;
import reactor.util.retry.Retry;

import java.net.URI;
import java.nio.ByteBuffer;

import static java.lang.String.format;

@Component
@Slf4j
@RequiredArgsConstructor
public class PdfGeneratorCall {

    private static final int MERGE_RETRIES = 5;
    private final HttpCallClient httpCallClient;
    private final PdfGeneratorProperties pdfGeneratorProperties;

    public Mono<byte[]> postGenerate(PdfServiceRequest pdfServiceRequest) {
        final URI uri = pdfGeneratorProperties.postGenerate().build().toUri();
        return httpCallClient.doCall(webClient ->
            webClient
                .post()
                .uri(uri)
                .bodyValue(pdfServiceRequest)
                .exchange()
                .flatMap(this::toByteBuffers)
                .doOnEach(MdcReactorLogger.logOnNext(data -> log.info("PDF generated successfully, request: {}", pdfServiceRequest)))
                .doOnEach(MdcReactorLogger.logOnError(ex -> log.error(format("Failed to generate PDF, request: %s", pdfServiceRequest), ex)))
        );
    }

    public Mono<PdfMergeResponse> postMerge(PdfServiceMergeRequest request) {
        final URI uri = pdfGeneratorProperties.postMerge().build().toUri();
        return httpCallClient.doCall(webClient ->
            webClient
                .post()
                .uri(uri)
                .bodyValue(request)
                .retrieve()
                .bodyToMono(PdfMergeResponse.class)
                .retryWhen(Retry.maxInARow(MERGE_RETRIES))
                .doOnEach(MdcReactorLogger.logOnNext(data -> log.info("PDF merged successfully, request: {}", request)))
                .onErrorResume(e -> {
                    log.error("Unable to merge PDFs with document ids: {}", request.getDocuments());
                    return Mono.just(new PdfMergeResponse());
                })
        );
    }

    private Mono<byte[]> toByteBuffers(ClientResponse clientResponse) {
        if (clientResponse.statusCode().is2xxSuccessful()) {
            return clientResponse.body(BodyExtractors.toDataBuffers())
                    .map(dataBuffer -> {
                        ByteBuffer byteBuffer = dataBuffer.asByteBuffer();
                        byte[] byteArray = new byte[byteBuffer.remaining()];
                        byteBuffer.get(byteArray);
                        return byteArray;
                    })
                    .reduce(Bytes::concat);
        }
        return clientResponse.createException()
                .map(webClientResponseException -> {
                    throw webClientResponseException;
                });
    }
}
