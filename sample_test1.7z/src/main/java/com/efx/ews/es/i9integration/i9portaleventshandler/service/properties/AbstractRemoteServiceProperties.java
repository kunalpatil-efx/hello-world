package com.efx.ews.es.i9integration.i9portaleventshandler.service.properties;

import lombok.Data;
import org.springframework.web.util.UriComponentsBuilder;

@Data
public class AbstractRemoteServiceProperties {

    private String scheme;
    private String host;
    private int port;
    private String path;
    private String[] validSources;

    @Data
    public static class RemoteResource {
        private String path;
        private String operation;
        private boolean enabled = true;
    }

    UriComponentsBuilder getBaseUriComponentsBuilder() {
        return UriComponentsBuilder.newInstance()
                .scheme(getScheme())
                .host(getHost())
                .port(getPort())
                .path(getPath());
    }

}
