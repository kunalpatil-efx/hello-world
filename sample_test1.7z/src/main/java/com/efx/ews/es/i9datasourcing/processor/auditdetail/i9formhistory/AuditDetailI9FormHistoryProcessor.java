package com.efx.ews.es.i9datasourcing.processor.auditdetail.i9formhistory;

import com.efx.ews.es.i9datasourcing.model.ChangeContext;
import com.efx.ews.es.i9datasourcing.processor.SingleI9FormHistoryProcessor;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class AuditDetailI9FormHistoryProcessor implements SingleI9FormHistoryProcessor {

    private final ConvertedI9FormDiffProcessor convertedI9FormDiffProcessor;
    private final I9FormSingleChangeProcessorBuilder i9FormSingleChangeProcessorBuilder;

    @Override
    public void process(Map<String, String> convertedI9FormBefore, Map<String, String> convertedI9FormAfter,
        ChangeContext changeContext) {
        I9FormSingleChangeProcessor i9FormSingleChangeProcessor = i9FormSingleChangeProcessorBuilder
            .buildDepPubSubSenderHelper(convertedI9FormAfter, changeContext);

        convertedI9FormDiffProcessor.process(convertedI9FormBefore, convertedI9FormAfter, i9FormSingleChangeProcessor);
    }
}
