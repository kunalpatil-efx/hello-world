package com.efx.ews.es.i9integration.i9portaleventshandler.service.client;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.partner.AppointmentStatusByIdResponse;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.logger.MdcReactorLogger;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.webclient.HttpCallClient;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.I9PartnerApiProperties;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.net.URI;

import static java.lang.String.format;

@Component
@Slf4j
@RequiredArgsConstructor
public class PartnerApiCall {

    private final HttpCallClient httpCallClient;
    private final I9PartnerApiProperties i9PartnerApiProperties;

    public Mono<AppointmentStatusByIdResponse> getAppointmentStatus(String id) {
        URI uri = i9PartnerApiProperties.getAppointmentStatusUrlBuilder().buildAndExpand(id).toUri();
        return httpCallClient.doCall(webClient ->
            webClient
                .get()
                .uri(uri)
                .retrieve()
                .bodyToMono(AppointmentStatusByIdResponse.class)
                .doOnEach(MdcReactorLogger.logOnNext(appointment -> log.info("Retrieved appointmentStatus successfully, id: {}, {}", id, appointment)))
                .doOnEach(MdcReactorLogger.logOnError(ex -> log.error(format("Failed appointmentStatus, id: %s", id), ex)))
        );
    }
}
