package com.efx.ews.es.i9integration.i9portaleventshandler.model;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.document.CustomMultipartFile;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.document.DocumentApiRequest;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;

@Component
public class BytesToDocumentUpload { // TODO: Consider builder pattern for this, would flow much better
    private static final String FILE_NAME = "I9Report.pdf"; // TODO: Change file name based on context of document.
    private static final String RETENTION_POLICY = "90";
    private static final String SECURITY_MODEL = "basic";
    private static final String OWNER_ID = "I9-form-owner";
    private static final String OWNER_REFERENCE_VERSION = "v1";
    private static final int DATA_CLASSIFICATION = 3;

    public DocumentApiRequest map(String documentId, byte[] i9PdfReportInBytes) {
        CustomMultipartFile customMultipartFile = new CustomMultipartFile(i9PdfReportInBytes, FILE_NAME);
        return DocumentApiRequest.builder()
                .documentName(FILE_NAME)
                .documentType(MediaType.APPLICATION_PDF_VALUE)
                .securityModel(SECURITY_MODEL)
                .retentionPolicy(RETENTION_POLICY)
                .dataClassification(DATA_CLASSIFICATION)
                .ownerId(OWNER_ID)
                .ownerReferenceId(documentId)
                .ownerReferenceVersion(OWNER_REFERENCE_VERSION)
                .multipartFile(customMultipartFile)
                .build();
    }
}
