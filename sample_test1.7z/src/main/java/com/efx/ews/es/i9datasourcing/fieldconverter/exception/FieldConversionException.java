package com.efx.ews.es.i9datasourcing.fieldconverter.exception;

public class FieldConversionException extends RuntimeException {

    public FieldConversionException(String message, Throwable cause) {
        super(message, cause);
    }
}
