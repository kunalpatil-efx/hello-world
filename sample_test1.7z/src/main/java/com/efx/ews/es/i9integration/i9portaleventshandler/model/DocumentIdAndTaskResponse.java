package com.efx.ews.es.i9integration.i9portaleventshandler.model;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.task.TaskResponse;
import lombok.AllArgsConstructor;
import lombok.Data;
import reactor.core.publisher.Mono;

@Data
@AllArgsConstructor
public class DocumentIdAndTaskResponse {
    private String documentId;
    private TaskResponse task;
    public static Mono<DocumentIdAndTaskResponse> of(String documentId, TaskResponse taskResponse) {
        return Mono.just(new DocumentIdAndTaskResponse(documentId, taskResponse));
    }
}