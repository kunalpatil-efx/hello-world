package com.efx.ews.es.everifydatasourcing.fieldconverter;

import com.efx.ews.es.i9datasourcing.fieldconverter.FieldDataConverter;
import com.efx.ews.es.i9datasourcing.fieldconverter.FormConverter;
import com.efx.ews.es.i9datasourcing.model.ChangeContext;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class EVerifyConverterImpl implements FormConverter {

    private final EVerifyFieldConverterConfigProviderImpl eVerifyFieldConverterConfigProviderImpl;

    @Override
    public Map<String, String> convertForm(final Map<String, String> flattenedEVerify, ChangeContext changeContext) {
        final Map<String, String> convertedEVerify = new HashMap<>();
        final Map<String, FieldDataConverter> config = eVerifyFieldConverterConfigProviderImpl
            .provideConfig(changeContext);
        config.forEach(
            (reportFieldName, fieldDataConverter) -> {
                String convertedValue = fieldDataConverter.convert(flattenedEVerify);
                convertedEVerify.put(reportFieldName, convertedValue);
            }
        );

        return Collections.unmodifiableMap(convertedEVerify);
    }
}
