package com.efx.ews.es.i9integration.i9portaleventshandler.model.i9;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.io.Serializable;
import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class SectionTwo implements Serializable {
    private Employee employee;
    private EmployerRepresentative employerRepresentative;
    private ListA listA;
    private ListB listB;
    private ListC listC;
    private Organization organization;
    private List<AdditionalInformation> additionalInformation;
    private SignatureData signature;
    private String hireDate;
    private String offset;
}
