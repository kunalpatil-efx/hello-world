package com.efx.ews.es.i9datasourcing.fieldconverter;

import java.util.Map;
import java.util.Objects;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

@RequiredArgsConstructor
@Slf4j
public class NoChangeConverter implements FieldDataConverter {

    private final String flattenedI9FormName;

    @Override
    public String convert(Map<String, String> flattenedI9Form) {
        String flattenedI9FormValue = flattenedI9Form.get(flattenedI9FormName);
        if (flattenedI9FormValue == null) {
            log.debug("Missing field in the flattened I9Form: " + flattenedI9FormName);
        }

        return Objects.toString(flattenedI9FormValue, StringUtils.EMPTY);
    }
}
