package com.efx.ews.es.everifydatasourcing.fieldconverter;

import com.efx.ews.es.i9datasourcing.fieldconverter.BlankConverter;
import com.efx.ews.es.i9datasourcing.fieldconverter.DateTimeZoneToDateConverter;
import com.efx.ews.es.i9datasourcing.fieldconverter.FieldDataConverter;
import com.efx.ews.es.i9datasourcing.fieldconverter.I9FormFieldConverterConfigProvider;
import com.efx.ews.es.i9datasourcing.fieldconverter.MergingConverter;
import com.efx.ews.es.i9datasourcing.fieldconverter.NoChangeConverter;
import com.efx.ews.es.i9datasourcing.model.ChangeContext;
import com.google.common.collect.ImmutableMap;
import java.util.Map;
import org.springframework.stereotype.Component;

@Component
public class EVerifyFieldConverterConfigProviderImpl implements I9FormFieldConverterConfigProvider {

    private final Map<String, FieldDataConverter> convertingConfig = ImmutableMap.<String, FieldDataConverter>builder()
        .put("E_VERIFY_CASE_NUMBER", new NoChangeConverter("caseData.caseNumber"))
        .put("CURRENT_E_VERIFY_STATUS", new NoChangeConverter("caseData.caseStatus"))
        .put("INITIAL_SUBMISSION_DATE", BlankConverter.INSTANCE)
        .put("INITIAL_SUBMISSION_USER", BlankConverter.INSTANCE)
        .put("INITIAL_RESPONSE_DATE", BlankConverter.INSTANCE)
        .put("INITIAL_RESPONSE", BlankConverter.INSTANCE)
        .put("REFERRAL", BlankConverter.INSTANCE)
        .put("E_VERIFY_EXPECTED_RESPONSE_DATE_FOR_REFERRALS", BlankConverter.INSTANCE)
        .put("SSA_REFERRAL_DATE", new DateTimeZoneToDateConverter("referralInfo.fanEmployerSignature.date"))
        .put("SSA_REFERRAL_USER", new NoChangeConverter("referralInfo.fanEmployerSignature.name"))
        .put("DHS_REFERRAL_DATE", new DateTimeZoneToDateConverter("referralInfo.fanEmployerSignature.date"))
        .put("DHS_REFERRAL_USER", new NoChangeConverter("referralInfo.fanEmployerSignature.name"))
        .put("DHS_REFERRAL_2_DATE", BlankConverter.INSTANCE)
        .put("DHS_REFERRAL_2_USER", BlankConverter.INSTANCE)
        .put("RESUBMIT_VERIFICATION_DATE", BlankConverter.INSTANCE)
        .put("RESUBMIT_VERIFICATION_USER", BlankConverter.INSTANCE)
        .put("FINAL_RESPONSE_DATE", new DateTimeZoneToDateConverter("updateDateUTC"))
        .put("FINAL_RESPONSE", new NoChangeConverter("caseData.caseStatus"))
        .put("DHS_ADDITIONAL_VERIFICATION_REASON", BlankConverter.INSTANCE)
        .put("SSA_TNC_REASON", BlankConverter.INSTANCE)
        .put("OVERDUE_VERIFY_REASON", new MergingConverter("caseData.reasonForDelayCode",
            "caseData.reasonForDelayDescription"))
        .put("FAR_E_VERIFY_STATUS", BlankConverter.INSTANCE)
        .put("E_VERIFY_COMPANY_ID", BlankConverter.INSTANCE)
        .build();

    @Override
    public Map<String, FieldDataConverter> provideConfig(ChangeContext changeContext) {
        return convertingConfig;
    }
}
