package com.efx.ews.es.i9datasourcing.processor.auditdetail.i9formhistory;

import com.efx.ews.es.i9datasourcing.constant.DepEventName;
import com.efx.ews.es.i9datasourcing.dep.api.DepEventPayloadSender;
import com.efx.ews.es.i9datasourcing.dep.model.DepEventPayload;
import com.efx.ews.es.i9datasourcing.dep.model.DepEventPayloadField;
import com.efx.ews.es.i9datasourcing.model.ChangeContext;
import java.util.ArrayList;
import java.util.List;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
class I9FormSingleChangeProcessor {

    private final DepEventPayloadSender depPubSubSender;
    private final SectionDescriptionProvider sectionDescriptionProvider;

    private final List<DepEventPayloadField> commonReportFields;
    private final ChangeContext changeContext;

    void publishDepEventForFieldChange(FieldDiff fieldDiff) {
        DepEventPayload payload = createPayload(fieldDiff);
        publishPayload(payload);
    }

    private DepEventPayload createPayload(FieldDiff fieldDiff) {
        List<DepEventPayloadField> payloadFields = createPayloadFields(fieldDiff);
        return new DepEventPayload(payloadFields);
    }

    private List<DepEventPayloadField> createPayloadFields(FieldDiff fieldDiff) {
        List<DepEventPayloadField> payloadFields = new ArrayList<>();
        appendCommonPayloadFields(payloadFields);
        appendFieldChangeRelatedPayloadFields(payloadFields, fieldDiff);
        return payloadFields;
    }

    private void appendCommonPayloadFields(List<DepEventPayloadField> payloadFields) {
        payloadFields.addAll(commonReportFields);
    }

    private void appendFieldChangeRelatedPayloadFields(List<DepEventPayloadField> payloadFields, FieldDiff fieldDiff) {
        payloadFields.add(new DepEventPayloadField(ReportField.FIELD_UPDATED.targetLabel, fieldDiff.getFieldName()));
        payloadFields.add(new DepEventPayloadField(ReportField.BEFORE.targetLabel, fieldDiff.getValueBefore()));
        payloadFields.add(new DepEventPayloadField(ReportField.AFTER.targetLabel, fieldDiff.getValueAfter()));
        String description = createDescription(fieldDiff);
        payloadFields.add(new DepEventPayloadField(ReportField.DESCRIPTION.targetLabel, description));
    }

    private void publishPayload(DepEventPayload depEventPayload) {
        depPubSubSender.publish(depEventPayload, changeContext, DepEventName.I9_AUDIT_DETAIL);
    }

    private String createDescription(FieldDiff fieldDiff) {
        return sectionDescriptionProvider.createDescription(fieldDiff, changeContext);
    }
}
