package com.efx.ews.es.everifydatasourcing.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonNaming
@JsonIgnoreProperties(ignoreUnknown = true)
public class ReferralInfo {

    private SignatureImage fanEmployeeSignature;
    private SignatureImage fanEmployerSignature;
}
