package com.efx.ews.es.i9integration.i9portaleventshandler.model.employer.person;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class EmployeeForFactId {
    @JsonProperty(value = "employee_id")
    private String employeeId;

    @JsonProperty(value = "update_date")
    private String updateDate;

    @JsonProperty(value = "insert_date")
    private String insertDate;

    public String getLastOperationDate() {
        return (updateDate != null) ? updateDate : insertDate;
    }


}
