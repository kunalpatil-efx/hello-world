package com.efx.ews.es.i9datasourcing.provider;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.referenceapi.Country;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.ReferenceApiConnector;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.ReferenceApiProperties;
import com.google.common.cache.Cache;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;
import javax.annotation.PostConstruct;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.context.annotation.Profile;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
@Profile("!mocked")
@RequiredArgsConstructor
public class CachedCountryProvider {

    private static final String EVERY_5_MINUTES_CRON_PATTERN = "0 0/5 * * * ?";

    private final ReferenceApiConnector referenceApiConnector;
    private final Cache<String, Optional<Country>> countriesCache;
    private final ReferenceApiProperties properties;

    @PostConstruct
    public void init() {
        updateCache();
    }

    @Async
    @Scheduled(cron = EVERY_5_MINUTES_CRON_PATTERN)
    public void updateCache() {
        countriesCache.putAll(loadCountries());
    }

    private Map<String, Optional<Country>> loadCountries() {
        List<Country> list = referenceApiConnector.getCountries(properties.getI9Version()).block();
        if(list != null) {
            return list.stream()
                .collect(Collectors.toMap(Country::getName, Optional::of));
        } else {
            return Collections.emptyMap();
        }
    }

    @SneakyThrows
    Country getCountryByName(String countryName) {
        try {
            return countriesCache.get(countryName, () -> {
                Map<String, Optional<Country>> countriesMap = loadCountries();
                return countriesMap.getOrDefault(countryName, Optional.empty());
            }).orElseThrow(() -> {
                throw new IllegalArgumentException("There is no country with name: " + countryName);
            });
        } catch (ExecutionException e) {
            throw e.getCause();
        }
    }
}
