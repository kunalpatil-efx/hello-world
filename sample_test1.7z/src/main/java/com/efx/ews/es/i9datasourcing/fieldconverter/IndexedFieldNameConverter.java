package com.efx.ews.es.i9datasourcing.fieldconverter;

import java.util.Map;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class IndexedFieldNameConverter implements FieldDataConverter {

    private final String fieldNameWithoutIndex;
    private final String indexedFieldKey;
    private final int index;

    @Override
    public String convert(Map<String, String> flattenedI9Form) {
        String indexedField = fieldNameWithoutIndex.replace(indexedFieldKey, indexedFieldKey + "[" + index + "]");
        return flattenedI9Form.keySet().stream()
            .filter(indexedField::equals)
            .findFirst()
            .orElse(null);
    }
}
