package com.efx.ews.es.i9integration.i9portaleventshandler;

import com.efx.ews.es.i9integration.i9portaleventshandler.exception.OutOfSubcriberScopeException;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.I9AnywhereAdditionalInfo;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.I9AnywhereEventType;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.UserIdAndTaskResponse;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.I9FormResponse;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.Task;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.partner.I9AnywhereStatus;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.I9ApiCall;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.I9HeaderBuilder;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.PartnerApiCall;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.logger.MdcSetting;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.TaskApiRemoteCallService;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.TaskApiProperties;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.TaskApiProperties.TaskType;
import com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageConfirmation;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.function.Predicate;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gcp.pubsub.core.PubSubTemplate;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.dsl.RouterSpec;
import org.springframework.integration.router.MethodInvokingRouter;
import org.springframework.messaging.Message;
import reactor.core.publisher.Mono;
import reactor.util.context.Context;

import java.util.List;

import static com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageConfirmation.manualAckMessageChannel;

@Configuration
@SuppressWarnings("unused")
@Slf4j
public class I9AnywhereTasksSubscriberConfig {

    @Value("${subscription.i9AnywhereTasks.enabled:false}")
    private boolean isEnabled;

    private static final String TASK_STATUS_NEW = "NEW";

    private final I9ApiCall i9ApiCall;
    private final TaskApiRemoteCallService taskApiRemoteCallService;
    private final MessageConfirmation messageConfirmation;
    private final TaskApiProperties properties;
    private final SubscriberErrorHandling errorHandling;
    private final ObjectMapper converter = new ObjectMapper();
    private final PartnerApiCall partnerApiCall;

    public I9AnywhereTasksSubscriberConfig(I9ApiCall i9ApiCall,
                                           TaskApiRemoteCallService taskApiRemoteCallService,
                                           MessageConfirmation messageConfirmation,
                                           TaskApiProperties properties,
                                           PartnerApiCall partnerApiCall) {
        this.i9ApiCall = i9ApiCall;
        this.taskApiRemoteCallService = taskApiRemoteCallService;
        this.messageConfirmation = messageConfirmation;
        this.properties = properties;
        this.partnerApiCall = partnerApiCall;
        this.errorHandling = new SubscriberErrorHandling(log);
    }

    /* ===============================================================================================================
     * I9 Anywhere Message Routing
     */
    @Bean("I9AnywhereTasksSubscriberConfig")
    IntegrationFlow subscriberFlow(PubSubTemplate pubSubTemplate,
                                   @Value("${subscription.i9AnywhereTasks.name}") String subscription) {
        return IntegrationFlows
            .from(manualAckMessageChannel(pubSubTemplate, subscription))
            .route(Message.class, this::resolveContext, this::routeMessage)
            .get();
    }

    private I9AnywhereEventType resolveContext(Message<?> message) {
        String event = message.getHeaders().get("event", String.class);
        return isEnabled && event != null ? I9AnywhereEventType.convertFromName(event) : I9AnywhereEventType.OTHER;
    }

    private void routeMessage(RouterSpec<I9AnywhereEventType, MethodInvokingRouter> mapping) {
        mapping
            .subFlowMapping(I9AnywhereEventType.SCHEDULED, sf -> sf.handle(msg -> MdcSetting.wrapWithHeaders(msg, this::appointmentScheduled)))
            .subFlowMapping(I9AnywhereEventType.CANCELLED, sf -> sf.handle(msg -> MdcSetting.wrapWithHeaders(msg, this::appointmentCanceled)))
            .subFlowMapping(I9AnywhereEventType.RESCHEDULED, sf -> sf.handle(msg -> MdcSetting.wrapWithHeaders(msg, this::appointmentRescheduled)))
            .subFlowMapping(I9AnywhereEventType.DATA_RECEIVED, sf -> sf.handle(msg -> MdcSetting.wrapWithHeaders(msg, this::appointmentDataReceived)))
            .subFlowMapping(I9AnywhereEventType.OTHER, sf -> sf.handle(msg -> MdcSetting.wrapWithHeaders(msg, this::noActionMessage)));
    }

    /* ===============================================================================================================
     * I9 Anywhere Appointment Scheduled Subflow
     */
    private void appointmentScheduled(Message<?> message) {
        final TaskContext context = TaskContext.fromMessage(message);
        log.info("Received message with appointment scheduled for I9 id: {}", context.getDocumentId());
        setupErrorHandling(
            Mono.zip(i9ApiCall.getForm(context.getDocumentId()), i9ApiCall.getTasks(context.getDocumentId()), TaskHandlerObject::new)
                .flatMap(taskHandlerObject -> filterForStatus(I9AnywhereStatus.SCHEDULED, context, taskHandlerObject))
                .flatMap(taskHandlerObject -> deleteTask(properties.getSection2type(), context.getDocumentId(), taskHandlerObject))
                .flatMap(taskHandlerObject -> createTask(properties.getSection2Anywhere(), context.getDocumentId(), taskHandlerObject)),
            message,
            context
        ).subscriberContext(Context.of(I9HeaderBuilder.build(message))).block();
    }

    /* ===============================================================================================================
     * I9 Anywhere Appointment Cancellation Subflow
     */
    private void appointmentCanceled(Message<?> message) {
        final TaskContext context = TaskContext.fromMessage(message);
        if (!I9AnywhereAdditionalInfo.PACKET_CANCELED.equalsIgnoreCase(context.additionalInformation)) {
            log.info("Received message with appointment canceled for I9 id: {}", context.getDocumentId());
            noActionMessage(message);
            return;
        }
        log.info("Received message with appointment canceled due to Packet cancellation for I9 id: {}", context.getDocumentId());
        setupErrorHandling(
            Mono.zip(i9ApiCall.getForm(context.getDocumentId()), i9ApiCall.getTasks(context.getDocumentId()), TaskHandlerObject::new)
                .flatMap(taskHandlerObject -> filterForStatus(I9AnywhereStatus.CANCELLED, context, taskHandlerObject))
                .flatMap(taskHandlerObject -> deleteAllPendingTasks(context.getDocumentId(), taskHandlerObject)),
            message,
            context
        ).subscriberContext(Context.of(I9HeaderBuilder.build(message))).block();
    }

    /* ===============================================================================================================
     * I9 Anywhere Appointment Rescheduled Subflow
     */
    private void appointmentRescheduled(Message<?> message) {
        final TaskContext context = TaskContext.fromMessage(message);
        log.info("Received message with appointment rescheduled for I9 id: {}", context.getDocumentId());
        setupErrorHandling(
            Mono.zip(i9ApiCall.getForm(context.getDocumentId()), i9ApiCall.getTasks(context.getDocumentId()), TaskHandlerObject::new)
                .flatMap(taskHandlerObject -> filterForStatus(I9AnywhereStatus.SCHEDULED, context, taskHandlerObject))
                .flatMap(taskHandlerObject -> deleteTask(properties.getSection2type(), context.getDocumentId(), taskHandlerObject))
                .flatMap(taskHandlerObject -> createTask(properties.getSection2Anywhere(), context.getDocumentId(), taskHandlerObject)),
            message,
            context
        ).subscriberContext(Context.of(I9HeaderBuilder.build(message))).block();
    }

    /* ===============================================================================================================
     * I9 Anywhere Appointment DataReceived Subflow
     */
    private void appointmentDataReceived(Message<?> message) {
        final TaskContext context = TaskContext.fromMessage(message);
        log.info("Received message with appointment completion for I9 id: {}", context.getDocumentId());
        setupErrorHandling(
            Mono.zip(i9ApiCall.getForm(context.getDocumentId()), i9ApiCall.getTasks(context.getDocumentId()), TaskHandlerObject::new)
                .flatMap(taskHandlerObject -> filterForStatus(I9AnywhereStatus.DATARECEIVED, context, taskHandlerObject))
                .flatMap(taskHandlerObject -> completeTask(properties.getSection2Anywhere().getCode(), context.getDocumentId(), taskHandlerObject)),
            message,
            context
        ).subscriberContext(Context.of(I9HeaderBuilder.build(message))).block();
    }

    /* ===============================================================================================================
     * I9 Anywhere Other Status - No Action
     */
    private void noActionMessage(Message<?> message) {
        final TaskContext taskContext = TaskContext.fromMessage(message);
        log.info("No action required document for I9 id: {}", taskContext.getDocumentId());
        messageConfirmation.acknowledge(message);
    }

    /* ===============================================================================================================
     * Task Management Methods
     */
    private Mono<TaskHandlerObject> createTask(TaskType taskType, String documentId, TaskHandlerObject i9form) {
        if (i9form.hasAnyActive(taskType.getCode())) {
            log.info("Skipping createTask for {}", documentId);
            return Mono.just(i9form);
        }
        return taskApiRemoteCallService.createTask(taskType, documentId, i9form.getI9form())
            .doOnSuccess(ignore -> log.info("Created task for I9 id: {}", documentId))
            .flatMap(task -> Mono.just(i9form.addTask(task)));
    }

    private Mono<TaskHandlerObject> deleteAllPendingTasks(String documentId, TaskHandlerObject i9form) {
        return Mono.just(i9form)
            .flatMap(form -> deleteTask(properties.getSection2type(), documentId, form))
            .flatMap(form -> deleteTask(properties.getSection2Anywhere(), documentId, form));
    }

    private Mono<TaskHandlerObject> deleteTask(TaskType taskType, String documentId, TaskHandlerObject i9form) {
        return Mono.just(i9form.getTasks())
            .doOnSuccess(tasks -> log.info("Retrieved tasks size {} i9 document with id {}", tasks.size(), documentId))
            .flatMap(tasks -> filterForTaskType(taskType.getCode(), tasks))
            .flatMap(task -> taskApiRemoteCallService.deleteTask(documentId, task))
            .doOnSuccess(ignore -> log.info("Deleted tasks for i9 with id {}", documentId))
            .flatMap(task -> Mono.just(i9form.removeTask(task)))
            .onErrorResume(IllegalArgumentException.class, e -> Mono.just(i9form));
    }

    private Mono<TaskHandlerObject> completeTask(String code, String documentId, TaskHandlerObject i9form) {
        return Mono.just(i9form.getTasks())
            .doOnSuccess(tasks -> log.info("Retrieved tasks size {} i9 document with id {}", tasks.size(), documentId))
            .flatMap(tasks -> filterForTaskType(code, tasks))
            .flatMap(task -> i9ApiCall.getAudit(documentId, i9form.getI9form().getRecordVersion())
                .flatMap(a -> Mono.just(new UserIdAndTaskResponse(a.getSourceKey(), task))))
            .doOnSuccess(ignore -> log.info("Retrieved Audit Entry for i9 with id {}", documentId))
            .flatMap(response -> taskApiRemoteCallService.completeTask(documentId, response.getTask(), response.getUserId()))
            .doOnSuccess(ignore -> log.info("Completed tasks for i9 with id {}", documentId))
            .flatMap(ignore -> Mono.just(i9form))
            .onErrorResume(OutOfSubcriberScopeException.class, e -> {
                log.warn("Ignoring Task completion for I9 id: {}", documentId);
                return Mono.just(i9form);
            });
    }

    /* ===============================================================================================================
     * Utility Methods
     */
    private Mono<Task> filterForTaskType(String taskType, List<Task> tasksList) {
        Predicate<Task> typeFilter = task -> taskType.equals(task.getTaskType());
        return tasksList.stream()
            .filter(typeFilter)
            .filter(task -> TASK_STATUS_NEW.equals(task.getTaskStatus()))
            .findFirst()
            .map(Mono::just)
            .orElse(Mono.error(new IllegalArgumentException("Unable to find task to close")));
    }

    private Mono<TaskHandlerObject> filterForStatus(I9AnywhereStatus status, TaskContext context, TaskHandlerObject i9form) {
        return partnerApiCall.getAppointmentStatus(context.appointmentId)
            .flatMap(response -> status == response.getLatestStatus()
                ? Mono.just(i9form)
                : Mono.error(new IllegalArgumentException("Appointment no longer in expected status"))
            );
    }

    private <T> Mono<T> setupErrorHandling(Mono<T> publisher, Message<?> message, TaskContext context) {
        return publisher.doOnSuccess(ignore -> messageConfirmation.acknowledge(message))
            .onErrorResume(errorHandling::processingCompleted, t -> {
                messageConfirmation.acknowledge(message);
                errorHandling.logClientErrorException(context.getAppointmentId(), t);
                return Mono.empty();
            })
            .onErrorResume(errorHandling::processingFailed, t -> {
                messageConfirmation.nAcknowledge(message);
                log.error("error in processing for appointmentId {}", context.getAppointmentId(), t);
                return Mono.empty();
            });
    }

    /* ===============================================================================================================
     * Nested Class Definitions
     */
    private static class TaskHandlerObject {
        private final I9FormResponse i9form;
        private final List<Task> tasks;

        TaskHandlerObject(I9FormResponse i9form, List<Task> tasks) {
            this.i9form = i9form;
            this.tasks = tasks;
        }

        boolean hasAnyActive(String type) {
            return tasks.stream()
                .filter(task -> type.equals(task.getTaskType()))
                .anyMatch(task -> TASK_STATUS_NEW.equals(task.getTaskStatus()));
        }

        I9FormResponse getI9form() {
            return i9form;
        }

        TaskHandlerObject addTask(Task task) {
            tasks.add(task);
            return this;
        }

        TaskHandlerObject removeTask(Task taskToRemove) {
            tasks.removeIf(task -> task.getTaskId().equals(taskToRemove.getTaskId()));
            return this;
        }

        List<Task> getTasks() {
            return tasks;
        }
    }

    @Getter
    private static class TaskContext {
        private final String appointmentId;
        private final String documentId;
        private final String event;
        private final String additionalInformation;
        private final String requestDateTime;

        private TaskContext(String appointmentId,
                            String documentId,
                            String event,
                            String additionalInformation,
                            String requestDateTime) {
            this.appointmentId = appointmentId;
            this.documentId = documentId;
            this.event = event;
            this.additionalInformation = additionalInformation;
            this.requestDateTime = requestDateTime;
        }

        public static TaskContext fromMessage(Message<?> message) {
            String appointmentId = getFromHeaders(message, "appointmentId");
            String documentId = getFromHeaders(message, "i9Id");
            String event = getFromHeaders(message, "event");
            String additionalInformation = getFromHeaders(message, "additionalInformation");
            String requestDateTime = getFromHeaders(message, "requestDateTime");
            return new TaskContext(appointmentId, documentId, event, additionalInformation, requestDateTime);
        }

        private static String getFromHeaders(Message<?> message, String key) {
            return message.getHeaders().get(key, String.class);
        }
    }
}
