package com.efx.ews.es.i9integration.i9portaleventshandler.service.configuration;

import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.FirestoreProperties;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.FirestoreOptions;
import java.io.IOException;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

@Component
public class FirestoreConfig {
    @Bean
    Firestore firestore(FirestoreProperties firestoreProperties) throws IOException {
        FirestoreOptions firestoreOptions =
                FirestoreOptions.newBuilder()
                        .setCredentials(GoogleCredentials.getApplicationDefault())
                        .setProjectId(firestoreProperties.getProjectId())
                        .build();
        return firestoreOptions.getService();
    }
}
