package com.efx.ews.es.i9datasourcing.fieldconverter;

import java.util.Map;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor(access = AccessLevel.PACKAGE)
class ESignaturePreparerConverter implements FieldDataConverter {

    private final String flattenedI9FormFieldNameToCheck;
    private final int preparerIndex;

    @Override
    public String convert(Map<String, String> flattenedI9Form) {
        String indexedFieldName = new PreparerConverter(flattenedI9FormFieldNameToCheck, preparerIndex)
            .getIndexedFieldName(flattenedI9Form);
        return new ESignatureConverter(indexedFieldName).convert(flattenedI9Form);
    }
}




