package com.efx.ews.es.i9datasourcing.processor;

import com.efx.ews.es.i9datasourcing.model.ChangeContext;
import java.util.Map;

public interface SingleI9FormHistoryProcessor {

    void process(Map<String, String> convertedI9FormBefore, Map<String, String> convertedI9FormAfter,
        ChangeContext changeContext);
}
