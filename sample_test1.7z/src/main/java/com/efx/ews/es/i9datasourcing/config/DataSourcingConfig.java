package com.efx.ews.es.i9datasourcing.config;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.referenceapi.Country;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import java.util.Optional;
import java.util.concurrent.TimeUnit;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;

@Configuration
@EnableScheduling
public class DataSourcingConfig {

    private static final int EXPIRATION_TIME = 10;

    @Bean
    public Cache<String, Optional<Country>> getCountryCache() {
        return CacheBuilder
            .newBuilder()
            .expireAfterWrite(EXPIRATION_TIME, TimeUnit.MINUTES)
            .build();
    }
}
