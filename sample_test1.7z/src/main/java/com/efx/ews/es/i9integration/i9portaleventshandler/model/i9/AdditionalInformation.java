package com.efx.ews.es.i9integration.i9portaleventshandler.model.i9;

import lombok.Data;

@Data
public class AdditionalInformation {
    private String additionalInformationKey;
    private String additionalInformationValue;
}
