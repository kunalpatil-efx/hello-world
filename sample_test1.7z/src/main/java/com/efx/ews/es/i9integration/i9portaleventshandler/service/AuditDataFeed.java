package com.efx.ews.es.i9integration.i9portaleventshandler.service;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.audit.AuditMessage;
import reactor.core.publisher.Mono;

import java.util.List;

public interface AuditDataFeed {

    Mono<List<AuditMessage>> fetchAuditData(String packetId);
}
