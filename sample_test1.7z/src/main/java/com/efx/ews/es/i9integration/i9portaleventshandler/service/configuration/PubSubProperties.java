package com.efx.ews.es.i9integration.i9portaleventshandler.service.configuration;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "pubsub")
@Data
public class PubSubProperties {
    private String projectId;
    private boolean enabled;
    private String eventTopicId;
    private String specVersion;
    private String businessUnit;
    private String tribeName;
    private String domain;
    private String subDomain;
    private String appId;
    private String appName;
    private String clientTransactionId;
    private String eventType;
    private String eventSource;
    private String eventGenerator;
    private String eventTrigger;
    private String eventName;
    private String fileBodyInformation;
    private String productCode;
    private String lineOfService;
    private int quantity;
    private String productCodeDescription;
    private String metadataSchemaVersion;
    private String metadataSchemaPath;
    private boolean sectionalPdfGenerationEnabled;
    private DataPurgeProperties dataPurge;
}
