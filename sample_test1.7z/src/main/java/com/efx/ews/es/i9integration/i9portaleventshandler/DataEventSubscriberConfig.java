package com.efx.ews.es.i9integration.i9portaleventshandler;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.event.I9EventPayload;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.I9HeaderBuilder;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.logger.MdcSetting;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation.AuditPubSubPublisherService;
import com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageConfirmation;
import com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageReader;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gcp.pubsub.core.PubSubTemplate;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.dsl.RouterSpec;
import org.springframework.integration.router.MethodInvokingRouter;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageHeaders;
import reactor.core.publisher.Mono;
import reactor.util.context.Context;

import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import static com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageConfirmation.manualAckMessageChannel;

@Configuration
@Slf4j
public class DataEventSubscriberConfig {

    static final String SYSTEM_HEADER_NAME = "system";
    static final String SYSTEM_HEADER_VALUE = "I9";

    private final MessageConfirmation messageConfirmation;
    private final AuditPubSubPublisherService publisherService;
    private final SubscriberErrorHandling errorHandling;
    private final ObjectMapper converter = new ObjectMapper();
    static final Set<String> REQUIRED_HEADERS = Set.of(
            "documentId",
            "sourceId",
            "sourceRefId",
            "status",
            "recordVersion"
    );

    public DataEventSubscriberConfig(
        MessageConfirmation messageConfirmation,
        AuditPubSubPublisherService publisherService) {
        this.messageConfirmation = messageConfirmation;
        this.publisherService = publisherService;
        this.errorHandling = new SubscriberErrorHandling(log);
    }

    @Bean("DataEventSubscriberConfig")
    IntegrationFlow subscriberFlow(PubSubTemplate pubSubTemplate,
        @Value("${subscription.repacker}") String subscription) {
        return IntegrationFlows
            .from(manualAckMessageChannel(pubSubTemplate, subscription))
                .route(Message.class, this::hasAuditPart, this::routeMessage)
                .get();
    }

    private void routeMessage(RouterSpec<Boolean, MethodInvokingRouter> mapping) {
        mapping.subFlowMapping(Boolean.TRUE, sf -> sf.handle(msg -> MdcSetting.wrapWithHeaders(msg, this::handleMessage)))
                .subFlowMapping(Boolean.FALSE, sf -> sf.handle(msg -> MdcSetting.wrapWithHeaders(msg, this::handleNoAudit)));
    }

    private boolean hasAuditPart(Message<?> message) {
        I9EventPayload payload = MessageReader.readPayload(message, I9EventPayload.class).block();
        if (payload.getAudit() == null) {
            return false;
        }
        return true;
    }

    private void handleNoAudit(Message<?> message) {
        log.warn("Received a message without audit for document {}", message.getHeaders().get("documentId", String.class));
        messageConfirmation.acknowledge(message);
    }

    void handleMessage(Message<?> message) {
        log.info("Handling audit message for document {} and status {}",
                message.getHeaders().get("documentId", String.class),
                message.getHeaders().get("status", String.class));
        log.debug(String.valueOf(message));
        MessageReader.readPayload(message, I9EventPayload.class)
            .flatMap(i9e -> publisherService.sendAuditMessage(
                    prepareHeaders(message.getHeaders()),
                    i9e))
            .doOnSuccess(ignore -> {
                log.info("Message successfully sent to Audit topic for documentId {}",
                        message.getHeaders().get("documentId", String.class));
                messageConfirmation.acknowledge(message);
            })
            .onErrorResume(errorHandling::processingCompleted, t -> {
                log.error("Unable to process the message", t);
                messageConfirmation.acknowledge(message);
                return Mono.empty();
            })
            .onErrorResume(errorHandling::processingFailed, t -> {
                log.error("Processing failed. Will re-try", t);
                messageConfirmation.nAcknowledge(message);
                return Mono.empty();
            })
        .subscriberContext(Context.of(I9HeaderBuilder.build(message)))
        .block();
    }

    Map<String, String> prepareHeaders(MessageHeaders messageHeaders) {
        Map<String, String> headers = filerInputHeaders(messageHeaders);
        appendSystemHeader(headers);
        return headers;
    }

    private Map<String, String> filerInputHeaders(MessageHeaders messageHeaders) {
        return messageHeaders.entrySet().stream()
            .filter(entry -> REQUIRED_HEADERS.contains(entry.getKey()))
            .collect(Collectors.toMap(
                entry -> entry.getKey(),
                entry -> String.valueOf(entry.getValue())));
    }

    private void appendSystemHeader(Map<String, String> headers) {
        headers.put(SYSTEM_HEADER_NAME, SYSTEM_HEADER_VALUE) ;
    }


}
