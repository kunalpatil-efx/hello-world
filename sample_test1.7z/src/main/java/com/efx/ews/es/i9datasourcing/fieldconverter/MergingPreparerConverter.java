package com.efx.ews.es.i9datasourcing.fieldconverter;

import static org.apache.commons.collections.CollectionUtils.isNotEmpty;

import com.efx.ews.es.i9datasourcing.fieldconverter.Utils.Constants;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor(access = AccessLevel.PACKAGE)
class MergingPreparerConverter implements FieldDataConverter {

    private final List<String> fieldNamesToMerge;
    private final int preparerIndex;

    @Override
    public String convert(Map<String, String> flattenedI9Form) {

        List<String> fieldsToMerge = new ArrayList<>();
        for (String fieldToMerge : fieldNamesToMerge) {
            String flattenedI9FormFieldNameWithCorrectIndex = new PreparerConverter(fieldToMerge,
                preparerIndex).getIndexedFieldName(flattenedI9Form);
            if (flattenedI9FormFieldNameWithCorrectIndex != null) {
                fieldsToMerge.add(flattenedI9FormFieldNameWithCorrectIndex);
            }
        }

        return isNotEmpty(fieldsToMerge) ? new MergingConverter(fieldsToMerge.toArray(String[]::new))
            .convert(flattenedI9Form) : Constants.DEFAULT_EMPTY_VALUE;
    }
}




