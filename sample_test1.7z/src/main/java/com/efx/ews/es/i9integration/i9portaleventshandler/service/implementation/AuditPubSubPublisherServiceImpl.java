package com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.event.I9EventPayload;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.AuditPubSubProperties;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.Map;

@Service
public class AuditPubSubPublisherServiceImpl extends PubSubPublisherServiceImpl implements AuditPubSubPublisherService {

    public AuditPubSubPublisherServiceImpl(AuditPubSubProperties auditProperties) {
        super(auditProperties);
    }

    public Mono<String> sendAuditMessage(Map<String, String> headers, I9EventPayload payload) {
        // we are sending the event to Audit API - there be monsters. Make sure just the audit part goes there
        payload.setForm(null);
        payload.setDocument(null);
        return sendMessage(payload, headers);
    }
}
