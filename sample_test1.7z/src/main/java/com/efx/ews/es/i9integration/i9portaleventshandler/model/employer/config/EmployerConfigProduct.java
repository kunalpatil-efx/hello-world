package com.efx.ews.es.i9integration.i9portaleventshandler.model.employer.config;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class EmployerConfigProduct {
    @JsonProperty("everify")
    private EmployerConfigEverifyProduct everifyProduct;
}
