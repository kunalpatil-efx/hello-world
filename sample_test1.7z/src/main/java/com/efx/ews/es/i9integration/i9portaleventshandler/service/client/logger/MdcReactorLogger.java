package com.efx.ews.es.i9integration.i9portaleventshandler.service.client.logger;


import java.util.HashSet;
import java.util.Set;
import java.util.function.Supplier;

import com.efx.ews.es.i9integration.i9portaleventshandler.utils.ContextLogging;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.slf4j.MDC;
import org.slf4j.MDC.MDCCloseable;
import reactor.core.publisher.Mono;
import reactor.core.publisher.Signal;
import reactor.util.context.Context;

import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.stream.Collectors;

import static com.efx.ews.es.i9integration.i9portaleventshandler.service.client.I9HeaderBuilder.HEADERS_NAME;
import static java.util.Objects.nonNull;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class MdcReactorLogger {
    private final static Set<String> MDC_KEYS;

    static {
        MDC_KEYS = new HashSet<>(HEADERS_NAME);
        MDC_KEYS.add(ContextLogging.CONTEXT_PROPERTY);
    }

    /**
     * This should be called in #doOnEach method
     */
    public static <T> Consumer<Signal<T>> logOnNext(Consumer<T> logStatement) {
        return signal -> {
            if (!signal.isOnNext()) {
                return;
            }

            List<MDC.MDCCloseable> mdcCloseableList = null;
            try {
                mdcCloseableList = addHeadersToMdc(signal.getContext());
                logStatement.accept(signal.get());

            } finally {
                if (nonNull(mdcCloseableList)) {
                    mdcCloseableList.forEach(MDC.MDCCloseable::close);
                }
            }
        };
    }

    /**
     * You must call this method only inside #flatMap, otherwise it won't work.
     *
     * Do not call it inside doOnSuccess, doOnError, etc. The context is not available there
     */
    public static  Mono<Object> logInFlatMap(Runnable logStatement) {
        return Mono.subscriberContext().map(ctx -> {
            List<MDC.MDCCloseable> mdcCloseableList = null;
            try {
                mdcCloseableList = addHeadersToMdc(ctx);
                logStatement.run();
            } finally {
                if (nonNull(mdcCloseableList)) {
                    mdcCloseableList.forEach(MDC.MDCCloseable::close);
                }
            }
            return Mono.empty();
        });
    }

    /**
     * This should be called at #doOnEach method
     */
    public static Consumer<Signal<?>> logOnError(Consumer<Throwable> errorLogStatement) {
        return signal -> {
            if (!signal.isOnError()) {
                return;
            }

            List<MDC.MDCCloseable> mdcCloseableList = null;
            try {
                mdcCloseableList = addHeadersToMdc(signal.getContext());
                errorLogStatement.accept(signal.getThrowable());

            } finally {
                if (nonNull(mdcCloseableList)) {
                    mdcCloseableList.forEach(MDC.MDCCloseable::close);
                }
            }
        };
    }

    public static <T> Mono<T> execute( Supplier<T> supplier  ) {
        return Mono.subscriberContext().map(context -> {
            List<MDCCloseable> mdcCloseableList = null;
            try {
                mdcCloseableList = addHeadersToMdc(context);
                return supplier.get() ;
            } finally {
                if (nonNull(mdcCloseableList)) {
                    mdcCloseableList.forEach(MDCCloseable::close);
                }
            }
        });
    }


    public static List<MDC.MDCCloseable> addHeadersToMdc(Context context) {
        return MDC_KEYS.stream()
                .map(headerName -> Map.entry(headerName, context.getOrEmpty(headerName)))
                .filter(headerEntry -> headerEntry.getValue().isPresent())
                .map(headerEntry -> MDC.putCloseable(headerEntry.getKey(), (String) headerEntry.getValue().get()))
                .collect(Collectors.toList());
    }
}
