package com.efx.ews.es.i9datasourcing.fieldconverter;

import com.efx.ews.es.i9datasourcing.model.ChangeContext;
import java.util.Map;

public interface I9FormFieldConverterConfigProvider {

    /**
     * Provides config in the form of a map where:
     * <ul>
     *     <li>
     *         key - report field name
     *     </li>
     *     <li> value - interface containing information how to convert field named as the key above
     *     </li>
     * </ul>
     *
     * @return a map described above
     * @see FieldDataConverter
     */
    Map<String, FieldDataConverter> provideConfig(ChangeContext changeContext);
}
