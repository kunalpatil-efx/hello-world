package com.efx.ews.es.i9datasourcing.fieldconverter;

import com.efx.ews.es.i9datasourcing.fieldconverter.exception.FieldConversionException;
import com.efx.ews.es.i9datasourcing.model.ChangeContext;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class FormConverterImpl implements FormConverter {

    private final I9FormFieldConverterConfigProviderImpl i9FormFieldConverterConfigProvider;

    @Override
    public Map<String, String> convertForm(final Map<String, String> flattenedI9Form, ChangeContext changeContext) {
        final Map<String, String> convertedI9Form = new HashMap<>();
        final Map<String, FieldDataConverter> config = i9FormFieldConverterConfigProvider.provideConfig(changeContext);
        config.forEach(
            (reportFieldName, fieldDataConverter) -> {
                try {
                    String convertedValue = fieldDataConverter.convert(flattenedI9Form);
                    convertedI9Form.put(reportFieldName, convertedValue);
                } catch (Exception e) {
                    throw new FieldConversionException(
                        String.format("Conversion failed for field: %s", reportFieldName), e);
                }
            }
        );

        return Collections.unmodifiableMap(convertedI9Form);
    }
}
