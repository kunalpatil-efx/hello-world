package com.efx.ews.es.i9integration.i9portaleventshandler.service.properties;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;

@Component
@ConfigurationProperties(prefix = "document-api")
@Data
@EqualsAndHashCode(callSuper = true)
public class DocumentApiProperties extends AbstractRemoteServiceProperties {
    RemoteResource uploadDocuments;
    RemoteResource document;

    public UriComponentsBuilder postUploadDocument(){
        return UriComponentsBuilder.newInstance()
                .scheme(getScheme())
                .host(getHost())
                .port(getPort())
                .path(getPath())
                .pathSegment(getUploadDocuments().getPath());
    }
}