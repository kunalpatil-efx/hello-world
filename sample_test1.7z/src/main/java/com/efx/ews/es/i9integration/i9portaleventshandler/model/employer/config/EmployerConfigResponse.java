package com.efx.ews.es.i9integration.i9portaleventshandler.model.employer.config;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class EmployerConfigResponse {
    @JsonProperty("id")
    private String employerId;
    @JsonProperty("name")
    private String employerName;
    @JsonProperty("employer_code")
    private String employerCode;
    @JsonProperty("efx_id")
    private String employerEfxId;
    @JsonProperty("products")
    private EmployerConfigProduct products;
}
