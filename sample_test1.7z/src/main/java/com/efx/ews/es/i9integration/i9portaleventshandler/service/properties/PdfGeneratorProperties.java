package com.efx.ews.es.i9integration.i9portaleventshandler.service.properties;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;

@Component
@ConfigurationProperties(prefix = "pdf-gen")
@Data
@EqualsAndHashCode(callSuper = true)
public class PdfGeneratorProperties extends AbstractRemoteServiceProperties {

    RemoteResource document, merge;

    public UriComponentsBuilder postGenerate() {
        return UriComponentsBuilder.newInstance()
                .scheme(getScheme())
                .host(getHost())
                .port(getPort())
                .path(getPath())
                .pathSegment(getDocument().getPath());
    }

    public UriComponentsBuilder postMerge() {
        return UriComponentsBuilder.newInstance()
                .scheme(getScheme())
                .host(getHost())
                .port(getPort())
                .path(getPath())
                .pathSegment(getMerge().getPath());
    }
}
