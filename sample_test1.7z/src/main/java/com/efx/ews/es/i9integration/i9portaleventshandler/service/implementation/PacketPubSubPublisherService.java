package com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation;

import reactor.core.publisher.Mono;

public interface PacketPubSubPublisherService {
    Mono<String> restartPacketForSSN(String packetId, String taskId);
    Mono<String> closePacketForSSN(String packetId);
    Mono<String> closePacketForUnconfirmedData(String packetId);
}
