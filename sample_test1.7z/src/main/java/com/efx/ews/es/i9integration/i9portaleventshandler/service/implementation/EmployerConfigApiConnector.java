package com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.employer.config.EmployerConfigResponse;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.EmployerConfigApiProperties;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

import java.net.URI;
import java.net.URISyntaxException;

@Slf4j
@Component
public class EmployerConfigApiConnector {

    private final WebClientConnector<EmployerConfigApiProperties> connector;
    private final EmployerConfigApiProperties employerConfigApiProperties;

    public EmployerConfigApiConnector(EmployerConfigApiProperties employerConfigApiProperties){
        connector =  new WebClientConnector<>(employerConfigApiProperties);
        this.employerConfigApiProperties = employerConfigApiProperties;
    }

    public Mono<EmployerConfigResponse> getEmployerInfo(String employerId) {
        log.info("EmployerConfigApiConnector: Retrieving employer by employerID {}",employerId);
        URI uri = null;
        try {
            uri = connector.getUriBuilder(employerConfigApiProperties.getEmployer(),employerId).build();
        } catch (URISyntaxException e) {
            throw new IllegalArgumentException(e);
        }
        return connector.get(uri).flatMap(response ->
        {
            if (HttpStatus.OK == response.statusCode()) {
                log.debug("Deserializing response from employer-config");
                return response.bodyToMono(EmployerConfigResponse.class);
            }
            String errorMsg = String.format("Failed to connect to emnployer-config-api: %s",
                    response.statusCode());
            log.error(errorMsg);
            throw new IllegalArgumentException(errorMsg);
        });
    }
}
