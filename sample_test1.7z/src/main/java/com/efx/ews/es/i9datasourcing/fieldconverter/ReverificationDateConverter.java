package com.efx.ews.es.i9datasourcing.fieldconverter;

import com.efx.ews.es.i9datasourcing.fieldconverter.Utils.Constants;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;

class ReverificationDateConverter extends ReverificationFieldNameConverter {

    private final DateTimeFormatter sourceFormatter;

    ReverificationDateConverter(String fieldName, DateTimeFormatter sourceFormatter) {
        super(fieldName);
        this.sourceFormatter = sourceFormatter;
    }

    @Override
    public String convert(Map<String, String> flattenedI9Form) {
        String fieldName = super.convert(flattenedI9Form);
        return StringUtils.isNotBlank(fieldName)
            ? new DateConverter(fieldName, sourceFormatter).convert(flattenedI9Form) : Constants.DEFAULT_EMPTY_VALUE;
    }
}