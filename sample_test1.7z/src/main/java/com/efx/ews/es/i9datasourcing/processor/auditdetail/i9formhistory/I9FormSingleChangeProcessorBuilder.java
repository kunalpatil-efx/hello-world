package com.efx.ews.es.i9datasourcing.processor.auditdetail.i9formhistory;

import com.efx.ews.es.i9datasourcing.dep.api.DepEventPayloadSender;
import com.efx.ews.es.i9datasourcing.dep.model.DepEventPayloadField;
import com.efx.ews.es.i9datasourcing.formatter.TemporalFormatter;
import com.efx.ews.es.i9datasourcing.model.ChangeContext;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
class I9FormSingleChangeProcessorBuilder {

    private final DepEventPayloadSender depPubSubSender;
    private final SectionDescriptionProvider sectionDescriptionProvider;
    private final SignatureMethodProvider signatureMethodProvider;
    private final TemporalFormatter temporalFormatter;

    public I9FormSingleChangeProcessor buildDepPubSubSenderHelper(Map<String, String> convertedI9FormAfter,
        ChangeContext changeContext) {
        List<DepEventPayloadField> commonReportFields = createCommonReportFields(convertedI9FormAfter, changeContext);
        return new I9FormSingleChangeProcessor(depPubSubSender, sectionDescriptionProvider, commonReportFields,
            changeContext);
    }

    private List<DepEventPayloadField> createCommonReportFields(Map<String, String> convertedI9FormAfter,
        ChangeContext changeContext) {
        List<DepEventPayloadField> commonReportFields = new ArrayList<>();
        appendI9RelatedCommonReportFields(commonReportFields, convertedI9FormAfter, changeContext);
        appendContextRelatedCommonReportFields(commonReportFields, changeContext);
        return commonReportFields;
    }

    private void appendI9RelatedCommonReportFields(List<DepEventPayloadField> commonReportFields,
        Map<String, String> convertedI9FormAfter, ChangeContext changeContext) {
        commonReportFields.add(createDepEventPayloadField(convertedI9FormAfter, ReportField.SSN));
        commonReportFields.add(createDepEventPayloadField(convertedI9FormAfter, ReportField.LAST_NAME));
        commonReportFields.add(createDepEventPayloadField(convertedI9FormAfter, ReportField.FIRST_NAME));
        commonReportFields.add(createDepEventPayloadField(convertedI9FormAfter, ReportField.MIDDLE_INITIAL));
        commonReportFields.add(createDepEventPayloadField(convertedI9FormAfter, ReportField.DATE_OF_BIRTH));
        commonReportFields.add(createSignatureMethodField(convertedI9FormAfter, changeContext));
        commonReportFields.add(createDepEventPayloadField(convertedI9FormAfter, ReportField.LOCATION_CODE));
    }

    private DepEventPayloadField createDepEventPayloadField(Map<String, String> convertedI9FormAfter,
        ReportField reportField) {
        return new DepEventPayloadField(reportField.targetLabel, convertedI9FormAfter.get(reportField.sourceLabel));
    }

    private DepEventPayloadField createSignatureMethodField(Map<String, String> convertedI9FormAfter,
        ChangeContext changeContext) {
        return new DepEventPayloadField(ReportField.SIGNATURE_METHOD.targetLabel,
            signatureMethodProvider.getSignatureMethod(convertedI9FormAfter, changeContext));
    }

    private void appendContextRelatedCommonReportFields(List<DepEventPayloadField> commonReportFields,
        ChangeContext context) {
        String eventDateTime = temporalFormatter.formatDateTime(context.getSourceEventDateTime());
        commonReportFields.add(new DepEventPayloadField(ReportField.I9_ID.targetLabel, context.getI9FormId()));
        commonReportFields.add(new DepEventPayloadField(ReportField.IP_ADDRESS.targetLabel, context.getIpAddress()));
        commonReportFields
            .add(new DepEventPayloadField(ReportField.EVENT_NAME.targetLabel, context.getI9Event().getEventKey()));
        commonReportFields.add(new DepEventPayloadField(ReportField.EVENT_SOURCE.targetLabel, context.getSource()));
        commonReportFields.add(new DepEventPayloadField(ReportField.EVENT_CREATE_TS.targetLabel, eventDateTime));
        commonReportFields.add(new DepEventPayloadField(ReportField.CREATE_TS.targetLabel, eventDateTime));
        commonReportFields
            .add(new DepEventPayloadField(ReportField.I9_EMPLOYER_ID.targetLabel, context.getEmployerId()));
    }
}
