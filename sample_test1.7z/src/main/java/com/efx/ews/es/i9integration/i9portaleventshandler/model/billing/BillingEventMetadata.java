package com.efx.ews.es.i9integration.i9portaleventshandler.model.billing;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class BillingEventMetadata {
    private String schemaVersion;
    private String schemaPath;
}
