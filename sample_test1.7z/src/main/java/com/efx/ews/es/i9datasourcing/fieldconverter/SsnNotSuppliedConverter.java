package com.efx.ews.es.i9datasourcing.fieldconverter;

import java.util.Map;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
class SsnNotSuppliedConverter implements FieldDataConverter {

    static final SsnNotSuppliedConverter INSTANCE = new SsnNotSuppliedConverter();

    @Override
    public String convert(Map<String, String> flattenedI9Form) {
        String ssn = flattenedI9Form.get("formData.sectionOne.employeeInfo.socialSecurityNumber");
        return StringUtils.isBlank(ssn) ? "true" : "false";
    }
}