package com.efx.ews.es.i9datasourcing.fieldconverter;

import java.util.Map;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor(access = AccessLevel.PACKAGE)
class ESignatureReverificationDataConverter implements FieldDataConverter {

    private final String fieldName;

    @Override
    public String convert(Map<String, String> flattenedI9Form) {
        String fieldNameWithMaxDate = new ReverificationFieldNameConverter(fieldName).convert(flattenedI9Form);
        return new ESignatureConverter(fieldNameWithMaxDate).convert(flattenedI9Form);
    }
}




