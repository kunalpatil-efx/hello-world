package com.efx.ews.es.i9integration.i9portaleventshandler.model.employer.config;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class EmployerConfigEverifyProduct {
    @JsonProperty("enabled")
    private Boolean enabled;
    @JsonProperty("org_category")
    private String orgCategory;
}
