package com.efx.ews.es.i9integration.i9portaleventshandler;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.BytesToDocumentUpload;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.document.DocumentDownloadResponse;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.document.DocumentUploadResponse;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.I9CompletionStatus;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.I9FormResponse;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.UpdateMetadataRequest;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.pdfGenerator.I9FormResponseToPdfGenerate;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.pdfGenerator.I9History;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.pdfGenerator.PdfServiceMergeRequest;
import com.efx.ews.es.i9integration.i9portaleventshandler.model.pdfGenerator.PdfServiceRequest;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.ICEAuditProvider;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.DocumentApiCall;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.I9ApiCall;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.I9HeaderBuilder;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.PdfGeneratorCall;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.logger.MdcReactorLogger;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.logger.MdcSetting;

import java.util.List;

import com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageConfirmation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.NullArgumentException;
import org.assertj.core.util.Strings;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gcp.pubsub.core.PubSubTemplate;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.dsl.RouterSpec;
import org.springframework.integration.router.MethodInvokingRouter;
import org.springframework.messaging.Message;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import reactor.util.context.Context;

import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.stream.Collectors;

import static com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageConfirmation.manualAckMessageChannel;

@Configuration
@Slf4j
public class PdfGenerationSubscriber {

    private final MessageConfirmation messageConfirmation;
    private final boolean sectionalPdfGeneration;

    private final I9ApiCall i9ApiCall;
    private final I9FormResponseToPdfGenerate i9FormResponseToPdfGenerate;
    private final PdfGeneratorCall pdfGeneratorCall;
    private final DocumentApiCall documentApiCall;
    private final BytesToDocumentUpload bytesToDocumentUpload;
    private final SubscriberErrorHandling errorHandling;

    private final ICEAuditProvider auditProvider;

    public PdfGenerationSubscriber(MessageConfirmation messageConfirmation,
                                   I9ApiCall i9ApiCall,
                                   I9FormResponseToPdfGenerate i9FormResponseToPdfGenerate,
                                   PdfGeneratorCall pdfGeneratorCall,
                                   DocumentApiCall documentApiCall,
                                   BytesToDocumentUpload bytesToDocumentUpload,
                                   @Value("${pubsub.sectionalPdfGenerationEnabled}") boolean sectionalPdfGeneration,
                                   ICEAuditProvider auditProvider) {
        this.messageConfirmation = messageConfirmation;
        this.bytesToDocumentUpload = bytesToDocumentUpload;
        this.i9ApiCall = i9ApiCall;
        this.i9FormResponseToPdfGenerate = i9FormResponseToPdfGenerate;
        this.pdfGeneratorCall = pdfGeneratorCall;
        this.documentApiCall = documentApiCall;
        this.sectionalPdfGeneration = sectionalPdfGeneration;
        log.info("sectionalPdfGeneration: {}", sectionalPdfGeneration);
        errorHandling = new SubscriberErrorHandling(log);
        this.auditProvider = auditProvider;
    }

    @Bean("PdfGenerationSubscriber")
    IntegrationFlow subscriberFlow(
            PubSubTemplate pubSubTemplate,
            @Value("${subscription.pdfgen}") String subscription) {
        return IntegrationFlows
                .from(manualAckMessageChannel(pubSubTemplate, subscription))
                .route(Message.class, I9CompletionStatus::getStatus, this::routeMessage)
                .get();
    }

    private void routeMessage(RouterSpec<I9CompletionStatus, MethodInvokingRouter> mapping) {
        mapping.subFlowMapping(I9CompletionStatus.SECTION1_AMENDED, sf -> sf.handle(this::handleMessageWithMdcHeaders))
                .subFlowMapping(I9CompletionStatus.SECTION1_COMPLETE, sf -> sf.handle(this::handleMessageWithMdcHeaders))
                .subFlowMapping(I9CompletionStatus.SECTION2_AMENDED, sf -> sf.handle(this::handleMessageWithMdcHeaders))
                .subFlowMapping(I9CompletionStatus.SECTION2_COMPLETE, sf -> sf.handle(this::handleMessageWithMdcHeaders))
                .subFlowMapping(I9CompletionStatus.SECTION2_DOCUMENTS_UPLOADED,
                    sf -> sf.handle(this::handleMessageWithMdcHeaders))
                .subFlowMapping(I9CompletionStatus.SECTION3_AMENDED, sf -> sf.handle(this::handleMessageWithMdcHeaders))
                .subFlowMapping(I9CompletionStatus.SECTION3_COMPLETE, sf -> sf.handle(this::handleMessageWithMdcHeaders))
                .subFlowMapping(I9CompletionStatus.MIGRATED_I9, sf -> sf.handle(this::noPdfForThisMessage))
                .subFlowMapping(I9CompletionStatus.NEW, sf -> sf.handle(this::noPdfForThisMessage))
                .defaultSubFlowMapping(sf -> sf.handle(this::noPdfForThisMessage));
    }

    private void noPdfForThisMessage(Message<?> message) {
        MdcSetting.wrapWithHeaders(message, () -> {
            log.info("PdfGenerationSubscriber filtered out {}", message.getHeaders().get("documentId", String.class));
            messageConfirmation.acknowledge(message);
        });
    }

    public Mono<PdfServiceMergeRequest> preparePdfMergeRequest(String documentId,
                                                               I9FormResponse form,
                                                               FormFixStatus formFixStatus,
                                                               UpdateMetadataRequest metadataRequest) {
        if (Strings.isNullOrEmpty(documentId) || form == null) {
            throw new NoSuchElementException("Form is missing for i9 {} when generating PDF merge request.");
        }

        PdfServiceMergeRequest.PdfServiceMergeRequestBuilder requestBuilder = PdfServiceMergeRequest.builder();

        if (formFixStatus == FormFixStatus.NEWLY_MIGRATED_FORM) {
            UpdateMetadataRequest updateMetadataRequest = new UpdateMetadataRequest();
            updateMetadataRequest.setDocumentApiRevisionId(form.getDocumentApiDocumentId());
            log.info("Adding previously-generated PDF to revisions for form {}", documentId);
            return i9ApiCall.patchMetadata(documentId, updateMetadataRequest)
                    .flatMap(i9Form -> {
                        requestBuilder.document(form.getDocumentApiDocumentId());
                        requestBuilder.document(metadataRequest.getDocumentApiRevisionId());
                        requestBuilder.document(metadataRequest.getDocumentApiAuditId());
                        return Mono.just(requestBuilder.build());
                    });
        }

        requestBuilder.documents(form.getDocumentApiRevisionIds());
        requestBuilder.document(metadataRequest.getDocumentApiRevisionId());
        requestBuilder.document(metadataRequest.getDocumentApiAuditId());
        return Mono.just(requestBuilder.build());
    }

    public Mono<UpdateMetadataRequest> generateMergedPdf(String documentId,
                                                         I9History i9History,
                                                         Long recordVersion,
                                                         UpdateMetadataRequest metadataRequest) {
        if (sectionalPdfGeneration) {
            I9FormResponse form = i9History.getVersion(recordVersion).orElseThrow();
            FormFixStatus formFixStatus = FormFixStatus.checkForFormFixes(form);

            log.info("Sending aggregated PDF to Document API for i9 {}", documentId);
            return preparePdfMergeRequest(documentId, form, formFixStatus, metadataRequest)
                    .doOnSuccess(pdfServiceMergeRequest -> log.info("Preparing to merge PDFs for i9 {}: {}", documentId, pdfServiceMergeRequest))
                    .flatMap(pdfRequest -> pdfGeneratorCall.postMerge(pdfRequest)
                            .flatMap(response -> {
                                metadataRequest.setDocumentApiDocumentId(response.getDocumentId());
                                log.info("Aggregated PDF for {} generated with document Id {}",
                                        documentId, metadataRequest.getDocumentApiDocumentId());
                                return Mono.just(metadataRequest);
                            })
                    );
        }
        return Mono.just(metadataRequest);
    }

    private Mono<UpdateMetadataRequest> generateAndSendAudit(String documentId,
                                                             I9History i9History,
                                                             UpdateMetadataRequest metadataRequest) {
        if (sectionalPdfGeneration) {
            log.info("Sending audit PDF to Document API for i9 {}", documentId);
            return pdfGeneratorCall.postGenerate(i9FormResponseToPdfGenerate.mapAudits(i9History))
                    .map(pdfDocumentBytes -> bytesToDocumentUpload.map(documentId, pdfDocumentBytes))
                    .flatMap(documentApiCall::uploadDocument)
                    .flatMap(response -> {
                        metadataRequest.setDocumentApiAuditId(response.getDocumentId());
                        log.info("Audit PDF for {} generated with document Id {}",
                                documentId, metadataRequest.getDocumentApiAuditId());
                        return Mono.just(metadataRequest);
                    });
        }

        return Mono.just(metadataRequest);
    }

    public Mono<PdfServiceRequest> getPdfServiceRequest(I9History i9Forms, I9CompletionStatus status, Long recordVersion, String documentId) {
        i9Forms.getI9Forms().forEach((formResp) -> formResp.setDocumentId(documentId));
        if (sectionalPdfGeneration)  {
            return Mono.just(i9FormResponseToPdfGenerate.selectiveMap(i9Forms, status, recordVersion));
        }
        return Mono.just(i9FormResponseToPdfGenerate.map(i9Forms));
    }

    void handleMessageWithMdcHeaders(Message<?> message){
        MdcSetting.wrapWithHeaders(message, this::handleMessage);
    }

    void handleMessage(Message<?> message) {
        log.info("Received message: {}", message);
        I9CompletionStatus status = I9CompletionStatus.getStatus(message);
        String documentId = message.getHeaders().get("documentId", String.class);
        String versionString = message.getHeaders().get("recordVersion", String.class);
        Long recordVersion = Strings.isNullOrEmpty(versionString) ? null : Long.valueOf(versionString);
        String sourceRefId = message.getHeaders().get("sourceRefId", String.class);

        log.info("Processing message at PdfGenerationSubscriber documentId: {}, status: {}", documentId, status);

        i9ApiCall.getHistory(documentId)
                .flatMap( i9FormResponses-> enrichI9FormRevisionsWithSignatures(documentId, i9FormResponses))
                .zipWith(auditProvider.getIceEntries(documentId, sourceRefId), I9History::new)
                .flatMap(i9Forms -> MdcReactorLogger.execute(()-> verifyI9HistoryValidForMessage(i9Forms, recordVersion, status)))
                .flatMap(i9History -> {
                    if (FormFixStatus.checkForFormFixes(i9History.getVersion(recordVersion).orElseThrow()) == FormFixStatus.LEGACY_FORM) {
                        return Mono.just(i9History)
                                .doOnEach(MdcReactorLogger.logOnNext( i9Hist -> log.info("Processing i9History - LEGACY_FORM document id: {}", documentId)))
                                .map(i9FormResponseToPdfGenerate::map)
                                .flatMap(i9FormResponseToPdfGenerate::updateIssuingAuthorityToFullName)
                                .flatMap(pdfGeneratorCall::postGenerate)
                                .doOnEach(MdcReactorLogger.logOnNext(pdfDocumentBytes -> log.info("i9 document id {} generated pdf of length {} bytes", documentId, pdfDocumentBytes.length)))
                                .map(pdfDocumentBytes -> bytesToDocumentUpload.map(documentId, pdfDocumentBytes))
                                .flatMap(documentApiCall::uploadDocument)
                                .doOnEach(MdcReactorLogger.logOnNext(documentUploadResponse -> log.info("uploaded pdf for i9 document id {}, document api id {}", documentId, documentUploadResponse.getDocumentId())))
                                .map(documentUploadResponse -> {
                                    UpdateMetadataRequest updateMetadataRequest = new UpdateMetadataRequest();
                                    updateMetadataRequest.setDocumentApiDocumentId(documentUploadResponse.getDocumentId());
                                    return updateMetadataRequest;
                                });
                    } else if(I9CompletionStatus.SECTION2_DOCUMENTS_UPLOADED == status) {
                        return generateAndSendAudit(documentId, i9History, new UpdateMetadataRequest())
                            .flatMap(metadata -> generateMergedPdf(documentId, i9History, recordVersion, metadata));
                    } else {
                        return Mono.just(i9History)
                                .doOnEach(MdcReactorLogger.logOnNext( i9Hist -> log.info("Processing i9History document id: {}", documentId)))
                                .flatMap( i9Hist -> getPdfServiceRequest(i9Hist, status, recordVersion, documentId))
                                .flatMap(i9FormResponseToPdfGenerate::updateIssuingAuthorityToFullName)
                                .flatMap(pdfGeneratorCall::postGenerate)
                                .doOnEach(MdcReactorLogger.logOnNext(pdfDocumentBytes -> log.info("i9 document id {} generated pdf of length {} bytes", documentId, pdfDocumentBytes.length)))
                                .map(pdfDocumentBytes -> bytesToDocumentUpload.map(documentId, pdfDocumentBytes))
                                .flatMap(documentApiCall::uploadDocument)
                                .doOnEach(MdcReactorLogger.logOnNext(documentUploadResponse -> log.info("uploaded pdf for i9 document id {}, document api id {}", documentId, documentUploadResponse.getDocumentId())))
                                .map(this::createAndInitializeUpdateMetadata)
                                .flatMap(metadata -> generateAndSendAudit(documentId, i9History, metadata))
                                .flatMap(metadata -> generateMergedPdf(documentId, i9History, recordVersion, metadata));
                    }
                }).doOnEach(MdcReactorLogger.logOnNext(metadataRequest -> {
                    if (metadataRequest != null) {
                        log.info("Sending metadata update for form {} based on status {} with ids: (Revision) {}, (Audit) {}, (Aggregate) {}",
                                documentId, status,
                                metadataRequest.getDocumentApiRevisionId(),
                                metadataRequest.getDocumentApiAuditId(),
                                metadataRequest.getDocumentApiDocumentId());
                    }
                }))
                .flatMap(metadataRequest -> i9ApiCall.patchMetadata(documentId, metadataRequest))
                .doOnSuccess(ignore -> messageConfirmation.acknowledge(message))
                .onErrorResume(errorHandling::processingCompleted, t -> {
                    messageConfirmation.acknowledge(message);
                    errorHandling.logClientErrorException(documentId, t);
                    return Mono.empty();
                })
                .doOnEach(MdcReactorLogger.logOnError(t -> log.error("Error in processing message while generating PDF(s) for documentId {}", documentId, t)))
                .onErrorResume(errorHandling::processingFailed, t -> {
                    messageConfirmation.nAcknowledge(message);
                    return Mono.empty();
                })
                .subscriberContext(Context.of(I9HeaderBuilder.build(message)))
                .block();
    }

    private Mono<List<I9FormResponse>> enrichI9FormRevisionsWithSignatures(String documentId,
        List<I9FormResponse> i9forms) {
        return Flux.merge(
            i9forms.stream()
                .map(i9form -> enrichI9FormRevisionWithSignatures(documentId, i9form))
                .collect(Collectors.toList()))
            .collectList();
    }

    private Mono<I9FormResponse> enrichI9FormRevisionWithSignatures(String documentId, I9FormResponse i9form) {
        Mono<List<DocumentDownloadResponse>> signatures = Mono.just(i9form.getSignatureRefs())
            .doOnEach(MdcReactorLogger.logOnNext(signatureRefs -> log
                .info("Retrieving signatures for i9form documentId: {}, recordVersion: {}, signatureRefs: {}",
                    documentId, i9form.getRecordVersion(), signatureRefs)))
            .flatMap(signatureRefs -> documentApiCall.getDocuments(documentId, signatureRefs)
                .collectList());
        return i9form.assignSignatureData(documentId, signatures);
    }

    public I9History verifyI9HistoryValidForMessage(I9History history, Long recordVersion, I9CompletionStatus status) {
        if (sectionalPdfGeneration) {
            I9FormResponse form = history.getVersion(recordVersion).orElseThrow();
            switch (status) {
                case SECTION1_AMENDED:
                case SECTION1_COMPLETE:
                    if (form.getFormData().getSectionOne() == null) {
                        log.error("Received {} message status, but Section 1 is missing from I9 form {}", status, form.getDocumentId());
                        throw new NullArgumentException("SectionOne");
                    }
                    break;
                case SECTION2_AMENDED:
                case SECTION2_COMPLETE:
                case SECTION2_DOCUMENTS_UPLOADED:
                    if (form.getFormData().getSectionTwo() == null) {
                        log.error("Received {} message status, but Section 2 is missing from I9 form {}", status, form.getDocumentId());
                        throw new NullArgumentException("SectionTwo");
                    }
                    break;
                case SECTION3_AMENDED:
                case SECTION3_COMPLETE:
                    if (form.getFormData().getSectionThreeList() == null) {
                        log.error("Received {} message status, but Section 3 is missing from I9 form {}", status, form.getDocumentId());
                        throw new NullArgumentException("SectionThree");
                    }
                    break;
                default:
                    break;
            }
            log.info("Status {} valid for form {}.", status, form.getDocumentId());
        }
        return history;
    }

    private UpdateMetadataRequest createAndInitializeUpdateMetadata(DocumentUploadResponse response) {
        UpdateMetadataRequest updateMetadataRequest = new UpdateMetadataRequest();

        if (sectionalPdfGeneration) {
            updateMetadataRequest.setDocumentApiRevisionId(response.getDocumentId());
        }
        else {
            updateMetadataRequest.setDocumentApiDocumentId(response.getDocumentId());
        }

        return updateMetadataRequest;
    }

    // The point of this status is to note any special conditions a form would be in that require special action.
    enum FormFixStatus {
        NEWLY_MIGRATED_FORM, LEGACY_FORM, NONE;

        static FormFixStatus checkForFormFixes (I9FormResponse form) {
            if (form == null) {
                return NONE;
            }

            if ((form.getDocumentApiRevisionIds() == null || form.getDocumentApiRevisionIds().isEmpty())
                    && form.getDocumentApiDocumentId() != null) {
                if (Objects.equals(form.getSourceId().toLowerCase(), "i9a")) {
                    return NEWLY_MIGRATED_FORM;
                } else {
                    return LEGACY_FORM;
                }
            }
            return NONE;
        }
    }
}
