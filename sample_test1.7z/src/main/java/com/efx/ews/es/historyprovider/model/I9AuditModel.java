package com.efx.ews.es.historyprovider.model;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class I9AuditModel {

    private String entryId;
    private String date;
    private String sourceKey;
    private String source;
    private String sourceIp;
    private String eventKey;
    private String eventDescription;
    private Boolean dataUpdate;
    private Integer recordRevision;
}
