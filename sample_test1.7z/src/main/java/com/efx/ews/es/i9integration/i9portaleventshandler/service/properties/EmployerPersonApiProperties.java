package com.efx.ews.es.i9integration.i9portaleventshandler.service.properties;

import lombok.Data;
import lombok.EqualsAndHashCode;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;

@Component
@ConfigurationProperties(prefix = "employer-person-api")
@Data
@EqualsAndHashCode(callSuper = true)
public class EmployerPersonApiProperties extends AbstractRemoteServiceProperties {
    RemoteResource employees;
    RemoteResource facts;

    public UriComponentsBuilder postGenerate() {
        return UriComponentsBuilder.newInstance()
                .scheme(getScheme())
                .host(getHost())
                .port(getPort())
                .path(getPath())
                .pathSegment(getFacts().getPath());
    }

    public UriComponentsBuilder getByFactId() {
        return UriComponentsBuilder.newInstance()
                .scheme(getScheme())
                .host(getHost())
                .port(getPort())
                .path(getPath())
                .pathSegment(getEmployees().getPath())
                .pathSegment(getEmployees().getOperation())
                .pathSegment("{factId}");
    }

    public UriComponentsBuilder getByEmployeeId() {
        return UriComponentsBuilder.newInstance()
            .scheme(getScheme())
            .host(getHost())
            .port(getPort())
            .path(getPath())
            .pathSegment(getEmployees().getPath())
            .pathSegment("{employeeId}");
    }
}
