package com.efx.ews.es.i9integration.i9portaleventshandler.model.i9;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class Audit {
    private String entryId;
    private String date;
    private String sourceKey;
    private String source;
    private String sourceIp;
    private String eventKey;
    private Boolean dataUpdate;
    private Long recordRevision;
}
