package com.efx.ews.es.i9datasourcing;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.i9.I9Form;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;
import java.io.IOException;
import org.springframework.stereotype.Component;
import org.springframework.util.ResourceUtils;

@Component
public class I9FormHistoryProcessorQuickMockImpl implements I9FormHistoryProcessorQuickMock {

    public static final String PATH_I9_FORMS_FILE = "classpath:i9forms/";

    @Override
    public I9Form simulateReceivedSection1Creation() throws IOException {
        return getI9FormFromFile("section1-test.json");
    }

    @Override
    public I9Form simulateReceivedSection2Creation() throws IOException {
        return getI9FormFromFile("section2-test.json");
    }

    private I9Form getI9FormFromFile(String fileName) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        File file = ResourceUtils.getFile(PATH_I9_FORMS_FILE + fileName);
        return mapper.readValue(file, I9Form.class);
    }
}
