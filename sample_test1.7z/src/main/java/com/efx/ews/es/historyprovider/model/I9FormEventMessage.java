package com.efx.ews.es.historyprovider.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.NoArgsConstructor;

import static com.efx.ews.es.i9datasourcing.constant.I9Event.MIGRATED_I9;

@Data
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class I9FormEventMessage {

    @JsonIgnore
    private String messageId;

    private EventMessageDocument document;
    private EventMessageForm form;

    @JsonIgnore
    private String status;

    public boolean isMigratedForm() {
        return MIGRATED_I9.getEventKey().equalsIgnoreCase(status);
    }
}
