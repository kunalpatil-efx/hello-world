package com.efx.ews.es.i9integration.i9portaleventshandler.model;

public enum PacketSourceId {
    PACKET_UI("packet-ui"), I9ANYWHERE("packet-ui-I9ANYWHERE"), OTHER("other");

    private final String value;

    PacketSourceId(String value) {
        this.value = value;
    }

    public boolean equalsIgnoreCase(String value) {
        return this.value.equalsIgnoreCase(value);
    }
}
