package com.efx.ews.es.i9integration.i9portaleventshandler.model.ingest;

import com.fasterxml.jackson.databind.PropertyNamingStrategy;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@JsonNaming(PropertyNamingStrategy.SnakeCaseStrategy.class)
public class IngestEmployeeFact {
    private String factId;
    private String factTypeCode;
    private String factTruthDate;
    private String employerId;
    private String rootFactId;
    private String firstName;
    private String lastName;
    private String middleName;
    private String ssn;
    private String startDate;
    private String addressLine1;
    private String city;
    private String state;
    private String zipCode;
    private String email;
    private String phone;
    private boolean active;
    private String dateOfBirth;
}
