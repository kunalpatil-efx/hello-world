package com.efx.ews.es.i9datasourcing.fieldconverter;

import static org.apache.commons.lang3.StringUtils.isNoneBlank;

import com.efx.ews.es.dto.LocationDto;
import com.efx.ews.es.i9datasourcing.provider.LocationDataProvider;
import java.util.Map;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import reactor.core.publisher.Mono;

@RequiredArgsConstructor
public abstract class AbstractLocationFieldConverter implements FieldDataConverter {

    private final String employerIdName;
    private final String employerLocationIdName;

    private final LocationDataProvider locationDataProvider;

    @Override
    public String convert(Map<String, String> flattenedI9Form) {
        String employerIdValue = flattenedI9Form.get(employerIdName);
        String locationIdValue = flattenedI9Form.get(employerLocationIdName);
        if (isNoneBlank(employerIdValue, locationIdValue)) {
            UUID employerId = UUID.fromString(employerIdValue);
            UUID employerLocationId = UUID.fromString(locationIdValue);

            return getField(locationDataProvider.getLocation(employerId, employerLocationId));
        }
        return StringUtils.EMPTY;
    }

    protected abstract String getField(Mono<LocationDto> locationMono);
}
