package com.efx.ews.es.i9integration.i9portaleventshandler.model;

import lombok.Data;

@Data
public class PacketEventMetadata {
    private String taskId;
    private String url;
}
