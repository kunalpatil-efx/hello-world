package com.efx.ews.es.i9integration.i9portaleventshandler.service;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.employer.config.EmployerConfigResponse;
import reactor.core.publisher.Mono;

public interface EmployerConfigApiRemoteCallService {
    Mono<EmployerConfigResponse> getEmployerInfo(String employerId);
}
