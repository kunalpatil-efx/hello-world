package com.efx.ews.es.everifydatasourcing.model.pubsub;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@JsonIgnoreProperties(ignoreUnknown = true)
public class EventData {

    private String orderNumber;
    private String orderDetails;
    private String orderTransactionType;
    private String orderDateTime;
    private String orderStatus;
    private String verifierName;
    private String verifierId;
}
