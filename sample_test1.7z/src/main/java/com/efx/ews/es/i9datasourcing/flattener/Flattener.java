package com.efx.ews.es.i9datasourcing.flattener;

import java.util.Map;

public interface Flattener {

    Map<String, String> process(Object object);
}
