package com.efx.ews.es.i9integration.i9portaleventshandler.service.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;

@Component
@ConfigurationProperties(prefix = "task-api")
@Data
public class TaskApiProperties extends AbstractRemoteServiceProperties {

    private TaskResource family;
    private TaskResource group;
    private RemoteResource task;
    private TaskType section2type;
    private TaskType ssnApplied;
    private TaskType section2UploadLater;
    private TaskType receiptUpdateSectionTwo;
    private TaskType section2Anywhere;
    private TaskType schedulerDateUpdated;
    private TaskType section2CovidFollowUp;
    private TaskType section2CovidDocumentInspection;

    @Data
    public static class TaskResource extends RemoteResource {
        private String name;
    }

    @Data
    public static class TaskType extends TaskResource {
        private String code;
        private String processorUrlTemplate;
        private String effortCode;
        private String workerSecurityFunction;
        private Boolean enabled = Boolean.TRUE;
    }

    public UriComponentsBuilder postGenerate() {
        return UriComponentsBuilder.newInstance()
                .scheme(getScheme())
                .host(getHost())
                .port(getPort())
                .path(getPath())
                .pathSegment(getTask().getPath());
    }
}
