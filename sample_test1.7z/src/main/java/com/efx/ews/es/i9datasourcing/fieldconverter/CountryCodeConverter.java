package com.efx.ews.es.i9datasourcing.fieldconverter;

import static org.apache.commons.lang3.StringUtils.EMPTY;
import static org.apache.commons.lang3.StringUtils.isNotEmpty;

import com.efx.ews.es.i9datasourcing.provider.CountryCodeProvider;
import java.util.Map;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
public class CountryCodeConverter implements FieldDataConverter {

    private final CountryCodeProvider countryCodeProvider;
    private final String countryNameField;

    @Override
    public String convert(Map<String, String> flattenedI9Form) {
        String countryName = flattenedI9Form.get(countryNameField);
        return isNotEmpty(countryName) ? countryCodeProvider.getCountryCode(countryName) : EMPTY;
    }
}
