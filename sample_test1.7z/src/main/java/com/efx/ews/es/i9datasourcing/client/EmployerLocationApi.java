package com.efx.ews.es.i9datasourcing.client;

import com.efx.ews.es.dto.LocationDto;
import com.efx.ews.es.i9datasourcing.properties.EmployerLocationConfigApiProperties;
import java.net.URI;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Slf4j
@RequiredArgsConstructor
@Component
public class EmployerLocationApi {

    private final WebClient employerConfigWebClient;
    private final EmployerLocationConfigApiProperties employerLocationConfigApiProperties;

    public Mono<LocationDto> getLocationByIdInternal(UUID employerId, UUID locationId) {
        URI uri = employerLocationConfigApiProperties.getLocationUrlBuilder()
            .build(employerId, locationId);
        return employerConfigWebClient.get()
            .uri(uri)
            .retrieve()
            .bodyToMono(LocationDto.class);
    }
}
