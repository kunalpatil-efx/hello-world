package com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation;

import com.efx.ews.es.common.filter.CorrelationFilter;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.AbstractRemoteServiceProperties;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Stream;

import org.apache.http.NameValuePair;
import org.apache.http.client.utils.URIBuilder;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

public class WebClientConnector<P extends AbstractRemoteServiceProperties> {
    P properties;

    private final WebClient webClient;

    WebClientConnector(P props) {
        properties = props;
        webClient = WebClient.builder().build();
    }

    WebClientConnector(P props, int maxInMemoryBytes) {
        properties = props;
        webClient = WebClient.builder()
            .exchangeStrategies(ExchangeStrategies.builder()
                .codecs(c -> c
                    .defaultCodecs()
                    .maxInMemorySize(maxInMemoryBytes))
                .build())
            .build();
    }

    boolean isValidContext(String sourceId) {
        return Stream.of(properties.getValidSources()).anyMatch(vs -> vs.equals(sourceId));
    }

    URIBuilder getUriBuilder(AbstractRemoteServiceProperties.RemoteResource resource, String id) {
        String resourcePath = "";
        if (Optional.ofNullable(id).isPresent()) {
            resourcePath = resource.getPath()
                    + Optional.ofNullable(resource.getOperation()).map(op -> "/" + id + "/" + op).orElse("/" + id);
        } else {
            resourcePath = resource.getPath();
        }
        return new URIBuilder()
                .setScheme(properties.getScheme())
                .setHost(properties.getHost())
                .setPort(properties.getPort())
                .setPath(properties.getPath() + "/" + resourcePath);
    }

    <P> Mono<ClientResponse> postToApi(AbstractRemoteServiceProperties.RemoteResource resource,
                                       String id,
                                       P payload) {
        try {
            return webClient.post()
                    .uri(getUriBuilder(resource, id).build())
                    .header(CorrelationFilter.TRANSACTION_ID_HEADER_NAME, CorrelationFilter.getTransactionId().orElse(UUID.randomUUID().toString()))
                    .header(CorrelationFilter.SESSION_ID_HEADER_NAME, CorrelationFilter.getSessionId().orElse(UUID.randomUUID().toString()))
                    .bodyValue(payload)
                    .exchange();
        } catch (URISyntaxException e) {
            return Mono.error(e);
        }
    }

    Mono<ClientResponse> deleteToApi(AbstractRemoteServiceProperties.RemoteResource resource, String id) {
        try {
            return webClient.delete()
                    .uri(getUriBuilder(resource, id).build())
                    .header(CorrelationFilter.TRANSACTION_ID_HEADER_NAME, CorrelationFilter.getTransactionId().orElse(UUID.randomUUID().toString()))
                    .header(CorrelationFilter.SESSION_ID_HEADER_NAME, CorrelationFilter.getSessionId().orElse(UUID.randomUUID().toString()))
                    .exchange();
        } catch (URISyntaxException e) {
            return Mono.error(e);
        }
    }

    <P> Mono<ClientResponse> patchToApi(AbstractRemoteServiceProperties.RemoteResource resource,
                                        String id,
                                        P payload) {
        try {
            return webClient.patch()
                    .uri(getUriBuilder(resource, id).build())
                    .header(CorrelationFilter.TRANSACTION_ID_HEADER_NAME, CorrelationFilter.getTransactionId().orElse(UUID.randomUUID().toString()))
                    .header(CorrelationFilter.SESSION_ID_HEADER_NAME, CorrelationFilter.getSessionId().orElse(UUID.randomUUID().toString()))
                    .bodyValue(payload)
                    .exchange();
        } catch (URISyntaxException e) {
            return Mono.error(e);
        }
    }

    ClientResponse callGetURI(URI uri) {
        final Mono<ClientResponse> response = get(uri);
        return response
                .block();
    }

    Mono<ClientResponse> get(URI uri) {
        return webClient.get()
                    .uri(uri)
                    .header(CorrelationFilter.TRANSACTION_ID_HEADER_NAME, CorrelationFilter.getTransactionId().orElse(UUID.randomUUID().toString()))
                    .header(CorrelationFilter.SESSION_ID_HEADER_NAME, CorrelationFilter.getSessionId().orElse(UUID.randomUUID().toString()))
                    .exchange();
    }

    Mono<ClientResponse> getToApi(AbstractRemoteServiceProperties.RemoteResource resource, String id,
        List<NameValuePair> queryParams) {
        try {
            URIBuilder builder = getUriBuilder(resource, id);
            if(queryParams != null) {
                builder.addParameters(queryParams);
            }
            return webClient.get()
                    .uri(builder.build())
                    .header(CorrelationFilter.TRANSACTION_ID_HEADER_NAME, CorrelationFilter.getTransactionId().orElse(UUID.randomUUID().toString()))
                    .header(CorrelationFilter.SESSION_ID_HEADER_NAME, CorrelationFilter.getSessionId().orElse(UUID.randomUUID().toString()))
                    .exchange();
        } catch (URISyntaxException e) {
            return Mono.error(e);
        }
    }
}
