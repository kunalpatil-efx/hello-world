package com.efx.ews.es.i9integration.i9portaleventshandler.model;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.task.TaskResponse;
import lombok.AllArgsConstructor;
import lombok.Data;
import reactor.core.publisher.Mono;

@Data
@AllArgsConstructor
public class TaskAndPacketResponse {
    private PacketEvent packet;
    private TaskResponse task;
    public static Mono<TaskAndPacketResponse> of(PacketEvent packetEvent, TaskResponse taskResponse) {
        return Mono.just(new TaskAndPacketResponse(packetEvent, taskResponse));
    }
}
