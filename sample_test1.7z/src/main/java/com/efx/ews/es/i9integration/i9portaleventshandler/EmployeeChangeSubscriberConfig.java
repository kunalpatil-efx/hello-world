package com.efx.ews.es.i9integration.i9portaleventshandler;

import static com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageConfirmation.manualAckMessageChannel;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.EmployeeDataPurgeResponse;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.EmployerPersonApiCall;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.client.I9ApiCall;
import com.efx.ews.es.i9integration.i9portaleventshandler.utils.MessageConfirmation;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.IOException;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneOffset;
import java.util.Optional;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.cloud.gcp.pubsub.core.PubSubTemplate;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.messaging.Message;
import org.springframework.web.reactive.function.client.ClientResponse;
import reactor.core.publisher.Mono;

@Configuration
@Slf4j
public class EmployeeChangeSubscriberConfig {

    private final EmployerPersonApiCall employerPersonApiCall;
    private final I9ApiCall i9ApiCall;
    private final MessageConfirmation messageConfirmation;

    public EmployeeChangeSubscriberConfig(EmployerPersonApiCall employerPersonApiCall,
        MessageConfirmation messageConfirmation, I9ApiCall i9ApiCall) {
        this.employerPersonApiCall = employerPersonApiCall;
        this.messageConfirmation = messageConfirmation;
        this.i9ApiCall = i9ApiCall;
    }

    @Bean(name = "employeeChangeSubscriberBean")
    @ConditionalOnProperty(name = "purge.employeeChange", havingValue = "true")
    IntegrationFlow subscriberFlow(
        PubSubTemplate pubSubTemplate,
        @Value("${subscription.employeeUpdate}") String subscription) {

        return IntegrationFlows
            .from(manualAckMessageChannel(pubSubTemplate, subscription))
            .handle(this::handleMessage)
            .get();
    }

    void handleMessage(Message<?> message) {
        log.info("Employee Change Message received: {}", message);
        readPayload(message).ifPresentOrElse(body -> Mono.justOrEmpty(body.getEmployee_id())
                .switchIfEmpty(Mono.defer(() -> Mono.just(StringUtils.EMPTY)))
                .flatMap(employeeId -> getEmployeeDetails(employeeId))
                .map(employeeDetails -> createTerminationDetail(employeeDetails))
                .map(terminationDetails -> submitTerminationDetails(body.getEmployee_id(),
                    terminationDetails))
                .flatMap(response -> response.doOnSuccess(clientResponse -> clientResponse.bodyToMono(String.class))
                    .doOnError(error -> Mono.error(IllegalArgumentException::new)))
                .doOnSuccess(employeeId -> {
                    log.info("Termination Details submitted for employee id: {}", employeeId);
                    messageConfirmation.acknowledge(message);
                })
                .doOnError(error -> {
                    log.error(error.getMessage());
                    messageConfirmation.nAcknowledge(message);
                }).block(), () -> {
                throw new EmployeeChangeException("Message does not have correct values for Employee Change event");
            }
        );
    }

    private Mono<ClientResponse> submitTerminationDetails(String employeeId,
        TerminationDetailBody terminationDetailBody) {
        log.info("Calling Form I9 to submit termination details for employee : {}", employeeId);
        return i9ApiCall.submitTerminationDetails(employeeId, terminationDetailBody).switchIfEmpty(Mono.empty());
    }

    private Mono<EmployeeDataPurgeResponse> getEmployeeDetails(String employeeId) {
        if (StringUtils.isNotBlank(employeeId)) {
            log.info("Employee {} id is not null or empty. Now fetching Employee details", employeeId);
            return employerPersonApiCall.getEmployeeByEmployeeId(employeeId)
                .switchIfEmpty(Mono.empty());
        }
        log.error("Employee id: {}  is not in correct format to fetch employee details.", employeeId);
        throw new EmployeeChangeException("Employee id is not valid.");
    }

    private TerminationDetailBody createTerminationDetail(
        EmployeeDataPurgeResponse employeeDataPurgeResponse) {
        TerminationDetailBody terminationDetailBody = new TerminationDetailBody();
        terminationDetailBody.setSeparationDate(convertToUTC(employeeDataPurgeResponse.getSeparationDate()));
        terminationDetailBody
            .setWasPaid(BooleanUtils.toBooleanDefaultIfNull(employeeDataPurgeResponse.getPaid(), Boolean.FALSE));
        log.info("Termination details request is constructed. Now submitting termination details..");
        return terminationDetailBody;
    }

    private String convertToUTC(String separationDate) {
        log.info("converting separation date to UTC offset format");
        if (StringUtils.isNotBlank(separationDate)) {
            log.info("converting separation date to UTC offset format. Separation date is : {}", separationDate);
            return LocalDateTime.of(LocalDate.parse(separationDate), LocalTime.now()).atOffset(ZoneOffset.UTC)
                .toString();
        }
        log.info("separation date is null, blank or empty.");
        return StringUtils.EMPTY;
    }

    private Optional<EmployeeChangeMessageBody> readPayload(Message<?> message) {
        try {
            return Optional
                .of(new ObjectMapper().readValue((byte[]) message.getPayload(), EmployeeChangeMessageBody.class));
        } catch (IOException e) {
            log.error("Invalid massage payload. " + e.getMessage());
            messageConfirmation.acknowledge(message);
            return Optional.empty();
        }
    }

    @Data
    public static class EmployeeChangeMessageBody implements Serializable {

        private String event, employee_id, as_of;
    }

    @Data
    public static class TerminationDetailBody implements Serializable {

        private String separationDate;
        private Boolean wasPaid;
    }

    static class EmployeeChangeException extends RuntimeException {

        EmployeeChangeException(String message) {
            super(message);
        }
    }
}
