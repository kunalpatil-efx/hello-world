package com.efx.ews.es.i9integration.i9portaleventshandler.service.implementation;

import com.efx.ews.es.i9integration.i9portaleventshandler.model.pubsub.Event;
import com.efx.ews.es.i9integration.i9portaleventshandler.service.properties.FirestoreProperties;
import com.google.api.core.ApiFuture;
import com.google.api.core.ApiFutureCallback;
import com.google.api.core.ApiFutures;
import com.google.cloud.firestore.*;

import com.google.common.util.concurrent.MoreExecutors;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service
@Primary
@Slf4j
public class I9FormDaoImpl implements I9FormDao {
    private static final String ERROR_MSG = "Persistence error for document %s. See inner exception for details.";
    private Firestore firestore;
    private FirestoreProperties.Collections collections;

    public I9FormDaoImpl(Firestore firestore, FirestoreProperties firestoreProperties) {
        this.firestore = firestore;
        this.collections = firestoreProperties.getCollections();
    }

    @Override
    public Mono<String> updateEvent(String documentId, Event event) {
        final ApiFuture<WriteResult> set = firestore.collection(collections.getEvents()).document().set(event);
        return Mono.create(callback -> ApiFutures.addCallback(set, new ApiFutureCallback<>() {
            @Override
            public void onFailure(Throwable throwable) {
                callback.error(throwable);
            }

            @Override
            public void onSuccess(WriteResult writeResult) {
                callback.success(writeResult.getUpdateTime().toString());
            }
        }, MoreExecutors.directExecutor()));
    }
}
