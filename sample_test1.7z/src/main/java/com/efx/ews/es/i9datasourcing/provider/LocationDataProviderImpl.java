package com.efx.ews.es.i9datasourcing.provider;

import com.efx.ews.es.dto.LocationDto;
import com.efx.ews.es.i9datasourcing.client.EmployerLocationApi;
import java.util.UUID;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import reactor.core.publisher.Mono;

@Profile("!mocked")
@Component
@RequiredArgsConstructor
public class LocationDataProviderImpl implements LocationDataProvider {

    private final EmployerLocationApi employerLocationApi;

    @Override
    public Mono<LocationDto> getLocation(UUID employerId, UUID locationId) {
        return employerLocationApi.getLocationByIdInternal(employerId, locationId);
    }
}
