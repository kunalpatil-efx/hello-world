package com.efx.ews.es.i9integration.i9portaleventshandler.model.billing;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class BillingEventEmployer {
    private String id;
    private String name;
    private String efxId;
    private String relationship;
    private String type;
}
