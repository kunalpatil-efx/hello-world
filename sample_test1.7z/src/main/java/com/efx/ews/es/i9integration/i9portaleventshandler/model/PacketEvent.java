package com.efx.ews.es.i9integration.i9portaleventshandler.model;

import com.fasterxml.jackson.annotation.JsonEnumDefaultValue;
import lombok.Data;

@Data
public class PacketEvent {
    private String packetId;
    private EventType eventType;
    private Status status;
    private PacketEventMetadata metadata;

    public enum EventType {
        APPLIED_FOR_SSN,
        UNCONFIRMED_DATA,
        @JsonEnumDefaultValue
        UNKNOWN
    }
    public enum Status {ON, OFF}

    public static PacketEvent createRestartEvent(String packetId, String taskId, String url) {
        PacketEvent event = new PacketEvent();
        event.setStatus(Status.ON);
        event.setPacketId(packetId);
        event.setEventType(EventType.APPLIED_FOR_SSN);
        event.setMetadata(new PacketEventMetadata());
        event.getMetadata().setTaskId(taskId);
        event.getMetadata().setUrl(url);
        return event;
    }

    public static PacketEvent closePacketEventForSSN(String packetId) {
        PacketEvent event = new PacketEvent();
        event.setStatus(Status.OFF);
        event.setPacketId(packetId);
        event.setEventType(EventType.APPLIED_FOR_SSN);
        return event;
    }

    public static PacketEvent closePacketEventForUnconfirmedDate(String packetId) {
        PacketEvent event = new PacketEvent();
        event.setStatus(Status.OFF);
        event.setPacketId(packetId);
        event.setEventType(EventType.UNCONFIRMED_DATA);
        return event;
    }

}
